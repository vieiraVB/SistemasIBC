<?php
require_once '../includes/config.php';

header('Content-Type: application/json');

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado']);
    exit;
}

// Verificar se o ID foi fornecido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

$solicitacao_id = (int)$_GET['id'];

try {
    $pdo = getDBConnection();
    
    // Buscar dados da solicitação
    $stmt = $pdo->prepare("
        SELECT s.*, 
               u.nome as usuario_nome,
               admin.nome as aprovada_por_nome
        FROM solicitacoes s 
        JOIN usuarios u ON s.usuario_id = u.id 
        LEFT JOIN usuarios admin ON s.aprovada_por = admin.id
        WHERE s.id = ?
    ");
    $stmt->execute([$solicitacao_id]);
    $solicitacao = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$solicitacao) {
        echo json_encode(['success' => false, 'message' => 'Solicitação não encontrada']);
        exit;
    }
    
    // Se não for admin, verificar se é o próprio usuário
    if (!isAdmin() && $solicitacao['usuario_id'] != $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'message' => 'Acesso negado']);
        exit;
    }
    
    // Buscar materiais da solicitação na tabela 'solicitacoes_materiais'
        $stmt_materiais = $pdo->prepare("
            SELECT sm.id_material, sm.quantidade_solicitada, m.nome, m.quantidade as estoque_atual
            FROM solicitacoes_materiais sm
            JOIN materiais m ON sm.id_material = m.id
            WHERE sm.id_solicitacao = ?
        ");
        $stmt_materiais->execute([$solicitacao_id]);
        $materiais = $stmt_materiais->fetchAll(PDO::FETCH_ASSOC);

        // Se houver materiais extras, como datashow, caixa de som, etc., adicionar ao array
        if ($solicitacao['materiais_extras']) {
            $materiais_extras_array = json_decode($solicitacao['materiais_extras'], true);
            if ($materiais_extras_array) {
                foreach ($materiais_extras_array as $material_extra => $quantidade) {
                    if ($quantidade > 0) {
                        $materiais[] = [
                            'id_material' => $material_extra,
                            'nome' => ucfirst(str_replace('_', ' ', $material_extra)),
                            'quantidade_solicitada' => $quantidade,
                            'estoque_atual' => 'N/A' // Materiais extras não possuem controle de estoque
                        ];
                    }
                }
            }
        }

        $solicitacao['materiais'] = $materiais;
        
        echo json_encode([
            'success' => true,
            'solicitacao' => $solicitacao
        ]);

    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Erro interno do servidor: ' . $e->getMessage()]);
        exit;
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Erro interno do sistema']);
    }
?>

