// Variável global para armazenar materiais selecionados
let materiaisSelecionados = new Map();

// Função corrigida para buscar materiais mantendo as seleções
function buscarMateriais(termo) {
    const materiaisGrid = document.getElementById('materiais-grid');
    if (!materiaisGrid) return;

    fetch(`buscar_materiais.php?termo=${encodeURIComponent(termo)}`)
        .then(response => response.json())
        .then(data => {
            materiaisGrid.innerHTML = '';
            if (data.length === 0) {
                materiaisGrid.innerHTML = '<p style="text-align: center; color: #6b7280; padding: 1rem;">Nenhum material encontrado.</p>';
            } else {
                data.forEach(material => {
                    const materialDiv = document.createElement('div');
                    materialDiv.className = 'material-item-search';
                    
                    // Verificar se este material já estava selecionado
                    const jaEstavaSelecionado = materiaisSelecionados.has(material.id);
                    const quantidadeSalva = materiaisSelecionados.get(material.id) || 1;
                    
                    materialDiv.innerHTML = `
                        <div class="material-left">
                            <input type="checkbox" id="material_${material.id}" name="materiais[]" value="${material.id}"
                                style="margin-right: 0.75rem; transform: scale(1.1);"
                                onchange="toggleQuantityInput(this, ${material.id})"
                                ${jaEstavaSelecionado ? 'checked' : ''}>
                            <div class="material-info">
                                <div class="material-name">${material.nome}</div>
                                <div class="material-qty">Disponível: ${material.quantidade} (Máx. permitido: ${material.quantidade_maxima})</div>
                            </div>
                        </div>
                        <div class="material-right">
                            <label for="qty_material_${material.id}" style="font-size: 0.875rem; color: #6b7280;">Qtd:</label>
                            <input type="number" id="qty_material_${material.id}" name="qty_materiais[${material.id}]" 
                                min="1" max="${material.quantidade_maxima}" value="${quantidadeSalva}"
                                style="width: 60px; padding: 0.25rem; border: 1px solid #d1d5db; border-radius: 4px; margin-left: 0.5rem;" 
                                ${jaEstavaSelecionado ? '' : 'disabled'}>
                        </div>
                    `;
                    materiaisGrid.appendChild(materialDiv);
                });
            }
            materiaisGrid.style.display = 'block';
        })
        .catch(error => {
            console.error('Erro ao buscar materiais:', error);
            if (materiaisGrid) {
                materiaisGrid.innerHTML = '<p style="text-align: center; color: #dc2626; padding: 1rem;">Erro ao buscar materiais.</p>';
                materiaisGrid.style.display = 'block';
            }
        });
}

// Função corrigida para controlar inputs de quantidade e salvar seleções
function toggleQuantityInput(checkbox, materialId) {
    const quantityInput = document.getElementById(`qty_material_${materialId}`);
    
    if (quantityInput) {
        quantityInput.disabled = !checkbox.checked;
        
        if (checkbox.checked) {
            // Material foi selecionado - salvar na memória
            const quantidade = parseInt(quantityInput.value) || 1;
            materiaisSelecionados.set(materialId, quantidade);
            
            // Adicionar listener para salvar mudanças na quantidade
            quantityInput.addEventListener('change', function() {
                if (checkbox.checked) {
                    materiaisSelecionados.set(materialId, parseInt(this.value) || 1);
                }
            });
        } else {
            // Material foi desmarcado - remover da memória
            materiaisSelecionados.delete(materialId);
            quantityInput.value = 1;
        }
    }
    
    // Atualizar resumo de materiais selecionados
    atualizarResumoMateriais();
}

// Função para atualizar resumo de materiais selecionados
function atualizarResumoMateriais() {
    let resumoContainer = document.getElementById('resumo-materiais');
    
    // Criar container de resumo se não existir
    if (!resumoContainer) {
        resumoContainer = document.createElement('div');
        resumoContainer.id = 'resumo-materiais';
        resumoContainer.style.cssText = `
            margin-top: 1rem;
            padding: 1rem;
            background: #f0f9ff;
            border: 1px solid #0ea5e9;
            border-radius: 6px;
            display: none;
        `;
        
        const materiaisContainer = document.getElementById('outros-materiais-container');
        if (materiaisContainer) {
            materiaisContainer.appendChild(resumoContainer);
        }
    }
    
    if (materiaisSelecionados.size === 0) {
        resumoContainer.style.display = 'none';
        return;
    }
    
    let html = '<h4 style="margin: 0 0 0.5rem 0; color: #0369a1;"><i class="fas fa-check-circle"></i> Materiais Selecionados:</h4>';
    html += '<div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">';
    
    // Buscar nomes dos materiais selecionados
    const checkboxes = document.querySelectorAll('input[name="materiais[]"]:checked');
    checkboxes.forEach(checkbox => {
        const materialId = parseInt(checkbox.value);
        const quantidade = materiaisSelecionados.get(materialId) || 1;
        const materialInfo = checkbox.closest('.material-item-search').querySelector('.material-name');
        const nomeMateria = materialInfo ? materialInfo.textContent : `Material ${materialId}`;
        
        html += `
            <span style="
                background: #0ea5e9; 
                color: white; 
                padding: 0.25rem 0.5rem; 
                border-radius: 4px; 
                font-size: 0.875rem;
                display: inline-flex;
                align-items: center;
                gap: 0.25rem;
            ">
                ${nomeMateria} (${quantidade}x)
                <button type="button" onclick="removerMaterial(${materialId})" style="
                    background: none; 
                    border: none; 
                    color: white; 
                    cursor: pointer; 
                    padding: 0;
                    margin-left: 0.25rem;
                    font-size: 0.75rem;
                ">×</button>
            </span>
        `;
    });
    
    html += '</div>';
    resumoContainer.innerHTML = html;
    resumoContainer.style.display = 'block';
}

// Função para remover material do resumo
function removerMaterial(materialId) {
    const checkbox = document.getElementById(`material_${materialId}`);
    if (checkbox) {
        checkbox.checked = false;
        toggleQuantityInput(checkbox, materialId);
    }
}

// Função para limpar todas as seleções
function limparSelecoesMateriais() {
    materiaisSelecionados.clear();
    const checkboxes = document.querySelectorAll('input[name="materiais[]"]');
    checkboxes.forEach(checkbox => {
        checkbox.checked = false;
        const materialId = parseInt(checkbox.value);
        const quantityInput = document.getElementById(`qty_material_${materialId}`);
        if (quantityInput) {
            quantityInput.disabled = true;
            quantityInput.value = 1;
        }
    });
    atualizarResumoMateriais();
}
