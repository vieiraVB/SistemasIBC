<?php
require_once '../includes/config.php';

// Verificar se está logado e é admin
if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}

$error = '';
$success = '';
$relatorio_dados = [];
$estatisticas = null;

// Processar geração de relatório
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data_inicio = sanitize($_POST['data_inicio'] ?? '');
    $data_fim = sanitize($_POST['data_fim'] ?? '');
    
    if (empty($data_inicio) || empty($data_fim)) {
        $error = 'Por favor, preencha as datas de início e fim.';
    } elseif ($data_inicio > $data_fim) {
        $error = 'A data de início não pode ser maior que a data de fim.';
    } else {
        try {
            $pdo = getDBConnection();
            
            // Obter estatísticas do período
            $estatisticas = obterEstatisticas($pdo, $data_inicio, $data_fim);
            
            // Buscar dados detalhados do relatório
            $stmt = $pdo->prepare("
                SELECT 
                    s.id,
                    s.data_solicitacao,
                    s.data_utilizacao,
                    s.data_devolucao,
                    s.sala,
                    s.status,
                    s.observacoes,
                    s.turno,
                    u.nome as professor_nome,
                    GROUP_CONCAT(
                        CONCAT(m.nome, ' (', sm.quantidade_solicitada, 'x)')
                        SEPARATOR ', '
                    ) as materiais_solicitados
                FROM solicitacoes s
                JOIN usuarios u ON s.usuario_id = u.id
                LEFT JOIN solicitacoes_materiais sm ON s.id = sm.id_solicitacao
                LEFT JOIN materiais m ON sm.id_material = m.id
                WHERE s.data_solicitacao BETWEEN ? AND ?
                GROUP BY s.id
                ORDER BY s.data_solicitacao DESC
            ");
            
            $stmt->execute([$data_inicio . ' 00:00:00', $data_fim . ' 23:59:59']);
            $relatorio_dados = $stmt->fetchAll();
            
            if (empty($relatorio_dados)) {
                $error = 'Nenhuma solicitação encontrada no período selecionado.';
            } else {
                $success = 'Relatório gerado com sucesso! ' . count($relatorio_dados) . ' solicitação(ões) encontrada(s).';
            }
            
        } catch (PDOException $e) {
            $error = 'Erro ao gerar relatório. Tente novamente.';
            error_log("Erro no relatório: " . $e->getMessage());
        }
    }
}

// Função para obter estatísticas do período
function obterEstatisticas($pdo, $data_inicio, $data_fim) {
    if (empty($data_inicio) || empty($data_fim)) return null;
    
    try {
        $stats = [];
        
        // 1. Total de materiais em estoque
        $stmt = $pdo->query("SELECT SUM(quantidade) as total FROM materiais WHERE ativo = 1");
        $stats['total_estoque'] = $stmt->fetchColumn() ?: 0;
        
        // 2. Materiais indisponíveis e baixo estoque
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM materiais WHERE ativo = 1 AND quantidade = 0");
        $stats['indisponiveis'] = $stmt->fetchColumn() ?: 0;
        
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM materiais WHERE ativo = 1 AND quantidade > 0 AND quantidade <= 5");
        $stats['baixo_estoque'] = $stmt->fetchColumn() ?: 0;
        
        // 3. Solicitações realizadas no período
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as total
            FROM solicitacoes 
            WHERE data_solicitacao BETWEEN ? AND ?
        ");
        $stmt->execute([$data_inicio . ' 00:00:00', $data_fim . ' 23:59:59']);
        $stats['total_solicitacoes'] = $stmt->fetchColumn() ?: 0;
        
        // 4. Devoluções feitas no período
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as total
            FROM solicitacoes 
            WHERE data_devolucao BETWEEN ? AND ?
            AND status = 'devolvida'
        ");
        $stmt->execute([$data_inicio . ' 00:00:00', $data_fim . ' 23:59:59']);
        $stats['total_devolucoes'] = $stmt->fetchColumn() ?: 0;
        
        // 5. Itens danificados (extrair das observações)
        $stmt = $pdo->prepare("
            SELECT observacoes
            FROM solicitacoes 
            WHERE data_solicitacao BETWEEN ? AND ?
            AND observacoes LIKE '%danificad%'
        ");
        $stmt->execute([$data_inicio . ' 00:00:00', $data_fim . ' 23:59:59']);
        $observacoes_danificados = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $itens_danificados = [];
        foreach ($observacoes_danificados as $obs) {
            // Extrair informações de itens danificados das observações
            if (preg_match_all('/(\w+.*?)\s*\((\d+)\s*danificad/i', $obs, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $match) {
                    $item = trim($match[1]);
                    $quantidade = (int)$match[2];
                    $itens_danificados[$item] = ($itens_danificados[$item] ?? 0) + $quantidade;
                }
            }
        }
        $stats['itens_danificados'] = $itens_danificados;
        $stats['total_danificados'] = array_sum($itens_danificados);
        
        // 6. Solicitações por status
        $stmt = $pdo->prepare("
            SELECT status, COUNT(*) as quantidade
            FROM solicitacoes 
            WHERE data_solicitacao BETWEEN ? AND ?
            GROUP BY status
        ");
        $stmt->execute([$data_inicio . ' 00:00:00', $data_fim . ' 23:59:59']);
        $stats['por_status'] = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        
        return $stats;
        
    } catch (PDOException $e) {
        error_log("Erro ao obter estatísticas: " . $e->getMessage());
        return null;
    }
}

$pdo = getDBConnection();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Relatórios</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .dashboard-container {
            background: #f8fafc;
            min-height: 100vh;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
            margin-bottom: 2.5rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
            border: 1px solid #f1f5f9;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--card-color);
        }
        
        .stat-card.green {
            --card-color: #10b981;
        }
        
        .stat-card.red {
            --card-color: #ef4444;
        }
        
        .stat-card.orange {
            --card-color: #f59e0b;
        }
        
        .stat-card.blue {
            --card-color: #3b82f6;
        }
        
        .stat-card.purple {
            --card-color: #8b5cf6;
        }
        
        .stat-icon {
            width: 64px;
            height: 64px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
            color: white;
        }
        
        .stat-card.green .stat-icon {
            background: linear-gradient(135deg, #10b981, #059669);
        }
        
        .stat-card.red .stat-icon {
            background: linear-gradient(135deg, #ef4444, #dc2626);
        }
        
        .stat-card.orange .stat-icon {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }
        
        .stat-card.blue .stat-icon {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
        }
        
        .stat-card.purple .stat-icon {
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
        }
        
        .stat-number {
            font-size: 3rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            color: #1f2937;
            line-height: 1;
        }
        
        .stat-label {
            font-size: 1rem;
            font-weight: 600;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        
        .stat-description {
            font-size: 0.875rem;
            color: #9ca3af;
            margin-top: 0.5rem;
            line-height: 1.4;
        }
        
        .relatorio-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
        }
        
        .relatorio-table th {
            background: #f8fafc;
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .relatorio-table td {
            padding: 1rem;
            border-bottom: 1px solid #f3f4f6;
            color: #4b5563;
        }
        
        .relatorio-table tr:hover {
            background: #f9fafb;
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 500;
            text-transform: uppercase;
        }
        
        .status-pendente {
            background: #fef3c7;
            color: #92400e;
        }
        
        .status-aprovada {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-retirada {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .status-devolvida {
            background: #e0e7ff;
            color: #3730a3;
        }
        
        .status-cancelada {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .export-buttons {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            margin-top: 2rem;
        }
        
        .damaged-items-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }
        
        .damaged-item {
            background: #fef2f2;
            border: 1px solid #fecaca;
            border-radius: 8px;
            padding: 1rem;
            text-align: center;
        }
        
        .damaged-item-name {
            font-weight: 600;
            color: #dc2626;
            margin-bottom: 0.5rem;
        }
        
        .damaged-item-qty {
            font-size: 1.5rem;
            font-weight: bold;
            color: #991b1b;
        }
        
        .filter-form {
            background: white;
            padding: 2rem;
            border-radius: 16px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
            margin-bottom: 2rem;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr auto;
            gap: 1rem;
            align-items: end;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .export-buttons {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Botão de menu hambúrguer para mobile -->
    <button class="mobile-menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    
    <!-- Overlay para fechar sidebar em mobile -->
    <div class="sidebar-overlay" onclick="closeSidebar()"></div>
    
    <div class="main-layout">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h1>SIMEI - IBC</h1>
                <p>Bem-vindo, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>
            
            <nav class="sidebar-nav">
                <?php if (isAdmin() || isColaborador()): ?>
                    <a href="usuarios.php" class="nav-item">
                        <i class="fas fa-users"></i> Usuários
                    </a>
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="materiais.php" class="nav-item">
                        <i class="fas fa-boxes"></i> Gestão de Materiais
                    </a>
                    <a href="relatorios.php" class="nav-item active">
                        <i class="fas fa-chart-bar"></i> Relatórios
                    </a>
                <?php endif; ?>
                <?php if ($_SESSION['user_type'] === 'professor' || isAdmin() || isColaborador()): ?>
                    <a href="solicitar.php" class="nav-item">
                        <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                    </a>
                    <?php
                    $stmt = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
                    $pendentes_count = $stmt->fetchColumn();
                    ?>
                    <a href="pendentes.php" class="nav-item">
                        <span id="contador-pendentes">
                            <i class="fas fa-clock"></i>
                        </span>
                        Solicitações
                    </a>
                <?php endif; ?>
            </nav>
            
            <div class="sidebar-footer">
                <a href="../logout.php" class="btn btn-secondary btn-full">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>
        
        <!-- Conteúdo Principal -->
        <div class="main-content dashboard-container">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-chart-bar"></i> Dashboard de Relatórios
                </h1>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <!-- Formulário de Filtro -->
            <div class="filter-form">
                <form method="POST" action="">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="data_inicio" class="form-label">
                                <i class="fas fa-calendar-alt"></i> Data de Início
                            </label>
                            <input 
                                type="date" 
                                id="data_inicio" 
                                name="data_inicio" 
                                class="form-input"
                                value="<?php echo $_POST['data_inicio'] ?? date('Y-m-01'); ?>"
                                required
                            >
                        </div>
                        
                        <div class="form-group">
                            <label for="data_fim" class="form-label">
                                <i class="fas fa-calendar-alt"></i> Data de Fim
                            </label>
                            <input 
                                type="date" 
                                id="data_fim" 
                                name="data_fim" 
                                class="form-input"
                                value="<?php echo $_POST['data_fim'] ?? date('Y-m-t'); ?>"
                                required
                            >
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i> Gerar Relatório
                        </button>
                    </div>
                </form>
            </div>
            
            <?php if ($estatisticas): ?>
            <!-- Dashboard de Estatísticas -->
            <div class="stats-grid">
                <div class="stat-card green">
                    <div class="stat-icon">
                        <i class="fas fa-boxes"></i>
                    </div>
                    <div class="stat-number"><?php echo $estatisticas['total_estoque']; ?></div>
                    <div class="stat-label">Total em Estoque</div>
                    <div class="stat-description">Quantidade total de materiais disponíveis</div>
                </div>
                
                <div class="stat-card red">
                    <div class="stat-icon">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="stat-number"><?php echo $estatisticas['indisponiveis']; ?></div>
                    <div class="stat-label">Indisponíveis</div>
                    <div class="stat-description">Materiais sem estoque disponível</div>
                </div>
                
                <div class="stat-card orange">
                    <div class="stat-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stat-number"><?php echo $estatisticas['baixo_estoque']; ?></div>
                    <div class="stat-label">Baixo Estoque</div>
                    <div class="stat-description">Materiais com 5 ou menos unidades</div>
                </div>
                
                <div class="stat-card blue">
                    <div class="stat-icon">
                        <i class="fas fa-clipboard-list"></i>
                    </div>
                    <div class="stat-number"><?php echo $estatisticas['total_solicitacoes']; ?></div>
                    <div class="stat-label">Solicitações</div>
                    <div class="stat-description">Total de solicitações no período</div>
                </div>
                
                <div class="stat-card purple">
                    <div class="stat-icon">
                        <i class="fas fa-undo"></i>
                    </div>
                    <div class="stat-number"><?php echo $estatisticas['total_devolucoes']; ?></div>
                    <div class="stat-label">Devoluções</div>
                    <div class="stat-description">Devoluções realizadas no período</div>
                </div>
            </div>
            
            <?php if (!empty($estatisticas['itens_danificados'])): ?>
            <!-- Detalhes de Itens Danificados -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-exclamation-triangle" style="color: #dc2626;"></i> Itens Danificados
                    </h2>
                </div>
                <div class="card-body">
                    <div class="damaged-items-grid">
                        <?php foreach ($estatisticas['itens_danificados'] as $item => $quantidade): ?>
                            <div class="damaged-item">
                                <div class="damaged-item-name"><?php echo htmlspecialchars($item); ?></div>
                                <div class="damaged-item-qty"><?php echo $quantidade; ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Tabela Detalhada -->
            <?php if (!empty($relatorio_dados)): ?>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-table"></i> Detalhes das Solicitações
                    </h2>
                </div>
                <div class="card-body">
                    <div style="overflow-x: auto;">
                        <table class="relatorio-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Professor</th>
                                    <th>Data Solicitação</th>
                                    <th>Data Utilização</th>
                                    <th>Data Devolução</th>
                                    <th>Sala</th>
                                    <th>Turno</th>
                                    <th>Materiais</th>
                                    <th>Status</th>
                                    <th>Observações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($relatorio_dados as $item): ?>
                                    <tr>
                                        <td><?php echo $item['id']; ?></td>
                                        <td><?php echo htmlspecialchars($item['professor_nome']); ?></td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($item['data_solicitacao'])); ?></td>
                                        <td><?php echo date('d/m/Y', strtotime($item['data_utilizacao'])); ?></td>
                                        <td><?php echo $item['data_devolucao'] ? date('d/m/Y H:i', strtotime($item['data_devolucao'])) : '-'; ?></td>
                                        <td><?php echo htmlspecialchars($item['sala']); ?></td>
                                        <td><?php echo $item['turno'] ? ucfirst($item['turno']) : '-'; ?></td>
                                        <td><?php echo $item['materiais_solicitados'] ?: '-'; ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $item['status']; ?>">
                                                <?php echo ucfirst($item['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($item['observacoes']): ?>
                                                <span title="<?php echo htmlspecialchars($item['observacoes']); ?>">
                                                    <?php echo htmlspecialchars(substr($item['observacoes'], 0, 50)); ?>
                                                    <?php if (strlen($item['observacoes']) > 50): ?>...<?php endif; ?>
                                                </span>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="export-buttons">
                        <button onclick="exportarPDF()" class="btn btn-primary">
                            <i class="fas fa-file-pdf"></i> Exportar PDF
                        </button>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        // Funções para controle do menu mobile
        function toggleSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            sidebar.classList.toggle("open");
            overlay.classList.toggle("active");
        }
        
        function closeSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            sidebar.classList.remove("open");
            overlay.classList.remove("active");
        }
        
        // Função para exportar dados para PDF
        function exportarPDF() {
            // Criar uma nova janela com o conteúdo do relatório
            const printWindow = window.open('', '_blank');
            
            // Obter dados das estatísticas
            const statsCards = document.querySelectorAll('.stat-card');
            const table = document.querySelector('.relatorio-table');
            
            if (!table) {
                alert('Nenhum relatório para exportar');
                return;
            }
            
            // Construir HTML do PDF
            let pdfContent = `
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <title>Relatório SIMEI - IBC</title>
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
                    <style>
                        body { 
                            font-family: Arial, sans-serif; 
                            margin: 20px; 
                            color: #333;
                            line-height: 1.4;
                        }
                        .header { 
                            text-align: center; 
                            margin-bottom: 30px; 
                            border-bottom: 2px solid #3b82f6;
                            padding-bottom: 20px;
                        }
                        .header h1 { 
                            color: #3b82f6; 
                            margin: 0;
                            font-size: 24px;
                        }
                        .header p { 
                            margin: 5px 0; 
                            color: #666;
                        }
                        .stats-section {
                            display: grid;
                            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                            gap: 20px;
                            margin-bottom: 30px;
                        }
                        .stat-box {
                            background: white;
                            border-radius: 12px;
                            padding: 20px;
                            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
                            border: 1px solid #f1f5f9;
                            position: relative;
                            overflow: hidden;
                            text-align: center;
                        }
                        .stat-box::before {
                            content: '';
                            position: absolute;
                            top: 0;
                            left: 0;
                            right: 0;
                            height: 4px;
                            background: var(--card-color);
                        }
                        .stat-box.green { --card-color: #10b981; }
                        .stat-box.red { --card-color: #ef4444; }
                        .stat-box.orange { --card-color: #f59e0b; }
                        .stat-box.blue { --card-color: #3b82f6; }
                        .stat-box.purple { --card-color: #8b5cf6; }
                        .stat-icon {
                            width: 48px;
                            height: 48px;
                            border-radius: 12px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin: 0 auto 15px;
                            font-size: 18px;
                            color: white;
                        }
                        .stat-box.green .stat-icon { background: linear-gradient(135deg, #10b981, #059669); }
                        .stat-box.red .stat-icon { background: linear-gradient(135deg, #ef4444, #dc2626); }
                        .stat-box.orange .stat-icon { background: linear-gradient(135deg, #f59e0b, #d97706); }
                        .stat-box.blue .stat-icon { background: linear-gradient(135deg, #3b82f6, #2563eb); }
                        .stat-box.purple .stat-icon { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
                        .stat-number { 
                            font-size: 32px; 
                            font-weight: 800; 
                            margin-bottom: 5px; 
                            color: #1f2937;
                            line-height: 1;
                        }
                        .stat-label { 
                            font-size: 14px; 
                            font-weight: 600; 
                            color: #6b7280; 
                            text-transform: uppercase;
                            letter-spacing: 0.05em;
                            margin-bottom: 5px;
                        }
                        .stat-description {
                            font-size: 11px;
                            color: #9ca3af;
                            line-height: 1.3;
                        }
                        .damaged-items {
                            background: #fef2f2;
                            border: 1px solid #fecaca;
                            border-radius: 8px;
                            padding: 20px;
                            margin-bottom: 30px;
                        }
                        .damaged-items h3 {
                            color: #dc2626;
                            margin-top: 0;
                            font-size: 18px;
                            border-bottom: 1px solid #fecaca;
                            padding-bottom: 10px;
                        }
                        .damaged-grid {
                            display: grid;
                            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                            gap: 10px;
                            margin-top: 15px;
                        }
                        .damaged-item {
                            background: white;
                            border: 1px solid #fecaca;
                            border-radius: 4px;
                            padding: 10px;
                            text-align: center;
                        }
                        .damaged-item-name { font-weight: 600; color: #dc2626; margin-bottom: 5px; }
                        .damaged-item-qty { font-size: 18px; font-weight: bold; color: #991b1b; }
                        table { 
                            width: 100%; 
                            border-collapse: collapse; 
                            margin-bottom: 30px;
                            font-size: 10px;
                        }
                        th, td { 
                            border: 1px solid #ddd; 
                            padding: 8px; 
                            text-align: left; 
                        }
                        th { 
                            background: #f8fafc; 
                            font-weight: bold; 
                            color: #374151;
                        }
                        tr:nth-child(even) { background: #f9fafb; }
                        .status-badge {
                            padding: 2px 6px;
                            border-radius: 10px;
                            font-size: 8px;
                            font-weight: 500;
                            text-transform: uppercase;
                        }
                        .status-pendente { background: #fef3c7; color: #92400e; }
                        .status-aprovada { background: #d1fae5; color: #065f46; }
                        .status-retirada { background: #dbeafe; color: #1e40af; }
                        .status-devolvida { background: #e0e7ff; color: #3730a3; }
                        .status-cancelada { background: #fee2e2; color: #991b1b; }
                        .summary {
                            background: #f0f9ff;
                            border: 1px solid #3b82f6;
                            border-radius: 8px;
                            padding: 20px;
                            margin-top: 30px;
                        }
                        .summary h3 {
                            color: #1e40af;
                            margin-top: 0;
                            font-size: 18px;
                        }
                        .summary-grid {
                            display: grid;
                            grid-template-columns: repeat(2, 1fr);
                            gap: 15px;
                            margin-top: 15px;
                        }
                        .summary-item {
                            display: flex;
                            justify-content: space-between;
                            padding: 8px 0;
                            border-bottom: 1px solid #bae6fd;
                        }
                        .summary-item:last-child { border-bottom: none; }
                        .summary-label { font-weight: 500; }
                        .summary-value { font-weight: bold; color: #1e40af; }
                        @media print {
                            body { margin: 0; }
                            .stats-section { grid-template-columns: repeat(2, 1fr); }
                        }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>SIMEI - IBC</h1>
                        <p><strong>Sistema de Movimentação de Equipamentos e Insumos</strong></p>
                        <p>Relatório Personalizado - ${new Date().toLocaleDateString('pt-BR')}</p>
                        <p>Período: ${document.getElementById('data_inicio').value} a ${document.getElementById('data_fim').value}</p>
                    </div>
            `;
            
            // Adicionar estatísticas
            if (statsCards.length > 0) {
                pdfContent += '<div class="stats-section">';
                statsCards.forEach((card) => {
                    const icon = card.querySelector('.stat-icon i').className;
                    const number = card.querySelector('.stat-number').textContent;
                    const label = card.querySelector('.stat-label').textContent;
                    const description = card.querySelector('.stat-description').textContent;
                    
                    let className = '';
                    if (card.classList.contains('green')) className = 'green';
                    else if (card.classList.contains('red')) className = 'red';
                    else if (card.classList.contains('orange')) className = 'orange';
                    else if (card.classList.contains('blue')) className = 'blue';
                    else if (card.classList.contains('purple')) className = 'purple';
                    
                    pdfContent += `
                        <div class="stat-box ${className}">
                            <div class="stat-icon">
                                <i class="${icon}"></i>
                            </div>
                            <div class="stat-number">${number}</div>
                            <div class="stat-label">${label}</div>
                            <div class="stat-description">${description}</div>
                        </div>
                    `;
                });
                pdfContent += '</div>';
            }
            
            // Adicionar itens danificados se existirem
            const damagedSection = document.querySelector('.card:has(h2:contains("Itens Danificados"))');
            if (damagedSection) {
                pdfContent += '<div class="damaged-items">';
                pdfContent += '<h3>🚨 Itens Danificados no Período</h3>';
                pdfContent += '<div class="damaged-grid">';
                
                const damagedItems = damagedSection.querySelectorAll('.damaged-item');
                damagedItems.forEach(item => {
                    const name = item.querySelector('.damaged-item-name').textContent;
                    const qty = item.querySelector('.damaged-item-qty').textContent;
                    pdfContent += `
                        <div class="damaged-item">
                            <div class="damaged-item-name">${name}</div>
                            <div class="damaged-item-qty">${qty}</div>
                        </div>
                    `;
                });
                
                pdfContent += '</div></div>';
            }
            
            // Adicionar tabela
            pdfContent += table.outerHTML.replace(/class="relatorio-table"/g, '');
            
            // Adicionar resumo geral
            if (statsCards.length > 0) {
                const totalEstoque = statsCards[0].querySelector('.stat-number').textContent;
                const indisponiveis = statsCards[1].querySelector('.stat-number').textContent;
                const baixoEstoque = statsCards[2].querySelector('.stat-number').textContent;
                const solicitacoes = statsCards[3].querySelector('.stat-number').textContent;
                const devolucoes = statsCards[4].querySelector('.stat-number').textContent;
                
                pdfContent += `
                    <div class="summary">
                        <h3>📊 Resumo Geral do Período</h3>
                        <div class="summary-grid">
                            <div class="summary-item">
                                <span class="summary-label">Total em Estoque:</span>
                                <span class="summary-value">${totalEstoque}</span>
                            </div>
                            <div class="summary-item">
                                <span class="summary-label">Materiais Indisponíveis:</span>
                                <span class="summary-value">${indisponiveis}</span>
                            </div>
                            <div class="summary-item">
                                <span class="summary-label">Baixo Estoque:</span>
                                <span class="summary-value">${baixoEstoque}</span>
                            </div>
                            <div class="summary-item">
                                <span class="summary-label">Total de Solicitações:</span>
                                <span class="summary-value">${solicitacoes}</span>
                            </div>
                            <div class="summary-item">
                                <span class="summary-label">Total de Devoluções:</span>
                                <span class="summary-value">${devolucoes}</span>
                            </div>
                        </div>
                        <div style="margin-top: 20px; text-align: center; color: #6b7280; font-size: 12px;">
                            Relatório gerado automaticamente pelo SIMEI - IBC em ${new Date().toLocaleString('pt-BR')}
                        </div>
                    </div>
                `;
            }
            
            pdfContent += '</body></html>';
            
            // Escrever conteúdo na nova janela e imprimir
            printWindow.document.write(pdfContent);
            printWindow.document.close();
            
            // Aguardar carregamento e imprimir
            printWindow.onload = function() {
                setTimeout(() => {
                    printWindow.print();
                    printWindow.close();
                }, 500);
            };
        }
        
        // Definir data padrão (último mês)
        document.addEventListener('DOMContentLoaded', function() {
            const hoje = new Date();
            const primeiroDiaMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
            const ultimoDiaMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0);
            
            if (!document.getElementById('data_inicio').value) {
                document.getElementById('data_inicio').value = primeiroDiaMes.toISOString().split('T')[0];
            }
            if (!document.getElementById('data_fim').value) {
                document.getElementById('data_fim').value = ultimoDiaMes.toISOString().split('T')[0];
            }
        });
    </script>
</body>
</html>
