<?php
require_once '../includes/config.php';
$pdo = getDBConnection();

$stmt = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
$pendentes = $stmt->fetchColumn();

if ($pendentes > 0) {
    echo '<strong><span class="badge" style="color: orange; font-size: 25px; padding: 0px 2px;">'.$pendentes.'</span></strong>';

} else {
    echo "<i class='fas fa-clock'></i>";
}
