<?php
// pages/notificacoes.php

// Inclui a configuração e as funções principais
require_once '../includes/config.php';

// Define o cabeçalho da resposta como JSON
header('Content-Type: application/json');

// Verifica se o usuário é um administrador logado
if (!isLoggedIn() || !isAdmin()) {
    // Se não for, retorna um erro em JSON e encerra o script
    echo json_encode(['success' => false, 'message' => 'Acesso negado.']);
    exit;
}

try {
    // Pega a conexão com o banco de dados
    $pdo = getDBConnection();

    // Prepara e executa uma consulta para contar as solicitações com status 'pendente'
    $stmt = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
    
    // Pega o resultado da contagem
    $pendentes_count = $stmt->fetchColumn();

    // Retorna uma resposta de sucesso em formato JSON com o número de solicitações pendentes
    echo json_encode(['success' => true, 'novas_solicitacoes' => (int)$pendentes_count]);

} catch (PDOException $e) {
    // Em caso de erro no banco de dados, retorna um erro em JSON
    echo json_encode(['success' => false, 'message' => 'Erro de banco de dados: ' . $e->getMessage()]);
}