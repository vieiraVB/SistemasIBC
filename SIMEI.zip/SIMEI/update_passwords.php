<?php
require_once 'includes/config.php';

try {
    $pdo = getDBConnection();
    
    // Senha padrão para todos os usuários de teste
    $password = 'password';
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Atualizar senhas de todos os usuários
    $stmt = $pdo->prepare("UPDATE usuarios SET senha = ?");
    $stmt->execute([$hashedPassword]);
    
    echo "Senhas atualizadas com sucesso!<br>";
    echo "Senha padrão para todos os usuários: <strong>password</strong><br>";
    echo "Usuários disponíveis:<br>";
    
    // Listar usuários
    $stmt = $pdo->query("SELECT nome, cpf, tipo FROM usuarios WHERE ativo = 1");
    while ($user = $stmt->fetch()) {
        echo "- {$user['nome']} ({$user['cpf']}) - {$user['tipo']}<br>";
    }
    
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>

