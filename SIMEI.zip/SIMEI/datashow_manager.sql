-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 11/10/2025 às 08:58
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `datashow_manager`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `chaves`
--

CREATE TABLE `chaves` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `tipo_local` enum('laboratorio','sala') NOT NULL,
  `numero_local` varchar(20) NOT NULL,
  `setor_responsavel` enum('ti','secretaria') NOT NULL,
  `status` enum('disponivel','emprestada','manutencao') DEFAULT 'disponivel',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `chaves`
--

INSERT INTO `chaves` (`id`, `nome`, `descricao`, `tipo_local`, `numero_local`, `setor_responsavel`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Chave Lab 1', 'Chave do Laboratório 1', 'laboratorio', '1', 'ti', 'disponivel', '2025-09-21 08:25:49', '2025-09-21 08:25:49'),
(2, 'Chave Lab 2', 'Chave do Laboratório 2', 'laboratorio', '2', 'ti', 'disponivel', '2025-09-21 08:25:49', '2025-09-21 08:25:49'),
(3, 'Chave Lab 3', 'Chave do Laboratório 3', 'laboratorio', '3', 'ti', 'disponivel', '2025-09-21 08:25:49', '2025-09-21 08:25:49'),
(4, 'Chave Sala 101', 'Chave da Sala 101', 'sala', '101', 'secretaria', 'disponivel', '2025-09-21 08:25:49', '2025-09-21 08:25:49'),
(5, 'Chave Sala 102', 'Chave da Sala 102', 'sala', '102', 'secretaria', 'disponivel', '2025-09-21 08:25:49', '2025-09-21 08:25:49'),
(6, 'Chave Sala 103', 'Chave da Sala 103', 'sala', '103', 'secretaria', 'disponivel', '2025-09-21 08:25:49', '2025-09-21 08:25:49'),
(7, 'Chave Sala 201', 'Chave da Sala 201', 'sala', '201', 'secretaria', 'disponivel', '2025-09-21 08:25:49', '2025-09-21 08:25:49'),
(8, 'Chave Sala 202', 'Chave da Sala 202', 'sala', '202', 'secretaria', 'disponivel', '2025-09-21 08:25:49', '2025-09-21 08:25:49'),
(9, 'Chave Sala 203', 'Chave da Sala 203', 'sala', '203', 'secretaria', 'disponivel', '2025-09-21 08:25:49', '2025-09-21 08:25:49'),
(10, 'Chave Auditório', 'Chave do Auditório', 'sala', 'Auditório', 'secretaria', 'disponivel', '2025-09-21 08:25:49', '2025-09-21 08:25:49');

-- --------------------------------------------------------

--
-- Estrutura para tabela `materiais`
--

CREATE TABLE `materiais` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `quantidade` int(11) DEFAULT 0,
  `status_disponibilidade` enum('disponivel','indisponivel') DEFAULT 'disponivel',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `materiais`
--

INSERT INTO `materiais` (`id`, `nome`, `descricao`, `quantidade`, `status_disponibilidade`, `created_at`, `updated_at`) VALUES
(1, 'Abraçadeira de Nylon Branco', 'Abraçadeira de Nylon Branco', 0, 'indisponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(2, 'Adaptador de Tomada ', 'Adaptador de Tomada ', 34, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(3, 'Adaptador USB Tipo C', 'Adaptador USB Tipo C', 27, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(4, 'Arduino nano ', 'Arduino nano ', 0, 'indisponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(5, 'Arduino Lilypad', 'Arduino Lilypad', 0, 'indisponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(6, 'Adaptadores Wireless', 'Adaptadores Wireless', 2, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(7, 'Alicate Amperímetro Digital ET-3III ', 'Alicate Amperímetro Digital ET-3III ', 4, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(8, 'Alicate Aperímetro LWJ - 302', 'Alicate Aperímetro LWJ - 302', 10, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(9, 'Alicate Corte Diagonal 105x65mm ', 'Alicate Corte Diagonal 105x65mm ', 5, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(10, 'Alicate Corte Diagonal 6.1/2 ', 'Alicate Corte Diagonal 6.1/2 ', 5, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(11, 'Alicate Corte Rente Zero Ac-12 ', 'Alicate Corte Rente Zero Ac-12 ', 2, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(12, 'Alicate de Crimpagem ', 'Alicate de Crimpagem ', 27, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(13, 'Alicate de Inserção HT3140 ', 'Alicate de Inserção HT3140 ', 23, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(14, 'Alicate Tipo Telefone 6,1/2 ', 'Alicate Tipo Telefone 6,1/2 ', 25, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(15, 'Alicate Universal Isolado ', 'Alicate Universal Isolado ', 8, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(16, 'Apagador', 'Apagador', 224, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(17, 'Apontador ', 'Apontador ', 27, 'disponivel', '2025-08-30 00:30:45', '2025-08-30 00:30:45'),
(18, 'Barramento Trifásico ', 'Barramento Trifásico ', 1, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(19, 'Bateria 3V CR2032', 'Bateria 3V CR2032', 20, 'disponivel', '2025-08-30 00:30:46', '2025-09-15 01:50:56'),
(20, 'Bateria CR123A 3V', 'Bateria CR123A 3V', 18, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(21, 'Bomba de Esgoto 350GPH ', 'Bomba de Esgoto 350GPH ', 5, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(22, 'Borracha ', 'Borracha ', 0, 'indisponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(23, 'Botão 22mm Duplo Plástico ', 'Botão 22mm Duplo Plástico ', 3, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(24, 'Cabo Coaxial BNC ', 'Cabo Coaxial BNC ', 2, 'disponivel', '2025-08-30 00:30:46', '2025-09-15 01:36:56'),
(25, 'Cabo Console', 'Cabo Console', 12, 'disponivel', '2025-08-30 00:30:46', '2025-09-15 01:37:00'),
(26, 'Cabo de Força ', 'Cabo de Força ', 140, 'disponivel', '2025-08-30 00:30:46', '2025-09-15 01:37:00'),
(27, 'Cabo de Impressora ', 'Cabo de Impressora ', 20, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(28, 'Cabo DP para  DVI Fêmea ', 'Cabo DP para  DVI Fêmea ', 165, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(29, 'Cabo DP para HDMI Macho ', 'Cabo DP para HDMI Macho ', 90, 'disponivel', '2025-08-30 00:30:46', '2025-09-15 01:32:47'),
(30, 'Cabo DVI ', 'Cabo DVI ', 135, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(31, 'Cabo Flexível Amarelo', 'Cabo Flexível Amarelo', 5, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(32, 'Cabo Flexível Azul ', 'Cabo Flexível Azul ', 10, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(33, 'Cabo Flexível Cinza', 'Cabo Flexível Cinza', 15, 'disponivel', '2025-08-30 00:30:46', '2025-09-15 01:32:15'),
(34, 'Cabo Flexível Verde', 'Cabo Flexível Verde', 7, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(35, 'Cabo Flexível Vermelho', 'Cabo Flexível Vermelho', 11, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(36, 'Cabo Resolver CR 1,5mm', 'Cabo Resolver CR 1,5mm', 1, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(37, 'Cabo Serial ', 'Cabo Serial ', 9, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(38, 'Cabo USB', 'Cabo USB', 1, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(39, 'Cabo VGA CKIT6305 ', 'Cabo VGA CKIT6305 ', 61, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(40, 'Cabos de Arduino', 'Cabos de Arduino', 8, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(41, 'Cabos HDMI ', 'Cabos HDMI ', 6, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(42, 'Caixa de embutir 4x2 ', 'Caixa de embutir 4x2 ', 19, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(43, 'Caixa de embutir 4x4 ', 'Caixa de embutir 4x4 ', 2, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(44, 'Caixa de Resistor 11KΩ', 'Caixa de Resistor 11KΩ', 1, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(45, 'Caixa de Resistor 22KΩ', 'Caixa de Resistor 22KΩ', 1, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(46, 'Caixa de Resistor 33KΩ', 'Caixa de Resistor 33KΩ', 1, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(47, 'Caixa de Resistor 47KΩ', 'Caixa de Resistor 47KΩ', 1, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(48, 'Caixa de Sobrepor Sistema ', 'Caixa de Sobrepor Sistema ', 32, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(49, 'Caixa Múltipla 3/4', 'Caixa Múltipla 3/4', 86, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(50, 'Câmera IP Power Fl895E ', 'Câmera IP Power Fl895E ', 37, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(51, 'Caneta Azul', 'Caneta Azul', 0, 'indisponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(52, 'Capacitor Box', 'Capacitor Box', 8, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(53, 'Capacitor Cerâmico 10', 'Capacitor Cerâmico 10', 78, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(54, 'Capacitor Cerâmico 100', 'Capacitor Cerâmico 100', 8, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(55, 'Capacitor Cerâmico 101', 'Capacitor Cerâmico 101', 90, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(56, 'Capacitor Cerâmico 102', 'Capacitor Cerâmico 102', 150, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(57, 'Capacitor Cerâmico 103', 'Capacitor Cerâmico 103', 96, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(58, 'Capacitor Cerâmico 104', 'Capacitor Cerâmico 104', 306, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(59, 'Capacitor Cerâmico 109', 'Capacitor Cerâmico 109', 23, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(60, 'Capacitor Cerâmico 122', 'Capacitor Cerâmico 122', 87, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(61, 'Capacitor Cerâmico 152', 'Capacitor Cerâmico 152', 39, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(62, 'Capacitor Cerâmico 152K', 'Capacitor Cerâmico 152K', 11, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(63, 'Capacitor Cerâmico 182', 'Capacitor Cerâmico 182', 76, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(64, 'Capacitor Cerâmico 1pF', 'Capacitor Cerâmico 1pF', 62, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(65, 'Capacitor Cerâmico 22', 'Capacitor Cerâmico 22', 84, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(66, 'Capacitor Cerâmico 220', 'Capacitor Cerâmico 220', 14, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(67, 'Capacitor Cerâmico 221', 'Capacitor Cerâmico 221', 90, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(68, 'Capacitor Cerâmico 222', 'Capacitor Cerâmico 222', 8, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(69, 'Capacitor Cerâmico 223', 'Capacitor Cerâmico 223', 22, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(70, 'Capacitor Cerâmico 229', 'Capacitor Cerâmico 229', 112, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(71, 'Capacitor Cerâmico 272', 'Capacitor Cerâmico 272', 80, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(72, 'Capacitor Cerâmico 33', 'Capacitor Cerâmico 33', 70, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(73, 'Capacitor Cerâmico 330', 'Capacitor Cerâmico 330', 19, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(74, 'Capacitor Cerâmico 331', 'Capacitor Cerâmico 331', 96, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(75, 'Capacitor Cerâmico 332', 'Capacitor Cerâmico 332', 8, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(76, 'Capacitor Cerâmico 339', 'Capacitor Cerâmico 339', 8, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(77, 'Capacitor Cerâmico 3R3', 'Capacitor Cerâmico 3R3', 66, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(78, 'Capacitor Cerâmico 4.7', 'Capacitor Cerâmico 4.7', 60, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(79, 'Capacitor Cerâmico 470', 'Capacitor Cerâmico 470', 39, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(80, 'Capacitor Cerâmico 471', 'Capacitor Cerâmico 471', 80, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(81, 'Capacitor Cerâmico 472', 'Capacitor Cerâmico 472', 4, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(82, 'Capacitor Cerâmico 473', 'Capacitor Cerâmico 473', 11, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(83, 'Capacitor Cerâmico 474', 'Capacitor Cerâmico 474', 24, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(84, 'Capacitor Cerâmico 479', 'Capacitor Cerâmico 479', 23, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(85, 'Capacitor Cerâmico 5', 'Capacitor Cerâmico 5', 17, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(86, 'Capacitor Cerâmico 68', 'Capacitor Cerâmico 68', 6, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(87, 'Capacitor Cerâmico 681', 'Capacitor Cerâmico 681', 13, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(88, 'Capacitor Cerâmico 682', 'Capacitor Cerâmico 682', 80, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(89, 'Capacitor Eletrolítico 0,1UF 50V', 'Capacitor Eletrolítico 0,1UF 50V', 0, 'indisponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(90, 'Capacitor Eletrolítico 0,22UF 50V', 'Capacitor Eletrolítico 0,22UF 50V', 18, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(91, 'Capacitor Eletrolítico 0,33UF 50V', 'Capacitor Eletrolítico 0,33UF 50V', 88, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(92, 'Capacitor Eletrolítico 1000UF 10V', 'Capacitor Eletrolítico 1000UF 10V', 60, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(93, 'Capacitor Eletrolítico 1000UF 16V', 'Capacitor Eletrolítico 1000UF 16V', 40, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(94, 'Capacitor Eletrolítico 1000UF 25V', 'Capacitor Eletrolítico 1000UF 25V', 15, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(95, 'Capacitor Eletrolítico 1000UF 50V', 'Capacitor Eletrolítico 1000UF 50V', 25, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(96, 'Capacitor Eletrolítico 100UF 16V', 'Capacitor Eletrolítico 100UF 16V', 30, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(97, 'Capacitor Eletrolítico 100UF 25V', 'Capacitor Eletrolítico 100UF 25V', 104, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(98, 'Capacitor Eletrolítico 100UF 50V', 'Capacitor Eletrolítico 100UF 50V', 85, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(99, 'Capacitor Eletrolítico 10UF 16V', 'Capacitor Eletrolítico 10UF 16V', 27, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(100, 'Capacitor Eletrolítico 10UF 25V', 'Capacitor Eletrolítico 10UF 25V', 10, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(101, 'Capacitor Eletrolítico 10UF 50V', 'Capacitor Eletrolítico 10UF 50V', 55, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(102, 'Capacitor Eletrolítico 10UF 63V', 'Capacitor Eletrolítico 10UF 63V', 0, 'indisponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(103, 'Capacitor Eletrolítico 1500UF 16V', 'Capacitor Eletrolítico 1500UF 16V', 91, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(104, 'Capacitor Eletrolítico 1UF 25V', 'Capacitor Eletrolítico 1UF 25V', 30, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(105, 'Capacitor Eletrolítico 1UF 50V', 'Capacitor Eletrolítico 1UF 50V', 51, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(106, 'Capacitor Eletrolítico 2,2UF 100V', 'Capacitor Eletrolítico 2,2UF 100V', 44, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(107, 'Capacitor Eletrolítico 2,2UF 50V', 'Capacitor Eletrolítico 2,2UF 50V', 85, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(108, 'Capacitor Eletrolítico 2200UF 10V', 'Capacitor Eletrolítico 2200UF 10V', 276, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(109, 'Capacitor Eletrolítico 2200UF 25V', 'Capacitor Eletrolítico 2200UF 25V', 60, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(110, 'Capacitor Eletrolítico 220UF 16V', 'Capacitor Eletrolítico 220UF 16V', 45, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(111, 'Capacitor Eletrolítico 220UF 25V', 'Capacitor Eletrolítico 220UF 25V', 70, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(112, 'Capacitor Eletrolítico 22UF 16V', 'Capacitor Eletrolítico 22UF 16V', 30, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(113, 'Capacitor Eletrolítico 22UF 25V', 'Capacitor Eletrolítico 22UF 25V', 99, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(114, 'Capacitor Eletrolítico 22UF 400V', 'Capacitor Eletrolítico 22UF 400V', 36, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(115, 'Capacitor Eletrolítico 3,3UF 100V', 'Capacitor Eletrolítico 3,3UF 100V', 39, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(116, 'Capacitor Eletrolítico 3,3UF 50V', 'Capacitor Eletrolítico 3,3UF 50V', 31, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(117, 'Capacitor Eletrolítico 330UF 25V', 'Capacitor Eletrolítico 330UF 25V', 47, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(118, 'Capacitor Eletrolítico 330UF 50V', 'Capacitor Eletrolítico 330UF 50V', 100, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(119, 'Capacitor Eletrolítico 33UF 25V', 'Capacitor Eletrolítico 33UF 25V', 106, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(120, 'Capacitor Eletrolítico 4,7UF 160V', 'Capacitor Eletrolítico 4,7UF 160V', 33, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(121, 'Capacitor Eletrolítico 4,7UF 25V', 'Capacitor Eletrolítico 4,7UF 25V', 44, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(122, 'Capacitor Eletrolítico 4,7UF 50V', 'Capacitor Eletrolítico 4,7UF 50V', 35, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(123, 'Capacitor Eletrolítico 4700UF 25V', 'Capacitor Eletrolítico 4700UF 25V', 39, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(124, 'Capacitor Eletrolítico 470UF 25V', 'Capacitor Eletrolítico 470UF 25V', 1, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(125, 'Capacitor Eletrolítico 470UF 50V', 'Capacitor Eletrolítico 470UF 50V', 94, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(126, 'Capacitor Eletrolítico 47UF 16V', 'Capacitor Eletrolítico 47UF 16V', 32, 'disponivel', '2025-08-30 00:30:46', '2025-08-30 00:30:46'),
(127, 'Capacitor Eletrolítico 47UF 25V', 'Capacitor Eletrolítico 47UF 25V', 78, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(128, 'Capacitor Eletrolítico 47UF 50V ', 'Capacitor Eletrolítico 47UF 50V ', 85, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(129, 'Capacitor Eletrolítico 560UF 200V', 'Capacitor Eletrolítico 560UF 200V', 1, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(130, 'Capacitor Eletrolítico 6,8UF 63V', 'Capacitor Eletrolítico 6,8UF 63V', 5, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(131, 'Capacitor Eletrolítico 60UF 250V', 'Capacitor Eletrolítico 60UF 250V', 7, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(132, 'Capacitor Eletrolítico 680UF 25V', 'Capacitor Eletrolítico 680UF 25V', 11, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(133, 'Capacitor Eletrolítico 68UF 250V', 'Capacitor Eletrolítico 68UF 250V', 22, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(134, 'Capacitor Poliester 0.68J', 'Capacitor Poliester 0.68J', 66, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(135, 'Capacitor Poliester 100NF104K 50V', 'Capacitor Poliester 100NF104K 50V', 44, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(136, 'Capacitor Poliester 103J', 'Capacitor Poliester 103J', 100, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(137, 'Capacitor Poliester 104J ( 250V )', 'Capacitor Poliester 104J ( 250V )', 83, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(138, 'Capacitor Poliester 1M224J', 'Capacitor Poliester 1M224J', 101, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(139, 'Capacitor Poliester 1N0J', 'Capacitor Poliester 1N0J', 90, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(140, 'Capacitor Poliester 224', 'Capacitor Poliester 224', 18, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(141, 'Capacitor Poliester 224J ( 250V )', 'Capacitor Poliester 224J ( 250V )', 20, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(142, 'Capacitor Poliester 22K63', 'Capacitor Poliester 22K63', 17, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(143, 'Capacitor Poliester 2A334K', 'Capacitor Poliester 2A334K', 14, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(144, 'Capacitor Poliester 2A68L', 'Capacitor Poliester 2A68L', 89, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(145, 'Capacitor Poliester 2E473J', 'Capacitor Poliester 2E473J', 85, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(146, 'Capacitor Poliester 334', 'Capacitor Poliester 334', 3, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(147, 'Capacitor Poliester 33M63', 'Capacitor Poliester 33M63', 83, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(148, 'Capacitor Poliester 33NK63', 'Capacitor Poliester 33NK63', 50, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(149, 'Capacitor Poliester 474', 'Capacitor Poliester 474', 88, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(150, 'Capacitor Poliester 47NJ', 'Capacitor Poliester 47NJ', 85, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(151, 'Capacitor Poliester 47NK63', 'Capacitor Poliester 47NK63', 31, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(152, 'Capacitor Poliester 683K (250V )', 'Capacitor Poliester 683K (250V )', 85, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(153, 'Capacitor Poliester 684', 'Capacitor Poliester 684', 14, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(154, 'Capacitor Poliester 68NJ', 'Capacitor Poliester 68NJ', 61, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(155, 'Capacitor Poliester CBB22 250V 223JOCY', 'Capacitor Poliester CBB22 250V 223JOCY', 83, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(156, 'Capacitor Poliester LI05J /EI201', 'Capacitor Poliester LI05J /EI201', 45, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(157, 'Capacitor Poliester LI05J /EI20J', 'Capacitor Poliester LI05J /EI20J', 43, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(158, 'Capacitor Poliester 2A152J', 'Capacitor Poliester 2A152J', 79, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(159, 'Capacitor Poliester 2A223J', 'Capacitor Poliester 2A223J', 73, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(160, 'Capacitor Poliester 2A222J', 'Capacitor Poliester 2A222J', 82, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(161, 'Capacitor R NTL100-11', 'Capacitor R NTL100-11', 0, 'indisponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(162, 'Capacitor Variavel  ', 'Capacitor Variavel  ', 54, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(163, 'Cartucho de Toner Amarelo SMSCLP680', 'Cartucho de Toner Amarelo SMSCLP680', 1, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(164, 'Cartucho de Toner Ciano SMSCLP680', 'Cartucho de Toner Ciano SMSCLP680', 0, 'indisponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(165, 'Cartucho de Toner Magenta SMSCLP680', 'Cartucho de Toner Magenta SMSCLP680', 0, 'indisponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(166, 'Cartucho de Toner Preto SMSCLP680', 'Cartucho de Toner Preto SMSCLP680', 0, 'indisponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(167, 'Chave Canhão 03mm ', 'Chave Canhão 03mm ', 17, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(168, 'Chave Canhão 06mm ', 'Chave Canhão 06mm ', 12, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(169, 'Chave Canhão 09mm ', 'Chave Canhão 09mm ', 14, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(170, 'Chave de Fenda 1/4x4 ', 'Chave de Fenda 1/4x4 ', 2, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(171, 'Chave de Fenda 1/8x5 ', 'Chave de Fenda 1/8x5 ', 0, 'indisponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(172, 'Chave de Fenda 3/16x5 ', 'Chave de Fenda 3/16x5 ', 1, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(173, 'Chave de Fenda 3/16x8 ', 'Chave de Fenda 3/16x8 ', 2, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(174, 'Chave Phillips ', 'Chave Phillips ', 0, 'indisponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(175, 'Chave Seletora', 'Chave Seletora', 21, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(176, 'Circuito Integrado 025', 'Circuito Integrado 025', 11, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(177, 'Circuito Integrado 071', 'Circuito Integrado 071', 73, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(178, 'Circuito Integrado 0804', 'Circuito Integrado 0804', 54, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(179, 'Circuito Integrado 14512', 'Circuito Integrado 14512', 6, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(180, 'Circuito Integrado 16628', 'Circuito Integrado 16628', 0, 'indisponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(181, 'Circuito Integrado 324', 'Circuito Integrado 324', 58, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(182, 'Circuito Integrado 4000', 'Circuito Integrado 4000', 24, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(183, 'Circuito Integrado 4001', 'Circuito Integrado 4001', 77, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(184, 'Circuito Integrado 4002', 'Circuito Integrado 4002', 68, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(185, 'Circuito Integrado 4011', 'Circuito Integrado 4011', 107, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(186, 'Circuito Integrado 4012', 'Circuito Integrado 4012', 74, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(187, 'Circuito Integrado 4013', 'Circuito Integrado 4013', 107, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(188, 'Circuito Integrado 4014', 'Circuito Integrado 4014', 52, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(189, 'Circuito Integrado 4015', 'Circuito Integrado 4015', 26, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(190, 'Circuito Integrado 4016', 'Circuito Integrado 4016', 59, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(191, 'Circuito Integrado 4017', 'Circuito Integrado 4017', 43, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(192, 'Circuito Integrado 4020', 'Circuito Integrado 4020', 71, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(193, 'Circuito Integrado 4021', 'Circuito Integrado 4021', 55, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(194, 'Circuito Integrado 4023', 'Circuito Integrado 4023', 100, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(195, 'Circuito Integrado 4027', 'Circuito Integrado 4027', 50, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(196, 'Circuito Integrado 4028', 'Circuito Integrado 4028', 26, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(197, 'Circuito Integrado 4029', 'Circuito Integrado 4029', 59, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(198, 'Circuito Integrado 4040', 'Circuito Integrado 4040', 48, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(199, 'Circuito Integrado 4045', 'Circuito Integrado 4045', 0, 'indisponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(200, 'Circuito Integrado 4049', 'Circuito Integrado 4049', 16, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(201, 'Circuito Integrado 4051', 'Circuito Integrado 4051', 90, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(202, 'Circuito Integrado 4052', 'Circuito Integrado 4052', 112, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(203, 'Circuito Integrado 4053', 'Circuito Integrado 4053', 106, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(204, 'Circuito Integrado 4060', 'Circuito Integrado 4060', 95, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(205, 'Circuito Integrado 4066', 'Circuito Integrado 4066', 107, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(206, 'Circuito Integrado 4070', 'Circuito Integrado 4070', 76, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(207, 'Circuito Integrado 4071', 'Circuito Integrado 4071', 48, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(208, 'Circuito Integrado 4072', 'Circuito Integrado 4072', 45, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(209, 'Circuito Integrado 4077', 'Circuito Integrado 4077', 38, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(210, 'Circuito Integrado 4081', 'Circuito Integrado 4081', 130, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(211, 'Circuito Integrado 4082', 'Circuito Integrado 4082', 71, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(212, 'Circuito Integrado 4093', 'Circuito Integrado 4093', 104, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(213, 'Circuito Integrado 4096', 'Circuito Integrado 4096', 48, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(214, 'Circuito Integrado 412', 'Circuito Integrado 412', 46, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(215, 'Circuito Integrado 7426', 'Circuito Integrado 7426', 53, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(216, 'Circuito Integrado 4510', 'Circuito Integrado 4510', 74, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(217, 'Circuito Integrado 4511', 'Circuito Integrado 4511', 102, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(218, 'Circuito Integrado 4512', 'Circuito Integrado 4512', 12, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(219, 'Circuito Integrado 4N33', 'Circuito Integrado 4N33', 0, 'indisponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(220, 'Circuito Integrado 555', 'Circuito Integrado 555', 59, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(221, 'Circuito Integrado 718/0808', 'Circuito Integrado 718/0808', 9, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(222, 'Circuito Integrado 7400', 'Circuito Integrado 7400', 125, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(223, 'Circuito Integrado 7402', 'Circuito Integrado 7402', 141, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(224, 'Circuito Integrado 7403', 'Circuito Integrado 7403', 69, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(225, 'Circuito Integrado 7404', 'Circuito Integrado 7404', 180, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(226, 'Circuito Integrado 7406', 'Circuito Integrado 7406', 51, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(227, 'Circuito Integrado 7407', 'Circuito Integrado 7407', 11, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(228, 'Circuito Integrado 7408', 'Circuito Integrado 7408', 91, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(229, 'Circuito Integrado 741', 'Circuito Integrado 741', 100, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(230, 'Circuito Integrado 7411', 'Circuito Integrado 7411', 38, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(231, 'Circuito Integrado 74121', 'Circuito Integrado 74121', 4, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(232, 'Circuito Integrado 74122', 'Circuito Integrado 74122', 22, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(233, 'Circuito Integrado 74126', 'Circuito Integrado 74126', 105, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(234, 'Circuito Integrado 7413', 'Circuito Integrado 7413', 5, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(235, 'Circuito Integrado 74132', 'Circuito Integrado 74132', 51, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(236, 'Circuito Integrado 74138', 'Circuito Integrado 74138', 5, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(237, 'Circuito Integrado 7414', 'Circuito Integrado 7414', 11, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(238, 'Circuito Integrado 7415', 'Circuito Integrado 7415', 46, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(239, 'Circuito Integrado 74151', 'Circuito Integrado 74151', 23, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(240, 'Circuito Integrado 74153', 'Circuito Integrado 74153', 71, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(241, 'Circuito Integrado 74155', 'Circuito Integrado 74155', 33, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(242, 'Circuito Integrado 74157', 'Circuito Integrado 74157', 14, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(243, 'Circuito Integrado 74160', 'Circuito Integrado 74160', 11, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(244, 'Circuito Integrado 74161', 'Circuito Integrado 74161', 16, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(245, 'Circuito Integrado 74163', 'Circuito Integrado 74163', 66, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(246, 'Circuito Integrado 74165', 'Circuito Integrado 74165', 17, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(247, 'Circuito Integrado 74166', 'Circuito Integrado 74166', 11, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(248, 'Circuito Integrado 74192', 'Circuito Integrado 74192', 84, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(249, 'Circuito Integrado 74193', 'Circuito Integrado 74193', 52, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(250, 'Circuito Integrado 74194', 'Circuito Integrado 74194', 17, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(251, 'Circuito Integrado 7420', 'Circuito Integrado 7420', 25, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(252, 'Circuito Integrado 7421', 'Circuito Integrado 7421', 24, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(253, 'Circuito Integrado 7423', 'Circuito Integrado 7423', 18, 'disponivel', '2025-08-30 00:30:47', '2025-08-30 00:30:47'),
(254, 'Circuito Integrado 7425', 'Circuito Integrado 7425', 20, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(255, 'Circuito Integrado 7427', 'Circuito Integrado 7427', 60, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(256, 'Circuito Integrado 7430', 'Circuito Integrado 7430', 14, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(257, 'Circuito Integrado 7432', 'Circuito Integrado 7432', 131, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(258, 'Circuito Integrado 74368', 'Circuito Integrado 74368', 2, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(259, 'Circuito Integrado 74373', 'Circuito Integrado 74373', 40, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(260, 'Circuito Integrado 74374', 'Circuito Integrado 74374', 34, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(261, 'Circuito Integrado 74379', 'Circuito Integrado 74379', 19, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(262, 'Circuito Integrado 74390', 'Circuito Integrado 74390', 69, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(263, 'Circuito Integrado 74393', 'Circuito Integrado 74393', 43, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(264, 'Circuito Integrado 744020', 'Circuito Integrado 744020', 45, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(265, 'Circuito Integrado 7442', 'Circuito Integrado 7442', 17, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(266, 'Circuito Integrado 7445', 'Circuito Integrado 7445', 1, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(267, 'Circuito Integrado 7447', 'Circuito Integrado 7447', 21, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(268, 'Circuito Integrado 74501', 'Circuito Integrado 74501', 50, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(269, 'Circuito Integrado 74502', 'Circuito Integrado 74502', 47, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(270, 'Circuito Integrado 74509', 'Circuito Integrado 74509', 50, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(271, 'Circuito Integrado 74514', 'Circuito Integrado 74514', 61, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(272, 'Circuito Integrado 74520', 'Circuito Integrado 74520', 30, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(273, 'Circuito Integrado 74530', 'Circuito Integrado 74530', 83, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(274, 'Circuito Integrado 74533', 'Circuito Integrado 74533', 10, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(275, 'Circuito Integrado 74590', 'Circuito Integrado 74590', 55, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(276, 'Circuito Integrado 74595', 'Circuito Integrado 74595', 13, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(277, 'Circuito Integrado 7460', 'Circuito Integrado 7460', 18, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(278, 'Circuito Integrado 7473', 'Circuito Integrado 7473', 52, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(279, 'Circuito Integrado 7474', 'Circuito Integrado 7474', 100, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(280, 'Circuito Integrado 7475', 'Circuito Integrado 7475', 5, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(281, 'Circuito Integrado 7476', 'Circuito Integrado 7476', 36, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(282, 'Circuito Integrado 7486', 'Circuito Integrado 7486', 126, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(283, 'Circuito Integrado 7490', 'Circuito Integrado 7490', 90, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(284, 'Circuito Integrado 7491', 'Circuito Integrado 7491', 36, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(285, 'Circuito Integrado 7493', 'Circuito Integrado 7493', 93, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(286, 'Circuito Integrado 7495', 'Circuito Integrado 7495', 79, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(287, 'Circuito Integrado 8951', 'Circuito Integrado 8951', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(288, 'Conduite Eletroduto ', 'Conduite Eletroduto ', 2, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(289, 'Conector RJ45 Macho', 'Conector RJ45 Macho', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(290, 'Conector RJ45 Fêmea', 'Conector RJ45 Fêmea', 280, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(291, 'Conector Saída Caixa Multipla', 'Conector Saída Caixa Multipla', 20, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(292, 'Console Cable V2', 'Console Cable V2', 11, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(293, 'Contador Auxiliar CA2KN22M7 ', 'Contador Auxiliar CA2KN22M7 ', 5, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(294, 'Controle de TV Samsung', 'Controle de TV Samsung', 2, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(295, 'Conversor de mídia UTP/ST Ethernet AT-MC ', 'Conversor de mídia UTP/ST Ethernet AT-MC ', 8, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(296, 'Cotovelo Interno 50x20mm ', 'Cotovelo Interno 50x20mm ', 13, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(297, 'Desencapador de fios', 'Desencapador de fios', 26, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(298, 'Development Kit', 'Development Kit', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(299, 'Dio Furukawa A-145 ', 'Dio Furukawa A-145 ', 8, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(300, 'Diodo 1N4001 BE', 'Diodo 1N4001 BE', 202, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(301, 'Diodo 1N4004', 'Diodo 1N4004', 31, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(302, 'Diodo 1N4007', 'Diodo 1N4007', 14, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(303, 'Diodo 1N4148', 'Diodo 1N4148', 240, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(304, 'Diodo 1N4733', 'Diodo 1N4733', 5, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(305, 'Diodo 1N60P', 'Diodo 1N60P', 25, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(306, 'Diodo 1N754A120', 'Diodo 1N754A120', 23, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(307, 'Diodo 1N75SA', 'Diodo 1N75SA', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(308, 'Diodo PHBZX79C6V8', 'Diodo PHBZX79C6V8', 15, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(309, 'Diodo 5408', 'Diodo 5408', 4, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(310, 'Diodo B1X56C10', 'Diodo B1X56C10', 56, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(311, 'Diodo BZX55C3V', 'Diodo BZX55C3V', 17, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(312, 'Diodo D45B 8029', 'Diodo D45B 8029', 3, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(313, 'Diodo DB3', 'Diodo DB3', 50, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(314, 'Diodo PHC3V3', 'Diodo PHC3V3', 35, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(315, 'Diodo PHC5V1', 'Diodo PHC5V1', 56, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(316, 'Disjuntor monofasico', 'Disjuntor monofasico', 39, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(317, 'Disjuntor Bifásico ', 'Disjuntor Bifásico ', 8, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(318, 'Disjuntor trifasico', 'Disjuntor trifasico', 9, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(319, 'Display LCD', 'Display LCD', 3, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(320, 'Dispositivo De Aplicação Virtual', 'Dispositivo De Aplicação Virtual', 1, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(321, 'Dissipador HP ', 'Dissipador HP ', 10, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(322, 'Esponja Metálica  ', 'Esponja Metálica  ', 5, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(323, 'Estabilizador (SALA MAKER)', 'Estabilizador (SALA MAKER)', 21, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(324, 'Estação de Solda Analógica HK-936ESD ', 'Estação de Solda Analógica HK-936ESD ', 11, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(325, 'Estação de Solda e Retrabalho 878D', 'Estação de Solda e Retrabalho 878D', 2, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(326, 'Estação de Solda FT-E50W ', 'Estação de Solda FT-E50W ', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(327, 'Estanhador de Fios CT-11C ', 'Estanhador de Fios CT-11C ', 1, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(328, 'Estilete', 'Estilete', 11, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(329, 'Exaustor de Fumaça HK-707', 'Exaustor de Fumaça HK-707', 1, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(330, 'Extensão Elétrica Multipla 5M', 'Extensão Elétrica Multipla 5M', 7, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(331, 'Fechaduras MM com Chave', 'Fechaduras MM com Chave', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(332, 'Ferro de Solda ', 'Ferro de Solda ', 14, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(333, 'Filtro Secador DML163 ', 'Filtro Secador DML163 ', 2, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(334, 'Fios Circuito', 'Fios Circuito', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(335, 'Fios Eletrônica p/2', 'Fios Eletrônica p/2', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(336, 'Fios Eletrônica p/2 Coloridos', 'Fios Eletrônica p/2 Coloridos', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(337, 'Fios p/ Circuitos ', 'Fios p/ Circuitos ', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(338, 'Fita Capacitor Ceramico ', 'Fita Capacitor Ceramico ', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(339, 'Fita Dessoldadora', 'Fita Dessoldadora', 4, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(340, 'Fita Isolante Preta', 'Fita Isolante Preta', 1, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(341, 'Fonte DC', 'Fonte DC', 1, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(342, 'Fonte TP2305C', 'Fonte TP2305C', 4, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(343, 'Galaxy S21 FE 5G Muraki', 'Galaxy S21 FE 5G Muraki', 19, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(344, 'Gerador de Função TFG22', 'Gerador de Função TFG22', 4, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(345, 'Grampeador De Pressao', 'Grampeador De Pressao', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(346, 'Grampos ', 'Grampos ', 15, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(347, 'HD externo ', 'HD externo ', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(348, 'Interface de Comando Industrial', 'Interface de Comando Industrial', 26, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(349, 'Interruptor Diferencial 4P 63A ', 'Interruptor Diferencial 4P 63A ', 2, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(350, 'Iphone 13 Mini Muraki', 'Iphone 13 Mini Muraki', 24, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(351, 'Kit Conjunto Manômetro R22/134ª/404AM ', 'Kit Conjunto Manômetro R22/134ª/404AM ', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(352, 'Kit CPLD', 'Kit CPLD', 10, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(353, 'Kit de Punção P/ Perfurador ', 'Kit de Punção P/ Perfurador ', 8, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(354, 'Kit Diático CLP KDCLP-01 ', 'Kit Diático CLP KDCLP-01 ', 1, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(355, 'Kit Diático para Circuitos ', 'Kit Diático para Circuitos ', 1, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(356, 'Kit Eletrônico Digital', 'Kit Eletrônico Digital', 7, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(357, 'Kit fonte Multímetro Digital 830B ', 'Kit fonte Multímetro Digital 830B ', 1, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(358, 'Lâmpada Bulbo A60', 'Lâmpada Bulbo A60', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(359, 'Lâmpada LED T8 18W', 'Lâmpada LED T8 18W', 0, 'indisponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(360, 'Lâmpadas ', 'Lâmpadas ', 20, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(361, 'Lâmpadas Hológena', 'Lâmpadas Hológena', 4, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(362, 'Lápis ', 'Lápis ', 20, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(363, 'Localizador de Cabo de Rede Kit', 'Localizador de Cabo de Rede Kit', 2, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(364, 'Lupa com Suporte e Pinça HL-S10 ', 'Lupa com Suporte e Pinça HL-S10 ', 1, 'disponivel', '2025-08-30 00:30:48', '2025-08-30 00:30:48'),
(365, 'Luvas Antiestáticas ', 'Luvas Antiestáticas ', 126, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(366, 'Maleta de ferramenta', 'Maleta de ferramenta', 10, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(367, 'Marca Texto', 'Marca Texto', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(368, 'Marcador de Pizarra', 'Marcador de Pizarra', 115, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(369, 'Marcador Permanente ', 'Marcador Permanente ', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(370, 'Mata-Junta 50x20mm ', 'Mata-Junta 50x20mm ', 14, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(371, 'Microcontrolador de treino', 'Microcontrolador de treino', 10, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(372, 'Microfone Dinamico sem fio', 'Microfone Dinamico sem fio', 1, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(373, 'Micrômetro Externo 0-25mm ', 'Micrômetro Externo 0-25mm ', 11, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(374, 'Modulo Luva 50x20mm ', 'Modulo Luva 50x20mm ', 15, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(375, 'Módulo Microcontrolador', 'Módulo Microcontrolador', 2, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(376, 'Modulo Placa 4x4 ', 'Modulo Placa 4x4 ', 50, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(377, 'Monitor', 'Monitor', 10, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(378, 'Mouse sem fio Sem adaptador', 'Mouse sem fio Sem adaptador', 7, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(379, 'Mouse com fio ', 'Mouse com fio ', 3, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(380, 'Mouse com fio Logetech', 'Mouse com fio Logetech', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(381, 'Mouse sem fio Logetech Sem adaptador', 'Mouse sem fio Logetech Sem adaptador', 12, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(382, 'Mouse sem fio Logetech ', 'Mouse sem fio Logetech ', 36, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(383, 'Multímetro Digital DM-1000 ', 'Multímetro Digital DM-1000 ', 1, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(384, 'Multímetro Digital DT- 831B+ ', 'Multímetro Digital DT- 831B+ ', 7, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(385, 'Multímetro Digital DT-830B ', 'Multímetro Digital DT-830B ', 5, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(386, 'Módulo leito de acerto RFID', 'Módulo leito de acerto RFID', 1, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(387, 'Módulo FTDI Basic', 'Módulo FTDI Basic', 3, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(388, 'Módulo Ethernet', 'Módulo Ethernet', 1, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(389, 'Módulo Semáforo', 'Módulo Semáforo', 2, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(390, 'Módulo HX711 conversor analogico Digital', 'Módulo HX711 conversor analogico Digital', 1, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(391, 'Módulo XBEE Com antena e adptador ', 'Módulo XBEE Com antena e adptador ', 3, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(392, 'Módulo XBEE Com antena  ', 'Módulo XBEE Com antena  ', 5, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(393, 'Módulo bluetooth HC-05', 'Módulo bluetooth HC-05', 1, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(394, 'Módulo MP3 WTV 020D', 'Módulo MP3 WTV 020D', 2, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(395, 'Módulo Recptor Infra-vermelho', 'Módulo Recptor Infra-vermelho', 1, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(396, 'Módulo Amperimetro CC', 'Módulo Amperimetro CC', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(397, 'MÓDULO AMPERÍMETRO CA', 'MÓDULO AMPERÍMETRO CA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(398, 'MÓDULO CHAVE SELETORA 2NA+2NF', 'MÓDULO CHAVE SELETORA 2NA+2NF', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(399, 'MÓDULO WATTIMETRO', 'MÓDULO WATTIMETRO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(400, 'MÓDULO COSFÍMETRO', 'MÓDULO COSFÍMETRO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(401, 'MÓDULO FREQUENCÍMETRO', 'MÓDULO FREQUENCÍMETRO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(402, 'MÓDULO INTERLIGAÇÕES', 'MÓDULO INTERLIGAÇÕES', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(403, 'MÓDULO DIMMER E LÂMPADA', 'MÓDULO DIMMER E LÂMPADA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(404, 'MÓDULO CONTATOR AUXILIAR 24 Vcc', 'MÓDULO CONTATOR AUXILIAR 24 Vcc', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(405, 'MÓDULO RELÉ TÉRMICO 2,8...4A', 'MÓDULO RELÉ TÉRMICO 2,8...4A', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49');
INSERT INTO `materiais` (`id`, `nome`, `descricao`, `quantidade`, `status_disponibilidade`, `created_at`, `updated_at`) VALUES
(406, 'MÓDULO RELÉ TEMPORIZADOR 24 Vcc', 'MÓDULO RELÉ TEMPORIZADOR 24 Vcc', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(407, 'MÓDULO DE SEGURANÇA', 'MÓDULO DE SEGURANÇA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(408, 'MÓDULO RELÉ TEMPORIZADOR Y-Δ', 'MÓDULO RELÉ TEMPORIZADOR Y-Δ', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(409, 'MÓDULO RELÉ FOTOELÉTRICO', 'MÓDULO RELÉ FOTOELÉTRICO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(410, 'MÓDULO RELÊ COMUTADOR', 'MÓDULO RELÊ COMUTADOR', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(411, 'MÓDULO RELÉ DE ESTADO SÓLIDO', 'MÓDULO RELÉ DE ESTADO SÓLIDO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(412, 'MÓDULO RELÉ DE SOBRECARGA', 'MÓDULO RELÉ DE SOBRECARGA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(413, 'MÓDULO RELÉ FALTA DE FASE', 'MÓDULO RELÉ FALTA DE FASE', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(414, 'MÓDULO RELÉ TEMPORIZADOR', 'MÓDULO RELÉ TEMPORIZADOR', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(415, 'MÓDULO RELÉ SEGURANÇA', 'MÓDULO RELÉ SEGURANÇA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(416, 'MÓDULO RESISTORES 10W', 'MÓDULO RESISTORES 10W', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(417, 'MÓDULO FIM DE CURSO', 'MÓDULO FIM DE CURSO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(418, 'MÓDULO CONTROLADOR DE TEMPERATURA', 'MÓDULO CONTROLADOR DE TEMPERATURA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(419, 'MÓDULO RETIFICADOR', 'MÓDULO RETIFICADOR', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(420, 'MÓDULO CONTATOR TRIPOLAR', 'MÓDULO CONTATOR TRIPOLAR', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(421, 'MÓDULO CONTATOR AUXILIAR', 'MÓDULO CONTATOR AUXILIAR', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(422, 'MÓDULO DISJUNTOR MONOPOLAR', 'MÓDULO DISJUNTOR MONOPOLAR', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(423, 'MODULO BOTÃO DE EMERGÊNCIA', 'MODULO BOTÃO DE EMERGÊNCIA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(424, 'MÓDULO CHAVE FIM DE CURSO', 'MÓDULO CHAVE FIM DE CURSO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(425, 'MODULO CAMPAINHA', 'MODULO CAMPAINHA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(426, 'MÓDULO INTERRUPTOR SIMPLES E PARALELO', 'MÓDULO INTERRUPTOR SIMPLES E PARALELO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(427, 'MÓDULO QUADRO DE DISJUNTORES', 'MÓDULO QUADRO DE DISJUNTORES', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(428, 'MÓDULO FUSÍVEIS', 'MÓDULO FUSÍVEIS', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(429, 'MÓDULO 3 FUSÍVEIS 25A', 'MÓDULO 3 FUSÍVEIS 25A', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(430, 'MÓDULO CAPACITORES', 'MÓDULO CAPACITORES', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(431, 'MÓDULO DISJUNTOR MOTOR ', 'MÓDULO DISJUNTOR MOTOR ', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(432, 'MODULO FONTE DE TENSÃO', 'MODULO FONTE DE TENSÃO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(433, 'MÓDULO BOTÃO PULSADOR 2NA + 2NF', 'MÓDULO BOTÃO PULSADOR 2NA + 2NF', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(434, 'MÓDULO SINALEIROS LED - 24 VCC', 'MÓDULO SINALEIROS LED - 24 VCC', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(435, 'MÓDULO BOTOEIRA 2NA+2NF', 'MÓDULO BOTOEIRA 2NA+2NF', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(436, 'MÓDULO 3 SINALEIROS', 'MÓDULO 3 SINALEIROS', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(437, 'MÓDULO CENTRAL TELEFONICA', 'MÓDULO CENTRAL TELEFONICA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(438, 'MODULO M MEDIDOR DE EN ENERGIA ATIVA', 'MODULO M MEDIDOR DE EN ENERGIA ATIVA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(439, 'MÓDULO CENTRAL DE ALARME', 'MÓDULO CENTRAL DE ALARME', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(440, 'MODULO INDUTOR', 'MODULO INDUTOR', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(441, 'MÓDULO CAMPAINHA', 'MÓDULO CAMPAINHA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(442, 'MÓDULO LAMPADAS FLUORESCENTES', 'MÓDULO LAMPADAS FLUORESCENTES', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(443, 'MÓDULO SENSOR INFRAVERMELHO', 'MÓDULO SENSOR INFRAVERMELHO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(444, 'MÓDULO TERMOSTATO', 'MÓDULO TERMOSTATO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(445, 'MÓDULO SENSOR DE ABERTURA COM FIO', 'MÓDULO SENSOR DE ABERTURA COM FIO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(446, 'MÓDULO SENSOR DE ABERTURA SEM FIO', 'MÓDULO SENSOR DE ABERTURA SEM FIO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(447, 'MÓDULO RESISTIVO', 'MÓDULO RESISTIVO', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(448, 'MÓDULO SIMULAÇÃO DE DEFEITOS', 'MÓDULO SIMULAÇÃO DE DEFEITOS', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(449, 'Multímetro Digital ET-1100A ', 'Multímetro Digital ET-1100A ', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(450, 'Nobreak EasyWay ', 'Nobreak EasyWay ', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(451, 'Óculos de Segurança ', 'Óculos de Segurança ', 46, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(452, 'Optic Analog', 'Optic Analog', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(453, 'Osciloscópio Digital TSO1102C+', 'Osciloscópio Digital TSO1102C+', 3, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(454, 'PCB com sensor de vibração', 'PCB com sensor de vibração', 2, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(455, 'Pastilha Piezoeletrica ', 'Pastilha Piezoeletrica ', 12, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(456, 'Paquímetro Analógico 300mm/12 ', 'Paquímetro Analógico 300mm/12 ', 83, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(457, 'Paquímetro Digital 150mm/6 ', 'Paquímetro Digital 150mm/6 ', 4, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(458, 'Par de Luvas Vaqueta Mista 16475 ', 'Par de Luvas Vaqueta Mista 16475 ', 10, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(459, 'Pasta Termica 100g', 'Pasta Termica 100g', 16, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(460, 'Pilha AA', 'Pilha AA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(461, 'Pilha AAA', 'Pilha AAA', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(462, 'Pinça', 'Pinça', 24, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(463, 'Pinça antiestática', 'Pinça antiestática', 59, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(464, 'Pincel antiestático', 'Pincel antiestático', 19, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(465, 'Pino Condutor Colorido ', 'Pino Condutor Colorido ', 4, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(466, 'Pistola de Cola Quente', 'Pistola de Cola Quente', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(467, 'Placa Analogica Digital', 'Placa Analogica Digital', 0, 'indisponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(468, 'Placa Arduino', 'Placa Arduino', 3, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(469, 'Placa Bread Board', 'Placa Bread Board', 15, 'disponivel', '2025-08-30 00:30:49', '2025-08-30 00:30:49'),
(470, 'Placa Buffer', 'Placa Buffer', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(471, 'Placa Comparador de Magnitude ', 'Placa Comparador de Magnitude ', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(472, 'Placa de Automação AI-8S', 'Placa de Automação AI-8S', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(473, 'Placa de Logica Gates', 'Placa de Logica Gates', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(474, 'Placa Decodificador Binário', 'Placa Decodificador Binário', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(475, 'Placa Eprom', 'Placa Eprom', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(476, 'Placa Ethernet ( Arduino )', 'Placa Ethernet ( Arduino )', 4, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(477, 'Placa Flip-Flop', 'Placa Flip-Flop', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(478, 'Placa Sistema X para XRJ45 ', 'Placa Sistema X para XRJ45 ', 13, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(479, 'Ponta de Prova de Osciloscópio LF-20A/ LF-60/ LF-100A ', 'Ponta de Prova de Osciloscópio LF-20A/ LF-60/ LF-100A ', 5, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(480, 'Ponta de Prova de Osciloscópio MTL-21 ', 'Ponta de Prova de Osciloscópio MTL-21 ', 21, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(481, 'Ponta de Prova de Osciloscópio P2200 ', 'Ponta de Prova de Osciloscópio P2200 ', 5, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(482, 'Ponta de Prova de Osciloscópio UT-P00 ', 'Ponta de Prova de Osciloscópio UT-P00 ', 11, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(483, 'Pontas de Prova Multímetro Jacaré HK-23 ', 'Pontas de Prova Multímetro Jacaré HK-23 ', 11, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(484, 'Pontas de Prova PPM-300 ', 'Pontas de Prova PPM-300 ', 58, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(485, 'Protetor Auricular 30Db ', 'Protetor Auricular 30Db ', 2, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(486, 'Protoboard Hk-P400', 'Protoboard Hk-P400', 12, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(487, 'Protoboard MP-830A', 'Protoboard MP-830A', 9, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(488, 'Pulseira Antiestática N68-S', 'Pulseira Antiestática N68-S', 38, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(489, 'Quadro de Distribuição ', 'Quadro de Distribuição ', 5, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(490, 'Régua 50cm ', 'Régua 50cm ', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(491, 'Régua 100cm', 'Régua 100cm', 3, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(492, 'Regulador de Tensão AN7809C', 'Regulador de Tensão AN7809C', 2, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(493, 'Regulador de Tensão BD135', 'Regulador de Tensão BD135', 28, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(494, 'Regulador de Tensão BD156', 'Regulador de Tensão BD156', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(495, 'Regulador de Tensão BT137', 'Regulador de Tensão BT137', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(496, 'Regulador de Tensão BT151', 'Regulador de Tensão BT151', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(497, 'Regulador de Tensão D49/30N06L', 'Regulador de Tensão D49/30N06L', 12, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(498, 'Regulador de Tensão G40LP ', 'Regulador de Tensão G40LP ', 4, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(499, 'Regulador de Tensão L7805', 'Regulador de Tensão L7805', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(500, 'Regulador de Tensão L7805CV', 'Regulador de Tensão L7805CV', 49, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(501, 'Regulador de Tensão L7808', 'Regulador de Tensão L7808', 27, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(502, 'Regulador de Tensão L7905CV', 'Regulador de Tensão L7905CV', 74, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(503, 'Regulador de Tensão L7912CV', 'Regulador de Tensão L7912CV', 36, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(504, 'Regulador de Tensão LM317T', 'Regulador de Tensão LM317T', 42, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(505, 'Regulador de Tensão LM338', 'Regulador de Tensão LM338', 4, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(506, 'Regulador de Tensão LM7809C', 'Regulador de Tensão LM7809C', 15, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(507, 'Regulador de Tensão LM7812', 'Regulador de Tensão LM7812', 18, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(508, 'Regulador de Tensão LM7812C', 'Regulador de Tensão LM7812C', 22, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(509, 'Regulador de Tensão P41C', 'Regulador de Tensão P41C', 39, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(510, 'Regulador de Tensão PHG950', 'Regulador de Tensão PHG950', 16, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(511, 'Regulador de Tensão PJD1045', 'Regulador de Tensão PJD1045', 21, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(512, 'Regulador de Tensão RA7909', 'Regulador de Tensão RA7909', 28, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(513, 'Regulador de Tensão SRTG8656', 'Regulador de Tensão SRTG8656', 7, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(514, 'Regulador de Tensão T1C126D', 'Regulador de Tensão T1C126D', 64, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(515, 'Regulador de Tensão TIC106O', 'Regulador de Tensão TIC106O', 26, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(516, 'Regulador de Tensão TIC126D', 'Regulador de Tensão TIC126D', 30, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(517, 'Regulador de Tensão TIP42C', 'Regulador de Tensão TIP42C', 13, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(518, 'Rele térmico', 'Rele térmico', 9, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(519, 'Relógio Comparador 0,01mm ', 'Relógio Comparador 0,01mm ', 12, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(520, 'Resistor 0,1Ω / 5%', 'Resistor 0,1Ω / 5%', 15, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(521, 'Resistor 0,91Ω / 5%', 'Resistor 0,91Ω / 5%', 2, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(522, 'Resistor 0,97Ω / 5%', 'Resistor 0,97Ω / 5%', 15, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(523, 'Resistor 1,1KΩ / 5%', 'Resistor 1,1KΩ / 5%', 59, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(524, 'Resistor 1,2KΩ/ 5%', 'Resistor 1,2KΩ/ 5%', 41, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(525, 'Resistor 1,2MΩ/ 5%', 'Resistor 1,2MΩ/ 5%', 125, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(526, 'Resistor 1,5KΩ / 5%', 'Resistor 1,5KΩ / 5%', 114, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(527, 'Resistor 1,5MΩ / 5%', 'Resistor 1,5MΩ / 5%', 90, 'disponivel', '2025-08-30 00:30:50', '2025-09-01 23:07:19'),
(528, 'Resistor 1,8KΩ / 5%', 'Resistor 1,8KΩ / 5%', 25, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(529, 'Resistor 1,8MΩ / 5%', 'Resistor 1,8MΩ / 5%', 86, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(530, 'Resistor 100KΩ / 5%', 'Resistor 100KΩ / 5%', 33, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(531, 'Resistor 100Ω / 5%', 'Resistor 100Ω / 5%', 46, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(532, 'Resistor 101Ω /5%', 'Resistor 101Ω /5%', 4, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(533, 'Resistor 10KΩ / 5%', 'Resistor 10KΩ / 5%', 95, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(534, 'Resistor 10Ω / 10%', 'Resistor 10Ω / 10%', 159, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(535, 'Resistor 10Ω / 5%', 'Resistor 10Ω / 5%', 90, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(536, 'Resistor 120KΩ /5%', 'Resistor 120KΩ /5%', 66, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(537, 'Resistor 120Ω /5%', 'Resistor 120Ω /5%', 14, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(538, 'Resistor 12KΩ /5% ', 'Resistor 12KΩ /5% ', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(539, 'Resistor 12Ω /5% ', 'Resistor 12Ω /5% ', 21, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(540, 'Resistor 150Ω /5%', 'Resistor 150Ω /5%', 14, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(541, 'Resistor 150KΩ /5%', 'Resistor 150KΩ /5%', 88, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(542, 'Resistor 151Ω /5%', 'Resistor 151Ω /5%', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(543, 'Resistor 15KΩ /5%', 'Resistor 15KΩ /5%', 38, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(544, 'Resistor 180KΩ /5%', 'Resistor 180KΩ /5%', 107, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(545, 'Resistor 18KΩ /5%', 'Resistor 18KΩ /5%', 46, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(546, 'Resistor 1KΩ / 5%', 'Resistor 1KΩ / 5%', 13, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(547, 'Resistor 1MΩ/ 5%', 'Resistor 1MΩ/ 5%', 260, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(548, 'Resistor 1Ω / 5%', 'Resistor 1Ω / 5%', 30, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(549, 'Resistor 2,2KΩ / 5%', 'Resistor 2,2KΩ / 5%', 20, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(550, 'Resistor 2,2MΩ / 5%', 'Resistor 2,2MΩ / 5%', 169, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(551, 'Resistor 2,6KΩ / 5%', 'Resistor 2,6KΩ / 5%', 25, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(552, 'Resistor 2,7KΩ / 5%', 'Resistor 2,7KΩ / 5%', 47, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(553, 'Resistor 2,7MΩ / 5%', 'Resistor 2,7MΩ / 5%', 117, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(554, 'Resistor 200Ω /5%', 'Resistor 200Ω /5%', 168, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(555, 'Resistor 20Ω /5%', 'Resistor 20Ω /5%', 36, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(556, 'Resistor 220KΩ /5%', 'Resistor 220KΩ /5%', 78, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(557, 'Resistor 220Ω /5%', 'Resistor 220Ω /5%', 56, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(558, 'Resistor 22Ω /5%', 'Resistor 22Ω /5%', 1000, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(559, 'Resistor 24.9Ω /1%', 'Resistor 24.9Ω /1%', 97, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(560, 'Resistor 270Ω /5%', 'Resistor 270Ω /5%', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(561, 'Resistor 27KΩ /5%', 'Resistor 27KΩ /5%', 85, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(562, 'Resistor 2KΩ / 5%', 'Resistor 2KΩ / 5%', 1, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(563, 'Resistor 3,3KΩ / 5%', 'Resistor 3,3KΩ / 5%', 580, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(564, 'Resistor 3,3MΩ / 5%', 'Resistor 3,3MΩ / 5%', 115, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(565, 'Resistor 3,3Ω / 5%', 'Resistor 3,3Ω / 5%', 0, 'indisponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(566, 'Resistor 3,9KΩ / 5%', 'Resistor 3,9KΩ / 5%', 85, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(567, 'Resistor 300Ω /5%', 'Resistor 300Ω /5%', 200, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(568, 'Resistor 33.1Ω ', 'Resistor 33.1Ω ', 33, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(569, 'Resistor 330KΩ /5%', 'Resistor 330KΩ /5%', 37, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(570, 'Resistor 330Ω /5%', 'Resistor 330Ω /5%', 106, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(571, 'Resistor 33KΩ /5%', 'Resistor 33KΩ /5%', 67, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(572, 'Resistor 33Ω /5%', 'Resistor 33Ω /5%', 165, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(573, 'Resistor 390KΩ /5%', 'Resistor 390KΩ /5%', 165, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(574, 'Resistor 390Ω /5%', 'Resistor 390Ω /5%', 32, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(575, 'Resistor 39KΩ /5%', 'Resistor 39KΩ /5%', 55, 'disponivel', '2025-08-30 00:30:50', '2025-08-30 00:30:50'),
(576, 'Resistor 4,7KΩ / 5%', 'Resistor 4,7KΩ / 5%', 142, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(577, 'Resistor 4,99KΩ / 0,05%', 'Resistor 4,99KΩ / 0,05%', 100, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(578, 'Resistor 402Ω /5%', 'Resistor 402Ω /5%', 69, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(579, 'Resistor 470KΩ /5%', 'Resistor 470KΩ /5%', 194, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(580, 'Resistor 470Ω /5%', 'Resistor 470Ω /5%', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(581, 'Resistor 47KΩ /5% ', 'Resistor 47KΩ /5% ', 245, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(582, 'Resistor 499Ω /1% 50', 'Resistor 499Ω /1% 50', 37, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(583, 'Resistor 499Ω /5%', 'Resistor 499Ω /5%', 37, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(584, 'Resistor 460Ω / 5%', 'Resistor 460Ω / 5%', 56, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(585, 'Resistor 5,6KΩ / 5%', 'Resistor 5,6KΩ / 5%', 17, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(586, 'Resistor 500KΩ /5%', 'Resistor 500KΩ /5%', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(587, 'Resistor 510Ω /5%', 'Resistor 510Ω /5%', 23, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(588, 'Resistor 560KΩ /5%', 'Resistor 560KΩ /5%', 107, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(589, 'Resistor 560Ω /5%', 'Resistor 560Ω /5%', 85, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(590, 'Resistor 56KΩ /5% ', 'Resistor 56KΩ /5% ', 81, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(591, 'Resistor 56Ω /5% ', 'Resistor 56Ω /5% ', 44, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(592, 'Resistor 6,8KΩ / 5%', 'Resistor 6,8KΩ / 5%', 76, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(593, 'Resistor 620KΩ /5%', 'Resistor 620KΩ /5%', 73, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(594, 'Resistor 680KΩ /5%', 'Resistor 680KΩ /5%', 131, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(595, 'Resistor 680Ω /5%', 'Resistor 680Ω /5%', 37, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(596, 'Resistor 68KΩ /5%', 'Resistor 68KΩ /5%', 155, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(597, 'Resistor 68Ω /5%', 'Resistor 68Ω /5%', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(598, 'Resistor 8,2KΩ / 5%', 'Resistor 8,2KΩ / 5%', 20, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(599, 'Resistor 820KΩ /5%', 'Resistor 820KΩ /5%', 72, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(600, 'Resistor 820Ω /5%', 'Resistor 820Ω /5%', 22, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(601, 'Resistor 82KΩ /5%', 'Resistor 82KΩ /5%', 98, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(602, 'Resistor 9,1KΩ / 5%', 'Resistor 9,1KΩ / 5%', 1, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(603, 'Resistor 909Ω /1%', 'Resistor 909Ω /1%', 107, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(604, 'Resistor 910KΩ /5%', 'Resistor 910KΩ /5%', 106, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(605, 'Resistor 910Ω /5%', 'Resistor 910Ω /5%', 3, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(606, 'Resistor 91KΩ /5%', 'Resistor 91KΩ /5%', 102, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(607, 'Resistor 9.1KΩ / 5%', 'Resistor 9.1KΩ / 5%', 28, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(608, 'Resma De Papel A4 500', 'Resma De Papel A4 500', 5, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(609, 'Rolo de Cabo Cat5e', 'Rolo de Cabo Cat5e', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(610, 'Rolo de Cobre ', 'Rolo de Cobre ', 1, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(611, 'Rolo de Solda CAT em fio', 'Rolo de Solda CAT em fio', 7, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(612, 'Roteador ', 'Roteador ', 8, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(613, 'Sensor de movimento ', 'Sensor de movimento ', 2, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(614, 'Sensor de Chama ', 'Sensor de Chama ', 1, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(615, 'Sensor de Temperatura ', 'Sensor de Temperatura ', 2, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(616, 'Sensor LUZLed', 'Sensor LUZLed', 2, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(617, 'Sensor Ultra Som', 'Sensor Ultra Som', 2, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(618, 'Sensor de rotação ', 'Sensor de rotação ', 2, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(619, 'Sensor Optica reflexiva ', 'Sensor Optica reflexiva ', 4, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(620, 'Sensor com Microfone ', 'Sensor com Microfone ', 1, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(621, 'Simulador de Solda', 'Simulador de Solda', 1, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(622, 'Sirene Isolada Ademco 748 ', 'Sirene Isolada Ademco 748 ', 2, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(623, 'Soprador Térmico HK-508 ', 'Soprador Térmico HK-508 ', 1, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(624, 'Sugador de Solda', 'Sugador de Solda', 6, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(625, 'Suporte de Fixação (Placa) 4x4 ', 'Suporte de Fixação (Placa) 4x4 ', 25, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(626, 'Suporte para Ferro de Solda', 'Suporte para Ferro de Solda', 10, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(627, 'Tab P11 Plus - Lenovo  ', 'Tab P11 Plus - Lenovo  ', 23, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(628, 'Tampa para Condulete 3/4', 'Tampa para Condulete 3/4', 125, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(629, 'Tampa para Condulete cega 3/4', 'Tampa para Condulete cega 3/4', 16, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(630, 'Teclado ', 'Teclado ', 64, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(631, 'Teodolito DE 2A-L ', 'Teodolito DE 2A-L ', 2, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(632, 'Testador de Cabo Rj11 Rj45', 'Testador de Cabo Rj11 Rj45', 13, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(633, 'Testador de Pulseira ESD', 'Testador de Pulseira ESD', 3, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(634, 'Tomada 2P+T ', 'Tomada 2P+T ', 69, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(635, 'Tomada Desmontável ', 'Tomada Desmontável ', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(636, 'Tomada em Barra', 'Tomada em Barra', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(637, 'Tomada LCS RJ45 ', 'Tomada LCS RJ45 ', 9, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(638, 'Tomada PB 2P+T ', 'Tomada PB 2P+T ', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(639, 'Traçador de Altura Analogico ', 'Traçador de Altura Analogico ', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(640, 'Transferidor de Grau 10cm ', 'Transferidor de Grau 10cm ', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(641, 'Transformador Pequeno 12v', 'Transformador Pequeno 12v', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(642, 'Transistor 178205', 'Transistor 178205', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(643, 'Transistor 222', 'Transistor 222', 2, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(644, 'Transistor 2222A', 'Transistor 2222A', 166, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(645, 'Transistor 3904', 'Transistor 3904', 35, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(646, 'Transistor 3906', 'Transistor 3906', 45, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(647, 'Transistor 59014', 'Transistor 59014', 2, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(648, 'Transistor 97081', 'Transistor 97081', 5, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(649, 'Transistor 98039', 'Transistor 98039', 8, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(650, 'Transistor BC327', 'Transistor BC327', 1, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(651, 'Transistor BC337', 'Transistor BC337', 50, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(652, 'Transistor BC548', 'Transistor BC548', 5, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(653, 'Transistor BC5488', 'Transistor BC5488', 50, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(654, 'Transistor BC558', 'Transistor BC558', 28, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(655, 'Transistor C32725', 'Transistor C32725', 48, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(656, 'Transistor C32740', 'Transistor C32740', 29, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(657, 'Transistor C33725', 'Transistor C33725', 38, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(658, 'Transistor C33740', 'Transistor C33740', 7, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(659, 'Transistor CTBF494', 'Transistor CTBF494', 47, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(660, 'Transistor L78L05', 'Transistor L78L05', 45, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(661, 'Trena de Fibra de Vidro ', 'Trena de Fibra de Vidro ', 6, 'disponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(662, 'Luvas Nitrícilicas ', 'Luvas Nitrícilicas ', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(663, 'Máscaras PFF2', 'Máscaras PFF2', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(664, 'Protetores Auditivos ', 'Protetores Auditivos ', 0, 'indisponivel', '2025-08-30 00:30:51', '2025-08-30 00:30:51'),
(665, 'Caixa de Som', 'Caixa de Som para uso com datashow', 2, 'disponivel', '2025-09-12 19:36:34', '2025-09-12 19:36:34'),
(666, 'Extensão', 'Extensão elétrica para equipamentos', 10, 'disponivel', '2025-09-12 19:36:34', '2025-09-12 19:36:34'),
(667, 'Microfone', 'Microfone para uso com datashow', 1, 'disponivel', '2025-09-12 19:36:34', '2025-09-12 19:36:34');

-- --------------------------------------------------------

--
-- Estrutura para tabela `solicitacoes`
--

CREATE TABLE `solicitacoes` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_utilizacao` date NOT NULL,
  `horario_inicio` time NOT NULL,
  `horario_fim` time NOT NULL,
  `sala` varchar(100) DEFAULT NULL,
  `turno` enum('matutino','vespertino','noturno') DEFAULT NULL,
  `status` enum('pendente','aprovada','retirada','devolvida','cancelada') DEFAULT 'pendente',
  `observacoes` text DEFAULT NULL,
  `data_solicitacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_retirada` timestamp NULL DEFAULT NULL,
  `data_devolucao` timestamp NULL DEFAULT NULL,
  `aprovada_por` int(11) DEFAULT NULL,
  `tipo_solicitacao` enum('equipamentos','materiais','ambos','chaves') DEFAULT 'equipamentos',
  `materiais_solicitados` text DEFAULT NULL,
  `materiais_extras` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`materiais_extras`)),
  `data_necessaria_materiais` date DEFAULT NULL,
  `demanda_datashow` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `solicitacoes_chaves`
--

CREATE TABLE `solicitacoes_chaves` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `chave_id` int(11) NOT NULL,
  `data_solicitacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_utilizacao` date NOT NULL,
  `turno` enum('matutino','vespertino','noturno') NOT NULL,
  `motivo` text NOT NULL,
  `status` enum('pendente','aprovada','rejeitada','retirada','devolvida','atrasada') DEFAULT 'pendente',
  `aprovada_por` int(11) DEFAULT NULL,
  `data_aprovacao` timestamp NULL DEFAULT NULL,
  `data_retirada` timestamp NULL DEFAULT NULL,
  `data_devolucao` timestamp NULL DEFAULT NULL,
  `observacoes_aprovacao` text DEFAULT NULL,
  `observacoes_retirada` text DEFAULT NULL,
  `observacoes_devolucao` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `solicitacoes_chaves`
--

INSERT INTO `solicitacoes_chaves` (`id`, `usuario_id`, `chave_id`, `data_solicitacao`, `data_utilizacao`, `turno`, `motivo`, `status`, `aprovada_por`, `data_aprovacao`, `data_retirada`, `data_devolucao`, `observacoes_aprovacao`, `observacoes_retirada`, `observacoes_devolucao`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2025-09-21 09:29:25', '2025-09-21', 'matutino', '', 'pendente', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-09-21 09:29:25', '2025-09-21 09:29:25');

-- --------------------------------------------------------

--
-- Estrutura para tabela `solicitacoes_materiais`
--

CREATE TABLE `solicitacoes_materiais` (
  `id` int(11) NOT NULL,
  `id_material` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `data_solicitacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_agendada` date NOT NULL,
  `status` enum('pendente','aprovada','rejeitada','concluida') DEFAULT 'pendente',
  `solicitacao_datashow_id` int(11) DEFAULT NULL,
  `observacoes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `quantidade_solicitada` int(11) NOT NULL DEFAULT 1,
  `id_solicitacao` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` enum('professor','admin','colaborador') DEFAULT 'professor',
  `setor` enum('ti','secretaria','outros') DEFAULT 'outros',
  `ativo` tinyint(1) DEFAULT 1,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ultimo_acesso` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `cpf`, `senha`, `tipo`, `setor`, `ativo`, `data_criacao`, `data_atualizacao`, `ultimo_acesso`) VALUES
(1, 'Vitor Vieira', '06302985218', '$2y$10$AIafNgG/N3CJjeY9RgKywONA5WobGYX7B1DlEZMkpwOVlM50SpLSC', 'admin', 'outros', 1, '2025-08-29 00:00:00', '2025-10-11 04:41:39', NULL),
(5, 'Sabrina Santos', '03384570200', '$2y$10$skXmKrRBDnNiKPvFEJaC3ODiEOCAbBSqCRl6cT.JcUE8kJx0Fhsdq', 'admin', 'outros', 1, '2025-08-29 20:36:56', '2025-08-29 20:38:26', NULL),
(8, 'Herick Bruno', '70490691242', '$2y$10$4.fDdSsnq1B0fqWo8SG.Y.1X0yKEAJv7qYPinynVQ9L1HGs4EbB9e', 'admin', 'outros', 1, '2025-08-29 22:45:51', '2025-09-15 01:50:26', NULL),
(10, 'Wellington Ferreira', '11077469306', '$2y$10$tkZjC83Md3YtRWPbJV5t9OX1S1u3nNxeggOJvDUb.AdAea5i36lty', 'admin', 'outros', 1, '2025-09-01 22:43:19', '2025-09-01 22:43:19', NULL),
(11, 'Yuri Gabriel', '70354627244', '$2y$10$AXjMCa1cLLZ8TTYwKi3twO.GiMCN6KG2ai3M9gpwTsXFotf2OvlSe', 'admin', 'outros', 1, '2025-09-02 13:21:09', '2025-09-02 22:55:19', NULL),
(12, 'PROFESSOR TESTE', '11111111111', '$2y$10$MThbLxSFDEccUNOuAQ6yB.79lgvBg1K6SHHoLNyvgT13P9e0m/7IO', 'professor', 'outros', 1, '2025-09-03 13:53:35', '2025-09-15 01:39:47', NULL),
(13, 'Kelrison Coelho', '88184242204', '$2y$10$sYG8GdFInsZ8yQ5W.dOx8ugFYyhWw2g3GBVXAxgERRzMz7V91CrJ.', 'admin', 'outros', 1, '2025-09-03 15:07:27', '2025-09-03 15:07:27', NULL),
(14, 'Monitor Lenovo Think Vision S22e', '12345678900', '$2y$10$3pGaY6ZWx7FZPvVYAkXgk./AeD2q2jOqaWcchzA5qwg.V.jeOy4wS', 'colaborador', 'outros', 1, '2025-09-21 09:23:43', '2025-09-21 09:23:43', NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `chaves`
--
ALTER TABLE `chaves`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `materiais`
--
ALTER TABLE `materiais`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `solicitacoes`
--
ALTER TABLE `solicitacoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `solicitacoes_ibfk_3` (`aprovada_por`),
  ADD KEY `idx_data_turno` (`data_utilizacao`,`turno`);

--
-- Índices de tabela `solicitacoes_chaves`
--
ALTER TABLE `solicitacoes_chaves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `chave_id` (`chave_id`),
  ADD KEY `aprovada_por` (`aprovada_por`),
  ADD KEY `idx_data_turno_chave` (`data_utilizacao`,`turno`,`chave_id`);

--
-- Índices de tabela `solicitacoes_materiais`
--
ALTER TABLE `solicitacoes_materiais`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_material` (`id_material`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cpf` (`cpf`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `chaves`
--
ALTER TABLE `chaves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `materiais`
--
ALTER TABLE `materiais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=668;

--
-- AUTO_INCREMENT de tabela `solicitacoes`
--
ALTER TABLE `solicitacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT de tabela `solicitacoes_chaves`
--
ALTER TABLE `solicitacoes_chaves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `solicitacoes_materiais`
--
ALTER TABLE `solicitacoes_materiais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `solicitacoes`
--
ALTER TABLE `solicitacoes`
  ADD CONSTRAINT `solicitacoes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `solicitacoes_ibfk_3` FOREIGN KEY (`aprovada_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `solicitacoes_chaves`
--
ALTER TABLE `solicitacoes_chaves`
  ADD CONSTRAINT `solicitacoes_chaves_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `solicitacoes_chaves_ibfk_2` FOREIGN KEY (`chave_id`) REFERENCES `chaves` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `solicitacoes_chaves_ibfk_3` FOREIGN KEY (`aprovada_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `solicitacoes_materiais`
--
ALTER TABLE `solicitacoes_materiais`
  ADD CONSTRAINT `solicitacoes_materiais_ibfk_1` FOREIGN KEY (`id_material`) REFERENCES `materiais` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `solicitacoes_materiais_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
