<?php
require_once 'includes/config.php';

// Se já estiver logado, redirecionar para o dashboard
if (isLoggedIn() && isAdmin()) {
    redirect('pages/pendentes.php');
}

$error = '';
$success = '';

// Processar login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cpf = sanitize($_POST['cpf'] ?? '');
    $senha = $_POST['senha'] ?? '';
    
    if (empty($cpf) || empty($senha)) {
        $error = 'Por favor, preencha todos os campos.';
    } else {
        try {
            $pdo = getDBConnection();
            
            // Buscar usuário por email ou matrícula
            $stmt = $pdo->prepare("
                SELECT id, nome, cpf, senha, tipo, ativo 
                FROM usuarios 
                WHERE (cpf = ?) AND ativo = 1
            ");
            $stmt->execute([$cpf]);
            $user = $stmt->fetch();
            
            if ($user && verifyPassword($senha, $user['senha'])) {
                // Login bem-sucedido
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['nome'];
                $_SESSION['user_cpf'] = $user['cpf'];
                $_SESSION['user_type'] = $user['tipo'];
                
                if ($user['tipo'] === 'admin') {
                    redirect('pages/pendentes.php');
                } elseif ($user['tipo'] === 'colaborador') {
                    redirect('pages/usuarios.php'); // Colaborador é direcionado para adicionar usuários
                } else {
                    redirect('pages/solicitar.php'); // Professor sempre começa por aqui
                }
            } else {
                $error = 'CPF ou senha incorreta.';
            }
        } catch (PDOException $e) {
            $error = 'Erro interno do sistema. Tente novamente.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Login</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <h1>SIDE - IBC</h1>
                <p><strong>Sistema de Equipamentos - IBC</strong></p>
                <p>Faça login para continuar</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="cpf" class="form-label">
                        <i class="fas fa-user"></i> CPF
                    </label>
                    <input 
                        type="text" 
                        id="cpf" 
                        name="cpf" 
                        class="form-input" 
                        placeholder="Digite seu CPF"
                        value="<?php echo htmlspecialchars($_POST['cpf'] ?? ''); ?>"
                        required
                    >
                </div>
                
                <div class="form-group">
                    <label for="senha" class="form-label">
                        <i class="fas fa-lock"></i> Senha
                    </label>
                    <input 
                        type="password" 
                        id="senha" 
                        name="senha" 
                        class="form-input" 
                        placeholder="Digite sua senha"
                        required
                    >
                </div>
                
                <button type="submit" class="btn btn-primary btn-full">
                    <i class="fas fa-sign-in-alt"></i> Entrar
                </button>
                
            </form>
            
        </div>


    </div>
    
    <script>
        // Adicionar animação de foco nos inputs
        document.querySelectorAll(".form-input").forEach(input => {
            input.addEventListener("focus", function() {
                this.parentElement.classList.add("focused");
            });
            
            input.addEventListener("blur", function() {
                if (!this.value) {
                    this.parentElement.classList.remove("focused");
                }
            });
        });
        
        // Animação do botão de submit
        document.querySelector("form").addEventListener("submit", function(e) {
            const btn = this.querySelector(".btn-primary");
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';
            btn.disabled = true;
        });
        
        // Esconder o botão do menu hambúrguer quando o menu lateral estiver aberto
        const mobileMenuToggle = document.querySelector(".mobile-menu-toggle");
        const sidebar = document.querySelector(".sidebar");
        
        if (mobileMenuToggle && sidebar) {
            const observer = new MutationObserver(() => {
                if (sidebar.classList.contains("open")) {
                    mobileMenuToggle.style.display = "none";
                } else {
                    mobileMenuToggle.style.display = "block";
                }
            });
            observer.observe(sidebar, { attributes: true, attributeFilter: ["class"] });
        }
    </script>

    <style>

    </style>
</body>
</html>