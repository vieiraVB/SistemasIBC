<?php
require_once '../includes/config.php';

// Verificar se está logado
if (!isLoggedIn()) {
    redirect('../index.php');
}

$error = '';
$success = '';

// Processar ações (aprovar, retirar, devolver)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($_POST['action'] ?? '');
    $solicitacao_id = (int)($_POST['solicitacao_id'] ?? 0);
    
    if ($action && $solicitacao_id) {
        try {
            $pdo = getDBConnection();
            
            switch ($action) {
                case 'aprovar':
                    if (isAdmin()) {
                        // Aprovar solicitação diretamente
                        $stmt = $pdo->prepare("
                            UPDATE solicitacoes 
                            SET status = 'aprovada', aprovada_por = ? 
                            WHERE id = ? AND status = 'pendente'
                        ");
                        $stmt->execute([$_SESSION['user_id'], $solicitacao_id]);

                        $success = 'Solicitação aprovada com sucesso!';
                    }
                    break;
                    
                case 'retirar':
                    if (isAdmin()) {
                        $stmt = $pdo->prepare("
                            UPDATE solicitacoes 
                            SET status = 'retirada', data_retirada = NOW() 
                            WHERE id = ? AND status = 'aprovada'
                        ");
                        $stmt->execute([$solicitacao_id]);
                        $success = 'Retirada confirmada!';
                    }
                    break;
                    
                case 'devolver':
                    if (isAdmin()) {
                        // Atualizar a solicitação diretamente para 'devolvida'
                        $stmt = $pdo->prepare("
                            UPDATE solicitacoes 
                            SET status = 'devolvida', data_devolucao = NOW() 
                            WHERE id = ?
                        ");
                        $stmt->execute([$solicitacao_id]);
                        
                        $success = 'Devolução confirmada!';
                    }
                    break;

                    
                case 'cancelar':
                    // Usuário pode cancelar suas próprias solicitações pendentes
                    $stmt = $pdo->prepare("
                        UPDATE solicitacoes 
                        SET status = 'cancelada' 
                        WHERE id = ? AND usuario_id = ? AND status = 'pendente'
                    ");
                    $stmt->execute([$solicitacao_id, $_SESSION['user_id']]);
                    $success = 'Solicitação cancelada!';
                    break;
                    
                case 'excluir':
                    // Apenas admin pode excluir solicitações pendentes
                    if (isAdmin()) {
                        // Primeiro, verificar se a solicitação está pendente
                        $stmt = $pdo->prepare("
                            SELECT status, materiais_solicitados 
                            FROM solicitacoes 
                            WHERE id = ? AND status = 'pendente'
                        ");
                        $stmt->execute([$solicitacao_id]);
                        $solicitacao = $stmt->fetch();
                        
                        if ($solicitacao) {
                            // Restaurar quantidades dos materiais antes de excluir
                            if ($solicitacao['materiais_solicitados']) {
                                $materiais = json_decode($solicitacao['materiais_solicitados'], true);
                                if ($materiais) {
                                    foreach ($materiais as $material_id => $quantidade) {
                                        // Verificar se é material extra (string) ou normal (numeric)
                                        if (is_numeric($material_id)) {
                                            // Material normal - usar ID
                                            $stmt = $pdo->prepare("
                                                UPDATE materiais 
                                                SET quantidade = quantidade + ? 
                                                WHERE id = ?
                                            ");
                                            $stmt->execute([$quantidade, $material_id]);
                                        } else {
                                            // Material extra - usar nome
                                            $materiais_extras_map = [
                                                'caixa_som' => 'Caixa de Som',
                                                'extensao' => 'Extensão', 
                                                'microfone' => 'Microfone'
                                            ];
                                            
                                            if (isset($materiais_extras_map[$material_id])) {
                                                $stmt = $pdo->prepare("
                                                    UPDATE materiais 
                                                    SET quantidade = quantidade + ? 
                                                    WHERE nome = ?
                                                ");
                                                $stmt->execute([$quantidade, $materiais_extras_map[$material_id]]);
                                            }
                                        }
                                    }
                                }
                            }
                            
                            // Excluir a solicitação
                            $stmt = $pdo->prepare("DELETE FROM solicitacoes WHERE id = ?");
                            $stmt->execute([$solicitacao_id]);
                            
                            $success = 'Solicitação excluída com sucesso! Materiais devolvidos ao estoque.';
                        } else {
                            $error = 'Apenas solicitações pendentes podem ser excluídas.';
                        }
                    }
                    break;
            }
        } catch (PDOException $e) {
            $error = 'Erro interno do sistema. Tente novamente.';
        }
    }
}

// Filtros
$filtro_status = sanitize($_GET['status'] ?? '');
$filtro_data = sanitize($_GET['data'] ?? '');
$filtro_tipo = sanitize($_GET['tipo'] ?? '');

// Buscar solicitações
try {
    $pdo = getDBConnection();
    
    $where_conditions = [];
    $params = [];
    
    // Se não for admin, mostrar apenas suas solicitações
    if (!isAdmin()) {
        $where_conditions[] = "s.usuario_id = ?";
        $params[] = $_SESSION['user_id'];
    }
    
    // Filtro por status
    if ($filtro_status) {
        $where_conditions[] = "s.status = ?";
        $params[] = $filtro_status;
    } else {
        // Por padrão, não mostrar canceladas
        $where_conditions[] = "s.status != 'cancelada'";
    }
    
    // Filtro por data
    if ($filtro_data) {
        $where_conditions[] = "s.data_utilizacao = ?";
        $params[] = $filtro_data;
    }
    
    // Filtro por tipo
    if ($filtro_tipo) {
        $where_conditions[] = "s.tipo_solicitacao = ?";
        $params[] = $filtro_tipo;
    }
    
    $where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
    
    $stmt = $pdo->prepare("
        SELECT s.*, u.nome as usuario_nome
        FROM solicitacoes s 
        JOIN usuarios u ON s.usuario_id = u.id 
        $where_clause
        ORDER BY s.data_solicitacao DESC
    ");
    $stmt->execute($params);
    $solicitacoes = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = "Erro ao carregar solicitações.";
    $solicitacoes = [];
}

// Função para obter nomes dos materiais
function obterNomesMateriais($pdo, $materiais_json) {
    if (!$materiais_json) return [];
    
    $materiais_ids = json_decode($materiais_json, true);
    if (!$materiais_ids) return [];
    
    $placeholders = str_repeat('?,', count($materiais_ids) - 1) . '?';
    $stmt = $pdo->prepare("SELECT nome FROM materiais WHERE id IN ($placeholders)");
    $stmt->execute($materiais_ids);
    
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

if (isset($_GET['ajax'])) {
    include 'partials/solicitacoes_table.php'; // extrai apenas a tabela num arquivo separado
    exit;
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Solicitações</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .tipo-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .tipo-datashow {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .tipo-materiais {
            background: #d1fae5;
            color: #065f46;
        }
        
        .tipo-ambos {
            background: #fef3c7;
            color: #92400e;
        }
        
        .materiais-list {
            font-size: 0.875rem;
            color: #6b7280;
            margin-top: 0.25rem;
        }
        
        .materiais-list .material-item {
            display: inline-block;
            background: #f3f4f6;
            padding: 0.125rem 0.375rem;
            border-radius: 3px;
            margin: 0.125rem;
        }
        
        .observacao-cell {
            max-width: 200px;
        }
        
        .turno-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .turno-matutino {
            background: #fef3c7;
            color: #92400e;
        }
        
        .turno-vespertino {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .turno-noturno {
            background: #e0e7ff;
            color: #3730a3;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }
        
        .modal-content-large {
            background-color: white;
            margin: 2% auto;
            padding: 2rem;
            border-radius: 8px;
            width: 90%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
            position: relative;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .modal-title {
            margin: 0;
            color: #1f2937;
        }
        
        .close {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #6b7280;
        }
        
        .close:hover {
            color: #374151;
        }
        
        .modal-body {
            line-height: 1.6;
        }
        
        .detail-section {
            margin-bottom: 1.5rem;
            padding: 1rem;
            background: #f9fafb;
            border-radius: 6px;
        }
        
        .detail-section h3 {
            margin: 0 0 0.75rem 0;
            color: #374151;
            font-size: 1.1rem;
        }
        
        .detail-row {
            display: flex;
            margin-bottom: 0.5rem;
        }
        
        .detail-label {
            font-weight: 600;
            color: #4b5563;
            min-width: 120px;
        }
        
        .detail-value {
            color: #1f2937;
            flex: 1;
        }
        
        .clickable-row {
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        
        .clickable-row:hover {
            background-color: #f3f4f6;
        }
        
        @media (max-width: 768px) {
            .modal-content-large {
                width: 95%;
                margin: 5% auto;
                padding: 1rem;
            }
            
            .detail-row {
                flex-direction: column;
            }
            
            .detail-label {
                min-width: auto;
                margin-bottom: 0.25rem;
            }
        }
        
        .observacao-text {
            display: block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            cursor: help;
        }
    </style>
</head>
<body>
    <!-- Botão de menu hambúrguer para mobile -->
    <button class="mobile-menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    
    <!-- Overlay para fechar sidebar em mobile -->
    <div class="sidebar-overlay" onclick="closeSidebar()"></div>
    
    <div class="main-layout">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h1>SIDE - IBC</h1>
                <p>Bem-vindo, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>
            
            <nav class="sidebar-nav">
                <?php if (isAdmin()): ?>
                    <a href="historico.php" class="nav-item">
                        <i class="fas fa-history"></i> Histórico
                    </a>
                    <a href="usuarios.php" class="nav-item">
                        <i class="fas fa-users"></i> Usuários
                    </a>
                    <a href="materiais.php" class="nav-item">
                        <i class="fas fa-boxes"></i> Gestão de Materiais
                    </a>
                <?php endif; ?>

                <?php if ($_SESSION['user_type'] === 'professor' || isAdmin()): ?>
                    <a href="solicitar.php" class="nav-item">
                        <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                    </a>
                    <?php
                    $stmt = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
                    $pendentes_count = $stmt->fetchColumn();
                    ?>
                    <a href="pendentes.php" class="nav-item active">
                        <span id="contador-pendentes">
                            <?php if (isAdmin()): ?>
                                <?php if ($pendentes_count > 0): ?>
                                    <span class="badge bg-danger"><?php echo $pendentes_count; ?></span>
                                <?php else: ?>
                                    <i class="fas fa-clock"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-list"></i>
                            <?php endif; ?>
                        </span>
                        Solicitações
                    </a>

                <?php endif; ?>
            </nav>
            
            <div class="sidebar-footer">
                <a href="../logout.php" class="btn btn-secondary btn-full">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>
        
        <!-- Conteúdo Principal -->
        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-list"></i> Solicitações <?php echo isAdmin() ? '' : 'Minhas'; ?>
                </h1>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <!-- Filtros -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" action="" style="display: flex; gap: 1rem; align-items: end; flex-wrap: wrap;">
                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="status" class="form-label">Status</label>
                            <select id="status" name="status" class="form-input" style="width: 150px;">
                                <option value="">Todos</option>
                                <option value="pendente" <?php echo $filtro_status === 'pendente' ? 'selected' : ''; ?>>Pendente</option>
                                <option value="aprovada" <?php echo $filtro_status === 'aprovada' ? 'selected' : ''; ?>>Aprovada</option>
                                <option value="retirada" <?php echo $filtro_status === 'retirada' ? 'selected' : ''; ?>>Retirada</option>
                                <option value="devolvida" <?php echo $filtro_status === 'devolvida' ? 'selected' : ''; ?>>Devolvida</option>
                                <option value="cancelada" <?php echo $filtro_status === 'cancelada' ? 'selected' : ''; ?>>Cancelada</option>
                            </select>
                        </div>
                        
                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="tipo" class="form-label">Tipo</label>
                            <select id="tipo" name="tipo" class="form-input" style="width: 150px;">
                                <option value="">Todos</option>
                                <option value="datashow" <?php echo $filtro_tipo === 'datashow' ? 'selected' : ''; ?>>Datashow</option>
                                <option value="materiais" <?php echo $filtro_tipo === 'materiais' ? 'selected' : ''; ?>>Materiais</option>
                                <option value="ambos" <?php echo $filtro_tipo === 'ambos' ? 'selected' : ''; ?>>Ambos</option>
                            </select>
                        </div>
                        
                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="data" class="form-label">Data</label>
                            <input type="date" id="data" name="data" class="form-input" value="<?php echo htmlspecialchars($filtro_data); ?>" style="width: 150px;">
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Filtrar
                        </button>
                        
                        <a href="pendentes.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Limpar
                        </a>
                    </form>
                </div>
            </div>
            
            <!-- Tabela de Solicitações -->
            <div class="table-container" id="lista-solicitacoes">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Professor</th>
                            <th>Tipo</th>
                            <th>Data</th>
                            <th>Turno</th>
                            <th>Sala</th>
                            <th>Status</th>
                            <th>Observações</th>
                            <?php if (isAdmin()): ?>
                            <th>Ações</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($solicitacoes)): ?>
                            <tr>
                                <td colspan="<?php echo isAdmin() ? '8' : '7'; ?>" class="text-center" style="padding: 2rem; color: #6b7280;">
                                    <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 1rem; display: block;"></i>
                                    Nenhuma solicitação encontrada.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($solicitacoes as $solicitacao): ?>
                                <tr class="clickable-row" onclick="abrirDetalhes(<?php echo $solicitacao['id']; ?>)">
                                    <td>
                                        <strong><?php echo htmlspecialchars($solicitacao['usuario_nome']); ?></strong>
                                        <br>
                                        <small style="color: #6b7280;">
                                            Solicitado em: <?php echo date('d/m/Y H:i', strtotime($solicitacao['data_solicitacao'])); ?>
                                        </small>
                                    </td>
                                    
                                    <td>
                                        <?php 
                                        $tipo = $solicitacao['tipo_solicitacao'];
                                        $tipo_classes = [
                                            'datashow' => 'tipo-datashow',
                                            'materiais' => 'tipo-materiais', 
                                            'ambos' => 'tipo-ambos'
                                        ];
                                        $tipo_icons = [
                                            'datashow' => 'fas fa-video',
                                            'materiais' => 'fas fa-boxes',
                                            'ambos' => 'fas fa-layer-group'
                                        ];
                                        $tipo_labels = [
                                            'datashow' => 'Datashow',
                                            'materiais' => 'Materiais',
                                            'ambos' => 'Ambos'
                                        ];
                                        ?>
                                        <span class="tipo-badge <?php echo $tipo_classes[$tipo]; ?>">
                                            <i class="<?php echo $tipo_icons[$tipo]; ?>"></i>
                                            <?php echo $tipo_labels[$tipo]; ?>
                                        </span>
                                        
                                        <?php if (($tipo === 'materiais' || $tipo === 'ambos') && $solicitacao['materiais_solicitados']): ?>
                                            <div class="materiais-list">
                                                <?php 
                                                $materiais_nomes = obterNomesMateriais($pdo, $solicitacao['materiais_solicitados']);
                                                foreach ($materiais_nomes as $material_nome): 
                                                ?>
                                                    <span class="material-item"><?php echo htmlspecialchars($material_nome); ?></span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td><?php echo date('d/m/Y', strtotime($solicitacao['data_utilizacao'])); ?></td>
                                    
                                    <td>
                                        <?php if ($tipo === 'datashow' || $tipo === 'ambos'): ?>
                                            <?php if ($solicitacao['turno']): ?>
                                                <span class="turno-badge turno-<?php echo $solicitacao['turno']; ?>">
                                                    <?php 
                                                    $turnos = [
                                                        'matutino' => 'Matutino',
                                                        'vespertino' => 'Vespertino', 
                                                        'noturno' => 'Noturno'
                                                    ];
                                                    echo $turnos[$solicitacao['turno']] ?? 'N/A';
                                                    ?>
                                                </span>
                                            <?php else: ?>
                                                <span style="color: #6b7280;">-</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span style="color: #6b7280;">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td><?php echo htmlspecialchars($solicitacao['sala']); ?></td>
                                    
                                    <td>
                                        <span class="badge badge-<?php 
                                            echo $solicitacao['status'] === 'pendente' ? 'warning' : 
                                                ($solicitacao['status'] === 'aprovada' ? 'info' : 
                                                ($solicitacao['status'] === 'retirada' ? 'success' : 
                                                ($solicitacao['status'] === 'devolvida' ? 'success' : 'danger'))); 
                                        ?>">
                                            <?php echo ucfirst($solicitacao['status']); ?>
                                        </span>
                                    </td>
                                    
                                    <td class="observacao-cell">
                                        <?php if ($solicitacao['observacoes']): ?>
                                            <span class="observacao-text" title="<?php echo htmlspecialchars($solicitacao['observacoes']); ?>">
                                                <i class="fas fa-comment"></i> <?php echo htmlspecialchars(substr($solicitacao['observacoes'], 0, 30)); ?>...
                                            </span>
                                        <?php endif; ?>
                                        

                                    </td>
                                    
                                    <?php if (isAdmin()): ?>
                                    <td>
                                        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                                            <?php if ($solicitacao['status'] === 'pendente'): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="action" value="aprovar">
                                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                                    <button type="submit" class="btn btn-success" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Aprovar esta solicitação?')">
                                                        <i class="fas fa-check"></i> Aprovar
                                                    </button>
                                                </form>
                                                
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="action" value="excluir">
                                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                                    <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Excluir esta solicitação? Esta ação não pode ser desfeita e os materiais serão devolvidos ao estoque.')">
                                                        <i class="fas fa-trash"></i> Excluir
                                                    </button>
                                                </form>
                                            <?php elseif ($solicitacao['status'] === 'aprovada'): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="action" value="retirar">
                                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                                    <button type="submit" class="btn btn-warning" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Confirmar retirada?')">
                                                        <i class="fas fa-hand-paper"></i> Retirar
                                                    </button>
                                                </form>
                                            <?php elseif ($solicitacao['status'] === 'retirada'): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="action" value="devolver">
                                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                                    <button type="submit" class="btn btn-primary" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Confirmar devolução?')">
                                                        <i class="fas fa-undo"></i> Devolver
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <?php elseif ($solicitacao['status'] === 'pendente' && $solicitacao['usuario_id'] == $_SESSION['user_id']): ?>
                                    <td>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="cancelar">
                                            <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                            <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Cancelar esta solicitação?')">
                                                <i class="fas fa-times"></i> Cancelar
                                            </button>
                                        </form>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Modal para Visualização Detalhada -->
    <div id="detalhesModal" class="modal" style="display: none;">
        <div class="modal-content-large">
            <button class="close" onclick="fecharDetalhes()">&times;</button>
            <div class="modal-header">
                <h2 id="detalhesTitle" class="modal-title">Detalhes da Solicitação</h2>
            </div>
            <div id="detalhesContent" class="modal-body">
                <!-- Conteúdo será carregado via JavaScript -->
            </div>
        </div>
    </div>
    
    <script>
        // Funções para controle do menu mobile
        function toggleSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");
            
            sidebar.classList.toggle("open");
            overlay.classList.toggle("active");
            
            if (sidebar.classList.contains("open")) {
                toggleButton.style.opacity = "0";
                toggleButton.style.pointerEvents = "none";
                mainContent.classList.add("menu-open");
            } else {
                toggleButton.style.opacity = "1";
                toggleButton.style.pointerEvents = "auto";
                mainContent.classList.remove("menu-open");
            }
        }
        
        function closeSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");
            
            sidebar.classList.remove("open");
            overlay.classList.remove("active");
            toggleButton.style.opacity = "1";
            toggleButton.style.pointerEvents = "auto";
            mainContent.classList.remove("menu-open");
        }

        function atualizarContador() {
            fetch('contador_pendentes.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('contador-pendentes').innerHTML = data;
                })
                .catch(error => console.error("Erro ao atualizar contador:", error));
        }

        // chama logo no carregamento
        atualizarContador();

        // Função para abrir detalhes da solicitação
        function abrirDetalhes(solicitacaoId) {
            // Buscar dados da solicitação via AJAX
            fetch(`detalhes_solicitacao.php?id=${solicitacaoId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        mostrarDetalhes(data.solicitacao);
                    } else {
                        alert('Erro ao carregar detalhes da solicitação.');
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Erro ao carregar detalhes da solicitação.');
                });
        }
        
        // Função para mostrar o modal com os detalhes
        function mostrarDetalhes(solicitacao) {
            const modal = document.getElementById('detalhesModal');
            const content = document.getElementById('detalhesContent');
            
            // Montar o conteúdo do modal
            let html = `
                <div class="detail-section">
                    <h3><i class="fas fa-user"></i> Informações do Solicitante</h3>
                    <div class="detail-row">
                        <span class="detail-label">Professor:</span>
                        <span class="detail-value">${solicitacao.usuario_nome}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Data da Solicitação:</span>
                        <span class="detail-value">${formatarDataHora(solicitacao.data_solicitacao)}</span>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h3><i class="fas fa-calendar"></i> Informações da Utilização</h3>
                    <div class="detail-row">
                        <span class="detail-label">Tipo:</span>
                        <span class="detail-value">${obterTipoLabel(solicitacao.tipo_solicitacao)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Data de Utilização:</span>
                        <span class="detail-value">${formatarData(solicitacao.data_utilizacao)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Sala:</span>
                        <span class="detail-value">${solicitacao.sala}</span>
                    </div>
            `;
            
            // Adicionar informações específicas do tipo
            if (solicitacao.tipo_solicitacao === 'datashow' || solicitacao.tipo_solicitacao === 'ambos') {
                html += `
                    <div class="detail-row">
                        <span class="detail-label">Turno:</span>
                        <span class="detail-value">${obterTurnoLabel(solicitacao.turno)}</span>
                    </div>
                `;
            }
            
            html += `</div>`;
            
            // Adicionar materiais se houver
            if (solicitacao.materiais && solicitacao.materiais.length > 0) {
                html += `
                    <div class="detail-section">
                        <h3><i class="fas fa-boxes"></i> Materiais Solicitados</h3>
                `;
                
                solicitacao.materiais.forEach(material => {
                    html += `
                        <div class="detail-row">
                            <span class="detail-label">${material.nome}:</span>
                            <span class="detail-value">${material.quantidade} unidade(s)</span>
                        </div>
                    `;
                });
                
                html += `</div>`;
            }
            
            // Adicionar observações se houver
            if (solicitacao.observacoes || solicitacao.observacoes_materiais) {
                html += `<div class="detail-section">
                    <h3><i class="fas fa-comment"></i> Observações</h3>
                `;
                
                if (solicitacao.observacoes) {
                    html += `
                        <div class="detail-row">
                            <span class="detail-label">Gerais:</span>
                            <span class="detail-value">${solicitacao.observacoes}</span>
                        </div>
                    `;
                }
                
                if (solicitacao.observacoes_materiais) {
                    html += `
                        <div class="detail-row">
                            <span class="detail-label">Materiais:</span>
                            <span class="detail-value">${solicitacao.observacoes_materiais}</span>
                        </div>
                    `;
                }
                
                html += `</div>`;
            }
            
            // Adicionar informações de status
            html += `
                <div class="detail-section">
                    <h3><i class="fas fa-info-circle"></i> Status</h3>
                    <div class="detail-row">
                        <span class="detail-label">Status Atual:</span>
                        <span class="detail-value">${obterStatusLabel(solicitacao.status)}</span>
                    </div>
            `;
            
            if (solicitacao.aprovada_por_nome) {
                html += `
                    <div class="detail-row">
                        <span class="detail-label">Aprovada por:</span>
                        <span class="detail-value">${solicitacao.aprovada_por_nome}</span>
                    </div>
                `;
            }
            
            if (solicitacao.data_aprovacao) {
                html += `
                    <div class="detail-row">
                        <span class="detail-label">Data de Aprovação:</span>
                        <span class="detail-value">${formatarDataHora(solicitacao.data_aprovacao)}</span>
                    </div>
                `;
            }
            
            html += `</div>`;
            
            content.innerHTML = html;
            modal.style.display = 'block';
        }
        
        // Função para fechar o modal
        function fecharDetalhes() {
            document.getElementById('detalhesModal').style.display = 'none';
        }
        
        // Funções auxiliares para formatação
        function formatarData(data) {
            return new Date(data).toLocaleDateString('pt-BR');
        }
        
        function formatarDataHora(dataHora) {
            return new Date(dataHora).toLocaleString('pt-BR');
        }
        
        function obterTipoLabel(tipo) {
            const tipos = {
                'datashow': 'Datashow',
                'materiais': 'Materiais',
                'ambos': 'Datashow + Materiais'
            };
            return tipos[tipo] || tipo;
        }
        
        function obterTurnoLabel(turno) {
            const turnos = {
                'matutino': 'Matutino',
                'vespertino': 'Vespertino',
                'noturno': 'Noturno'
            };
            return turnos[turno] || turno;
        }
        
        function obterStatusLabel(status) {
            const statuses = {
                'pendente': 'Pendente',
                'aprovada': 'Aprovada',
                'retirada': 'Retirada',
                'devolvida': 'Devolvida',
                'cancelada': 'Cancelada'
            };
            return statuses[status] || status;
        }
        
        // Fechar modal ao clicar fora dele
        window.onclick = function(event) {
            const modal = document.getElementById('detalhesModal');
            if (event.target === modal) {
                fecharDetalhes();
            }
        }

        // e repete a cada 5s
        setInterval(atualizarContador, 5000);
        
        // Sistema de notificações push para administradores
        <?php if (isAdmin()): ?>
        let notificacoesPermitidas = false;
        
        // Solicitar permissão para notificações
        function solicitarPermissaoNotificacao() {
            if ("Notification" in window) {
                if (Notification.permission === "default") {
                    Notification.requestPermission().then(function (permission) {
                        if (permission === "granted") {
                            notificacoesPermitidas = true;
                            console.log("Permissão para notificações concedida");
                        }
                    });
                } else if (Notification.permission === "granted") {
                    notificacoesPermitidas = true;
                }
            }
        }
        
        // Verificar novas solicitações
        function verificarNovasSolicitacoes() {
            if (!notificacoesPermitidas) return;
            
            fetch('notificacoes.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.novas_solicitacoes > 0) {
                        // Criar notificação
                        const notification = new Notification("Nova Solicitação - SIDE IBC", {
                            body: `${data.novas_solicitacoes} nova(s) solicitação(ões) pendente(s)`,
                            icon: "../assets/images/3dd9c2bf93e33f1adf031b0ad3801207b79cf53d.png",
                            tag: "nova-solicitacao",
                            requireInteraction: true
                        });
                        
                        // Ao clicar na notificação, focar na janela
                        notification.onclick = function() {
                            window.focus();
                            notification.close();
                            // Recarregar a página para mostrar as novas solicitações
                            location.reload();
                        };
                        
                        // Fechar automaticamente após 10 segundos
                        setTimeout(() => {
                            notification.close();
                        }, 10000);
                    }
                })
                .catch(error => {
                    console.error('Erro ao verificar notificações:', error);
                });
        }
        
        // Inicializar sistema de notificações
        document.addEventListener('DOMContentLoaded', function() {
            solicitarPermissaoNotificacao();
            
            // Verificar novas solicitações a cada 30 segundos
            setInterval(verificarNovasSolicitacoes, 30000);
        });
        <?php endif; ?>
    </script>
</body>
</html>

