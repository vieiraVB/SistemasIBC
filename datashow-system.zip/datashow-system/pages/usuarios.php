<?php
require_once '../includes/config.php';
$pdo = getDBConnection();


// Verificar se está logado e é admin
if (!isLoggedIn() || (!isAdmin() && !isColaborador())) {
    redirect('../index.php');
}

$error = '';
$success = '';

// Processar ações CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($_POST['action'] ?? '');
    
    try {
        $pdo = getDBConnection();
        
        switch ($action) {
            case 'adicionar':
                $nome = sanitize($_POST['nome'] ?? '');
                $cpf = sanitize($_POST['cpf'] ?? '');
                $senha = $_POST['senha'] ?? '';
                $tipo = sanitize($_POST['tipo'] ?? 'professor');

                if (isColaborador() && $tipo === 'admin') {
                    $error = 'Você não tem permissão para criar usuários administradores.';
                    break;
                }
                
                if (empty($nome) || empty($cpf)  || empty($senha)) {
                    $error = 'Por favor, preencha todos os campos obrigatórios.';
                } elseif (!preg_match('/^\d{11}$/', $cpf)) {
                    $error = 'CPF inválido. Informe apenas números (11 dígitos).';
                } elseif (strlen($senha) < 6) {
                    $error = 'A senha deve ter pelo menos 6 caracteres.';
                } else {
                    // Verificar se CPF já existe
                    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM usuarios WHERE CPF = ?");
                    $stmt->execute([$cpf]);
                    
                    if ($stmt->fetch()['total'] > 0) {
                        $error = 'CPF já existe.';
                    } else {
                        $senha_hash = hashPassword($senha);
                        $stmt = $pdo->prepare("
                            INSERT INTO usuarios (nome, cpf, senha, tipo) 
                            VALUES (?, ?, ?, ?)
                        ");
                        $stmt->execute([$nome, $cpf, $senha_hash, $tipo]);
                        $success = 'Usuário adicionado com sucesso!';
                    }
                }
                break;
                
            case 'editar':
                $id = (int)($_POST['id'] ?? 0);
                $nome = sanitize($_POST['nome'] ?? '');
                $cpf = sanitize($_POST['cpf'] ?? '');
                $senha = $_POST['senha'] ?? '';
                $tipo = sanitize($_POST['tipo'] ?? '');
                $ativo = isset($_POST['ativo']) ? 1 : 0;
                
                if ($id && !empty($nome) && !empty($cpf)) {
                    if (!preg_match('/^\d{11}$/', $cpf)) {
                        $error = 'CPF inválido. Informe apenas números (11 dígitos).';
                    } else {
                        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM usuarios WHERE (cpf = ?) AND id != ?");
                        $stmt->execute([$cpf, $id]);
                        
                        if ($stmt->fetch()['total'] > 0) {
                            $error = 'CPF já existe.';
                        } else {
                            if (!empty($senha)) {
                                if (strlen($senha) < 6) {
                                    $error = 'A senha deve ter pelo menos 6 caracteres.';
                                    break;
                                }
                                $senha_hash = hashPassword($senha);
                                $stmt = $pdo->prepare("
                                    UPDATE usuarios 
                                    SET nome = ?, CPF = ?, senha = ?, tipo = ?, ativo = ? 
                                    WHERE id = ?
                                ");
                                $stmt->execute([$nome, $cpf, $senha_hash, $tipo, $ativo, $id]);
                            } else {
                                $stmt = $pdo->prepare("
                                    UPDATE usuarios 
                                    SET nome = ?, cpf = ?, tipo = ?, ativo = ? 
                                    WHERE id = ?
                                ");
                                $stmt->execute([$nome, $cpf, $tipo, $ativo, $id]);
                            }
                            $success = 'Usuário atualizado com sucesso!';
                        }
                    }
                }
                break;
                
            case 'excluir':
                $id = (int)($_POST['id'] ?? 0);

                if ($id && $id != $_SESSION['user_id']) {
                    // Verificar se usuário tem solicitações ativas
                    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM solicitacoes WHERE usuario_id = ? AND status IN ('pendente', 'aprovada', 'retirada')");
                    $stmt->execute([$id]);

                    if ($stmt->fetch()['total'] > 0) {
                        $error = 'Não é possível excluir usuário com solicitações ativas.';
                    } else {
                        // Em vez de deletar, apenas inativar
                        $stmt = $pdo->prepare("UPDATE usuarios SET ativo = 0 WHERE id = ?");
                        $stmt->execute([$id]);

                        $success = 'Usuário inativado com sucesso!';
                    }
                } elseif ($id == $_SESSION['user_id']) {
                    $error = 'Você não pode excluir sua própria conta.';
                }
                break;

        }
    } catch (PDOException $e) {
        $error = 'Erro interno do sistema. Tente novamente.';
    }
}

// Buscar usuários
try {
    $pdo = getDBConnection();
    
    $filtro_tipo = sanitize($_GET['tipo'] ?? '');
    $filtro_ativo = sanitize($_GET['ativo'] ?? '');
    
    $where_conditions = [];
    $params = [];
    
    if ($filtro_tipo) {
        $where_conditions[] = "tipo = ?";
        $params[] = $filtro_tipo;
    }
    
    if ($filtro_ativo !== '') {
        $where_conditions[] = "ativo = ?";
        $params[] = (int)$filtro_ativo;
    }
    
    $where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
    
    $stmt = $pdo->prepare("
        SELECT u.*, 
               COUNT(s.id) as total_solicitacoes,
               COUNT(CASE WHEN s.status = 'devolvida' THEN 1 END) as solicitacoes_concluidas
        FROM usuarios u 
        LEFT JOIN solicitacoes s ON u.id = s.usuario_id 
        $where_clause
        GROUP BY u.id 
        ORDER BY u.nome
    ");
    $stmt->execute($params);
    $usuarios = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = "Erro ao carregar usuários.";
    $usuarios = [];
}

// Buscar usuário para edição
$usuario_edit = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
        $stmt->execute([$edit_id]);
        $usuario_edit = $stmt->fetch();
    } catch (PDOException $e) {
        // Ignorar erro
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Usuários</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Botão de menu hambúrguer para mobile -->
    <button class="mobile-menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    
    <!-- Overlay para fechar sidebar em mobile -->
    <div class="sidebar-overlay" onclick="closeSidebar()"></div>
    
    <div class="main-layout">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h1>SIDE - IBC</h1>
                <p>Bem-vindo, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>
            
            <nav class="sidebar-nav">
                <?php if (isAdmin() || isColaborador()): ?>
                    <a href="usuarios.php" class="nav-item">
                        <i class="fas fa-users"></i> Usuários
                    </a>
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="materiais.php" class="nav-item">
                        <i class="fas fa-boxes"></i> Gestão de Materiais
                    </a>
                <?php endif; ?>
                <?php if ($_SESSION['user_type'] === 'professor' || isAdmin() || isColaborador()): ?>
                    <a href="solicitar.php" class="nav-item">
                        <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                    </a>
                <?php
                $stmt = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
                $pendentes_count = $stmt->fetchColumn();
                ?>
                <a href="pendentes.php" class="nav-item">
                    <span id="contador-pendentes">
                        <i class="fas fa-clock"></i>
                    </span>
                    Solicitações
                </a>
                <?php endif; ?>
            </nav>
            
            <div class="sidebar-footer">
                <a href="../logout.php" class="btn btn-secondary btn-full">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>
        
        <!-- Conteúdo Principal -->
        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-users"></i> Gerenciar Usuários
                </h1>
                <?php if (isAdmin()): ?>
                    <button onclick="toggleForm()" class="btn btn-primary">
                        <i class="fas fa-user-plus"></i> Adicionar Usuário
                    </button>
                <?php endif; ?>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <!-- Formulário de Adicionar/Editar -->
            <div id="usuario-form" class="card" style="display: <?php echo (isColaborador() || $usuario_edit) ? 'block' : 'none'; ?>;">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-<?php echo $usuario_edit ? 'user-edit' : 'user-plus'; ?>"></i> 
                        <?php echo $usuario_edit ? 'Editar' : 'Adicionar'; ?> Usuário
                    </h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="<?php echo $usuario_edit ? 'editar' : 'adicionar'; ?>">
                        <?php if ($usuario_edit): ?>
                            <input type="hidden" name="id" value="<?php echo $usuario_edit['id']; ?>">
                        <?php endif; ?>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                            <div class="form-group">
                                <label for="nome" class="form-label">
                                    <i class="fas fa-user"></i> Nome Completo *
                                </label>
                                <input 
                                    type="text" 
                                    id="nome" 
                                    name="nome" 
                                    class="form-input" 
                                    placeholder="Ex: João Silva"
                                    value="<?php echo htmlspecialchars($usuario_edit['nome'] ?? ''); ?>"
                                    required
                                >
                            </div>
                            
                            <div class="form-group">
                                <label for="cpf" class="form-label">
                                    <i class="fas fa-envelope"></i> CPF *
                                </label>
                                <input 
                                    type="text" 
                                    id="cpf" 
                                    name="cpf" 
                                    class="form-input" 
                                    placeholder="Somente números"
                                    value="<?php echo htmlspecialchars($usuario_edit['cpf'] ?? ''); ?>"
                                    maxlength="11"
                                    pattern="\d{11}"
                                    required
                                >
                            </div>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                            
                            <div class="form-group">
                                <label for="senha" class="form-label">
                                    <i class="fas fa-lock"></i> Senha <?php echo $usuario_edit ? '(deixe vazio para manter)' : '*'; ?>
                                </label>
                                <input 
                                    type="password" 
                                    id="senha" 
                                    name="senha" 
                                    class="form-input" 
                                    placeholder="Mínimo 6 caracteres"
                                    <?php echo $usuario_edit ? '' : 'required'; ?>
                                >
                            </div>
                            
                            <div class="form-group">
                                <label for="tipo" class="form-label">
                                    <i class="fas fa-user-tag"></i> Tipo
                                </label>
                                <select id="tipo" name="tipo" class="form-input">
                                    <option value="professor" <?php echo ($usuario_edit['tipo'] ?? '') === 'professor' ? 'selected' : ''; ?>>Professor</option>
                                    <option value="colaborador" <?php echo ($usuario_edit['tipo'] ?? '') === 'colaborador' ? 'selected' : ''; ?>>Colaborador</option>
                                    <?php if (isAdmin()): // Apenas Admins podem criar outros Admins ?>
                                    <option value="admin" <?php echo ($usuario_edit['tipo'] ?? '') === 'admin' ? 'selected' : ''; ?>>Administrador</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        
                        <?php if ($usuario_edit): ?>
                        <div class="form-group">
                            <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                                <input 
                                    type="checkbox" 
                                    name="ativo" 
                                    <?php echo $usuario_edit['ativo'] ? 'checked' : ''; ?>
                                    style="width: auto;"
                                >
                                <i class="fas fa-toggle-on"></i> Usuário Ativo
                            </label>
                        </div>
                        <?php endif; ?>
                        
                        <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                            <button type="button" onclick="cancelForm()" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancelar
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> <?php echo $usuario_edit ? 'Atualizar' : 'Adicionar'; ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Filtros -->
            <?php if (isAdmin()): ?>
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" action="" style="display: flex; gap: 1rem; align-items: end; flex-wrap: wrap;">
                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="tipo" class="form-label">Tipo</label>
                                <select id="tipo" name="tipo" class="form-input" style="width: 200px;">
                                    <option value="">Todos</option>
                                    <option value="professor" <?php echo $filtro_tipo === 'professor' ? 'selected' : ''; ?>>Professor</option>
                                    <option value="admin" <?php echo $filtro_tipo === 'admin' ? 'selected' : ''; ?>>Administrador</option>
                                </select>
                            </div>
                            
                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="ativo" class="form-label">Status</label>
                                <select id="ativo" name="ativo" class="form-input" style="width: 200px;">
                                    <option value="">Todos</option>
                                    <option value="1" <?php echo $filtro_ativo === '1' ? 'selected' : ''; ?>>Ativo</option>
                                    <option value="0" <?php echo $filtro_ativo === '0' ? 'selected' : ''; ?>>Inativo</option>
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter"></i> Filtrar
                            </button>
                            
                            <a href="usuarios.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Limpar
                            </a>
                        </form>
                    </div>
                </div>
            
            <!-- Lista de Usuários Separada por Ativos e Inativos -->
                <div class="table-container">
                    <!-- Usuários Ativos -->
                    <h2 style="margin: 2rem 0 1rem 0; text-align: center;">Usuários Ativos</h2>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>CPF</th>
                                <th>Tipo</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $ativos_existem = false;
                            foreach ($usuarios as $usuario): 
                                if ($usuario['ativo']):
                                    $ativos_existem = true;
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($usuario['nome']); ?></strong>
                                    <?php if ($usuario['id'] == $_SESSION['user_id']): ?>
                                        <br><small style="color: #2563eb;"><i class="fas fa-star"></i> Você</small>
                                    <?php endif; ?>
                                </td>
                                <td><strong><?php echo htmlspecialchars($usuario['cpf']); ?></strong></td>
                                <td>
                                    <?php
                                        // Mapeamento de tipos para classes de CSS e nomes de exibição
                                        $tipos_map = [
                                            'admin'       => ['classe' => 'dark', 'nome' => 'Administrador'],
                                            'professor'   => ['classe' => 'info',   'nome' => 'Professor'],
                                            'colaborador' => ['classe' => 'secondary', 'nome' => 'Colaborador']
                                        ];
                                        $tipo_atual = $usuario['tipo'];
                                        $classe = $tipos_map[$tipo_atual]['classe'] ?? 'light';
                                        $nome = $tipos_map[$tipo_atual]['nome'] ?? 'Desconhecido';
                                    ?>
                                    <span class="badge badge-<?php echo $classe; ?>">
                                        <?php echo $nome; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge badge-success">Ativo</span>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                                        <a href="?edit=<?php echo $usuario['id']; ?>" class="btn btn-warning" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">
                                            <i class="fas fa-edit"></i> Editar
                                        </a>
                                        <?php if ($usuario['id'] != $_SESSION['user_id']): ?>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Tem certeza que deseja excluir este usuário?')">
                                            <input type="hidden" name="action" value="excluir">
                                            <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">
                                            <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">
                                                <i class="fas fa-trash"></i> Inativar
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php 
                                endif; 
                            endforeach; 
                            if (!$ativos_existem): ?>
                                <tr>
                                    <td colspan="6" class="text-center" style="padding: 2rem; color: #6b7280;">
                                        Nenhum usuário ativo encontrado.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <!-- Usuários Inativos -->
                    <h2 style="margin: 2rem 0 1rem 0; text-align: center;">Usuários Inativos</h2>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>CPF</th>
                                <th>Tipo</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $inativos_existem = false;
                            foreach ($usuarios as $usuario): 
                                if (!$usuario['ativo']):
                                    $inativos_existem = true;
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($usuario['nome']); ?></strong>
                                    <?php if ($usuario['id'] == $_SESSION['user_id']): ?>
                                        <br><small style="color: #2563eb;"><i class="fas fa-star"></i> Você</small>
                                    <?php endif; ?>
                                </td>
                                <td><strong><?php echo htmlspecialchars($usuario['cpf']); ?></strong></td>
                                <td>
                                    <span class="badge badge-<?php echo $usuario['tipo'] === 'admin' ? 'danger' : 'info'; ?>">
                                        <?php echo $usuario['tipo'] === 'admin' ? 'Administrador' : 'Professor'; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge badge-danger">Inativo</span>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                                        <a href="?edit=<?php echo $usuario['id']; ?>" class="btn btn-warning" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">
                                            <i class="fas fa-edit"></i> Editar
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php 
                                endif; 
                            endforeach; 
                            if (!$inativos_existem): ?>
                                <tr>
                                    <td colspan="6" class="text-center" style="padding: 2rem; color: #6b7280;">
                                        Nenhum usuário inativo encontrado.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>   
                </div>
           <?php endif; // Fim da verificação isAdmin() ?>
        </div>
    </div>
    
    <script>
        // Funções para controle do menu mobile
        function toggleSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");
            
            sidebar.classList.toggle("open");
            overlay.classList.toggle("active");
            
            if (sidebar.classList.contains("open")) {
                toggleButton.style.opacity = "0";
                toggleButton.style.pointerEvents = "none";
                mainContent.classList.add("menu-open");
            } else {
                toggleButton.style.opacity = "1";
                toggleButton.style.pointerEvents = "auto";
                mainContent.classList.remove("menu-open");
            }
        }
        
        function closeSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");
            
            sidebar.classList.remove("open");
            overlay.classList.remove("active");
            toggleButton.style.opacity = "1";
            toggleButton.style.pointerEvents = "auto";
            mainContent.classList.remove("menu-open");
        }
        
        function toggleForm() {
            const form = document.getElementById('usuario-form');
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        }
        
        function showForm() {
            document.getElementById('usuario-form').style.display = 'block';
            document.getElementById('nome').focus();
        }
        
        function cancelForm() {
            document.getElementById('usuario-form').style.display = 'none';
            window.location.href = 'usuarios.php';
        }
        
        // Auto-focus no primeiro campo quando formulário está visível
        <?php if ($usuario_edit): ?>
        document.getElementById('nome').focus();
        <?php endif; ?>
        
        // Validação de email em tempo real
        document.getElementById('cpf').addEventListener('blur', function() {
            const cpf = this.value.replace(/\D/g, '');
            if (cpf.length !== 11) {
                alert('CPF inválido. Deve conter 11 números.');
                this.focus();
            }
        });

        function atualizarContador() {
            fetch('contador_pendentes.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('contador-pendentes').innerHTML = data;
                })
                .catch(error => console.error("Erro ao atualizar contador:", error));
        }

        // chama logo no carregamento
        atualizarContador();

        // e repete a cada 5s
        setInterval(atualizarContador, 5000);
    </script>

<style>
    .sidebar.open ~ .mobile-menu-toggle {
        display: none;
    }
</style>

<script>
    function toggleSidebar() {
        const sidebar = document.querySelector(".sidebar");
        const overlay = document.querySelector(".sidebar-overlay");
        const mainContent = document.querySelector(".main-content");
        
        sidebar.classList.toggle("open");
        overlay.classList.toggle("active");
        mainContent.classList.toggle("menu-open");
    }
    
    function closeSidebar() {
        const sidebar = document.querySelector(".sidebar");
        const overlay = document.querySelector(".sidebar-overlay");
        const mainContent = document.querySelector(".main-content");
        
        sidebar.classList.remove("open");
        overlay.classList.remove("active");
        mainContent.classList.remove("menu-open");
    }
</script>