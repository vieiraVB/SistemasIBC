<?php
session_start();
require_once '../includes/config.php';

// Verificar se o usuário está logado e é admin
if (!isset($_SESSION['user_id']) || !isAdmin()) {
    http_response_code(403);
    exit('Acesso negado');
}

header('Content-Type: application/json');

try {
    $pdo = getDBConnection();
    
    // Verificar se há novas solicitações desde a última verificação
    $ultima_verificacao = $_SESSION['ultima_verificacao_notificacao'] ?? date('Y-m-d H:i:s', strtotime('-1 hour'));
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as novas_solicitacoes
        FROM solicitacoes 
        WHERE status = 'pendente' 
        AND data_solicitacao > ?
    ");
    $stmt->execute([$ultima_verificacao]);
    $resultado = $stmt->fetch();
    
    $novas_solicitacoes = $resultado['novas_solicitacoes'];
    
    // Atualizar a última verificação
    $_SESSION['ultima_verificacao_notificacao'] = date('Y-m-d H:i:s');
    
    // Buscar detalhes das novas solicitações se houver
    $detalhes = [];
    if ($novas_solicitacoes > 0) {
        $stmt = $pdo->prepare("
            SELECT s.id, s.tipo_solicitacao, s.data_utilizacao, s.sala, u.nome as usuario_nome
            FROM solicitacoes s
            JOIN usuarios u ON s.usuario_id = u.id
            WHERE s.status = 'pendente' 
            AND s.data_solicitacao > ?
            ORDER BY s.data_solicitacao DESC
        ");
        $stmt->execute([$ultima_verificacao]);
        $detalhes = $stmt->fetchAll();
    }
    
    echo json_encode([
        'success' => true,
        'novas_solicitacoes' => $novas_solicitacoes,
        'detalhes' => $detalhes
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erro interno do sistema'
    ]);
}
?>

