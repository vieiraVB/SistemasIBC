<?php
require_once '../includes/config.php';

header('Content-Type: application/json');

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado']);
    exit;
}

// Verificar se o ID foi fornecido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

$solicitacao_id = (int)$_GET['id'];

try {
    $pdo = getDBConnection();
    
    // Buscar dados da solicitação
    $stmt = $pdo->prepare("
        SELECT s.*, 
               u.nome as usuario_nome,
               admin.nome as aprovada_por_nome
        FROM solicitacoes s 
        JOIN usuarios u ON s.usuario_id = u.id 
        LEFT JOIN usuarios admin ON s.aprovada_por = admin.id
        WHERE s.id = ?
    ");
    $stmt->execute([$solicitacao_id]);
    $solicitacao = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$solicitacao) {
        echo json_encode(['success' => false, 'message' => 'Solicitação não encontrada']);
        exit;
    }
    
    // Se não for admin, verificar se é o próprio usuário
    if (!isAdmin() && $solicitacao['usuario_id'] != $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'message' => 'Acesso negado']);
        exit;
    }
    
    // Buscar materiais solicitados se houver
    $materiais = [];
    if ($solicitacao['materiais_solicitados']) {
        $materiais_data = json_decode($solicitacao['materiais_solicitados'], true);
        if ($materiais_data) {
            foreach ($materiais_data as $material_id => $quantidade) {
                $stmt = $pdo->prepare("SELECT nome FROM materiais WHERE id = ?");
                $stmt->execute([$material_id]);
                $material = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($material) {
                    $materiais[] = [
                        'nome' => $material['nome'],
                        'quantidade' => $quantidade
                    ];
                }
            }
        }
    }
    
    // Adicionar materiais extras se houver
    if ($solicitacao['tipo_solicitacao'] === 'datashow' || $solicitacao['tipo_solicitacao'] === 'ambos') {
        // Verificar se há materiais extras selecionados (isso seria implementado no processamento do formulário)
        // Por enquanto, vamos assumir que não há dados específicos para materiais extras
    }
    
    $solicitacao['materiais'] = $materiais;
    
    echo json_encode([
        'success' => true,
        'solicitacao' => $solicitacao
    ]);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro interno do sistema']);
}
?>

