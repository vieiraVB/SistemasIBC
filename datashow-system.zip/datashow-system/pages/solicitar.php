<?php
require_once '../includes/config.php';
$pdo = getDBConnection();
date_default_timezone_set('America/Manaus');

// Verificar se está logado
if (!isLoggedIn()) {
    redirect('../index.php');
}

$error = '';
$success = '';

// Buscar materiais disponíveis
$stmt = $pdo->query("SELECT id, nome, quantidade FROM materiais WHERE status_disponibilidade = 'disponivel' AND quantidade > 0 ORDER BY nome");
$materiais_disponiveis = $stmt->fetchAll();

// Processar solicitação
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // --- PASSO DE DEBUG (OPCIONAL) ---
    // Se o erro persistir, remova o comentário da linha abaixo para ver todos os dados que o formulário está enviando.
    //var_dump($_POST); die();

    $tipo_solicitacao = sanitize($_POST['tipo_solicitacao'] ?? '');
    $data_utilizacao = sanitize($_POST['data_utilizacao'] ?? '');
    $turno = sanitize($_POST['turno'] ?? '');
    $sala = sanitize($_POST['sala'] ?? '');
    $observacoes = sanitize($_POST['observacoes'] ?? '');
    $materiais_selecionados = $_POST['materiais'] ?? [];
    $equipamentos_requeridos = $_POST['equipamentos_requeridos'] ?? [];

    try {
        // Validações principais
        if (empty($tipo_solicitacao) || empty($data_utilizacao) || empty($sala)) {
            $error = 'Por favor, preencha todos os campos obrigatórios (Tipo, Data e Sala).';

            // Validação específica para equipamentos e ambos
        } elseif (($tipo_solicitacao === 'equipamentos' || $tipo_solicitacao === 'ambos') && empty($turno)) {
            $error = 'Para solicitações de equipamentos, o Turno é obrigatório.';
        } else {
            // --- INÍCIO DO BLOCO COMPLETO E CORRIGIDO ---

            // Define os limites máximos por turno
            $limites = [
                'datashow' => 7,
                'notebook' => 3,
                'caixa_som' => 2,
                'extensao' => 6
            ];

            $erros_limite = [];
            $data_selecionada = $data_utilizacao;
            $turno_selecionado = $turno;

            // VERIFICAÇÕES DE LIMITE DE EQUIPAMENTOS (APENAS SE HOUVER TURNO)
            if (!empty($turno_selecionado)) {
                // 1. VERIFICAR LIMITE DE DATASHOWS E NOTEBOOKS
                $stmt_equip_check = $pdo->prepare("
            SELECT observacoes FROM solicitacoes
            WHERE data_utilizacao = ? AND turno = ? AND status IN ('pendente', 'aprovada', 'retirada')
        ");
                $stmt_equip_check->execute([$data_selecionada, $turno_selecionado]);
                $solicitacoes_ativas_obs = $stmt_equip_check->fetchAll(PDO::FETCH_COLUMN);

                if (in_array('Datashow', $equipamentos_requeridos)) {
                    $datashows_em_uso = 0;
                    foreach ($solicitacoes_ativas_obs as $obs) {
                        if (strpos($obs, 'Datashow') !== false) $datashows_em_uso++;
                    }
                    if ($datashows_em_uso >= $limites['datashow']) {
                        $erros_limite[] = "O limite de {$limites['datashow']} datashows para este turno já foi atingido.";
                    }
                }
                if (in_array('Notebook', $equipamentos_requeridos)) {
                    $notebooks_em_uso = 0;
                    foreach ($solicitacoes_ativas_obs as $obs) {
                        if (strpos($obs, 'Notebook') !== false) $notebooks_em_uso++;
                    }
                    if ($notebooks_em_uso >= $limites['notebook']) {
                        $erros_limite[] = "O limite de {$limites['notebook']} notebooks para este turno já foi atingido.";
                    }
                }
            }

            // Se algum limite foi excedido, exibe o erro
            if (!empty($erros_limite)) {
                $error = implode('<br>', $erros_limite);
            } else {
                // Se passou pelos limites, verifica duplicidade de SALA
                $is_duplicate_sala = false;
                if (!empty($turno)) {
                    $stmt_check_sala = $pdo->prepare("
                SELECT COUNT(*) FROM solicitacoes
                WHERE sala = ? AND turno = ? AND data_utilizacao = ?
                AND status IN ('pendente', 'aprovada', 'retirada')
            ");
                    $stmt_check_sala->execute([$sala, $turno, $data_utilizacao]);
                    if ($stmt_check_sala->fetchColumn() > 0) {
                        $is_duplicate_sala = true;
                    }
                }

                if ($is_duplicate_sala) {
                    $error = "Conflito de Agendamento: Já existe uma solicitação ativa para esta sala, nesta data e turno.";
                } else {
                    // Se tudo estiver OK, FINALMENTE prossegue com a criação da solicitação
                    $pdo->beginTransaction();

                    $observacoes_finais = $observacoes;
                    if (!empty($equipamentos_requeridos)) {
                        $equipamentos_str = ' [Equipamentos Solicitados: ' . implode(', ', $equipamentos_requeridos) . ']';
                        $observacoes_finais .= $equipamentos_str;
                    }

                    $materiais_json = json_encode(array_keys($materiais_selecionados));

                    $stmt_insert = $pdo->prepare("
                INSERT INTO solicitacoes (
                    usuario_id, data_utilizacao, horario_inicio, horario_fim, 
                    sala, observacoes, status, tipo_solicitacao, 
                    turno, materiais_solicitados
                ) 
                VALUES (?, ?, ?, ?, ?, ?, 'pendente', ?, ?, ?)
            ");

                    $stmt_insert->execute([
                        $_SESSION['user_id'],
                        $data_utilizacao,
                        '00:00:00',
                        '00:00:00',
                        $sala,
                        $observacoes_finais,
                        $tipo_solicitacao,
                        $turno,
                        $materiais_json
                    ]);

                    $solicitacao_id = $pdo->lastInsertId();

                    // Salvar materiais da busca na tabela solicitacoes_materiais
                    if (!empty($materiais_selecionados)) {
                        $stmt_materiais = $pdo->prepare("INSERT INTO solicitacoes_materiais (id_solicitacao, id_material, quantidade_solicitada, usuario_id) VALUES (?, ?, ?, ?)");
                        $qty_materiais = $_POST['qty_materiais'] ?? [];
                        foreach ($materiais_selecionados as $material_id) {
                            $quantidade = isset($qty_materiais[$material_id]) ? (int)$qty_materiais[$material_id] : 1;
                            if ($quantidade > 0) {
                                $stmt_materiais->execute([$solicitacao_id, $material_id, $quantidade, $_SESSION['user_id']]);
                            }
                        }
                    }

                    $pdo->commit();
                    $success = 'Solicitação enviada com sucesso! Aguarde a aprovação.';
                }
            }
        }
    } catch (PDOException $e) {
        $error = 'Erro interno do sistema. Tente novamente.';
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Solicitar Equipamentos</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .tipo-solicitacao {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .tipo-option {
            position: relative;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            padding: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
        }

        .tipo-option:hover {
            border-color: #3b82f6;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.15);
        }

        .tipo-option.selected {
            border-color: #3b82f6;
            background: #eff6ff;
        }

        .tipo-option input[type="radio"] {
            position: absolute;
            opacity: 0;
            pointer-events: none;
        }

        .tipo-option .icon {
            font-size: 2rem;
            color: #6b7280;
            margin-bottom: 0.5rem;
            display: block;
        }

        .tipo-option.selected .icon {
            color: #3b82f6;
        }

        .tipo-option .title {
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 0.25rem;
        }

        .tipo-option .description {
            font-size: 0.875rem;
            color: #6b7280;
            line-height: 1.4;
        }

        .materiais-section {
            display: none;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            background: #f9fafb;
        }

        .materiais-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 0.75rem;
            margin-top: 1rem;
        }

        .material-item {
            display: flex;
            align-items: center;
            padding: 0.75rem;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            transition: all 0.2s ease;
        }

        .material-item:hover {
            border-color: #3b82f6;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
        }

        .material-item input[type="checkbox"] {
            margin-right: 0.75rem;
            transform: scale(1.1);
        }

        .material-info {
            flex: 1;
        }

        .material-name {
            font-weight: 500;
            color: #1f2937;
            margin-bottom: 0.25rem;
        }

        .material-qty {
            font-size: 0.875rem;
            color: #6b7280;
        }

        .material-item-with-qty {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            padding: 0.75rem;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            transition: all 0.2s ease;
        }

        .material-item-with-qty:hover {
            border-color: #3b82f6;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
        }

        .material-checkbox {
            display: flex;
            align-items: center;
        }

        .material-quantity {
            display: flex;
            align-items: center;
            justify-content: flex-end;
        }

        .materiais-grid-scrollable {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            padding: 1rem;
            background: white;
        }

        .materiais-grid-scrollable::-webkit-scrollbar {
            width: 8px;
        }

        .materiais-grid-scrollable::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 4px;
        }

        .materiais-grid-scrollable::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 4px;
        }

        .materiais-grid-scrollable::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }

        .material-item-search {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            margin-bottom: 0.5rem;
            transition: all 0.2s ease;
        }

        .material-item-search:hover {
            border-color: #3b82f6;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
        }

        .material-item-search:last-child {
            margin-bottom: 0;
        }

        .material-left {
            display: flex;
            align-items: center;
            flex: 1;
        }

        .material-right {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .horarios-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        @media (max-width: 768px) {
            .horarios-section {
                grid-template-columns: 1fr;
            }

            .material-item-with-qty {
                padding: 0.5rem;
            }

            .material-quantity {
                justify-content: flex-start;
            }
        }
    </style>
</head>

<body>
    <!-- Botão de menu hambúrguer para mobile -->
    <button class="mobile-menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Overlay para fechar sidebar em mobile -->
    <div class="sidebar-overlay" onclick="closeSidebar()"></div>

    <div class="main-layout">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h1>SIDE - IBC</h1>
                <p>Bem-vindo, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>

            <nav class="sidebar-nav">
                <?php if (isAdmin() || isColaborador()): ?>
                    <a href="usuarios.php" class="nav-item">
                        <i class="fas fa-users"></i> Usuários
                    </a>
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="materiais.php" class="nav-item">
                        <i class="fas fa-boxes"></i> Gestão de Materiais
                    </a>
                <?php endif; ?>
                <?php if ($_SESSION['user_type'] === 'professor' || isAdmin() || isColaborador()): ?>
                    <a href="solicitar.php" class="nav-item">
                        <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                    </a>
                    <?php
                    $stmt = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
                    $pendentes_count = $stmt->fetchColumn();
                    ?>
                    <a href="pendentes.php" class="nav-item">
                        <span id="contador-pendentes">
                            <i class="fas fa-clock"></i>
                        </span>
                        Solicitações
                    </a>
                <?php endif; ?>
            </nav>

            <div class="sidebar-footer">
                <a href="../logout.php" class="btn btn-secondary btn-full">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>

        <!-- Conteúdo Principal -->
        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                </h1>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-form"></i> Formulário de Solicitação
                    </h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <!-- Tipo de Solicitação -->
                        <div class="form-group">
                            <label class="form-label">
                                <i class="fas fa-list"></i> Tipo de Solicitação *
                            </label>
                            <div class="tipo-solicitacao">
                                <label class="tipo-option" for="tipo_equipamentos">
                                    <input type="radio" id="tipo_equipamentos" name="tipo_solicitacao" value="equipamentos" required>
                                    <i class="fas fa-video icon"></i>
                                    <div class="title">Equipamentos</div>
                                    <div class="description">Para datashow e/ou notebook. Pode solicitar para o mesmo dia.</div>
                                </label>

                                <label class="tipo-option" for="tipo_materiais">
                                    <input type="radio" id="tipo_materiais" name="tipo_solicitacao" value="materiais" required>
                                    <i class="fas fa-boxes icon"></i>
                                    <div class="title">Apenas Materiais</div>
                                    <div class="description">Requer 48 horas de antecedência.</div>
                                </label>

                                <label class="tipo-option" for="tipo_ambos">
                                    <input type="radio" id="tipo_ambos" name="tipo_solicitacao" value="ambos" required>
                                    <i class="fas fa-layer-group icon"></i>
                                    <div class="title">Equipamentos + Materiais</div>
                                    <div class="description">Requer 48 horas de antecedência.</div>
                                </label>
                            </div>
                            <div id="equipamentos-container" style="display: none; margin-bottom: 1.5rem; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem;">
                                <h3 style="margin-top: 0; margin-bottom: 1rem; color: #1f2937;">
                                    <i class="fas fa-desktop"></i> Quais equipamentos você precisa? *
                                </h3>
                                <div style="display: flex; gap: 1.5rem; flex-wrap: wrap; margin-bottom: 1.5rem;">
                                    <label style="display: flex; align-items: center; gap: 0.5rem; font-weight: 500;">
                                        <input type="checkbox" id="equip_datashow" name="equipamentos_requeridos[]" value="Datashow" style="transform: scale(1.2);">
                                        Datashow
                                    </label>
                                    <label style="display: flex; align-items: center; gap: 0.5rem; font-weight: 500;">
                                        <input type="checkbox" id="equip_notebook" name="equipamentos_requeridos[]" value="Notebook" style="transform: scale(1.2);">
                                        Notebook
                                    </label>
                                </div>
                                <small style="color: #6b7280; font-size: 0.875rem; margin-top: -1rem; display: block;">
                                    <i class="fas fa-info-circle"></i> Limites por turno: 7 datashows e 3 notebooks.
                                </small>

                                <div id="materiais-extras-container" style="display: none;">
                                    <h4 style="margin-bottom: 0.75rem; color: #374151; font-size: 1rem;">
                                        <!-- Materiais Extras para Datashow -->
                                        <i class="fas fa-video"></i> Materiais para Datashow
                                    </h4>

                                    <div class="material-item-with-qty">
                                        <div class="material-checkbox">
                                            <input type="checkbox" id="material_extra_caixa_som" name="materiais_extras[caixa_som]" value="1" ...>
                                            <div class="material-info">
                                                <div class="material-name">Caixa de Som</div>
                                                <div class="material-qty">Limite por turno: 2 unidades</div>
                                            </div>
                                        </div>
                                        <div class="material-quantity">
                                            <label ...>Qtd:</label>
                                            <input type="number" id="qty_caixa_som" name="qty_materiais_extras[caixa_som]" min="1" max="2" value="1" ... disabled>
                                        </div>
                                    </div>
                                    <div class="material-item-with-qty">
                                        <div class="material-checkbox">
                                            <input type="checkbox" id="material_extra_extensao" name="materiais_extras[extensao]" value="1" ...>
                                            <div class="material-info">
                                                <div class="material-name">Extensão</div>
                                                <div class="material-qty">Limite por turno: 6 unidades</div>
                                            </div>
                                        </div>
                                        <div class="material-quantity">
                                            <label ...>Qtd:</label>
                                            <input type="number" id="qty_extensao" name="qty_materiais_extras[extensao]" min="1" max="6" value="1" ... disabled>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Informações Básicas -->
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                                <div class="form-group">
                                    <label for="professor" class="form-label">
                                        <i class="fas fa-user"></i> Professor
                                    </label>
                                    <input
                                        type="text"
                                        id="professor"
                                        class="form-input"
                                        value="<?php echo htmlspecialchars($_SESSION['user_name']); ?>"
                                        readonly
                                        style="background-color: #f8fafc; color: #6b7280;">
                                </div>

                                <div class="form-group">
                                    <label for="data_utilizacao" class="form-label">
                                        <i class="fas fa-calendar"></i> Data de Utilização *
                                    </label>
                                    <input
                                        type="date"
                                        id="data_utilizacao"
                                        name="data_utilizacao"
                                        class="form-input"
                                        value="<?php echo htmlspecialchars($data_utilizacao ?? ''); ?>"
                                        min="<?php echo date('Y-m-d'); ?>"
                                        required>
                                </div>
                            </div>

                            <!-- Turno (apenas para datashow) -->
                            <div id="turno-container" style="display: none;">
                                <div class="form-group" style="margin-bottom: 1.5rem;">
                                    <label for="turno" class="form-label">
                                        <i class="fas fa-sun"></i> Turno *
                                    </label>
                                    <select
                                        id="turno"
                                        name="turno"
                                        class="form-input">
                                        <option value="">Selecione o turno</option>
                                        <option value="matutino" <?php echo ($turno ?? '') === 'matutino' ? 'selected' : ''; ?>>Matutino</option>
                                        <option value="vespertino" <?php echo ($turno ?? '') === 'vespertino' ? 'selected' : ''; ?>>Vespertino</option>
                                        <option value="noturno" <?php echo ($turno ?? '') === 'noturno' ? 'selected' : ''; ?>>Noturno</option>
                                    </select>
                                    <small style="color: #6b7280; font-size: 0.875rem; margin-top: 0.5rem; display: block;">
                                        <i class="fas fa-info-circle"></i> Limite de 7 datashows por turno
                                    </small>
                                </div>
                            </div>

                            <!-- Sala -->
                            <div class="form-group" style="margin-bottom: 1.5rem;">
                                <label for="sala" class="form-label">
                                    <i class="fas fa-door-open"></i> Sala *
                                </label>
                                <select
                                    id="sala"
                                    name="sala"
                                    class="form-input"
                                    required>
                                    <option value="">Selecione a sala</option>
                                    <optgroup label="Laboratórios">
                                        <option value="Laboratório 3" <?php echo ($sala ?? '') === 'Laboratório 3' ? 'selected' : ''; ?>>Laboratório 3</option>
                                        <option value="Laboratório 4" <?php echo ($sala ?? '') === 'Laboratório 4' ? 'selected' : ''; ?>>Laboratório 4</option>
                                        <option value="Laboratório 5" <?php echo ($sala ?? '') === 'Laboratório 5' ? 'selected' : ''; ?>>Laboratório 5</option>
                                        <option value="Laboratório 6" <?php echo ($sala ?? '') === 'Laboratório 6' ? 'selected' : ''; ?>>Laboratório 6</option>
                                        <option value="Laboratório 7" <?php echo ($sala ?? '') === 'Laboratório 7' ? 'selected' : ''; ?>>Laboratório 7</option>
                                        <option value="Laboratório 8" <?php echo ($sala ?? '') === 'Laboratório 8' ? 'selected' : ''; ?>>Laboratório 8</option>
                                        <option value="Laboratório 9" <?php echo ($sala ?? '') === 'Laboratório 9' ? 'selected' : ''; ?>>Laboratório 9</option>
                                        <option value="Laboratório 10" <?php echo ($sala ?? '') === 'Laboratório 10' ? 'selected' : ''; ?>>Laboratório 10</option>
                                        <option value="Laboratório 11" <?php echo ($sala ?? '') === 'Laboratório 11' ? 'selected' : ''; ?>>Laboratório 11</option>
                                    </optgroup>
                                    <optgroup label="Salas de Aula">
                                        <option value="Sala 2" <?php echo ($sala ?? '') === 'Sala 2' ? 'selected' : ''; ?>>Sala 2</option>
                                        <option value="Sala 3" <?php echo ($sala ?? '') === 'Sala 3' ? 'selected' : ''; ?>>Sala 3</option>
                                        <option value="Sala 4" <?php echo ($sala ?? '') === 'Sala 4' ? 'selected' : ''; ?>>Sala 4</option>
                                        <option value="Sala 5" <?php echo ($sala ?? '') === 'Sala 5' ? 'selected' : ''; ?>>Sala 5</option>
                                        <option value="Sala 6" <?php echo ($sala ?? '') === 'Sala 6' ? 'selected' : ''; ?>>Sala 6</option>
                                        <option value="Sala 7" <?php echo ($sala ?? '') === 'Sala 7' ? 'selected' : ''; ?>>Sala 7</option>
                                        <option value="Sala 8" <?php echo ($sala ?? '') === 'Sala 8' ? 'selected' : ''; ?>>Sala 8</option>
                                        <option value="Sala 9" <?php echo ($sala ?? '') === 'Sala 9' ? 'selected' : ''; ?>>Sala 9</option>
                                        <option value="Sala 10" <?php echo ($sala ?? '') === 'Sala 10' ? 'selected' : ''; ?>>Sala 10</option>
                                        <option value="Sala 11" <?php echo ($sala ?? '') === 'Sala 11' ? 'selected' : ''; ?>>Sala 11</option>
                                    </optgroup>
                                    <optgroup label="Laboratórios Especializados">
                                        <option value="Laboratório de Eletrotécnica" <?php echo ($sala ?? '') === 'Laboratório de Eletrotécnica' ? 'selected' : ''; ?>>Laboratório de Eletrotécnica</option>
                                        <option value="Laboratório de Eletricidade" <?php echo ($sala ?? '') === 'Laboratório de Eletricidade' ? 'selected' : ''; ?>>Laboratório de Eletricidade</option>
                                        <option value="Laboratório de ESD" <?php echo ($sala ?? '') === 'Laboratório de ESD' ? 'selected' : ''; ?>>Laboratório de ESD</option>
                                        <option value="Laboratório de Automação" <?php echo ($sala ?? '') === 'Laboratório de Automação' ? 'selected' : ''; ?>>Laboratório de Automação</option>
                                    </optgroup>
                                    <optgroup label="Outros Espaços">
                                        <option value="Reunião">Reunião</option>
                                    </optgroup>
                                </select>
                                <small style="color: #6b7280; font-size: 0.875rem; margin-top: 0.5rem; display: block;">
                                    <i class="fas fa-info-circle"></i> Para a opção "Reunião", por favor, especifique a sala (ex: diretoria, coordenação) nas Observações Gerais.
                                </small>
                            </div>

                            <!-- Seleção de Materiais -->
                            <div id="materiais-container" class="materiais-section">
                                <h3 style="margin-bottom: 1rem; color: #1f2937;">
                                    <i class="fas fa-boxes"></i> Selecionar Materiais
                                </h3>

                                <!-- Barra de Pesquisa para Outros Materiais -->
                                <div id="outros-materiais-container" style="display: none;">
                                    <h4 style="margin-bottom: 0.75rem; color: #374151; font-size: 1rem;">
                                        <i class="fas fa-search"></i> Outros Materiais
                                    </h4>
                                    <div class="form-group" style="margin-bottom: 1rem;">
                                        <input
                                            type="text"
                                            id="busca-materiais"
                                            class="form-input"
                                            placeholder="Digite para buscar materiais..."
                                            style="width: 100%;">
                                    </div>
                                    <div id="materiais-grid" class="materiais-grid-scrollable" style="display: none;">
                                        <!-- Materiais serão carregados via JavaScript -->
                                    </div>
                                </div>
                            </div>

                            <!-- Observações Gerais -->
                            <div class="form-group">
                                <label for="observacoes" class="form-label">
                                    <i class="fas fa-comment"></i> Observações Gerais
                                </label>
                                <textarea
                                    id="observacoes"
                                    name="observacoes"
                                    class="form-input"
                                    rows="4"
                                    placeholder="Informações adicionais sobre a utilização dos equipamentos..."
                                    style="resize: vertical;"><?php echo htmlspecialchars($observacoes ?? ''); ?></textarea>
                            </div>

                            <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                                <button type="reset" class="btn btn-secondary">
                                    <i class="fas fa-undo"></i> Limpar
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane"></i> Enviar Solicitação
                                </button>
                            </div>
                    </form>
                </div>
            </div>

            <!-- Informações Importantes -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-info-circle"></i> Informações Importantes
                    </h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem;">
                        <div>
                            <h3 style="color: #3b82f6; margin-bottom: 0.5rem;">
                                <i class="fas fa-video"></i> Datashow
                            </h3>
                            <p style="color: #6b7280; font-size: 0.875rem;">
                                • Pode ser solicitado para o mesmo dia<br>
                                • Seleção de turno é obrigatória<br>
                                • Limite de 7 datashows por turno<br>
                                • Materiais extras: Caixa de Som, Extensão, Microfone
                            </p>
                        </div>

                        <div>
                            <h3 style="color: #10b981; margin-bottom: 0.5rem;">
                                <i class="fas fa-boxes"></i> Materiais
                            </h3>
                            <p style="color: #6b7280; font-size: 0.875rem;">
                                • Requer 48 horas de antecedência<br>
                                • Use a barra de pesquisa para encontrar materiais<br>
                                • Especifique quantidades nas observações<br>
                                • Materiais disponíveis conforme estoque
                            </p>
                        </div>

                        <div>
                            <h3 style="color: #f59e0b; margin-bottom: 0.5rem;">
                                <i class="fas fa-exclamation-triangle"></i> Responsabilidades
                            </h3>
                            <p style="color: #6b7280; font-size: 0.875rem;">
                                • Cuidar dos equipamentos durante o uso<br>
                                • Devolver no horário combinado<br>
                                • Reportar problemas imediatamente<br>
                                • Respeitar os limites de quantidade
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // A chave da solução: todo o código que manipula o HTML agora espera a página carregar completamente.
        document.addEventListener('DOMContentLoaded', function() {

            // Funções para controle do menu mobile
            function toggleSidebar() {
                const sidebar = document.querySelector(".sidebar");
                const overlay = document.querySelector(".sidebar-overlay");
                if (sidebar) sidebar.classList.toggle("open");
                if (overlay) overlay.classList.toggle("active");
            }

            function closeSidebar() {
                const sidebar = document.querySelector(".sidebar");
                const overlay = document.querySelector(".sidebar-overlay");
                if (sidebar) sidebar.classList.remove("open");
                if (overlay) overlay.classList.remove("active");
            }

            const mobileMenuToggle = document.querySelector(".mobile-menu-toggle");
            if (mobileMenuToggle) {
                mobileMenuToggle.onclick = toggleSidebar;
            }
            const sidebarOverlay = document.querySelector(".sidebar-overlay");
            if (sidebarOverlay) {
                sidebarOverlay.onclick = closeSidebar;
            }

            // --- LÓGICA DO FORMULÁRIO ---
            const tipoRadios = document.querySelectorAll('input[name="tipo_solicitacao"]');
            const turnoContainer = document.getElementById('turno-container');
            const equipamentosContainer = document.getElementById('equipamentos-container');
            const materiaisContainer = document.getElementById('materiais-container');
            const materiaisExtrasContainer = document.getElementById('materiais-extras-container');
            const outrosMateriaisContainer = document.getElementById('outros-materiais-container');
            const dataInput = document.getElementById('data_utilizacao');
            const turnoInput = document.getElementById('turno');
            const datashowCheckbox = document.getElementById('equip_datashow');
            const buscaMateriais = document.getElementById('busca-materiais');
            const materiaisGrid = document.getElementById('materiais-grid');

            function updateFormBasedOnType() {
                const selectedType = document.querySelector('input[name="tipo_solicitacao"]:checked')?.value;

                document.querySelectorAll('.tipo-option').forEach(option => option.classList.remove('selected'));
                if (selectedType) {
                    const selectedOption = document.querySelector(`input[value="${selectedType}"]`);
                    if (selectedOption) selectedOption.closest('.tipo-option').classList.add('selected');
                }

                if (turnoContainer) turnoContainer.style.display = 'none';
                if (equipamentosContainer) equipamentosContainer.style.display = 'none';
                if (materiaisContainer) materiaisContainer.style.display = 'none';
                if (outrosMateriaisContainer) outrosMateriaisContainer.style.display = 'none';
                if (turnoInput) turnoInput.required = false;

                if (selectedType === 'equipamentos') {
                    if (turnoContainer) turnoContainer.style.display = 'block';
                    if (equipamentosContainer) equipamentosContainer.style.display = 'block';
                    if (dataInput) dataInput.min = new Date().toISOString().split('T')[0];
                    if (turnoInput) turnoInput.required = true;
                } else if (selectedType === 'materiais') {
                    if (materiaisContainer) materiaisContainer.style.display = 'block';
                    if (outrosMateriaisContainer) outrosMateriaisContainer.style.display = 'block';
                    const minDate = new Date();
                    minDate.setDate(minDate.getDate() + 2);
                    if (dataInput) dataInput.min = minDate.toISOString().split('T')[0];
                } else if (selectedType === 'ambos') {
                    if (turnoContainer) turnoContainer.style.display = 'block';
                    if (equipamentosContainer) equipamentosContainer.style.display = 'block';
                    if (materiaisContainer) materiaisContainer.style.display = 'block';
                    if (outrosMateriaisContainer) outrosMateriaisContainer.style.display = 'block';
                    const minDate = new Date();
                    minDate.setDate(minDate.getDate() + 2);
                    if (dataInput) dataInput.min = minDate.toISOString().split('T')[0];
                    if (turnoInput) turnoInput.required = true;
                }
            }

            if (tipoRadios.length > 0) {
                tipoRadios.forEach(radio => radio.addEventListener('change', updateFormBasedOnType));
            }

            if (datashowCheckbox) {
                datashowCheckbox.addEventListener('change', function() {
                    if (materiaisExtrasContainer) {
                        materiaisExtrasContainer.style.display = this.checked ? 'block' : 'none';
                    }
                });
            }

            let timeoutId;
            if (buscaMateriais) {
                buscaMateriais.addEventListener('input', function() {
                    clearTimeout(timeoutId);
                    const termo = this.value.trim();
                    if (termo.length < 2) {
                        if (materiaisGrid) {
                            materiaisGrid.style.display = 'none';
                            materiaisGrid.innerHTML = '';
                        }
                        return;
                    }
                    timeoutId = setTimeout(() => buscarMateriais(termo), 300);
                });
            }

            updateFormBasedOnType(); // Inicializa o estado do formulário

            // Controle dos campos de quantidade (Caixa de Som, Extensão)
            ['caixa_som', 'extensao'].forEach(id => {
                const checkbox = document.getElementById(`material_extra_${id}`);
                if (checkbox) {
                    checkbox.addEventListener('change', function() {
                        const qtyInput = document.getElementById(`qty_${id}`);
                        if (qtyInput) {
                            qtyInput.disabled = !this.checked;
                            if (!this.checked) qtyInput.value = 1;
                        }
                    });
                }
            });

            const mainForm = document.querySelector('.card-body form');
            if (mainForm) {
                mainForm.addEventListener('submit', function(e) {
                    const btn = this.querySelector('button[type="submit"]');
                    if (btn) {
                        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
                        btn.disabled = true;
                    }
                });
            }
        }); // Fim do 'DOMContentLoaded'

        // == FUNÇÕES COMPLETAS AQUI ==
        function buscarMateriais(termo) {
            const materiaisGrid = document.getElementById('materiais-grid');
            if (!materiaisGrid) return;

            fetch(`buscar_materiais.php?termo=${encodeURIComponent(termo)}`)
                .then(response => response.json())
                .then(data => {
                    materiaisGrid.innerHTML = '';
                    if (data.length === 0) {
                        materiaisGrid.innerHTML = '<p style="text-align: center; color: #6b7280; padding: 1rem;">Nenhum material encontrado.</p>';
                    } else {
                        data.forEach(material => {
                            const materialDiv = document.createElement('div');
                            materialDiv.className = 'material-item-search';
                            // --- AQUI ESTÁ A CORREÇÃO PRINCIPAL ---
                            materialDiv.innerHTML = `
                        <div class="material-left">
                            <input type="checkbox" id="material_${material.id}" name="materiais[]" value="${material.id}"
                                style="margin-right: 0.75rem; transform: scale(1.1);"
                                onchange="toggleQuantityInput(this, ${material.id})">
                            <div class="material-info">
                                <div class="material-name">${material.nome}</div>
                                <div class="material-qty">Disponível: ${material.quantidade} (Máx. permitido: ${material.quantidade_maxima})</div>
                            </div>
                        </div>
                        <div class="material-right">
                            <label for="qty_material_${material.id}" style="font-size: 0.875rem; color: #6b7280;">Qtd:</label>
                            <input type="number" id="qty_material_${material.id}" name="qty_materiais[${material.id}]" 
                                min="1" max="${material.quantidade_maxima}" value="1"
                                style="width: 60px; padding: 0.25rem; border: 1px solid #d1d5db; border-radius: 4px; margin-left: 0.5rem;" disabled>
                        </div>
                    `;
                            materiaisGrid.appendChild(materialDiv);
                        });
                    }
                    materiaisGrid.style.display = 'block';
                })
                .catch(error => {
                    console.error('Erro ao buscar materiais:', error);
                    if (materiaisGrid) {
                        materiaisGrid.innerHTML = '<p style="text-align: center; color: #dc2626; padding: 1rem;">Erro ao buscar materiais.</p>';
                        materiaisGrid.style.display = 'block';
                    }
                });
        }

        function toggleQuantityInput(checkbox, materialId, maxQuantity) {
            const quantityInput = document.getElementById(`qty_material_${materialId}`);
            if (quantityInput) {
                quantityInput.disabled = !checkbox.checked;
                if (!checkbox.checked) {
                    quantityInput.value = 1;
                }
            }
        }

        // --- FUNÇÃO DO CONTADOR ---
        function atualizarContador() {
            const contadorElement = document.getElementById('contador-pendentes');
            if (contadorElement) {
                fetch('contador_pendentes.php')
                    .then(response => {
                        if (!response.ok) throw new Error('Network response was not ok');
                        return response.text();
                    })
                    .then(data => {
                        contadorElement.innerHTML = data;
                    })
                    .catch(error => console.error("Erro ao atualizar contador:", error));
            }
        }

        // Chama a função no carregamento da página e a cada 5 segundos
        atualizarContador();
        setInterval(atualizarContador, 5000);
    </script>
</body>

</html>