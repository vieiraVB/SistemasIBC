<table class="table">
    <thead>
        <tr>
            <th>Professor</th>
            <th>Data</th>
            <th>Sala</th>
            <th>Materiais</th>
            <th>Status</th>
            <?php if (isAdmin()): ?>
            <th>Ações</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($solicitacoes)): ?>
            <tr>
                <td colspan="<?php echo isAdmin() ? '7' : '6'; ?>" class="text-center" style="padding: 2rem; color: #6b7280;">
                    <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 1rem; display: block;"></i>
                    Nenhuma solicitação encontrada.
                </td>
            </tr>
        <?php else: ?>
            <?php foreach ($solicitacoes as $solicitacao): ?>
                <tr class="clickable-row" onclick="abrirDetalhes(<?php echo $solicitacao['id']; ?>)">
                    <td>
                        <strong><?php echo htmlspecialchars($solicitacao['usuario_nome']); ?></strong>
                        <?php if ($solicitacao['observacoes']): ?>
                            <br><small style="color: #6b7280;" title="<?php echo htmlspecialchars($solicitacao['observacoes']); ?>">
                                <i class="fas fa-comment"></i> Obs: <?php echo substr(htmlspecialchars($solicitacao['observacoes']), 0, 30) . (strlen($solicitacao['observacoes']) > 30 ? '...' : ''); ?>
                            </small>
                        <?php endif; ?>
                    </td>
                    <td><?php echo date('d/m/Y', strtotime($solicitacao['data_utilizacao'])); ?></td>
                    <td><?php echo htmlspecialchars($solicitacao['sala']); ?></td>
<td>
    <?php 
    $materiais_info = obterNomesMateriais($pdo, $solicitacao['materiais_solicitados']);
    if (!empty($materiais_info)):
        foreach ($materiais_info as $material):
            echo htmlspecialchars($material['nome']) . ' (' . htmlspecialchars($material['quantidade']) . ')<br>';
        endforeach;
    else:
        echo 'N/A';
    endif;
    ?>
</td>
                    
                    <td>
                        <span class="badge badge-<?php 
                            echo $solicitacao['status'] === 'pendente' ? 'warning' : 
                                ($solicitacao['status'] === 'aprovada' ? 'info' : 
                                ($solicitacao['status'] === 'retirada' ? 'success' : 
                                ($solicitacao['status'] === 'devolvida' ? 'success' : 'danger'))); 
                        ?>">
                            <?php echo ucfirst($solicitacao['status']); ?>
                        </span>
                    </td>
                    <?php if (isAdmin()): ?>
                    <td>
                        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                            <?php if ($solicitacao['status'] === 'pendente'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="aprovar">
                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                    <button type="submit" class="btn btn-success" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">
                                        <i class="fas fa-check"></i> Aprovar
                                    </button>
                                </form>
                            <?php elseif ($solicitacao['status'] === 'aprovada'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="retirar">
                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                    <button type="submit" class="btn btn-warning" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">
                                        <i class="fas fa-hand-paper"></i> Retirar
                                    </button>
                                </form>
                            <?php elseif ($solicitacao['status'] === 'retirada'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="devolver">
                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                    <button type="submit" class="btn btn-primary" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">
                                        <i class="fas fa-undo"></i> Devolver
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                    <?php elseif ($solicitacao['status'] === 'pendente' && $solicitacao['usuario_id'] == $_SESSION['user_id']): ?>
                    <td>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="action" value="cancelar">
                            <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                            <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">
                                <i class="fas fa-times"></i> Cancelar
                            </button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>
