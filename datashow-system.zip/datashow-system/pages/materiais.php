<?php
require_once '../includes/config.php';

// Verificar se está logado e é admin
if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}

$error = '';
$success = '';

// Processar ações CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($_POST['action'] ?? '');
    
    try {
        $pdo = getDBConnection();
        
        switch ($action) {
            case 'adicionar':
                $nome = sanitize($_POST['nome'] ?? '');
                $descricao = sanitize($_POST['descricao'] ?? '');
                $quantidade = (int)($_POST['quantidade'] ?? 0);
                $status = sanitize($_POST['status'] ?? 'disponivel');
                
                if (empty($nome)) {
                    $error = 'O nome do material é obrigatório.';
                } else {
                    $stmt = $pdo->prepare("
                        INSERT INTO materiais (nome, descricao, quantidade, status_disponibilidade) 
                        VALUES (?, ?, ?, ?)
                    ");
                    $stmt->execute([$nome, $descricao, $quantidade, $status]);
                    $success = 'Material adicionado com sucesso!';
                }
                break;
                
            case 'editar':
                $id = (int)($_POST['id'] ?? 0);
                $nome = sanitize($_POST['nome'] ?? '');
                $descricao = sanitize($_POST['descricao'] ?? '');
                $quantidade = (int)($_POST['quantidade'] ?? 0);
                $status = sanitize($_POST['status'] ?? 'disponivel');
                
                if (empty($nome) || !$id) {
                    $error = 'Dados inválidos para edição.';
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE materiais 
                        SET nome = ?, descricao = ?, quantidade = ?, status_disponibilidade = ?, updated_at = NOW()
                        WHERE id = ?
                    ");
                    $stmt->execute([$nome, $descricao, $quantidade, $status, $id]);
                    $success = 'Material atualizado com sucesso!';
                }
                break;
                
            case 'remover':
                $id = (int)($_POST['id'] ?? 0);
                
                if (!$id) {
                    $error = 'ID inválido para remoção.';
                } else {
                    // Verificar se o material está sendo usado em solicitações pendentes
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*) as total 
                        FROM solicitacoes 
                        WHERE status IN ('pendente', 'aprovada', 'retirada') 
                        AND materiais_solicitados LIKE ?
                    ");
                    $stmt->execute(['%"' . $id . '"%']);
                    
                    if ($stmt->fetch()['total'] > 0) {
                        $error = 'Não é possível remover este material pois ele está sendo usado em solicitações ativas.';
                    } else {
                        $stmt = $pdo->prepare("DELETE FROM materiais WHERE id = ?");
                        $stmt->execute([$id]);
                        $success = 'Material removido com sucesso!';
                    }
                }
                break;
        }
    } catch (PDOException $e) {
        $error = 'Erro interno do sistema. Tente novamente.';
    }
}

// Filtros
$filtro_status = sanitize($_GET['status'] ?? '');
$filtro_busca = sanitize($_GET['busca'] ?? '');

// Buscar materiais
try {
    $pdo = getDBConnection();
    
    $where_conditions = [];
    $params = [];
    
    if ($filtro_status) {
        $where_conditions[] = "status_disponibilidade = ?";
        $params[] = $filtro_status;
    }
    
    if ($filtro_busca) {
        $where_conditions[] = "(nome LIKE ? OR descricao LIKE ?)";
        $params[] = "%$filtro_busca%";
        $params[] = "%$filtro_busca%";
    }
    
    $where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
    
    $stmt = $pdo->prepare("
        SELECT * FROM materiais 
        $where_clause
        ORDER BY nome ASC
    ");
    $stmt->execute($params);
    $materiais = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = "Erro ao carregar materiais.";
    $materiais = [];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Gestão de Materiais</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 2rem;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            position: relative;
        }
        
        .modal-header {
            display: flex;
            justify-content: between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .modal-title {
            margin: 0;
            color: #1f2937;
        }
        
        .close {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #6b7280;
        }
        
        .close:hover {
            color: #374151;
        }
        
        .status-badge {
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .status-disponivel {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-indisponivel {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .actions-cell {
            white-space: nowrap;
        }
        
        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
        }
        
        .search-container {
            display: flex;
            gap: 1rem;
            align-items: end;
            flex-wrap: wrap;
        }
        
        @media (max-width: 768px) {
            .search-container {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-container .form-group {
                margin-bottom: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Botão de menu hambúrguer para mobile -->
    <button class="mobile-menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    
    <!-- Overlay para fechar sidebar em mobile -->
    <div class="sidebar-overlay" onclick="closeSidebar()"></div>
    
    <div class="main-layout">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h1>SIDE - IBC</h1>
                <p>Bem-vindo, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>
            
            <nav class="sidebar-nav">
                <a href="historico.php" class="nav-item">
                    <i class="fas fa-history"></i> Histórico
                </a>
                <a href="usuarios.php" class="nav-item">
                    <i class="fas fa-users"></i> Usuários
                </a>
                <a href="materiais.php" class="nav-item active">
                    <i class="fas fa-boxes"></i> Gestão de Materiais
                </a>
                <a href="solicitar.php" class="nav-item">
                    <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                </a>
                <?php
                $stmt = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
                $pendentes_count = $stmt->fetchColumn();
                ?>
                <a href="pendentes.php" class="nav-item">
                    <span id="contador-pendentes">
                        <?php if ($pendentes_count > 0): ?>
                            <span class="badge bg-danger"><?php echo $pendentes_count; ?></span>
                        <?php else: ?>
                            <i class="fas fa-clock"></i>
                        <?php endif; ?>
                    </span>
                    Solicitações
                </a>
            </nav>
            
            <div class="sidebar-footer">
                <a href="../logout.php" class="btn btn-secondary btn-full">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>
        
        <!-- Conteúdo Principal -->
        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-boxes"></i> Gestão de Materiais
                </h1>
                <button class="btn btn-primary" onclick="abrirModal('adicionar')">
                    <i class="fas fa-plus"></i> Adicionar Material
                </button>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <!-- Filtros e Busca -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" action="">
                        <div class="search-container">
                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="busca" class="form-label">Buscar</label>
                                <input 
                                    type="text" 
                                    id="busca" 
                                    name="busca" 
                                    class="form-input" 
                                    placeholder="Nome ou descrição..."
                                    value="<?php echo htmlspecialchars($filtro_busca); ?>"
                                    style="width: 250px;"
                                >
                            </div>
                            
                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="status" class="form-label">Status</label>
                                <select id="status" name="status" class="form-input" style="width: 150px;">
                                    <option value="">Todos</option>
                                    <option value="disponivel" <?php echo $filtro_status === 'disponivel' ? 'selected' : ''; ?>>Disponível</option>
                                    <option value="indisponivel" <?php echo $filtro_status === 'indisponivel' ? 'selected' : ''; ?>>Indisponível</option>
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> Buscar
                            </button>
                            
                            <a href="materiais.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Limpar
                            </a>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Tabela de Materiais -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-list"></i> Lista de Materiais
                    </h2>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Descrição</th>
                                    <th>Quantidade</th>
                                    <th>Status</th>
                                    <th>Última Atualização</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($materiais)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center" style="padding: 2rem; color: #6b7280;">
                                            <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 1rem; display: block;"></i>
                                            Nenhum material encontrado.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($materiais as $material): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($material['nome']); ?></strong>
                                            </td>
                                            <td>
                                                <?php echo htmlspecialchars($material['descricao'] ?: '-'); ?>
                                            </td>
                                            <td>
                                                <span style="font-weight: 600; color: <?php echo $material['quantidade'] > 0 ? '#059669' : '#dc2626'; ?>">
                                                    <?php echo $material['quantidade']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="status-badge status-<?php echo $material['status_disponibilidade']; ?>">
                                                    <?php echo $material['status_disponibilidade'] === 'disponivel' ? 'Disponível' : 'Indisponível'; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php echo date('d/m/Y H:i', strtotime($material['updated_at'])); ?>
                                            </td>
                                            <td class="actions-cell">
                                                <button 
                                                    class="btn btn-primary btn-sm" 
                                                    onclick="editarMaterial(<?php echo htmlspecialchars(json_encode($material)); ?>)"
                                                    title="Editar"
                                                >
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button 
                                                    class="btn btn-danger btn-sm" 
                                                    onclick="removerMaterial(<?php echo $material['id']; ?>, '<?php echo htmlspecialchars($material['nome']); ?>')"
                                                    title="Remover"
                                                >
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para Adicionar/Editar Material -->
    <div id="materialModal" class="modal">
        <div class="modal-content">
            <button class="close" onclick="fecharModal()">&times;</button>
            <div class="modal-header">
                <h2 id="modalTitle" class="modal-title">Adicionar Material</h2>
            </div>
            <form id="materialForm" method="POST" action="">
                <input type="hidden" id="action" name="action" value="adicionar">
                <input type="hidden" id="materialId" name="id" value="">
                
                <div class="form-group">
                    <label for="nome" class="form-label">
                        <i class="fas fa-tag"></i> Nome do Material *
                    </label>
                    <input 
                        type="text" 
                        id="nome" 
                        name="nome" 
                        class="form-input" 
                        placeholder="Ex: Resistor 10KΩ"
                        required
                    >
                </div>
                
                <div class="form-group">
                    <label for="descricao" class="form-label">
                        <i class="fas fa-align-left"></i> Descrição
                    </label>
                    <textarea 
                        id="descricao" 
                        name="descricao" 
                        class="form-input" 
                        rows="3"
                        placeholder="Descrição detalhada do material..."
                    ></textarea>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label for="quantidade" class="form-label">
                            <i class="fas fa-hashtag"></i> Quantidade
                        </label>
                        <input 
                            type="number" 
                            id="quantidade" 
                            name="quantidade" 
                            class="form-input" 
                            min="0"
                            value="0"
                        >
                    </div>
                    
                    <div class="form-group">
                        <label for="status" class="form-label">
                            <i class="fas fa-toggle-on"></i> Status
                        </label>
                        <select id="statusModal" name="status" class="form-input">
                            <option value="disponivel">Disponível</option>
                            <option value="indisponivel">Indisponível</option>
                        </select>
                    </div>
                </div>
                
                <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 2rem;">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal()">
                        <i class="fas fa-times"></i> Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Form oculto para remoção -->
    <form id="removeForm" method="POST" action="" style="display: none;">
        <input type="hidden" name="action" value="remover">
        <input type="hidden" id="removeId" name="id" value="">
    </form>
    
    <script>
        // Funções para controle do menu mobile
        function toggleSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");
            
            sidebar.classList.toggle("open");
            overlay.classList.toggle("active");
            
            if (sidebar.classList.contains("open")) {
                toggleButton.style.opacity = "0";
                toggleButton.style.pointerEvents = "none";
                mainContent.classList.add("menu-open");
            } else {
                toggleButton.style.opacity = "1";
                toggleButton.style.pointerEvents = "auto";
                mainContent.classList.remove("menu-open");
            }
        }
        
        function closeSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");
            
            sidebar.classList.remove("open");
            overlay.classList.remove("active");
            toggleButton.style.opacity = "1";
            toggleButton.style.pointerEvents = "auto";
            mainContent.classList.remove("menu-open");
        }
        
        // Funções do modal
        function abrirModal(action, material = null) {
            const modal = document.getElementById('materialModal');
            const form = document.getElementById('materialForm');
            const title = document.getElementById('modalTitle');
            
            // Resetar formulário
            form.reset();
            
            if (action === 'adicionar') {
                title.textContent = 'Adicionar Material';
                document.getElementById('action').value = 'adicionar';
                document.getElementById('materialId').value = '';
            } else if (action === 'editar' && material) {
                title.textContent = 'Editar Material';
                document.getElementById('action').value = 'editar';
                document.getElementById('materialId').value = material.id;
                document.getElementById('nome').value = material.nome;
                document.getElementById('descricao').value = material.descricao || '';
                document.getElementById('quantidade').value = material.quantidade;
                document.getElementById('statusModal').value = material.status_disponibilidade;
            }
            
            modal.style.display = 'block';
            document.getElementById('nome').focus();
        }
        
        function fecharModal() {
            document.getElementById('materialModal').style.display = 'none';
        }
        
        function editarMaterial(material) {
            abrirModal('editar', material);
        }
        
        function removerMaterial(id, nome) {
            if (confirm(`Tem certeza que deseja remover o material "${nome}"?`)) {
                document.getElementById('removeId').value = id;
                document.getElementById('removeForm').submit();
            }
        }
        
        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('materialModal');
            if (event.target === modal) {
                fecharModal();
            }
        }
        
        function atualizarContador() {
            fetch('contador_pendentes.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('contador-pendentes').innerHTML = data;
                })
                .catch(error => console.error("Erro ao atualizar contador:", error));
        }

        // chama logo no carregamento
        atualizarContador();

        // e repete a cada 5s
        setInterval(atualizarContador, 5000);
    </script>
</body>
</html>

