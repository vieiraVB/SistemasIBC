# Sistema de Gerenciamento de Datashows - SIDE IBC

Sistema web para gerenciamento de solicitações de equipamentos de datashow em instituições de ensino.

## Funcionalidades

### Para Professores:
- Solicitar datashow informando data, horário e sala
- Visualizar suas solicitações pendentes
- Cancelar solicitações pendentes

### Para Administradores:
- Gerenciar usuários (professores e administradores)
- Aprovar/rejeitar solicitações
- Controlar retirada e devolução de equipamentos
- Visualizar histórico completo de solicitações
- Filtrar e pesquisar registros

## Requisitos do Sistema

- PHP 7.4 ou superior
- MySQL 5.7 ou superior
- Servidor web (Apache/Nginx)
- Extensões PHP: PDO, PDO_MySQL

## Instalação

1. **Configurar o Banco de Dados:**
   - Crie um banco de dados MySQL chamado `datashow_manager`
   - Importe o arquivo `datashow_manager_updated.sql`
   - Configure as credenciais no arquivo `includes/config.php`

2. **Configurar o Sistema:**
   - Copie os arquivos para o diretório do servidor web
   - Ajuste as permissões dos arquivos se necessário
   - Acesse o sistema pelo navegador

3. **Usuários Padrão:**
   - **Administrador:** CPF: 12345678901, Senha: admin123
   - **Professor:** CPF: 12345678900, Senha: professor123

## Estrutura do Projeto

```
datashow-system/
├── assets/                 # Imagens e recursos
├── css/                   # Arquivos de estilo
├── includes/              # Arquivos de configuração
│   └── config.php        # Configurações do banco
├── js/                   # Scripts JavaScript
├── pages/                # Páginas do sistema
│   ├── dashboard.php     # Dashboard administrativo
│   ├── historico.php     # Histórico de solicitações
│   ├── pendentes.php     # Solicitações pendentes
│   ├── solicitar.php     # Formulário de solicitação
│   └── usuarios.php      # Gerenciamento de usuários
├── index.php             # Página de login
├── logout.php            # Logout do sistema
└── datashow_manager_updated.sql  # Script do banco
```

## Principais Correções Implementadas

1. **Lógica de Redirecionamento:**
   - Corrigido redirecionamento após login para professores e administradores
   - Criado dashboard.php para administradores

2. **Campos de Horário:**
   - Adicionados campos horario_inicio e horario_fim nas solicitações
   - Validação de conflitos de horário na mesma sala
   - Exibição de horários nas listagens

3. **Navegação:**
   - Adicionado link para dashboard em todas as páginas
   - Corrigida estrutura de navegação no sidebar

4. **Validações:**
   - Validação de horários (início deve ser anterior ao fim)
   - Verificação de conflitos de agendamento
   - Validação de CPF com 11 dígitos

5. **Interface:**
   - Melhorada exibição de data/horário nas tabelas
   - Corrigidos botões de ação para administradores
   - Mantido design visual original

## Configuração do Banco de Dados

Edite o arquivo `includes/config.php` com suas credenciais:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'datashow_manager');
define('DB_USER', 'seu_usuario');
define('DB_PASS', 'sua_senha');
```

## Uso do Sistema

1. **Login:** Acesse com CPF e senha
2. **Professores:** Podem solicitar datashows e acompanhar suas solicitações
3. **Administradores:** Têm acesso completo ao sistema para gerenciar usuários e solicitações

## Segurança

- Senhas são criptografadas com password_hash()
- Validação e sanitização de dados de entrada
- Controle de sessão seguro
- Verificação de permissões por tipo de usuário

## Suporte

Para dúvidas ou problemas, consulte a documentação do código ou entre em contato com o desenvolvedor.

