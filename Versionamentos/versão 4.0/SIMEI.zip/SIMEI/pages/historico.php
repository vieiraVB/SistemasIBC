<?php
require_once '../includes/config.php';
$pdo = getDBConnection();


// Verificar se está logado
if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}

// Filtros
$filtro_data_inicio = sanitize($_GET['data_inicio'] ?? '');
$filtro_data_fim = sanitize($_GET['data_fim'] ?? '');
$filtro_professor = sanitize($_GET['professor'] ?? '');
$filtro_status = sanitize($_GET['status'] ?? '');

// Buscar histórico de solicitações
try {
    $pdo = getDBConnection();

    $where_conditions = [];
    $params = [];

    // Se não for admin, mostrar apenas suas solicitações
    if (!isAdmin()) {
        $where_conditions[] = "s.usuario_id = ?";
        $params[] = $_SESSION['user_id'];
    }

    // Filtro por data de início
    if ($filtro_data_inicio) {
        $where_conditions[] = "s.data_utilizacao >= ?";
        $params[] = $filtro_data_inicio;
    }

    // Filtro por data de fim
    if ($filtro_data_fim) {
        $where_conditions[] = "s.data_utilizacao <= ?";
        $params[] = $filtro_data_fim;
    }

    // Filtro por professor
    if ($filtro_professor) {
        $where_conditions[] = "u.nome LIKE ?";
        $params[] = "%$filtro_professor%";
    }

    // Filtro por status
    if ($filtro_status) {
        $where_conditions[] = "s.status = ?";
        $params[] = $filtro_status;
    }

    $where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

    $stmt = $pdo->prepare("
        SELECT s.*, 
               u.nome as usuario_nome, 
               admin.nome as aprovada_por_nome
        FROM solicitacoes s 
        JOIN usuarios u ON s.usuario_id = u.id 
        LEFT JOIN usuarios admin ON s.aprovada_por = admin.id
        $where_clause
        ORDER BY s.data_solicitacao DESC
        LIMIT 100
    ");
    $stmt->execute($params);
    $historico = $stmt->fetchAll();

    // Buscar professores para o filtro
    $stmt = $pdo->query("SELECT DISTINCT nome FROM usuarios WHERE tipo = 'professor' ORDER BY nome");
    $professores = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Erro ao carregar histórico.";
    $historico = [];
    $professores = [];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Histórico</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <button class="mobile-menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <div class="sidebar-overlay" onclick="closeSidebar()"></div>

    <div class="main-layout">
        <div class="sidebar">
            <div class="sidebar-header">
                <h1>SIDE - IBC</h1>
                <p>Bem-vindo, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>

            <nav class="sidebar-nav">
                <?php if (isAdmin()): ?>
                    <a href="historico.php" class="nav-item">
                        <i class="fas fa-history"></i> Histórico
                    </a>
                    <a href="usuarios.php" class="nav-item">
                        <i class="fas fa-users"></i> Usuários
                    </a>
                    <a href="materiais.php" class="nav-item">
                        <i class="fas fa-boxes"></i> Gestão de Materiais
                    </a>
                <?php endif; ?>

                <?php if ($_SESSION['user_type'] === 'professor' || isAdmin()): ?>
                    <a href="solicitar.php" class="nav-item">
                        <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                    </a>
                    <?php
                    $stmt = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
                    $pendentes_count = $stmt->fetchColumn();
                    ?>
                    <a href="pendentes.php" class="nav-item">
                        <span id="contador-pendentes">
                            <i class="fas fa-clock"></i>
                        </span>
                        Solicitações
                    </a>
                <?php endif; ?>
            </nav>


            <div class="sidebar-footer">
                <a href="../logout.php" class="btn btn-secondary btn-full">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>

        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-history"></i> Histórico <?php echo isAdmin() ? 'de Solicitações' : 'das Minhas Solicitações'; ?>
                </h1>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-filter"></i> Filtros de Pesquisa
                    </h2>
                </div>
                <div class="card-body">
                    <form method="GET" action="">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="data_inicio" class="form-label">Data Início</label>
                                <input type="date" id="data_inicio" name="data_inicio" class="form-input" value="<?php echo htmlspecialchars($filtro_data_inicio); ?>">
                            </div>

                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="data_fim" class="form-label">Data Fim</label>
                                <input type="date" id="data_fim" name="data_fim" class="form-input" value="<?php echo htmlspecialchars($filtro_data_fim); ?>">
                            </div>

                            <?php if (isAdmin()): ?>
                                <div class="form-group" style="margin-bottom: 0;">
                                    <label for="professor" class="form-label">Professor</label>
                                    <input type="text" id="professor" name="professor" class="form-input" placeholder="Nome do professor" value="<?php echo htmlspecialchars($filtro_professor); ?>">
                                </div>
                            <?php endif; ?>


                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="status" class="form-label">Status</label>
                                <select id="status" name="status" class="form-input">
                                    <option value="">Todos</option>
                                    <option value="pendente" <?php echo $filtro_status === 'pendente' ? 'selected' : ''; ?>>Pendente</option>
                                    <option value="aprovada" <?php echo $filtro_status === 'aprovada' ? 'selected' : ''; ?>>Aprovada</option>
                                    <option value="retirada" <?php echo $filtro_status === 'retirada' ? 'selected' : ''; ?>>Retirada</option>
                                    <option value="devolvida" <?php echo $filtro_status === 'devolvida' ? 'selected' : ''; ?>>Devolvida</option>
                                    <option value="cancelada" <?php echo $filtro_status === 'cancelada' ? 'selected' : ''; ?>>Cancelada</option>
                                </select>
                            </div>
                        </div>

                        <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> Pesquisar
                            </button>

                            <a href="historico.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Limpar Filtros
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <div class="cards-grid mb-4">
                <div class="stat-card">
                    <div class="stat-icon blue">
                        <i class="fas fa-list"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Total de Registros</h3>
                        <p><?php echo count($historico); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon green">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Devolvidas</h3>
                        <p><?php echo count(array_filter($historico, fn($h) => $h['status'] === 'devolvida')); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon yellow">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Pendentes</h3>
                        <p><?php echo count(array_filter($historico, fn($h) => $h['status'] === 'pendente')); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon red">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Canceladas</h3>
                        <p><?php echo count(array_filter($historico, fn($h) => $h['status'] === 'cancelada')); ?></p>
                    </div>
                </div>
            </div>

            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Data Solicitação</th>
                            <?php if (isAdmin()): ?>
                                <th>Professor</th>
                            <?php endif; ?>
                            <th>Período de Utilização</th>
                            <th>Item Solicitado / Sala</th>
                            <th>Status</th>
                            <th>Aprovado Por</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($historico)): ?>
                            <tr>
                                <td colspan="<?php echo isAdmin() ? '8' : '7'; ?>" class="text-center" style="padding: 2rem; color: #6b7280;">
                                    <i class="fas fa-history" style="font-size: 2rem; margin-bottom: 1rem; display: block;"></i>
                                    Nenhum registro encontrado.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($historico as $item): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo date('d/m/Y', strtotime($item['data_solicitacao'])); ?></strong><br>
                                        <small style="color: #6b7280;"><?php echo date('H:i', strtotime($item['data_solicitacao'])); ?></small>
                                    </td>
                                    <?php if (isAdmin()): ?>
                                        <td>
                                            <strong><?php echo htmlspecialchars($item['usuario_nome']); ?></strong>
                                            <?php if ($item['observacoes']): ?>
                                                <br><small style="color: #6b7280;" title="<?php echo htmlspecialchars($item['observacoes']); ?>">
                                                    <i class="fas fa-comment"></i> Obs
                                                </small>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                    
                                    <td>
                                        <strong><?php echo date('d/m/Y', strtotime($item['data_utilizacao'])); ?></strong>
                                        <?php if (($item['tipo_solicitacao'] == 'software' || $item['tipo_solicitacao'] == 'materiais') && !empty($item['data_termino_uso'])): ?>
                                            <br><small style="color: #6b7280;">até <?php echo date('d/m/Y', strtotime($item['data_termino_uso'])); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($item['tipo_solicitacao'] == 'software'): ?>
                                            <strong><?php echo nl2br(htmlspecialchars($item['softwares_solicitados'])); ?></strong>
                                            <br><small style="color: #6b7280;">Na Sala: <?php echo htmlspecialchars($item['sala']); ?></small>

                                            <?php if ($item['anexo_path']): ?>
                                                <br><a href="../<?php echo htmlspecialchars($item['anexo_path']); ?>" target="_blank" style="font-size: 0.875rem;">
                                                    <i class="fas fa-file-alt"></i> Baixar Guia
                                                </a>
                                            <?php endif; ?>

                                        <?php else: ?>
                                            <strong><?php echo htmlspecialchars($item['sala']); ?></strong>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php
                                                                    echo $item['status'] === 'pendente' ? 'warning' : ($item['status'] === 'aprovada' ? 'info' : ($item['status'] === 'retirada' ? 'success' : ($item['status'] === 'devolvida' ? 'success' : 'danger')));
                                                                    ?>">
                                            <?php echo ucfirst($item['status']); ?>
                                        </span>

                                        <?php if ($item['data_retirada']): ?>
                                            <br><small style="color: #6b7280;">
                                                Retirada: <?php echo date('d/m/Y H:i', strtotime($item['data_retirada'])); ?>
                                            </small>
                                        <?php endif; ?>

                                        <?php if ($item['data_devolucao']): ?>
                                            <br><small style="color: #6b7280;">
                                                Devolução: <?php echo date('d/m/Y H:i', strtotime($item['data_devolucao'])); ?>
                                            </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($item['aprovada_por_nome']): ?>
                                            <small><?php echo htmlspecialchars($item['aprovada_por_nome']); ?></small>
                                        <?php else: ?>
                                            <span style="color: #6b7280;">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if (count($historico) >= 100): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Mostrando os 100 registros mais recentes. Use os filtros para refinar a pesquisa.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function exportarCSV() {
            // Construir URL com filtros atuais
            const params = new URLSearchParams(window.location.search);
            params.set('export', 'csv');

            // Criar link temporário para download
            const link = document.createElement('a');
            link.href = 'export_historico.php?' + params.toString();
            link.download = 'historico_datashows.csv';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        // Funções para controle do menu mobile
        function toggleSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");

            sidebar.classList.toggle("open");
            overlay.classList.toggle("active");

            if (sidebar.classList.contains("open")) {
                toggleButton.style.opacity = "0";
                toggleButton.style.pointerEvents = "none";
                mainContent.classList.add("menu-open");
            } else {
                toggleButton.style.opacity = "1";
                toggleButton.style.pointerEvents = "auto";
                mainContent.classList.remove("menu-open");
            }
        }

        function closeSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");

            sidebar.classList.remove("open");
            overlay.classList.remove("active");
            toggleButton.style.opacity = "1";
            toggleButton.style.pointerEvents = "auto";
            mainContent.classList.remove("menu-open");
        }

        // Validação de datas
        document.getElementById('data_inicio').addEventListener('change', function() {
            const dataFim = document.getElementById('data_fim');
            if (this.value && dataFim.value && this.value > dataFim.value) {
                alert('Data de início não pode ser posterior à data de fim.');
                this.value = '';
            }
        });

        document.getElementById('data_fim').addEventListener('change', function() {
            const dataInicio = document.getElementById('data_inicio');
            if (this.value && dataInicio.value && this.value < dataInicio.value) {
                alert('Data de fim não pode ser anterior à data de início.');
                this.value = '';
            }
        });

        function atualizarContador() {
            fetch('contador_pendentes.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('contador-pendentes').innerHTML = data;
                })
                .catch(error => console.error("Erro ao atualizar contador:", error));
        }

        // chama logo no carregamento
        atualizarContador();

        // e repete a cada 5s
        setInterval(atualizarContador, 5000);
    </script>
</body>

</html>


<script>
    function toggleSidebar() {
        const sidebar = document.querySelector(".sidebar");
        const overlay = document.querySelector(".sidebar-overlay");
        const toggleButton = document.querySelector(".mobile-menu-toggle");
        const mainContent = document.querySelector(".main-content");

        sidebar.classList.toggle("open");
        overlay.classList.toggle("active");

        if (sidebar.classList.contains("open")) {
            toggleButton.style.opacity = "0";
            toggleButton.style.pointerEvents = "none";
            mainContent.classList.add("menu-open");
        } else {
            toggleButton.style.opacity = "1";
            toggleButton.style.pointerEvents = "auto";
            mainContent.classList.remove("menu-open");
        }
    }

    function closeSidebar() {
        const sidebar = document.querySelector(".sidebar");
        const overlay = document.querySelector(".sidebar-overlay");
        const toggleButton = document.querySelector(".mobile-menu-toggle");
        const mainContent = document.querySelector(".main-content");

        sidebar.classList.remove("open");
        overlay.classList.remove("active");
        toggleButton.style.opacity = "1";
        toggleButton.style.pointerEvents = "auto";
        mainContent.classList.remove("menu-open");
    }
</script>
-