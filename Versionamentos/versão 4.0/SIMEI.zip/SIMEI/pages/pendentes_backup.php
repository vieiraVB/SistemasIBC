<?php
require_once '../includes/config.php';

// Verificar se está logado
if (!isLoggedIn()) {
    redirect('../index.php');
}

$error = '';
$success = '';

// Processar ações (aprovar, retirar, devolver)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($_POST['action'] ?? '');
    $solicitacao_id = (int)($_POST['solicitacao_id'] ?? 0);
    
    if ($action && $solicitacao_id) {
        try {
            $pdo = getDBConnection();
            
            switch ($action) {
                case 'aprovar':
                    if (isAdmin()) {
                        try {
                            // Depuração: verifique os valores das variáveis
                            error_log("Tentativa de aprovar solicitação #{$solicitacao_id} pelo usuário ID: {$_SESSION['user_id']}");
                            
                            $stmt = $pdo->prepare("
                                UPDATE solicitacoes 
                                SET status = 'aprovada', aprovada_por = ? 
                                WHERE id = ? AND status = 'pendente'
                            ");

                            $stmt->execute([$_SESSION['user_id'], $solicitacao_id]);
                            
                            $success = 'Solicitação aprovada com sucesso!';

                        } catch (PDOException $e) {
                            // Exibir erro específico do banco de dados
                            $error = "Erro no banco de dados: " . $e->getMessage();
                            error_log("Erro ao aprovar solicitação: " . $e->getMessage());
                        }
                    }
                    break;
                    
                case 'retirar':
                    if (isAdmin()) {
                        // 1. Iniciar uma transação para garantir a integridade
                        $pdo->beginTransaction();

                        try {
                            // 2. Obter os materiais da solicitação
                            $stmt_materiais = $pdo->prepare("
                                SELECT id_material, quantidade_solicitada
                                FROM solicitacoes_materiais
                                WHERE id_solicitacao = ?
                            ");
                            $stmt_materiais->execute([$solicitacao_id]);
                            $materiais = $stmt_materiais->fetchAll(PDO::FETCH_ASSOC);

                            if (!empty($materiais)) {
                                // 3. Atualizar a quantidade de cada material no estoque
                                $stmt_update_estoque = $pdo->prepare("
                                    UPDATE materiais
                                    SET quantidade = quantidade - ?
                                    WHERE id = ?
                                ");
                                foreach ($materiais as $material) {
                                    $stmt_update_estoque->execute([
                                        $material['quantidade_solicitada'],
                                        $material['id_material']
                                    ]);
                                }
                            }

                            // 4. Atualizar o status da solicitação
                            $stmt = $pdo->prepare("
                                UPDATE solicitacoes 
                                SET status = 'retirada', data_retirada = NOW() 
                                WHERE id = ? AND status = 'aprovada'
                            ");
                            $stmt->execute([$solicitacao_id]);

                            $pdo->commit(); // Confirma as alterações
                            $success = 'Solicitação marcada como retirada e estoque atualizado!';

                        } catch (PDOException $e) {
                            $pdo->rollBack(); // Desfaz todas as alterações em caso de erro
                            $error = 'Erro ao processar a retirada. Tente novamente.';
                            error_log("Erro ao processar retirada: " . $e->getMessage());
                        }
                    }
                    break;
                    
                case 'devolver_materiais':
                    if (isAdmin()) {
                        $pdo->beginTransaction();
                        try {
                            $materiais_devolvidos = $_POST['materiais_devolvidos'] ?? [];
                            $observacoes_devolucao = sanitize($_POST['observacoes_devolucao'] ?? '');
                            
                            // 1. Atualizar a quantidade dos materiais no estoque
                            foreach ($materiais_devolvidos as $material_id => $quantidade_devolvida) {
                                $quantidade_devolvida = (int)$quantidade_devolvida;
                                if ($quantidade_devolvida > 0) {
                                    $stmt = $pdo->prepare("
                                        UPDATE materiais 
                                        SET quantidade = quantidade + ? 
                                        WHERE id = ?
                                    ");
                                    $stmt->execute([$quantidade_devolvida, $material_id]);
                                }
                            }
                            
                            // 2. Atualizar o status da solicitação
                            $observacoes_completas = $observacoes_devolucao ? 
                                "Devolução: " . $observacoes_devolucao : null;
                            
                            $stmt = $pdo->prepare("
                                UPDATE solicitacoes 
                                SET status = 'devolvida', 
                                    data_devolucao = NOW(),
                                    observacoes = CASE 
                                        WHEN observacoes IS NULL OR observacoes = '' THEN ?
                                        ELSE CONCAT(observacoes, '\n\n', ?)
                                    END
                                WHERE id = ?
                            ");
                            $stmt->execute([$observacoes_completas, $observacoes_completas, $solicitacao_id]);
                            
                            $pdo->commit();
                            $success = 'Devolução processada com sucesso! Estoque atualizado automaticamente.';
                            header("Location: pendentes.php?success=" . urlencode($success));
                            exit;
                        } catch (PDOException $e) {
                            $pdo->rollBack();
                            $error = 'Erro ao processar devolução.';
                            header("Location: pendentes.php?error=" . urlencode($error));
                            exit;
                        }
                    }
                    break;

                    
                case 'cancelar':
                    // Ação de cancelamento da solicitação (pode ser feita por qualquer usuário na própria solicitação)
                    $pdo->beginTransaction();
                    try {
                        // Obter os materiais da solicitação para devolver ao estoque
                        $stmt_materiais = $pdo->prepare("
                            SELECT id_material, quantidade_solicitada
                            FROM solicitacoes_materiais
                            WHERE id_solicitacao = ?
                        ");
                        $stmt_materiais->execute([$solicitacao_id]);
                        $materiais = $stmt_materiais->fetchAll(PDO::FETCH_ASSOC);

                        // Atualizar a quantidade de cada material no estoque
                        if (!empty($materiais)) {
                            $stmt_update_estoque = $pdo->prepare("
                                UPDATE materiais
                                SET quantidade = quantidade + ?
                                WHERE id = ?
                            ");
                            foreach ($materiais as $material) {
                                $stmt_update_estoque->execute([
                                    $material['quantidade_solicitada'],
                                    $material['id_material']
                                ]);
                            }
                        }

                        // Mudar o status da solicitação para cancelada
                        $stmt = $pdo->prepare("
                            UPDATE solicitacoes 
                            SET status = 'cancelada' 
                            WHERE id = ? AND status = 'pendente'
                        ");
                        $stmt->execute([$solicitacao_id]);

                        $pdo->commit();
                        $success = 'Solicitação cancelada e material devolvido ao estoque com sucesso!';
                    } catch (PDOException $e) {
                        $pdo->rollBack();
                        $error = 'Erro ao cancelar a solicitação. Tente novamente.';
                        error_log("Erro ao cancelar solicitação: " . $e->getMessage());
                    }
                    break;
                    
                case 'excluir':
                    // Apenas admin pode excluir solicitações pendentes
                    if (isAdmin()) {
                        // Primeiro, verificar se a solicitação está pendente
                        $stmt = $pdo->prepare("
                            SELECT status, materiais_solicitados 
                            FROM solicitacoes 
                            WHERE id = ? AND status = 'pendente'
                        ");
                        $stmt->execute([$solicitacao_id]);
                        $solicitacao = $stmt->fetch();
                        
                        if ($solicitacao) {
                            // Restaurar quantidades dos materiais antes de excluir
                            if ($solicitacao['materiais_solicitados']) {
                                $materiais = json_decode($solicitacao['materiais_solicitados'], true);
                                if ($materiais) {
                                    foreach ($materiais as $material_id => $quantidade) {
                                        // Verificar se é material extra (string) ou normal (numeric)
                                        if (is_numeric($material_id)) {
                                            // Material normal - usar ID
                                            $stmt = $pdo->prepare("
                                                UPDATE materiais 
                                                SET quantidade = quantidade + ? 
                                                WHERE id = ?
                                            ");
                                            $stmt->execute([$quantidade, $material_id]);
                                        } else {
                                            // Material extra - usar nome
                                            $materiais_extras_map = [
                                                'caixa_som' => 'Caixa de Som',
                                                'extensao' => 'Extensão', 
                                                'microfone' => 'Microfone'
                                            ];
                                            
                                            if (isset($materiais_extras_map[$material_id])) {
                                                $stmt = $pdo->prepare("
                                                    UPDATE materiais 
                                                    SET quantidade = quantidade + ? 
                                                    WHERE nome = ?
                                                ");
                                                $stmt->execute([$quantidade, $materiais_extras_map[$material_id]]);
                                            }
                                        }
                                    }
                                }
                            }
                            
                            // Excluir a solicitação
                            $stmt = $pdo->prepare("DELETE FROM solicitacoes WHERE id = ?");
                            $stmt->execute([$solicitacao_id]);
                            
                            $success = 'Solicitação excluída com sucesso! Materiais devolvidos ao estoque.';
                            header("Location: pendentes.php?success=" . urlencode($success));
                            exit;
                        } else {
                            $error = 'Apenas solicitações pendentes podem ser excluídas.';
                        }
                    }
                    break;
            }
        } catch (PDOException $e) {
            $error = 'Erro interno do sistema. Tente novamente.';
        }
    }
}

// Filtros
$filtro_status = sanitize($_GET['status'] ?? '');
$filtro_data = sanitize($_GET['data'] ?? '');
$filtro_tipo = sanitize($_GET['tipo'] ?? '');

// Buscar solicitações
try {
    $pdo = getDBConnection();
    
    $where_conditions = [];
    $params = [];
    
    // Se não for admin, mostrar apenas suas solicitações
    if (!isAdmin()) {
        $where_conditions[] = "s.usuario_id = ?";
        $params[] = $_SESSION['user_id'];
    }
    
    // Filtro por status
    if ($filtro_status) {
        $where_conditions[] = "s.status = ?";
        $params[] = $filtro_status;
    } else {
        // Por padrão, não mostrar canceladas
        $where_conditions[] = "s.status != 'cancelada'";
    }
    
    // Filtro por data
    if ($filtro_data) {
        $where_conditions[] = "s.data_utilizacao = ?";
        $params[] = $filtro_data;
    }
    
    // Filtro por tipo
    if ($filtro_tipo) {
        $where_conditions[] = "s.tipo_solicitacao = ?";
        $params[] = $filtro_tipo;
    }
    
    $where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
    
    $stmt = $pdo->prepare("
        SELECT s.*, u.nome as usuario_nome
        FROM solicitacoes s 
        JOIN usuarios u ON s.usuario_id = u.id 
        $where_clause
        ORDER BY s.data_solicitacao DESC
    ");
    $stmt->execute($params);
    $solicitacoes = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = "Erro ao carregar solicitações.";
    $solicitacoes = [];
}

// Função para obter nomes dos materiais
function obterNomesMateriais($pdo, $materiais_json) {
    global $pdo;
    if (!$materiais_json) return [];
    
    $materiais_solicitados = json_decode($materiais_json, true);
    if (empty($materiais_solicitados)) return [];

    $materiais_info = [];
    $ids = array_keys($materiais_solicitados);

    if (empty($ids)) return [];

    $placeholders = implode(",", array_fill(0, count($ids), "?"));
    $stmt = $pdo->prepare("SELECT id, nome FROM materiais WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $materiais_db = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    foreach ($materiais_solicitados as $id => $quantidade) {
        if (isset($materiais_db[$id])) {
            $materiais_info[] = [
                'nome' => $materiais_db[$id],
                'quantidade' => $quantidade
            ];
        }
    }

    return $materiais_info;
}

if (isset($_GET['ajax'])) {
    include 'partials/solicitacoes_table.php'; // extrai apenas a tabela num arquivo separado
    exit;
}

?>
