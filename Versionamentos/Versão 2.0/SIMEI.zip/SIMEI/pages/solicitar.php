<?php
require_once '../includes/config.php';
$pdo = getDBConnection();
date_default_timezone_set('America/Manaus');

// Obter total de equipamentos do banco de dados (ou definir um limite fixo se não houver tabela de equipamentos)
$total_datashows = 7; // Limite fixo conforme definido no array $limites
$total_notebooks = 3; // Limite fixo conforme definido no array $limites
$total_caixas_som = 2; // Limite fixo conforme definido no array $limites
$total_extensoes = 6; // Limite fixo conforme definido no array $limites
$total_chave_lab1 = 1; // Limite fixo para chave do laboratório 1
$total_chave_lab2 = 1; // Limite fixo para chave do laboratório 2
$total_chave_lab3 = 1; // Limite fixo para chave do laboratório 3

// Contar equipamentos em uso (status 'aprovada' ou 'retirada')
$stmt_datashows_em_uso = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE (observacoes LIKE '%Datashow%' OR materiais_solicitados LIKE '%Datashow%') AND status IN ('aprovada', 'retirada')");
$datashows_em_uso_total = $stmt_datashows_em_uso->fetchColumn();

$stmt_notebooks_em_uso = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE (observacoes LIKE '%Notebook%' OR materiais_solicitados LIKE '%Notebook%') AND status IN ('aprovada', 'retirada')");
$notebooks_em_uso_total = $stmt_notebooks_em_uso->fetchColumn();

$stmt_caixas_som_em_uso = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE (observacoes LIKE '%Caixa de Som%' OR materiais_solicitados LIKE '%Caixa de Som%') AND status IN ('aprovada', 'retirada')");
$caixas_som_em_uso_total = $stmt_caixas_som_em_uso->fetchColumn();

$stmt_extensoes_em_uso = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE (observacoes LIKE '%Extensão%' OR materiais_solicitados LIKE '%Extensão%') AND status IN ('aprovada', 'retirada')");
$extensoes_em_uso_total = $stmt_extensoes_em_uso->fetchColumn();

$stmt_chave_lab1_em_uso = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE (observacoes LIKE '%Chave Lab 1%' OR materiais_solicitados LIKE '%Chave Lab 1%') AND status IN ('aprovada', 'retirada')");
$chave_lab1_em_uso_total = $stmt_chave_lab1_em_uso->fetchColumn();

$stmt_chave_lab2_em_uso = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE (observacoes LIKE '%Chave Lab 2%' OR materiais_solicitados LIKE '%Chave Lab 2%') AND status IN ('aprovada', 'retirada')");
$chave_lab2_em_uso_total = $stmt_chave_lab2_em_uso->fetchColumn();

$stmt_chave_lab3_em_uso = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE (observacoes LIKE '%Chave Lab 3%' OR materiais_solicitados LIKE '%Chave Lab 3%') AND status IN ('aprovada', 'retirada')");
$chave_lab3_em_uso_total = $stmt_chave_lab3_em_uso->fetchColumn();

$datashows_disponiveis = $total_datashows - $datashows_em_uso_total;
$notebooks_disponiveis = $total_notebooks - $notebooks_em_uso_total;
$caixas_som_disponiveis = $total_caixas_som - $caixas_som_em_uso_total;
$extensoes_disponiveis = $total_extensoes - $extensoes_em_uso_total;
$chave_lab1_disponiveis = $total_chave_lab1 - $chave_lab1_em_uso_total;
$chave_lab2_disponiveis = $total_chave_lab2 - $chave_lab2_em_uso_total;
$chave_lab3_disponiveis = $total_chave_lab3 - $chave_lab3_em_uso_total;

// Garantir que os valores não sejam negativos
$datashows_disponiveis = max(0, $datashows_disponiveis);
$notebooks_disponiveis = max(0, $notebooks_disponiveis);
$caixas_som_disponiveis = max(0, $caixas_som_disponiveis);
$extensoes_disponiveis = max(0, $extensoes_disponiveis);
$chave_lab1_disponiveis = max(0, $chave_lab1_disponiveis);
$chave_lab2_disponiveis = max(0, $chave_lab2_disponiveis);
$chave_lab3_disponiveis = max(0, $chave_lab3_disponiveis);

// Verificar se está logado
if (!isLoggedIn()) {
    redirect('../index.php');
}

$error = '';
$success = '';

// Buscar materiais disponíveis
$stmt = $pdo->query("SELECT id, nome, quantidade FROM materiais WHERE status_disponibilidade = 'disponivel' AND quantidade > 0 ORDER BY nome");
$materiais_disponiveis = $stmt->fetchAll();

// Processar solicitação
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // --- PASSO DE DEBUG (OPCIONAL) ---
    // Se o erro persistir, remova o comentário da linha abaixo para ver todos os dados que o formulário está enviando.
    //var_dump($_POST); die();

    $tipo_solicitacao = sanitize($_POST['tipo_solicitacao'] ?? '');
    $data_utilizacao = sanitize($_POST['data_utilizacao'] ?? '');
    $turno = sanitize($_POST['turno'] ?? '');
    $sala = sanitize($_POST['sala'] ?? '');
    $observacoes = sanitize($_POST['observacoes'] ?? '');
    $materiais_selecionados_json = $_POST["selected_materials_json"] ?? "[]";
    $materiais_selecionados = json_decode($materiais_selecionados_json, true);
    $equipamentos_requeridos = $_POST['equipamentos_requeridos'] ?? [];

    try {
        // Validações principais
        if (empty($tipo_solicitacao) || empty($data_utilizacao) || empty($sala)) {
            $error = 'Por favor, preencha todos os campos obrigatórios (Tipo, Data e Sala).';

            // Validação específica para equipamentos, materiais e ambos
        } elseif (($tipo_solicitacao === 'equipamentos' || $tipo_solicitacao === 'materiais' || $tipo_solicitacao === 'ambos') && empty($turno)) {
            $error = 'Para solicitações de equipamentos e materiais, o Turno é obrigatório.';
        } else {
            // --- INÍCIO DO BLOCO COMPLETO E CORRIGIDO ---

            // Define os limites máximos por turno
            $limites = [
                'datashow' => 7,
                'notebook' => 3,
                'caixa_som' => 2,
                'extensao' => 6
            ];

            $erros_limite = [];
            $data_selecionada = $data_utilizacao;
            $turno_selecionado = $turno;

            // VERIFICAÇÕES DE LIMITE DE EQUIPAMENTOS (APENAS SE HOUVER TURNO)
            if (!empty($turno_selecionado)) {
                // 1. VERIFICAR LIMITE DE DATASHOWS E NOTEBOOKS
                $stmt_equip_check = $pdo->prepare("
            SELECT observacoes FROM solicitacoes
            WHERE data_utilizacao = ? AND turno = ? AND status IN ('pendente', 'aprovada', 'retirada')
        ");
                $stmt_equip_check->execute([$data_selecionada, $turno_selecionado]);
                $solicitacoes_ativas_obs = $stmt_equip_check->fetchAll(PDO::FETCH_COLUMN);

                // Contar datashows em uso para o turno selecionado
                $datashows_em_uso = 0;
                foreach ($solicitacoes_ativas_obs as $obs) {
                    if (strpos($obs, "Datashow") !== false) $datashows_em_uso++;
                }

                // Se o usuário solicitou Datashow
                if (in_array("Datashow", $equipamentos_requeridos)) {
                    if ($datashows_em_uso >= $limites["datashow"]) {
                        $erros_limite[] = "O limite de {$limites["datashow"]} datashows para este turno já foi atingido.";
                    }
                }

                // Mensagem para data-show indisponível se todos estiverem retirados
                if ($datashows_em_uso >= $limites["datashow"]) {
                    $error = "Todos os data-shows disponíveis já foram retirados.";
                }
                if (in_array('Notebook', $equipamentos_requeridos)) {
                    $notebooks_em_uso = 0;
                    foreach ($solicitacoes_ativas_obs as $obs) {
                        if (strpos($obs, 'Notebook') !== false) $notebooks_em_uso++;
                    }
                    if ($notebooks_em_uso >= $limites['notebook']) {
                        $erros_limite[] = "O limite de {$limites['notebook']} notebooks para este turno já foi atingido.";
                    }
                }
            }

            // Se algum limite foi excedido, exibe o erro
            if (!empty($erros_limite)) {
                $error = implode('<br>', $erros_limite);
            } else {
                // Se passou pelos limites, verifica duplicidade de SALA
                $is_duplicate_sala = false;
                if (!empty($turno)) {
                    $stmt_check_sala = $pdo->prepare("
                SELECT COUNT(*) FROM solicitacoes
                WHERE sala = ? AND turno = ? AND data_utilizacao = ?
                AND status IN ('pendente', 'aprovada', 'retirada')
            ");
                    $stmt_check_sala->execute([$sala, $turno, $data_utilizacao]);
                    if ($stmt_check_sala->fetchColumn() > 0) {
                        $is_duplicate_sala = true;
                    }
                }

                if ($is_duplicate_sala) {
                    $error = "Conflito de Agendamento: Já existe uma solicitação ativa para esta sala, nesta data e turno.";
                } else {
                    // Se tudo estiver OK, FINALMENTE prossegue com a criação da solicitação
                    $pdo->beginTransaction();

                    $observacoes_finais = $observacoes;
                    if (!empty($equipamentos_requeridos)) {
                        $equipamentos_str = ' [Equipamentos Solicitados: ' . implode(', ', $equipamentos_requeridos) . ']';
                        $observacoes_finais .= $equipamentos_str;
                    }

                    $materiais_json = json_encode(array_keys($materiais_selecionados));

                    $stmt_insert = $pdo->prepare("
                INSERT INTO solicitacoes (
                    usuario_id, data_utilizacao, horario_inicio, horario_fim, 
                    sala, observacoes, status, tipo_solicitacao, 
                    turno, materiais_solicitados
                ) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

                    $stmt_insert->execute([
                        $_SESSION['user_id'],
                        $data_utilizacao,
                        '00:00:00',
                        '00:00:00',
                        $sala,
                        $observacoes_finais,
                        'pendente',
                        $tipo_solicitacao,
                        $turno,
                        $materiais_json
                    ]);

                    $solicitacao_id = $pdo->lastInsertId();

                    // Salvar materiais da busca na tabela solicitacoes_materiais
                    if (!empty($materiais_selecionados)) {
                        $stmt_materiais = $pdo->prepare("INSERT INTO solicitacoes_materiais (id_solicitacao, id_material, quantidade_solicitada, usuario_id) VALUES (?, ?, ?, ?)");
                        foreach ($materiais_selecionados as $material) {
                            $material_id = $material["id"];
                            $quantidade = $material["quantidade"];
                            if ($quantidade > 0) {
                                $stmt_materiais->execute([$solicitacao_id, $material_id, $quantidade, $_SESSION["user_id"]]);
                            }
                        }
                    }

                    $pdo->commit();
                    $success = 'Solicitação enviada com sucesso! Aguarde a aprovação.';
                }
            }
        }
    } catch (PDOException $e) {
        $error = 'Erro interno do sistema. Tente novamente.';
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Solicitar Equipamentos</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .tipo-solicitacao {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .tipo-option {
            position: relative;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            padding: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
        }

        .tipo-option:hover {
            border-color: #3b82f6;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.15);
        }

        .tipo-option.selected {
            border-color: #3b82f6;
            background: #eff6ff;
        }

        .tipo-option input[type="radio"] {
            position: absolute;
            opacity: 0;
            pointer-events: none;
        }

        .tipo-option .icon {
            font-size: 2rem;
            color: #6b7280;
            margin-bottom: 0.5rem;
            display: block;
        }

        .tipo-option.selected .icon {
            color: #3b82f6;
        }

        .tipo-option .title {
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 0.25rem;
        }

        .tipo-option .description {
            font-size: 0.875rem;
            color: #6b7280;
            line-height: 1.4;
        }

        .materiais-section {
            display: none;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            background: #f9fafb;
        }

        .materiais-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 0.75rem;
            margin-top: 1rem;
        }

        .material-item {
            display: flex;
            align-items: center;
            padding: 0.75rem;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            transition: all 0.2s ease;
        }

        .material-item:hover {
            border-color: #3b82f6;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
        }

        .material-item input[type="checkbox"] {
            margin-right: 0.75rem;
            transform: scale(1.1);
        }

        .material-info {
            flex: 1;
        }

        .material-name {
            font-weight: 500;
            color: #1f2937;
            margin-bottom: 0.25rem;
        }

        .material-qty {
            font-size: 0.875rem;
            color: #6b7280;
        }

        .material-item-with-qty {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            padding: 0.75rem;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            transition: all 0.2s ease;
        }

        .material-item-with-qty:hover {
            border-color: #3b82f6;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
        }

        .material-checkbox {
            display: flex;
            align-items: center;
        }

        .material-quantity {
            display: flex;
            align-items: center;
            justify-content: flex-end;
        }

        .materiais-grid-scrollable {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            padding: 1rem;
            background: white;
        }

        .materiais-grid-scrollable::-webkit-scrollbar {
            width: 8px;
        }

        .materiais-grid-scrollable::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 4px;
        }

        .materiais-grid-scrollable::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 4px;
        }

        .materiais-grid-scrollable::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }

        .material-item-search {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            margin-bottom: 0.5rem;
            transition: all 0.2s ease;
        }

        .material-item-search:hover {
            border-color: #3b82f6;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
        }

        .material-item-search:last-child {
            margin-bottom: 0;
        }

        .material-left {
            display: flex;
            align-items: center;
            flex: 1;
        }

        .material-right {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .horarios-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        @media (max-width: 768px) {
            .horarios-section {
                grid-template-columns: 1fr;
            }

            .material-item-with-qty {
                padding: 0.5rem;
            }

            .material-quantity {
                justify-content: flex-start;
            }
        }
    </style>
</head>

<body>
    <!-- Botão de menu hambúrguer para mobile -->
    <button class="mobile-menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Overlay para fechar sidebar em mobile -->
    <div class="sidebar-overlay" onclick="closeSidebar()"></div>

    <div class="main-layout">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h1>SIMEI - IBC</h1>
                <p>Bem-vindo, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>

            <nav class="sidebar-nav">
                <?php if (isAdmin() || isColaborador()): ?>
                    <a href="usuarios.php" class="nav-item">
                        <i class="fas fa-users"></i> Usuários
                    </a>
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="materiais.php" class="nav-item">
                        <i class="fas fa-boxes"></i> Gestão de Materiais
                    </a>
                    <a href="relatorios.php" class="nav-item">
                        <i class="fas fa-chart-bar"></i> Relatórios
                    </a>
                <?php endif; ?>
                <?php if ($_SESSION['user_type'] === 'professor' || isAdmin() || isColaborador()): ?>
                    <a href="solicitar.php" class="nav-item">
                        <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                    </a>
                    <?php
                    $stmt = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
                    $pendentes_count = $stmt->fetchColumn();
                    ?>
                    <a href="pendentes.php" class="nav-item">
                        <span id="contador-pendentes">
                            <i class="fas fa-clock"></i>
                        </span>
                        Solicitações
                    </a>
                <?php endif; ?>
            </nav>

            <div class="sidebar-footer">
                <a href="../logout.php" class="btn btn-secondary btn-full">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>

        <!-- Conteúdo Principal -->
        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                </h1>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-form"></i> Formulário de Solicitação
                    </h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <!-- Tipo de Solicitação -->
                        <div class="form-group">
                            <label class="form-label">
                                <i class="fas fa-list"></i> Tipo de Solicitação *
                            </label>
                            <div class="tipo-solicitacao">
                                <label class="tipo-option" for="tipo_equipamentos">
                                    <input type="radio" id="tipo_equipamentos" name="tipo_solicitacao" value="equipamentos" required>
                                    <i class="fas fa-video icon"></i>
                                    <div class="title">Equipamentos</div>
                                    <div class="description">Para datashow e/ou notebook. Pode solicitar para o mesmo dia.</div>
                                </label>

                                <label class="tipo-option" for="tipo_materiais">
                                    <input type="radio" id="tipo_materiais" name="tipo_solicitacao" value="materiais" required>
                                    <i class="fas fa-boxes icon"></i>
                                    <div class="title">Apenas Materiais</div>
                                    <div class="description">Requer 48 horas de antecedência.</div>
                                </label>

                                <label class="tipo-option" for="tipo_ambos">
                                    <input type="radio" id="tipo_ambos" name="tipo_solicitacao" value="ambos" required>
                                    <i class="fas fa-layer-group icon"></i>
                                    <div class="title">Equipamentos + Materiais</div>
                                    <div class="description">Requer 48 horas de antecedência.</div>
                                </label>
                            </div>
                            <div id="equipamentos-container" style="display: none; margin-bottom: 1.5rem; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem;">
                                <h3 style="margin-top: 0; margin-bottom: 1rem; color: #1f2937;">
                                    <i class="fas fa-desktop"></i> Quais equipamentos você precisa? *
                                </h3>
                                <div style="display: flex; gap: 1.5rem; flex-wrap: wrap; margin-bottom: 1.5rem;">
                                    <label style="display: flex; align-items: center; gap: 0.5rem; font-weight: 500;">
                                        <input type="checkbox" id="equip_datashow" name="equipamentos_requeridos[]" value="Datashow" style="transform: scale(1.2);">
                                        Datashow
                                    </label>
                                    <label style="display: flex; align-items: center; gap: 0.5rem; font-weight: 500;">
                                        <input type="checkbox" id="equip_notebook" name="equipamentos_requeridos[]" value="Notebook" style="transform: scale(1.2);">
                                        Notebook
                                    </label>
                                    <label style="display: flex; align-items: center; gap: 0.5rem; font-weight: 500;">
                                        <input type="checkbox" id="equip_caixa_som" name="equipamentos_requeridos[]" value="Caixa de Som" style="transform: scale(1.2);">
                                        Caixa de Som
                                    </label>
                                    <label style="display: flex; align-items: center; gap: 0.5rem; font-weight: 500;">
                                        <input type="checkbox" id="equip_extensao" name="equipamentos_requeridos[]" value="Extensão" style="transform: scale(1.2);">
                                        Extensão
                                    </label>
                                    <div class="form-group" style="margin-bottom: 1.5rem;">
                                        <label for="sala" class="form-label">
                                            <i class="fas fa-door-open"></i> Chaves dos Laboratórios
                                        </label>
                                        <select
                                            id="sala"
                                            name="equipamentos_requeridos[]"
                                            class="form-input">
                                            <option value="">Selecione a sala</option>
                                            <optgroup label="Laboratórios">
                                                <option value="chave_lab1" id="equip_chave_lab1" <?php echo ($sala ?? '') === 'chave_lab1' ? 'selected' : ''; ?>>Chave Do Laboratório 1</option>
                                                <option value="chave_lab2" id="equip_chave_lab2" <?php echo ($sala ?? '') === 'chave_lab2' ? 'selected' : ''; ?>>Chave Do Laboratório 2</option>
                                                <option value="chave_lab3" id="equip_chave_lab3" <?php echo ($sala ?? '') === 'chave_lab3' ? 'selected' : ''; ?>>Chave Do Laboratório 3</option>
                                            </optgroup>
                                        </select>
                                    </div>
                                </div>
                                <small style="color: #6b7280; font-size: 0.875rem; margin-top: -1rem; display: block;">
                                    <i class="fas fa-info-circle"></i> Data-shows disponíveis: <?php echo $datashows_disponiveis; ?> | Notebooks disponíveis: <?php echo $notebooks_disponiveis; ?> | Caixa de Som disponíveis: 2 | Extensões disponíveis: 6
                                    <br><br>
                                    <i class="fas fa-info-circle"></i> Chave do Laboratório 1 disponível: <?php echo $chave_lab1_disponiveis; ?> | Chave do Laboratório 2 disponível: <?php echo $chave_lab2_disponiveis; ?> | Chave do Laboratório 3 disponível: <?php echo $chave_lab3_disponiveis; ?>
                                    <br><br>
                                    <i class="fas fa-info-circle"></i> <strong>Chaves dos laboratórios 1 e 2 acompanham o controle da TV!!</strong>
                                </small>
                            </div>

                            <!-- Informações Básicas -->
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                                <div class="form-group">
                                    <label for="professor" class="form-label">
                                        <i class="fas fa-user"></i> Professor
                                    </label>
                                    <input
                                        type="text"
                                        id="professor"
                                        class="form-input"
                                        value="<?php echo htmlspecialchars($_SESSION['user_name']); ?>"
                                        readonly
                                        style="background-color: #f8fafc; color: #6b7280;">
                                </div>

                                <div class="form-group">
                                    <label for="data_utilizacao" class="form-label">
                                        <i class="fas fa-calendar"></i> Data de Utilização *
                                    </label>
                                    <input
                                        type="date"
                                        id="data_utilizacao"
                                        name="data_utilizacao"
                                        class="form-input"
                                        value="<?php echo htmlspecialchars($data_utilizacao ?? ''); ?>"
                                        min="<?php echo date('Y-m-d'); ?>"
                                        required>
                                </div>
                            </div>

                            <!-- Turno (para equipamentos e materiais) -->
                            <div id="turno-container" style="display: none;">
                                <div class="form-group" style="margin-bottom: 1.5rem;">
                                    <label for="turno" class="form-label">
                                        <i class="fas fa-sun"></i> Turno *
                                    </label>
                                    <select
                                        id="turno"
                                        name="turno"
                                        class="form-input">
                                        <option value="">Selecione o turno</option>
                                        <option value="matutino" <?php echo ($turno ?? '') === 'matutino' ? 'selected' : ''; ?>>Matutino</option>
                                        <option value="vespertino" <?php echo ($turno ?? '') === 'vespertino' ? 'selected' : ''; ?>>Vespertino</option>
                                        <option value="noturno" <?php echo ($turno ?? '') === 'noturno' ? 'selected' : ''; ?>>Noturno</option>
                                    </select>
                                    <small style="color: #6b7280; font-size: 0.875rem; margin-top: 0.5rem; display: block;">
                                        <i class="fas fa-info-circle"></i> Obrigatório para equipamentos e materiais
                                    </small>
                                </div>
                            </div>

                            <!-- Sala -->
                            <div class="form-group" style="margin-bottom: 1.5rem;">
                                <label for="sala" class="form-label">
                                    <i class="fas fa-door-open"></i> Sala *
                                </label>
                                <select
                                    id="sala"
                                    name="sala"
                                    class="form-input"
                                    required>
                                    <option value="">Selecione a sala</option>
                                    <optgroup label="Laboratórios">
                                        <option value="Laboratório 1" <?php echo ($sala ?? '') === 'Laboratório 1' ? 'selected' : ''; ?>>Laboratório 1</option>
                                        <option value="Laboratório 2" <?php echo ($sala ?? '') === 'Laboratório 2' ? 'selected' : ''; ?>>Laboratório 2</option>
                                        <option value="Laboratório 3" <?php echo ($sala ?? '') === 'Laboratório 3' ? 'selected' : ''; ?>>Laboratório 3</option>
                                        <option value="Laboratório 4" <?php echo ($sala ?? '') === 'Laboratório 4' ? 'selected' : ''; ?>>Laboratório 4</option>
                                        <option value="Laboratório 5" <?php echo ($sala ?? '') === 'Laboratório 5' ? 'selected' : ''; ?>>Laboratório 5</option>
                                        <option value="Laboratório 6" <?php echo ($sala ?? '') === 'Laboratório 6' ? 'selected' : ''; ?>>Laboratório 6</option>
                                        <option value="Laboratório 7" <?php echo ($sala ?? '') === 'Laboratório 7' ? 'selected' : ''; ?>>Laboratório 7</option>
                                        <option value="Laboratório 8" <?php echo ($sala ?? '') === 'Laboratório 8' ? 'selected' : ''; ?>>Laboratório 8</option>
                                        <option value="Laboratório 9" <?php echo ($sala ?? '') === 'Laboratório 9' ? 'selected' : ''; ?>>Laboratório 9</option>
                                        <option value="Laboratório 10" <?php echo ($sala ?? '') === 'Laboratório 10' ? 'selected' : ''; ?>>Laboratório 10</option>
                                        <option value="Laboratório 11" <?php echo ($sala ?? '') === 'Laboratório 11' ? 'selected' : ''; ?>>Laboratório 11</option>
                                    </optgroup>
                                    <optgroup label="Salas de Aula">
                                        <option value="Sala 2" <?php echo ($sala ?? '') === 'Sala 2' ? 'selected' : ''; ?>>Sala 2</option>
                                        <option value="Sala 3" <?php echo ($sala ?? '') === 'Sala 3' ? 'selected' : ''; ?>>Sala 3</option>
                                        <option value="Sala 4" <?php echo ($sala ?? '') === 'Sala 4' ? 'selected' : ''; ?>>Sala 4</option>
                                        <option value="Sala 5" <?php echo ($sala ?? '') === 'Sala 5' ? 'selected' : ''; ?>>Sala 5</option>
                                        <option value="Sala 6" <?php echo ($sala ?? '') === 'Sala 6' ? 'selected' : ''; ?>>Sala 6</option>
                                        <option value="Sala 7" <?php echo ($sala ?? '') === 'Sala 7' ? 'selected' : ''; ?>>Sala 7</option>
                                        <option value="Sala 8" <?php echo ($sala ?? '') === 'Sala 8' ? 'selected' : ''; ?>>Sala 8</option>
                                        <option value="Sala 9" <?php echo ($sala ?? '') === 'Sala 9' ? 'selected' : ''; ?>>Sala 9</option>
                                        <option value="Sala 10" <?php echo ($sala ?? '') === 'Sala 10' ? 'selected' : ''; ?>>Sala 10</option>
                                        <option value="Sala 11" <?php echo ($sala ?? '') === 'Sala 11' ? 'selected' : ''; ?>>Sala 11</option>
                                    </optgroup>
                                    <optgroup label="Laboratórios Especializados">
                                        <option value="Laboratório de Eletrotécnica" <?php echo ($sala ?? '') === 'Laboratório de Eletrotécnica' ? 'selected' : ''; ?>>Laboratório de Eletrotécnica</option>
                                        <option value="Laboratório de Eletricidade" <?php echo ($sala ?? '') === 'Laboratório de Eletricidade' ? 'selected' : ''; ?>>Laboratório de Eletricidade</option>
                                        <option value="Laboratório de ESD" <?php echo ($sala ?? '') === 'Laboratório de ESD' ? 'selected' : ''; ?>>Laboratório de ESD</option>
                                        <option value="Laboratório de Automação" <?php echo ($sala ?? '') === 'Laboratório de Automação' ? 'selected' : ''; ?>>Laboratório de Automação</option>
                                    </optgroup>
                                    <optgroup label="Outros Espaços">
                                        <option value="Reunião">Reunião</option>
                                    </optgroup>
                                </select>
                                <small style="color: #6b7280; font-size: 0.875rem; margin-top: 0.5rem; display: block;">
                                    <i class="fas fa-info-circle"></i> Para a opção "Reunião", por favor, especifique a sala (ex: diretoria, coordenação) nas Observações Gerais.
                                </small>
                            </div>

                            <!-- Seleção de Materiais -->
                            <div id="materiais-container" class="materiais-section">
                                <h3 style="margin-bottom: 1rem; color: #1f2937;">
                                    <i class="fas fa-boxes"></i> Selecionar Materiais
                                </h3>

                                <!-- Barra de Pesquisa para Outros Materiais -->
                                <div id="outros-materiais-container" style="display: none;">
                                    <h4 style="margin-bottom: 0.75rem; color: #374151; font-size: 1rem;">
                                        <i class="fas fa-search"></i> Outros Materiais
                                    </h4>
                                    <div class="form-group" style="margin-bottom: 1rem;">
                                        <input
                                            type="text"
                                            id="busca-materiais"
                                            class="form-input"
                                            placeholder="Digite para buscar materiais..."
                                            style="width: 100%;">
                                    </div>
                                    <div id="materiais-grid" class="materiais-grid-scrollable">
                                        <!-- Materiais serão carregados via JavaScript -->
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" name="selected_materials_json" id="selected-materials-json">

                            <!-- Observações Gerais -->
                            <div class="form-group">
                                <label for="observacoes" class="form-label">
                                    <i class="fas fa-comment"></i> Observações Gerais
                                </label>
                                <textarea
                                    id="observacoes"
                                    name="observacoes"
                                    class="form-input"
                                    rows="4"
                                    placeholder="Informações adicionais sobre a utilização dos equipamentos..."
                                    style="resize: vertical;"><?php echo htmlspecialchars($observacoes ?? ''); ?></textarea>
                            </div>


                            <!-- Termo de Responsabilidade -->
                            <div class="form-group" style="margin-top: 2rem; border-top: 1px solid #e5e7eb; padding-top: 1.5rem;">
                                <h3 style="color: #1f2937; margin-bottom: 1rem;">Termo de Compromisso de Responsabilidade</h3>
                                <div style="background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem; font-size: 0.875rem; color: #374151; max-height: 200px; overflow-y: auto;">
                                    <p>Ao aceitar o presente termo, o(a) Professor(a) declara estar ciente e de acordo com as seguintes condições:</p>
                                    <ol style="margin-left: 1.5rem; line-height: 1.6;">
                                        <li>Todos os itens recebidos foram entregues em perfeito estado de conservação e funcionamento.</li>
                                        <li>O(a) Professor(a) assume total responsabilidade pela guarda, zelo e uso adequado dos itens, devendo acompanhar os(as) alunos(as) durante as práticas em sala de aula ou em outros ambientes da instituição, a fim de evitar danos ou mau uso.</li>
                                        <li>Caso algum item seja devolvido com defeito ou danificado, o(a) Professor(a) será responsabilizado(a) por sua reparação ou substituição, salvo quando o problema for comunicado imediatamente à Gerência de Tecnologia no ato de seu uso.</li>
                                        <li>É dever do(a) Professor(a) devolver, de forma imediata, qualquer item que apresente defeito, informando formalmente à Gerência de Tecnologia - IBC, a fim de que o ocorrido seja registrado e não seja contabilizado como entregue em más condições.</li>
                                    </ol>
                                    <p style="margin-top: 1rem;">Declaro que li e compreendi integralmente este termo e que estou de acordo com todas as responsabilidades aqui descritas.</p>
                                </div>
                                <label style="display: flex; align-items: center; gap: 0.75rem; margin-top: 1rem; cursor: pointer; font-weight: 500;">
                                    <input type="checkbox" id="aceite_termo" name="aceite_termo" required style="transform: scale(1.2);" />
                                    <span>Li e aceito os termos de responsabilidade.</span>
                                </label>
                            </div>

                            <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 2rem;">
                                <button type="reset" class="btn btn-secondary">
                                    <i class="fas fa-undo"></i> Limpar
                                </button>
                                <button type="submit" class="btn btn-primary" id="submit-button">
                                    <i class="fas fa-paper-plane"></i> Enviar Solicitação
                                </button>
                            </div>
                    </form>
                </div>
            </div>

            <!-- Informações Importantes -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-info-circle"></i> Informações Importantes
                    </h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem;">
                        <div>
                            <h3 style="color: #3b82f6; margin-bottom: 0.5rem;">
                                <i class="fas fa-video"></i> Datashow
                            </h3>
                            <p style="color: #6b7280; font-size: 0.875rem;">
                                • Pode ser solicitado para o mesmo dia<br>
                                • Seleção de turno é obrigatória<br>
                                • Limite de 7 datashows por turno<br>
                                • Materiais extras: Caixa de Som, Extensão, Microfone
                            </p>
                        </div>

                        <div>
                            <h3 style="color: #10b981; margin-bottom: 0.5rem;">
                                <i class="fas fa-boxes"></i> Materiais
                            </h3>
                            <p style="color: #6b7280; font-size: 0.875rem;">
                                • Requer 48 horas de antecedência<br>
                                • Use a barra de pesquisa para encontrar materiais<br>
                                • Especifique quantidades nas observações<br>
                                • Materiais disponíveis conforme estoque
                            </p>
                        </div>

                        <div>
                            <h3 style="color: #f59e0b; margin-bottom: 0.5rem;">
                                <i class="fas fa-exclamation-triangle"></i> Responsabilidades
                            </h3>
                            <p style="color: #6b7280; font-size: 0.875rem;">
                                • Cuidar dos equipamentos durante o uso<br>
                                • Devolver no horário combinado<br>
                                • Reportar problemas imediatamente<br>
                                • Respeitar os limites de quantidade
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // A chave da solução: todo o código que manipula o HTML agora espera a página carregar completamente.
        document.addEventListener('DOMContentLoaded', function() {

            // Funções para controle do menu mobile
            function toggleSidebar() {
                const sidebar = document.querySelector(".sidebar");
                const overlay = document.querySelector(".sidebar-overlay");
                if (sidebar) sidebar.classList.toggle("open");
                if (overlay) overlay.classList.toggle("active");
            }

            function closeSidebar() {
                const sidebar = document.querySelector(".sidebar");
                const overlay = document.querySelector(".sidebar-overlay");
                if (sidebar) sidebar.classList.remove("open");
                if (overlay) overlay.classList.remove("active");
            }

            const mobileMenuToggle = document.querySelector(".mobile-menu-toggle");
            if (mobileMenuToggle) {
                mobileMenuToggle.onclick = toggleSidebar;
            }
            const sidebarOverlay = document.querySelector(".sidebar-overlay");
            if (sidebarOverlay) {
                sidebarOverlay.onclick = closeSidebar;
            }

            // --- LÓGICA DO FORMULÁRIO ---
            const tipoRadios = document.querySelectorAll('input[name="tipo_solicitacao"]');
            const turnoContainer = document.getElementById('turno-container');
            const equipamentosContainer = document.getElementById('equipamentos-container');
            const materiaisContainer = document.getElementById('materiais-container');
            const outrosMateriaisContainer = document.getElementById('outros-materiais-container');
            const dataInput = document.getElementById('data_utilizacao');
            const turnoInput = document.getElementById('turno');
            const datashowCheckbox = document.getElementById('equip_datashow');
            const buscaMateriais = document.getElementById('busca-materiais');
            const materiaisGrid = document.getElementById('materiais-grid');

            function updateFormBasedOnType() {
                const selectedType = document.querySelector('input[name="tipo_solicitacao"]:checked')?.value;

                document.querySelectorAll('.tipo-option').forEach(option => option.classList.remove('selected'));
                if (selectedType) {
                    const selectedOption = document.querySelector(`input[value="${selectedType}"]`);
                    if (selectedOption) selectedOption.closest('.tipo-option').classList.add('selected');
                }

                if (turnoContainer) turnoContainer.style.display = 'none';
                if (equipamentosContainer) equipamentosContainer.style.display = 'none';
                if (materiaisContainer) materiaisContainer.style.display = 'none';
                if (outrosMateriaisContainer) outrosMateriaisContainer.style.display = 'none';
                if (turnoInput) turnoInput.required = false;

                const hoje = new Date().toISOString().split('T')[0]; // data de hoje

                if (selectedType === 'equipamentos') {
                    if (turnoContainer) turnoContainer.style.display = 'block';
                    if (equipamentosContainer) equipamentosContainer.style.display = 'block';
                    if (dataInput) {
                        dataInput.min = hoje; // não permite datas antes de hoje
                        dataInput.max = hoje; // bloqueia datas futuras
                        dataInput.value = hoje; // seta o valor inicial para hoje
                    }
                    if (turnoInput) turnoInput.required = true;
                } else if (selectedType === 'materiais') {
                    if (turnoContainer) turnoContainer.style.display = 'block';
                    if (materiaisContainer) materiaisContainer.style.display = 'block';
                    if (outrosMateriaisContainer) outrosMateriaisContainer.style.display = 'block';
                    const minDate = new Date();
                    minDate.setDate(minDate.getDate() + 2);
                    if (dataInput) {
                        dataInput.min = minDate.toISOString().split('T')[0];
                        dataInput.max = ''; // permite datas futuras
                    }
                    if (turnoInput) turnoInput.required = true;
                } else if (selectedType === 'ambos') {
                    if (turnoContainer) turnoContainer.style.display = 'block';
                    if (equipamentosContainer) equipamentosContainer.style.display = 'block';
                    if (materiaisContainer) materiaisContainer.style.display = 'block';
                    if (outrosMateriaisContainer) outrosMateriaisContainer.style.display = 'block';
                    const minDate = new Date();
                    minDate.setDate(minDate.getDate() + 2);
                    if (dataInput) {
                        dataInput.min = minDate.toISOString().split('T')[0];
                        dataInput.max = ''; // permite datas futuras
                    }
                    if (turnoInput) turnoInput.required = true;
                }
            }

            if (tipoRadios.length > 0) {
                tipoRadios.forEach(radio => radio.addEventListener('change', updateFormBasedOnType));
            }

            if (datashowCheckbox) {
                datashowCheckbox.addEventListener('change', function() {
                    if (materiaisExtrasContainer) {
                        materiaisExtrasContainer.style.display = this.checked ? 'block' : 'none';
                    }
                });
            }

            let timeoutId;
            if (buscaMateriais) {
                buscaMateriais.addEventListener('input', function() {
                    clearTimeout(timeoutId);
                    const termo = this.value.trim();
                    if (termo.length < 2) {
                        if (materiaisGrid) {
                            materiaisGrid.style.display = 'none';
                            materiaisGrid.innerHTML = '';
                        }
                        return;
                    }
                    timeoutId = setTimeout(() => buscarMateriais(termo), 300);
                });
            }

            updateFormBasedOnType(); // Inicializa o estado do formulário

            // Controle dos campos de quantidade (Caixa de Som, Extensão)
            ['caixa_som', 'extensao'].forEach(id => {
                const checkbox = document.getElementById(`material_extra_${id}`);
                if (checkbox) {
                    checkbox.addEventListener('change', function() {
                        const qtyInput = document.getElementById(`qty_${id}`);
                        if (qtyInput) {
                            qtyInput.disabled = !this.checked;
                            if (!this.checked) qtyInput.value = 1;
                        }
                    });
                }
            });

            const mainForm = document.querySelector('.card-body form');
            if (mainForm) {
                mainForm.addEventListener('submit', function(e) {
                    // Antes de enviar, corrige possíveis referências inválidas
                    try {
                        // Verifica e previne uso de colunas inexistentes (como 'equipamentos_solicitados')
                        const queryPlaceholder = document.querySelector('#query-sql');
                        if (queryPlaceholder && queryPlaceholder.value.includes('equipamentos_solicitados')) {
                            queryPlaceholder.value = queryPlaceholder.value.replace(/equipamentos_solicitados/g, 'id_equipamento');
                            console.warn("⚠️ Corrigido: referência inválida à coluna 'equipamentos_solicitados'.");
                        }
                    } catch (error) {
                        console.error("Erro ao verificar colunas antes do envio:", error);
                    }

                    // Continua o envio normal
                    const selectedMaterialsArray = [];
                    materiaisSelecionados.forEach((materialData, id) => {
                        selectedMaterialsArray.push({
                            id: id,
                            quantidade: materialData.quantidade
                        });
                    });
                    document.getElementById('selected-materials-json').value = JSON.stringify(selectedMaterialsArray);

                    const btn = this.querySelector('button[type="submit"]');
                    if (btn) {
                        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
                        btn.disabled = true;
                    }
                });
            }

        }); // Fim do 'DOMContentLoaded'

        // Variável global para armazenar materiais selecionados
        let materiaisSelecionados = new Map();

        // Inicializar materiaisSelecionados se houver dados pré-existentes (ex: após erro de validação)
        document.addEventListener("DOMContentLoaded", function() {
            const selectedMaterialsJsonInput = document.getElementById("selected-materials-json");
            if (selectedMaterialsJsonInput && selectedMaterialsJsonInput.value) {
                try {
                    const preSelected = JSON.parse(selectedMaterialsJsonInput.value);
                    preSelected.forEach(item => {
                        // CORREÇÃO: Garante que o item é sempre armazenado como um objeto
                        // mesmo que o nome seja temporariamente nulo.
                        materiaisSelecionados.set(item.id, {
                            nome: null,
                            quantidade: item.quantidade
                        });
                    });
                    // NOTA: O resumo será atualizado se houver itens
                    if (preSelected.length > 0) {
                        // Se for 'materiais' ou 'ambos', o resumo pode ser exibido antes da busca
                        atualizarResumoMateriais();
                    }
                } catch (e) {
                    console.error("Erro ao parsear materiais selecionados JSON:", e);
                }
            }
        });

        // ==========================
        // BUSCAR MATERIAIS
        // ==========================
        function buscarMateriais(termo) {
            const materiaisGrid = document.getElementById('materiais-grid');
            if (!materiaisGrid) return;

            fetch(`buscar_materiais.php?termo=${encodeURIComponent(termo)}`)
                .then(response => response.json())
                .then(data => {
                    materiaisGrid.innerHTML = '';

                    if (data.length === 0) {
                        materiaisGrid.innerHTML = '<p style="text-align:center;color:#6b7280;padding:1rem;">Nenhum material encontrado.</p>';
                    } else {
                        data.forEach(material => {
                            const materialDiv = document.createElement('div');
                            materialDiv.className = 'material-item-search';

                            const jaEstavaSelecionado = materiaisSelecionados.has(material.id);
                            const quantidadeSalva = materiaisSelecionados.get(material.id) || 1;

                            const nomeSeguro = material.nome.replace(/'/g, "\\'");
                            materialDiv.innerHTML = `
                        <div class="material-left">
                            <input type="checkbox" id="material_${material.id}" name="materiais[]" value="${material.id}"
                                style="margin-right: 0.75rem; transform: scale(1.1);"
                                onchange="toggleQuantityInput(this, ${material.id}, '${nomeSeguro}')"
                                ${jaEstavaSelecionado ? 'checked' : ''}>
                            <div class="material-info">
                                <div class="material-name">${material.nome}</div>
                                <div class="material-qty">Disponível: ${material.quantidade} (Máx. permitido: ${material.quantidade_maxima})</div>
                            </div>
                        </div>
                        <div class="material-right">
                            <label for="qty_material_${material.id}" style="font-size:0.875rem;color:#6b7280;">Qtd:</label>
                            <input type="number" id="qty_material_${material.id}" name="qty_materiais[${material.id}]"
                                min="1" max="${material.quantidade_maxima}" value="${quantidadeSalva}"
                                style="width:60px;padding:0.25rem;border:1px solid #d1d5db;border-radius:4px;margin-left:0.5rem;"
                                ${jaEstavaSelecionado ? '' : 'disabled'}>
                        </div>
                    `;
                            materiaisGrid.appendChild(materialDiv);
                        });
                    }

                    materiaisGrid.style.display = 'block';
                    atualizarResumoMateriais(); // Atualiza resumo sempre que uma pesquisa é feita
                })
                .catch(error => {
                    console.error('Erro ao buscar materiais:', error);
                    materiaisGrid.innerHTML = '<p style="text-align:center;color:#dc2626;padding:1rem;">Erro ao buscar materiais.</p>';
                    materiaisGrid.style.display = 'block';
                });
        }

        // ==========================
        // TOGGLE QUANTIDADE
        // ==========================
        // solicitar.php (~Linha 749)
        // ==========================
        // TOGGLE QUANTIDADE
        // ==========================
        function toggleQuantityInput(checkbox, materialId, materialName) {
            const quantityInput = document.getElementById(`qty_material_${materialId}`);
            if (!quantityInput) return;

            quantityInput.disabled = !checkbox.checked;

            if (checkbox.checked) {
                const quantidade = parseInt(quantityInput.value) || 1;

                // CRUCIAL: Salva um objeto, garantindo que o nome do material não se perca.
                // Se o nome vier nulo (de uma recarga) e o materialName for fornecido (da busca), atualiza o nome.
                const nomeParaSalvar = materialName || materiaisSelecionados.get(materialId)?.nome || `Material ${materialId}`;

                materiaisSelecionados.set(materialId, {
                    nome: nomeParaSalvar, // Salva o nome para o resumo
                    quantidade: quantidade
                });

                // Remover listener antigo e adicionar novo
                quantityInput.onchange = function() {
                    if (checkbox.checked) {
                        // Atualiza APENAS a quantidade do objeto salvo no Map
                        materiaisSelecionados.get(materialId).quantidade = parseInt(this.value) || 1;
                        atualizarResumoMateriais();
                    }
                };
            } else {
                materiaisSelecionados.delete(materialId);
                quantityInput.value = 1;
                // Opcional: remover o listener se quiser ser mais limpo (não estritamente necessário)
                quantityInput.onchange = null;
            }

            atualizarResumoMateriais();
        }

        // ==========================
        // ATUALIZAR RESUMO
        // ==========================
        function atualizarResumoMateriais() {
            let resumoContainer = document.getElementById('resumo-materiais');

            if (!resumoContainer) {
                resumoContainer = document.createElement('div');
                resumoContainer.id = 'resumo-materiais';
                resumoContainer.style.cssText = `
            margin-top: 1rem;
            padding: 1rem;
            background: #f0f9ff;
            border: 1px solid #0ea5e9;
            border-radius: 6px;
            display: none;
        `;
                const materiaisContainer = document.getElementById('outros-materiais-container');
                if (materiaisContainer) materiaisContainer.appendChild(resumoContainer);
            }

            if (materiaisSelecionados.size === 0) {
                resumoContainer.style.display = 'none';
                resumoContainer.innerHTML = '';
                return;
            }

            let html = '<h4 style="margin:0 0 0.5rem 0;color:#0369a1;"><i class="fas fa-check-circle"></i> Materiais Selecionados:</h4>';
            html += '<div style="display:flex;flex-wrap:wrap;gap:0.5rem;">';

            materiaisSelecionados.forEach((materialData, materialId) => {
                const nomeMateria = materialData.nome; // AGORA FUNCIONA
                const quantidade = materialData.quantidade; // AGORA FUNCIONA

                // CORREÇÃO: Se o nome estiver nulo (vindo do pré-selecionado), busca no DOM.
                if (!nomeMateria) {
                    const checkbox = document.getElementById(`material_${materialId}`);
                    const materialInfo = checkbox?.closest('.material-item-search')?.querySelector('.material-name');
                    nomeMateria = materialInfo ? materialInfo.textContent : `Material ${materialId}`;
                }

                html += `
            <span style="
                background: #0ea5e9; 
                color: white; 
                padding: 0.25rem 0.5rem; 
                border-radius: 4px; 
                font-size: 0.875rem;
                display: inline-flex;
                align-items: center;
                gap: 0.25rem;
            ">
                ${nomeMateria} (${quantidade}x)
                <button type="button" onclick="removerMaterial(${materialId})" style="
                    background:none; 
                    border:none; 
                    color:white; 
                    cursor:pointer; 
                    padding:0;
                    margin-left:0.25rem;
                    font-size:0.75rem;
                ">×</button>
            </span>
        `;
            });

            html += '</div>';
            resumoContainer.innerHTML = html;
            resumoContainer.style.display = 'block';
        }

        // ==========================
        // REMOVER MATERIAL
        // ==========================
        function removerMaterial(materialId) {
            materiaisSelecionados.delete(materialId);

            const checkbox = document.getElementById(`material_${materialId}`);
            if (checkbox) {
                checkbox.checked = false;
                const quantityInput = document.getElementById(`qty_material_${materialId}`);
                if (quantityInput) quantityInput.disabled = true;
                quantityInput.value = 1;
            }

            atualizarResumoMateriais();
        }


        // --- FUNÇÃO DO CONTADOR ---
        function atualizarContador() {
            const contadorElement = document.getElementById('contador-pendentes');
            if (contadorElement) {
                fetch('contador_pendentes.php')
                    .then(response => {
                        if (!response.ok) throw new Error('Network response was not ok');
                        return response.text();
                    })
                    .then(data => {
                        contadorElement.innerHTML = data;
                    })
                    .catch(error => console.error("Erro ao atualizar contador:", error));
            }
        }

        // Chama a função no carregamento da página e a cada 5 segundos
        atualizarContador();
        setInterval(atualizarContador, 5000);
    </script>
</body>

</html>