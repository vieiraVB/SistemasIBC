# Instruções para Copilot AI - SIMEI

## Visão Geral do Projeto

**SIMEI** (Sistema de Movimentação de Equipamentos e Insumos) é uma aplicação web PHP/MySQL para gerenciar solicitações de equipamentos (datashows, notebooks, caixas de som, extensões, chaves de laboratório) e materiais em uma instituição de ensino (IBC).

### Arquitetura em Três Camadas:
1. **Frontend**: PHP templating + HTML/CSS (style.css com variables CSS) + JavaScript vanilla
2. **Backend**: PHP 7.4+ com PDO para MySQL 5.7+
3. **Banco de Dados**: MySQL com tabelas de usuários, solicitações, materiais, e relacionamentos

## Fluxo de Dados Principal

### Usuários e Autenticação
- **3 tipos de usuários**: `admin`, `colaborador`, `professor`
- **Login**: CPF (11 dígitos) + senha com hash `PASSWORD_DEFAULT`
- **Sessão**: `$_SESSION['user_id']`, `['user_name']`, `['user_type']`, `['user_cpf']`
- **Funções de verificação**: `isLoggedIn()`, `isAdmin()`, `isColaborador()`

### Fluxo de Solicitação (Requisição)
**Professor** → Solicita → **Pendente** → Admin aprova → **Aprovada** → Admin retira → **Retirada** → Admin devolve → **Concluída**

**Tipos de solicitação**:
1. **Equipamentos extra** (datashow, notebook, caixa de som, extensões, chaves de lab)
2. **Materiais** (da tabela `materiais` com controle de estoque)
3. **Software** (requer 48h de antecedência)

### Tabelas Principais
- `usuarios` (id, nome, cpf, senha, tipo, ativo)
- `solicitacoes` (id, usuario_id, status, tipo_solicitacao, data_utilizacao, materiais_solicitados, materiais_extras)
- `solicitacoes_materiais` (id_solicitacao, id_material, quantidade_solicitada)
- `materiais` (id, nome, descricao, quantidade, status_disponibilidade)

## Convenções e Padrões

### Estrutura de Arquivos
- **`pages/*.php`**: Páginas principais (solicitar.php, pendentes.php, usuarios.php, materiais.php)
- **`includes/config.php`**: Arquivo central de configuração, funções utilitárias, conexão PDO
- **`pages/partials/`**: Templates reutilizáveis (solicitacoes_table.php)
- **`css/style.css`**: CSS único com variáveis CSS (--primary-color, --success-color, etc.)

### Padrões de Segurança
- **Sanitização**: Usar `sanitize()` para HTML/XSS (strip_tags + htmlspecialchars)
- **Prepared Statements**: SEMPRE com `$pdo->prepare()` + `execute()` para evitar SQL injection
- **Senhas**: Hash com `hashPassword()` (PASSWORD_DEFAULT), verificar com `verifyPassword()`
- **Sessão segura**: httponly cookies, use_only_cookies=1, cookie_secure=1 em produção

### Padrões de Formulário
- **POST para alterações**: Sempre `$_SERVER['REQUEST_METHOD'] === 'POST'`
- **Validação**: Declarar variáveis padrão no topo do arquivo para repopular formulários em erro
- **Resposta**: `$error` e `$success` para mensagens, exibidas em `alert` divs
- **JSON para materiais**: Materiais são armazenados como JSON em `materiais_solicitados` ou arrays em `materiais_extras`

### Padrões de Controle de Estoque
- **Disponibilidade de equipamentos**: Contagem dinâmica com `SELECT COUNT()` filtrando status 'aprovada' ou 'retirada'
- **Materiais**: Estoque ajustado em transações PDO (`beginTransaction()`, `commit()`, `rollback()`)
- **Limites fixos**: Datashows=7, Notebooks=3, Caixas=2, Extensões=6, Chaves Lab=1 cada

### Tratamento de Erros
- **PDOException**: Try/catch com mensagens descritivas
- **Log de erros**: `error_log()` para debugging (ex: aprovações, transações)
- **Feedback ao usuário**: Nunca expor mensagens de banco diretas; usar mensagens genéricas

## Fluxos Críticos de Desenvolvimento

### Ao Adicionar Nova Funcionalidade de Solicitação
1. Adicionar **tipo** em validação `$tipo_solicitacao` (solicitar.php)
2. Implementar **validação específica** do tipo
3. Inserir em tabela `solicitacoes` com `usuario_id = $_SESSION['user_id']`
4. Se houver materiais: inserir em `solicitacoes_materiais` em transação
5. Atualizar pendentes.php com novo **case de ação** se necessário

### Ao Modificar Controle de Estoque
- **SEMPRE usar transações** (`beginTransaction()`, `commit()`, `rollback()`)
- Validar quantidades ANTES de atualizar (não podem ir negativas)
- Atualizar `data_retirada` ou `data_devolucao` conforme status
- Log em `error_log()` para rastreabilidade

### Ao Acessar Dados de Solicitação
- **Verificar permissão**: Admin vê tudo; professor só suas próprias
- **Usar joins**: Sempre incluir nome do usuário via `JOIN usuarios u`
- **Agrupar materiais**: Combinar `solicitacoes_materiais` + `materiais_extras` JSON

## Pontos de Atenção Comuns

### Data/Hora
- Timezone definido em solicitar.php: `date_default_timezone_set('America/Manaus')`
- Sempre usar timestamps MySQL com `NOW()` ou datas no formato `YYYY-MM-DD HH:MM:SS`

### Validações Críticas
- **Datas**: Solicitação de software requer 48h de antecedência
- **CPF**: Deve ter 11 dígitos (remover pontos/hífens antes de comparar)
- **Quantidade**: Não pode exceder estoque disponível

### CSS e UI
- Use variáveis CSS definidas em `:root` (style.css)
- Classes padrão: `.form-group`, `.form-input`, `.alert`, `.btn`, `.table`
- Responsividade: `@media (max-width: 768px)` para mobile

### Problema Conhecido: Perda de Dados em Formulários
- Arquivo solicitar.php declara variáveis padrão no topo para repopulação em erro
- Pattern: `$variavel = sanitize($_POST['campo'] ?? '');` (com valor padrão)

## Referências Rápidas

**Rotas principais**:
- `/` → login
- `/pages/solicitar.php` → criar solicitação (professor)
- `/pages/pendentes.php` → gerenciar solicitações (admin)
- `/pages/usuarios.php` → gerenciar usuários (admin/colaborador)
- `/pages/materiais.php` → gerenciar estoque (admin)

**Funções utilitárias** (em includes/config.php):
- `getDBConnection()` → PDO
- `isLoggedIn()`, `isAdmin()`, `isColaborador()`
- `sanitize()`, `hashPassword()`, `verifyPassword()`, `redirect()`
