<table class="table">
    
    <tbody>
        <?php if (empty($solicitacoes)): ?>
            <tr>
                <td colspan="<?php echo isAdmin() ? '9' : '8'; ?>" class="text-center" style="padding: 2rem; color: #6b7280;">
                    <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 1rem; display: block;"></i>
                    Nenhuma solicitação encontrada.
                </td>
            </tr>
        <?php else: ?>
            <?php foreach ($solicitacoes as $solicitacao): 
                $tipo = $solicitacao['tipo_solicitacao']; // Definindo $tipo
            ?>
                <tr class="clickable-row" onclick="abrirDetalhes(<?php echo $solicitacao['id']; ?>)">
                    <td>
                        <strong><?php echo htmlspecialchars($solicitacao['usuario_nome']); ?></strong>
                        <br>
                        <small style="color: #6b7280;">
                            Solicitado em: <?php echo date('d/m/Y H:i', strtotime($solicitacao['data_solicitacao'])); ?>
                        </small>
                    </td>

                    <td>
                        <?php
                        $tipo_classes = [
                            'equipamentos' => 'tipo-datashow',
                            'materiais' => 'tipo-materiais',
                            'software' => 'tipo-software',
                            'equipamentos_e_materiais' => 'tipo-datashow' // Pode criar um estilo novo se quiser
                        ];
                        $tipo_icons = [
                            'equipamentos' => 'fas fa-video',
                            'materiais' => 'fas fa-boxes',
                            'software' => 'fas fa-laptop-code',
                            'equipamentos_e_materiais' => 'fas fa-server'
                        ];
                        $tipo_labels = [
                            'equipamentos' => 'Equipamentos',
                            'materiais' => 'Materiais',
                            'software' => 'Software',
                            'equipamentos_e_materiais' => 'Equip. + Mat.'
                        ];
                        $classe = $tipo_classes[$tipo] ?? 'tipo-datashow';
                        $icone = $tipo_icons[$tipo] ?? 'fas fa-question-circle';
                        $label = $tipo_labels[$tipo] ?? ucfirst($tipo ?: 'Indefinido');
                        ?>
                        <span class="tipo-badge <?php echo $classe; ?>">
                            <i class="<?php echo $icone; ?>"></i>
                            <?php echo $label; ?>
                        </span>
                    </td>
                    
                    <td><?php echo date('d/m/Y', strtotime($solicitacao['data_utilizacao'])); ?></td>

                    <td>
                        <?php if ($tipo === 'equipamentos' || $tipo === 'materiais' || $tipo === 'equipamentos_e_materiais'): ?>
                            <?php if ($solicitacao['turno']): ?>
                                <span class="turno-badge turno-<?php echo $solicitacao['turno']; ?>">
                                    <?php
                                    $turnos = [
                                        'matutino' => 'Matutino',
                                        'vespertino' => 'Vespertino',
                                        'noturno' => 'Noturno'
                                    ];
                                    echo $turnos[$solicitacao['turno']] ?? 'N/A';
                                    ?>
                                </span>
                            <?php else: ?>
                                <span style="color: #6b7280;">-</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span style="color: #6b7280;">N/A</span>
                        <?php endif; ?>
                    </td>

                    <td><?php echo htmlspecialchars($solicitacao['sala']); ?></td>

                    <td>
                        <?php 
                        $materiais_solicitados_str = '';
                        // Verifica se é 'materiais' OU 'combinado'
                        if (($tipo === 'materiais' || $tipo === 'equipamentos_e_materiais') && !empty($solicitacao['materiais_solicitados']) && $solicitacao['materiais_solicitados'] != '[]'): 
                        ?>
                            <div class="materiais-column">
                                <?php
                                    $stmt_materiais = $pdo->prepare("
                                        SELECT m.nome, sm.quantidade_solicitada
                                        FROM solicitacoes_materiais sm
                                        JOIN materiais m ON sm.id_material = m.id
                                        WHERE sm.id_solicitacao = ?
                                    ");
                                    $stmt_materiais->execute([$solicitacao['id']]);
                                    $materiais = $stmt_materiais->fetchAll(PDO::FETCH_ASSOC);

                                    if ($materiais) {
                                        $total_materiais = count($materiais);
                                        $primeiros_materiais = array_slice($materiais, 0, 2); // Pega os 2 primeiros

                                        foreach ($primeiros_materiais as $material) {
                                            $materiais_solicitados_str .= htmlspecialchars($material['nome']) . ' (x' . htmlspecialchars($material['quantidade_solicitada']) . ')<br>';
                                        }
                                        
                                        echo $materiais_solicitados_str;

                                        if ($total_materiais > 2) {
                                            $restante = $total_materiais - 2;
                                            echo "<small style='color: #0ea5e9; font-weight: 500;'>...e mais $restante itens</small>";
                                        }
                                    } else {
                                        echo 'Nenhum material associado';
                                    }
                                ?>
                            </div>
                        
                        <?php elseif ($tipo === 'software'): ?>
                            <div class="materiais-column">
                                <small style="color: #3730A3; white-space: normal; font-weight: 500;">
                                    <?php echo nl2br(htmlspecialchars($solicitacao['softwares_solicitados'])); ?>
                                </small>
                                <?php if ($solicitacao['anexo_path']): ?>
                                    <br><a href="../<?php echo htmlspecialchars($solicitacao['anexo_path']); ?>" target="_blank" style="font-size: 0.875rem;" onclick="event.stopPropagation();">
                                        <i class="fas fa-file-alt"></i> Baixar Guia
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php elseif ($tipo === 'equipamentos'): ?>
                            <span style="color: #6b7280;">N/A (Equip.)</span>
                        <?php else: ?>
                            <span style="color: #6b7280;">-</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge badge-<?php 
                            echo $solicitacao['status'] === 'pendente' ? 'warning' : 
                                ($solicitacao['status'] === 'aprovada' ? 'info' : 
                                ($solicitacao['status'] === 'retirada' ? 'success' : 
                                ($solicitacao['status'] === 'devolvida' ? 'success' : 'danger'))); 
                        ?>">
                            <?php echo ucfirst($solicitacao['status']); ?>
                        </span>
                    </td>
                    
                    <td class="observacao-cell">
                        <?php if ($solicitacao['observacoes']): ?>
                            <span class="observacao-text" title="<?php echo htmlspecialchars($solicitacao['observacoes']); ?>">
                                <i class="fas fa-comment"></i> <?php echo htmlspecialchars(substr($solicitacao['observacoes'], 0, 30)); ?>...
                            </span>
                        <?php endif; ?>
                    </td>
                    
                    <?php if (isAdmin()): ?>
                    <td>
                        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                            
                            <?php if ($solicitacao['status'] !== 'cancelada'): // Mostra Editar para TUDO, exceto cancelada ?>
                                <a href="editar_solicitacao.php?id=<?php echo $solicitacao['id']; ?>" class="btn btn-info" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="event.stopPropagation();" title="Editar">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>
                            <?php endif; ?>
                            <?php if ($solicitacao['status'] === 'pendente'): ?>
                                <form method="POST" style="display: inline;" onclick="event.stopPropagation();">
                                    <input type="hidden" name="action" value="aprovar">
                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                    <button type="submit" class="btn btn-success" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Tem certeza que deseja aprovar esta solicitação?');">
                                        <i class="fas fa-check"></i> Aprovar
                                    </button>
                                </form>
                                <form method="POST" style="display: inline;" onclick="event.stopPropagation();">
                                    <input type="hidden" name="action" value="excluir">
                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                    <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Excluir esta solicitação? Esta ação não pode ser desfeita e os materiais serão devolvidos ao estoque.')">
                                        <i class="fas fa-trash"></i> Excluir
                                    </button>
                                </form>
                            <?php elseif ($solicitacao['status'] === 'aprovada'): ?>
                                <form method="POST" style="display: inline;" onclick="event.stopPropagation();">
                                    <input type="hidden" name="action" value="retirar">
                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                    <button type="submit" class="btn btn-warning" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Confirmar retirada?')">
                                        <i class="fas fa-hand-paper"></i> Retirar
                                    </button>
                                </form>
                            <?php elseif ($solicitacao['status'] === 'retirada'): ?>
                                <button type="button" class="btn btn-primary" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="event.stopPropagation(); abrirModalDevolucao(<?php echo $solicitacao['id']; ?>)">
                                    <i class="fas fa-undo"></i> Devolver
                                </button>
                            <?php endif; ?>
                        </div>
                    </td>
                    <?php elseif ($solicitacao['status'] === 'pendente' && $solicitacao['usuario_id'] == $_SESSION['user_id']): ?>
                    <td>
                        <form method="POST" style="display: inline;" onclick="event.stopPropagation();">
                            <input type="hidden" name="action" value="cancelar">
                            <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                            <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Cancelar esta solicitação?')">
                                <i class="fas fa-times"></i> Cancelar
                            </button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>