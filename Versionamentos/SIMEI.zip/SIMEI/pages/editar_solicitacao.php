<?php
require_once '../includes/config.php';
$pdo = getDBConnection();
date_default_timezone_set('America/Manaus');

// --- INÍCIO DA LÓGICA DE EDIÇÃO ---

// 1. VERIFICAR SE É ADMIN E SE TEM ID
if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirect('pendentes.php');
}

$solicitacao_id = (int)$_GET['id'];
$error = '';
$success = '';

// 2. PROCESSAR O POST (SALVAR ALTERAÇÕES)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Pegar os dados comuns
        $observacoes = sanitize($_POST['observacoes'] ?? '');
        $tipo_solicitacao = sanitize($_POST['tipo_solicitacao'] ?? ''); // O tipo não muda, mas é usado
        
        $pdo->beginTransaction();

        // --- LÓGICA DE UPDATE PARA CADA TIPO ---

        if ($tipo_solicitacao === 'software') {
            $softwares = sanitize(trim($_POST['softwares_solicitados'] ?? ''));
            $sala_software = sanitize(trim($_POST['sala_software'] ?? ''));
            $data_utilizacao = sanitize($_POST['data_utilizacao_software'] ?? '');
            $data_termino = sanitize($_POST['data_termino_uso'] ?? '');
            
            // (Lógica de upload de anexo - se um *novo* anexo for enviado, ele substitui o antigo)
            $anexo_path = sanitize($_POST['anexo_existente'] ?? null); // Pega o anexo que já existe
            
            if (!empty($_FILES['anexo']['name'])) {
                $nome_arquivo = basename($_FILES['anexo']['name']);
                $extensao = strtolower(pathinfo($nome_arquivo, PATHINFO_EXTENSION));
                $permitidos = ["doc", "docx", "pdf", "xls", "xlsx", "ppt", "pptx"];

                if (!in_array($extensao, $permitidos)) {
                    throw new Exception('Tipo de arquivo não permitido.');
                }
                
                $nome_arquivo_unico = time() . "_" . $nome_arquivo;
                $destino = "../uploads/software/" . $nome_arquivo_unico;

                if (move_uploaded_file($_FILES['anexo']['tmp_name'], $destino)) {
                    $anexo_path = "uploads/software/" . $nome_arquivo_unico; // Caminho salvo no DB
                } else {
                    throw new Exception('Erro ao salvar o novo anexo.');
                }
            }

            $sql = "UPDATE solicitacoes SET 
                        softwares_solicitados = :softwares, 
                        sala = :sala, 
                        data_utilizacao = :data_inicio, 
                        data_termino_uso = :data_termino, 
                        anexo_path = :anexo,
                        observacoes = :obs
                    WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':softwares' => $softwares,
                ':sala' => $sala_software,
                ':data_inicio' => $data_utilizacao,
                ':data_termino' => $data_termino,
                ':anexo' => $anexo_path,
                ':obs' => $observacoes,
                ':id' => $solicitacao_id
            ]);

        } elseif ($tipo_solicitacao === 'materiais') {
            $data_utilizacao = sanitize($_POST['data_utilizacao_materiais'] ?? '');
            $data_termino = sanitize($_POST['data_termino_uso_materiais'] ?? '');
            $turno = sanitize($_POST['turno'] ?? '');
            $sala = sanitize($_POST['sala'] ?? '');
            $materiais_selecionados_json = $_POST["selected_materials_json"] ?? "[]";
            $materiais_selecionados = json_decode($materiais_selecionados_json, true);

            $sql = "UPDATE solicitacoes SET 
                        data_utilizacao = :data_inicio, 
                        data_termino_uso = :data_termino, 
                        turno = :turno, 
                        sala = :sala, 
                        observacoes = :obs
                    WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':data_inicio' => $data_utilizacao,
                ':data_termino' => $data_termino,
                ':turno' => $turno,
                ':sala' => $sala,
                ':obs' => $observacoes,
                ':id' => $solicitacao_id
            ]);
            
            // Atualizar a lista de materiais (Delete todos e Insere de novo)
            $stmt_delete = $pdo->prepare("DELETE FROM solicitacoes_materiais WHERE id_solicitacao = ?");
            $stmt_delete->execute([$solicitacao_id]);
            
            if (!empty($materiais_selecionados)) {
                // Precisamos do ID do usuário da *solicitação original*, não do admin logado
                $stmt_get_user = $pdo->prepare("SELECT usuario_id FROM solicitacoes WHERE id = ?");
                $stmt_get_user->execute([$solicitacao_id]);
                $solicitante_id = $stmt_get_user->fetchColumn();

                $stmt_materiais = $pdo->prepare("INSERT INTO solicitacoes_materiais (id_solicitacao, id_material, quantidade_solicitada, usuario_id) VALUES (?, ?, ?, ?)");
                foreach ($materiais_selecionados as $material) {
                    $material_id = $material["id"];
                    $quantidade = $material["quantidade"];
                    if ($quantidade > 0) {
                        $stmt_materiais->execute([$solicitacao_id, $material_id, $quantidade, $solicitante_id]); // Usa o ID do solicitante
                    }
                }
            }

        } elseif ($tipo_solicitacao === 'equipamentos') {
            $data_utilizacao = sanitize($_POST['data_utilizacao'] ?? '');
            $turno = sanitize($_POST['turno'] ?? '');
            $sala = sanitize($_POST['sala'] ?? '');
            $equipamentos_requeridos = $_POST['equipamentos_requeridos'] ?? [];
            
            // Limpa as observações antigas de equipamentos antes de adicionar as novas
            $obs_base = preg_replace('/\[Equipamentos Solicitados:.*?\]/', '', $observacoes);
            $observacoes_finais = trim($obs_base);
            
            if (!empty($equipamentos_requeridos)) {
                $equipamentos_str = ' [Equipamentos Solicitados: ' . implode(', ', $equipamentos_requeridos) . ']';
                $observacoes_finais .= $equipamentos_str;
            }

            $sql = "UPDATE solicitacoes SET 
                        data_utilizacao = :data_inicio, 
                        turno = :turno, 
                        sala = :sala, 
                        observacoes = :obs
                    WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':data_inicio' => $data_utilizacao,
                ':turno' => $turno,
                ':sala' => $sala,
                ':obs' => $observacoes_finais,
                ':id' => $solicitacao_id
            ]);
        }

        $pdo->commit();
        $success = 'Solicitação atualizada com sucesso!';
        // Recarrega a página de edição para ver as mudanças
        header("Location: editar_solicitacao.php?id=" . $solicitacao_id . "&success=1");
        exit;

    } catch (Exception $e) {
        $pdo->rollBack();
        $error = 'Erro ao atualizar: ' . $e->getMessage();
    }
}

// 3. BUSCAR DADOS DA SOLICITAÇÃO (PARA PREENCHER O FORMULÁRIO)
try {
    // --- CORREÇÃO DO NOME DO PROFESSOR (ADICIONADO u.nome) ---
    $stmt = $pdo->prepare("
        SELECT s.*, u.nome AS usuario_nome 
        FROM solicitacoes s
        JOIN usuarios u ON s.usuario_id = u.id
        WHERE s.id = ?
    ");
    $stmt->execute([$solicitacao_id]);
    $solicitacao = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$solicitacao) {
        throw new Exception("Solicitação não encontrada.");
    }

    // Buscar materiais (se for do tipo materiais)
    $materiais_selecionados_js = "[]";
    if ($solicitacao['tipo_solicitacao'] === 'materiais') {
        $stmt_materiais = $pdo->prepare("
            SELECT sm.id_material, sm.quantidade_solicitada, m.nome 
            FROM solicitacoes_materiais sm
            JOIN materiais m ON sm.id_material = m.id
            WHERE sm.id_solicitacao = ?
        ");
        $stmt_materiais->execute([$solicitacao_id]);
        $materiais_db = $stmt_materiais->fetchAll(PDO::FETCH_ASSOC);
        
        $materiais_para_js = [];
        foreach($materiais_db as $mat) {
            $materiais_para_js[] = [
                'id' => (int)$mat['id_material'],
                'quantidade' => (int)$mat['quantidade_solicitada'],
                'nome' => $mat['nome']
            ];
        }
        $materiais_selecionados_js = json_encode($materiais_para_js);
    }
    
    // Buscar equipamentos (se for do tipo equipamentos)
    $equipamentos_selecionados = [];
    if ($solicitacao['tipo_solicitacao'] === 'equipamentos' && $solicitacao['observacoes']) {
        // Extrai os equipamentos da observação
        preg_match('/\[Equipamentos Solicitados: (.*?)\]/', $solicitacao['observacoes'], $matches);
        if (isset($matches[1])) {
            $equipamentos_selecionados = explode(', ', $matches[1]);
        }
    }


} catch (Exception $e) {
    $error = "Erro ao carregar dados: " . $e->getMessage();
    $solicitacao = []; // Limpa solicitação em caso de erro
}

// Mensagem de sucesso (se veio do redirect)
if (isset($_GET['success'])) {
    $success = 'Solicitação atualizada com sucesso!';
}

// --- FIM DA LÓGICA DE EDIÇÃO ---

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Editar Solicitação</title>
    
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/estilos_sistema.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <button class="mobile-menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    <div class="sidebar-overlay" onclick="closeSidebar()"></div>
    <div class="main-layout">
        <div class="sidebar">
            <div class="sidebar-header">
                <h1>SIMEI - IBC</h1>
                <p>Bem-vindo, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>
            <nav class="sidebar-nav">
                <?php if (isAdmin() || isColaborador()): ?>
                    <a href="usuarios.php" class="nav-item">
                        <i class="fas fa-users"></i> Usuários
                    </a>
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="materiais.php" class="nav-item">
                        <i class="fas fa-boxes"></i> Gestão de Materiais
                    </a>
                    <a href="relatorios.php" class="nav-item">
                        <i class="fas fa-chart-bar"></i> Relatórios
                    </a>
                <?php endif; ?>
                <?php if ($_SESSION['user_type'] === 'professor' || isAdmin() || isColaborador()): ?>
                    <a href="solicitar.php" class="nav-item">
                        <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                    </a>
                    <?php
                    // Recalcula o contador de pendentes
                    $stmt_count_pdo = getDBConnection(); // Garante uma nova conexão se a transação falhou
                    $stmt_count = $stmt_count_pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
                    $pendentes_count = $stmt_count->fetchColumn();
                    ?>
                    <a href="pendentes.php" class="nav-item">
                        <span id="contador-pendentes">
                            <i class="fas fa-clock"></i>
                        </span>
                        Solicitações
                    </a>
                <?php endif; ?>
            </nav>
            <div class="sidebar-footer">
                <a href="../logout.php" class="btn btn-secondary btn-full">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>

        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-pencil-alt"></i> Editar Solicitação #<?php echo $solicitacao_id; ?>
                </h1>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($solicitacao)): ?>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-form"></i> Formulário de Edição
                    </h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="editar_solicitacao.php?id=<?php echo $solicitacao_id; ?>" enctype="multipart/form-data">
                        
                        <input type="hidden" name="tipo_solicitacao" value="<?php echo $solicitacao['tipo_solicitacao']; ?>">

                        <div class="form-group">
                            <label class="form-label"><i class="fas fa-list"></i> Tipo de Solicitação</label>
                            <div class="tipo-solicitacao">
                                <label class="tipo-option selected" style="cursor: not-allowed; background: #f9fafb;">
                                    <?php if($solicitacao['tipo_solicitacao'] === 'equipamentos'): ?>
                                        <i class="fas fa-video icon"></i>
                                        <div class="title">Equipamentos</div>
                                    <?php elseif($solicitacao['tipo_solicitacao'] === 'materiais'): ?>
                                        <i class="fas fa-boxes icon"></i>
                                        <div class="title">Apenas Materiais</div>
                                    <?php else: ?>
                                        <i class="fas fa-laptop-code icon"></i>
                                        <div class="title">Solicitação de Software</div>
                                    <?php endif; ?>
                                    <div class="description" style="color: #ef4444;">Não é possível alterar o tipo de uma solicitação.</div>
                                </label>
                            </div>
                        </div>

                        <div id="equipamentos-container" class="box-destaque" style="display: none;">
                            <h3>
                                <i class="fas fa-desktop"></i> Quais equipamentos você precisa?
                            </h3>
                            <div class="flex-wrap-gap">
                                <label class="checkbox-label">
                                    <input type="checkbox" name="equipamentos_requeridos[]" value="Datashow" class="checkbox-scale" <?php echo in_array('Datashow', $equipamentos_selecionados) ? 'checked' : ''; ?>>
                                    Datashow
                                </label>
                                <label class="checkbox-label">
                                    <input type="checkbox" name="equipamentos_requeridos[]" value="Notebook" class="checkbox-scale" <?php echo in_array('Notebook', $equipamentos_selecionados) ? 'checked' : ''; ?>>
                                    Notebook
                                </label>
                                <label class="checkbox-label">
                                    <input type="checkbox" name="equipamentos_requeridos[]" value="Caixa de Som" class="checkbox-scale" <?php echo in_array('Caixa de Som', $equipamentos_selecionados) ? 'checked' : ''; ?>>
                                    Caixa de Som
                                </label>
                                <label class="checkbox-label">
                                    <input type="checkbox" name="equipamentos_requeridos[]" value="Extensão" class="checkbox-scale" <?php echo in_array('Extensão', $equipamentos_selecionados) ? 'checked' : ''; ?>>
                                    Extensão
                                </label>
                                <div class="form-group" style="margin-bottom: 1.5rem;">
                                    <label for="chave_lab" class="form-label">
                                        <i class="fas fa-door-open"></i> Chaves dos Laboratórios
                                    </label>
                                    <select id="chave_lab" name="equipamentos_requeridos[]" class="form-input">
                                        <option value="">Nenhuma chave</option>
                                        <optgroup label="Laboratórios">
                                            <option value="chave_lab1" <?php echo in_array('chave_lab1', $equipamentos_selecionados) ? 'selected' : ''; ?>>Chave Do Laboratório 1</option>
                                            <option value="chave_lab2" <?php echo in_array('chave_lab2', $equipamentos_selecionados) ? 'selected' : ''; ?>>Chave Do Laboratório 2</option>
                                            <option value="chave_lab3" <?php echo in_array('chave_lab3', $equipamentos_selecionados) ? 'selected' : ''; ?>>Chave Do Laboratório 3</option>
                                        </optgroup>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="grid-2-col">
                            <div class="form-group">
                                <label for="professor" class="form-label"><i class="fas fa-user"></i> Professor</label>
                                <input type="text" id="professor" class="form-input input-readonly" value="<?php echo htmlspecialchars($solicitacao['usuario_nome']); ?>" readonly>
                                </div>
                            <div class="form-group" id="data-geral-container">
                                <label for="data_utilizacao" class="form-label"><i class="fas fa-calendar"></i> Data de Utilização *</label>
                                <input type="date" id="data_utilizacao" name="data_utilizacao" class="form-input" value="<?php echo htmlspecialchars($solicitacao['data_utilizacao']); ?>">
                            </div>
                        </div>
                        <div id="turno-container" style="display: none;">
                            <div class="form-group" style="margin-bottom: 1.5rem;">
                                <label for="turno" class="form-label"><i class="fas fa-sun"></i> Turno *</label>
                                <select id="turno" name="turno" class="form-input">
                                    <option value="">Selecione o turno</option>
                                    <option value="matutino" <?php echo ($solicitacao['turno'] === 'matutino') ? 'selected' : ''; ?>>Matutino</option>
                                    <option value="vespertino" <?php echo ($solicitacao['turno'] === 'vespertino') ? 'selected' : ''; ?>>Vespertino</option>
                                    <option value="noturno" <?php echo ($solicitacao['turno'] === 'noturno') ? 'selected' : ''; ?>>Noturno</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group" style="margin-bottom: 1.5rem;" id="sala-geral-container">
                            <label for="sala" class="form-label"><i class="fas fa-door-open"></i> Sala *</label>
                            <select id="sala" name="sala" class="form-input">
                                <option value="">Selecione a sala</option>
                                <optgroup label="Laboratórios">
                                    <option value="Laboratório 1" <?php echo ($solicitacao['sala'] === 'Laboratório 1') ? 'selected' : ''; ?>>Laboratório 1</option>
                                    <option value="Laboratório 2" <?php echo ($solicitacao['sala'] === 'Laboratório 2') ? 'selected' : ''; ?>>Laboratório 2</option>
                                    <option value="Laboratório 3" <?php echo ($solicitacao['sala'] === 'Laboratório 3') ? 'selected' : ''; ?>>Laboratório 3</option>
                                    <option value="Laboratório 4" <?php echo ($solicitacao['sala'] === 'Laboratório 4') ? 'selected' : ''; ?>>Laboratório 4</option>
                                    <option value="Laboratório 5" <?php echo ($solicitacao['sala'] === 'Laboratório 5') ? 'selected' : ''; ?>>Laboratório 5</option>
                                    <option value="Laboratório 6" <?php echo ($solicitacao['sala'] === 'Laboratório 6') ? 'selected' : ''; ?>>Laboratório 6</option>
                                    <option value="Laboratório 7" <?php echo ($solicitacao['sala'] === 'Laboratório 7') ? 'selected' : ''; ?>>Laboratório 7</option>
                                    <option value="Laboratório 8" <?php echo ($solicitacao['sala'] === 'Laboratório 8') ? 'selected' : ''; ?>>Laboratório 8</option>
                                    <option value="Laboratório 9" <?php echo ($solicitacao['sala'] === 'Laboratório 9') ? 'selected' : ''; ?>>Laboratório 9</option>
                                    <option value="Laboratório 10" <?php echo ($solicitacao['sala'] === 'Laboratório 10') ? 'selected' : ''; ?>>Laboratório 10</option>
                                    <option value="Laboratório 11" <?php echo ($solicitacao['sala'] === 'Laboratório 11') ? 'selected' : ''; ?>>Laboratório 11</option>
                                </optgroup>
                                <optgroup label="Salas de Aula">
                                    <option value="Sala 2" <?php echo ($solicitacao['sala'] === 'Sala 2') ? 'selected' : ''; ?>>Sala 2</option>
                                    <option value="Sala 3" <?php echo ($solicitacao['sala'] === 'Sala 3') ? 'selected' : ''; ?>>Sala 3</option>
                                    <option value="Sala 4" <?php echo ($solicitacao['sala'] === 'Sala 4') ? 'selected' : ''; ?>>Sala 4</option>
                                    <option value="Sala 5" <?php echo ($solicitacao['sala'] === 'Sala 5') ? 'selected' : ''; ?>>Sala 5</option>
                                    <option value="Sala 6" <?php echo ($solicitacao['sala'] === 'Sala 6') ? 'selected' : ''; ?>>Sala 6</option>
                                    <option value="Sala 7" <?php echo ($solicitacao['sala'] === 'Sala 7') ? 'selected' : ''; ?>>Sala 7</option>
                                    <option value="Sala 8" <?php echo ($solicitacao['sala'] === 'Sala 8') ? 'selected' : ''; ?>>Sala 8</option>
                                    <option value="Sala 9" <?php echo ($solicitacao['sala'] === 'Sala 9') ? 'selected' : ''; ?>>Sala 9</option>
                                    <option value="Sala 10" <?php echo ($solicitacao['sala'] === 'Sala 10') ? 'selected' : ''; ?>>Sala 10</option>
                                    <option value="Sala 11" <?php echo ($solicitacao['sala'] === 'Sala 11') ? 'selected' : ''; ?>>Sala 11</option>
                                </optgroup>
                                <optgroup label="Laboratórios Especializados">
                                    <option value="Laboratório de Eletrotécnica" <?php echo ($solicitacao['sala'] === 'Laboratório de Eletrotécnica') ? 'selected' : ''; ?>>Laboratório de Eletrotécnica</option>
                                    <option value="Laboratório de Eletricidade" <?php echo ($solicitacao['sala'] === 'Laboratório de Eletricidade') ? 'selected' : ''; ?>>Laboratório de Eletricidade</option>
                                    <option value="Laboratório de ESD" <?php echo ($solicitacao['sala'] === 'Laboratório de ESD') ? 'selected' : ''; ?>>Laboratório de ESD</option>
                                    <option value="Laboratório de Automação" <?php echo ($solicitacao['sala'] === 'Laboratório de Automação') ? 'selected' : ''; ?>>Laboratório de Automação</option>
                                </optgroup>
                                <optgroup label="Outros Espaços">
                                    <option value="Reunião" <?php echo ($solicitacao['sala'] === 'Reunião') ? 'selected' : ''; ?>>Reunião</option>
                                </optgroup>
                            </select>
                        </div>

                        <div id="materiais-container" class="materiais-section" style="display: none;">
                            <h3><i class="fas fa-boxes"></i> Selecionar Materiais</h3>
                            <div class="grid-2-col">
                                <div class="form-group">
                                    <label for="data_utilizacao_materiais" class="form-label"><i class="fas fa-calendar-check"></i> Data de utilização (início): *</label>
                                    <input type="date" name="data_utilizacao_materiais" id="data_utilizacao_materiais" class="form-input" value="<?php echo htmlspecialchars($solicitacao['data_utilizacao']); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="data_termino_uso_materiais" class="form-label"><i class="fas fa-calendar-times"></i> Data de término de uso: *</label>
                                    <input type="date" name="data_termino_uso_materiais" id="data_termino_uso_materiais" class="form-input" value="<?php echo htmlspecialchars($solicitacao['data_termino_uso']); ?>">
                                </div>
                            </div>
                            <div id="outros-materiais-container" style="display: none;">
                                <h4 style="margin-bottom: 0.75rem; color: #374151; font-size: 1rem;"><i class="fas fa-search"></i> Outros Materiais</h4>
                                <div class="form-group" style="margin-bottom: 1rem;">
                                    <input type="text" id="busca-materiais" class="form-input w-100" placeholder="Digite para buscar materiais...">
                                </div>
                                <div id="materiais-grid" class="materiais-grid-scrollable"></div>
                            </div>
                        </div>

                        <div id="software-container" class="box-destaque" style="display: none;">
                            <h3><i class="fas fa-laptop-code"></i> Detalhes da Solicitação de Software</h3>
                            <div class="form-group" style="margin-bottom: 1.5rem;">
                                <label for="softwares_solicitados" class="form-label"><i class="fas fa-list-ul"></i> Liste os softwares que deseja instalar: *</label>
                                <textarea name="softwares_solicitados" id="softwares_solicitados" class="form-input" rows="4" placeholder="Ex: Adobe Photoshop, AutoCAD 2024, etc."><?php echo htmlspecialchars($solicitacao['softwares_solicitados']); ?></textarea>
                            </div>
                            <div class="form-group" style="margin-bottom: 1.5rem;">
                                <label for="sala_software" class="form-label"><i class="fas fa-door-open"></i> Escolha a sala para instalação: *</label>
                                <select id="sala_software" name="sala_software" class="form-input">
                                    <option value="">-- Selecione a sala --</option>
                                    <optgroup label="Laboratórios">
                                        <option value="Laboratório 1" <?php echo ($solicitacao['sala'] === 'Laboratório 1') ? 'selected' : ''; ?>>Laboratório 1</option>
                                        <option value="Laboratório 2" <?php echo ($solicitacao['sala'] === 'Laboratório 2') ? 'selected' : ''; ?>>Laboratório 2</option>
                                        <option value="Laboratório 3" <?php echo ($solicitacao['sala'] === 'Laboratório 3') ? 'selected' : ''; ?>>Laboratório 3</option>
                                        <option value="Laboratório 4" <?php echo ($solicitacao['sala'] === 'Laboratório 4') ? 'selected' : ''; ?>>Laboratório 4</option>
                                        <option value="Laboratório 5" <?php echo ($solicitacao['sala'] === 'Laboratório 5') ? 'selected' : ''; ?>>Laboratório 5</option>
                                        <option value="Laboratório 6" <?php echo ($solicitacao['sala'] === 'Laboratório 6') ? 'selected' : ''; ?>>Laboratório 6</option>
                                        <option value="Laboratório 7" <?php echo ($solicitacao['sala'] === 'Laboratório 7') ? 'selected' : ''; ?>>Laboratório 7</option>
                                        <option value="Laboratório 8" <?php echo ($solicitacao['sala'] === 'Laboratório 8') ? 'selected' : ''; ?>>Laboratório 8</option>
                                        <option value="Laboratório 9" <?php echo ($solicitacao['sala'] === 'Laboratório 9') ? 'selected' : ''; ?>>Laboratório 9</option>
                                        <option value="Laboratório 10" <?php echo ($solicitacao['sala'] === 'Laboratório 10') ? 'selected' : ''; ?>>Laboratório 10</option>
                                        <option value="Laboratório 11" <?php echo ($solicitacao['sala'] === 'Laboratório 11') ? 'selected' : ''; ?>>Laboratório 11</option>
                                    </optgroup>
                                    <optgroup label="Salas de Aula">
                                        <option value="Sala 2" <?php echo ($solicitacao['sala'] === 'Sala 2') ? 'selected' : ''; ?>>Sala 2</option>
                                        <option value="Sala 3" <?php echo ($solicitacao['sala'] === 'Sala 3') ? 'selected' : ''; ?>>Sala 3</option>
                                        <option value="Sala 4" <?php echo ($solicitacao['sala'] === 'Sala 4') ? 'selected' : ''; ?>>Sala 4</option>
                                        <option value="Sala 5" <?php echo ($solicitacao['sala'] === 'Sala 5') ? 'selected' : ''; ?>>Sala 5</option>
                                        <option value="Sala 6" <?php echo ($solicitacao['sala'] === 'Sala 6') ? 'selected' : ''; ?>>Sala 6</option>
                                        <option value="Sala 7" <?php echo ($solicitacao['sala'] === 'Sala 7') ? 'selected' : ''; ?>>Sala 7</option>
                                        <option value="Sala 8" <?php echo ($solicitacao['sala'] === 'Sala 8') ? 'selected' : ''; ?>>Sala 8</option>
                                        <option value="Sala 9" <?php echo ($solicitacao['sala'] === 'Sala 9') ? 'selected' : ''; ?>>Sala 9</option>
                                        <option value="Sala 10" <?php echo ($solicitacao['sala'] === 'Sala 10') ? 'selected' : ''; ?>>Sala 10</option>
                                        <option value="Sala 11" <?php echo ($solicitacao['sala'] === 'Sala 11') ? 'selected' : ''; ?>>Sala 11</option>
                                    </optgroup>
                                    <optgroup label="Laboratórios Especializados">
                                        <option value="Laboratório de Eletrotécnica" <?php echo ($solicitacao['sala'] === 'Laboratório de Eletrotécnica') ? 'selected' : ''; ?>>Laboratório de Eletrotécnica</option>
                                        <option value="Laboratório de Eletricidade" <?php echo ($solicitacao['sala'] === 'Laboratório de Eletricidade') ? 'selected' : ''; ?>>Laboratório de Eletricidade</option>
                                        <option value="Laboratório de ESD" <?php echo ($solicitacao['sala'] === 'Laboratório de ESD') ? 'selected' : ''; ?>>Laboratório de ESD</option>
                                        <option value="Laboratório de Automação" <?php echo ($solicitacao['sala'] === 'Laboratório de Automação') ? 'selected' : ''; ?>>Laboratório de Automação</option>
                                    </optgroup>
                                    <optgroup label="Outros Espaços">
                                        <option value="Reunião" <?php echo ($solicitacao['sala'] === 'Reunião') ? 'selected' : ''; ?>>Reunião</option>
                                    </optgroup>
                                </select>
                            </div>
                            <div class="grid-2-col">
                                <div class="form-group">
                                    <label for="data_utilizacao_software" class="form-label"><i class="fas fa-calendar-check"></i> Data de utilização (início): *</label>
                                    <input type="date" name="data_utilizacao_software" id="data_utilizacao_software" class="form-input" value="<?php echo htmlspecialchars($solicitacao['data_utilizacao']); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="data_termino_uso" class="form-label"><i class="fas fa-calendar-times"></i> Data de término de uso: *</label>
                                    <input type="date" name="data_termino_uso" id="data_termino_uso" class="form-input" value="<?php echo htmlspecialchars($solicitacao['data_termino_uso']); ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="anexo_software" class="form-label"><i class="fas fa-file-upload"></i> Anexar guia de instalação (opcional):</label>
                                <?php if ($solicitacao['anexo_path']): ?>
                                    <div style="margin-bottom: 0.5rem; font-size: 0.875rem;">
                                        Anexo atual: <a href="../<?php echo htmlspecialchars($solicitacao['anexo_path']); ?>" target="_blank"><?php echo basename($solicitacao['anexo_path']); ?></a>
                                        <input type="hidden" name="anexo_existente" value="<?php echo htmlspecialchars($solicitacao['anexo_path']); ?>">
                                    </div>
                                <?php endif; ?>
                                <input type="file" name="anexo" id="anexo_software" class="form-input" accept=".doc,.docx,.pdf,.xls,.xlsx,.ppt,.pptx">
                                <small class="text-info-sm">
                                    Envie um novo arquivo apenas se quiser substituir o anexo atual.
                                </small>
                            </div>
                        </div>
                        
                        <input type="hidden" name="selected_materials_json" id="selected-materials-json">

                        <div class="form-group">
                            <label for="observacoes" class="form-label"><i class="fas fa-comment"></i> Observações Gerais</label>
                            <textarea id="observacoes" name="observacoes" class="form-input" rows="4" placeholder="Informações adicionais..."><?php echo htmlspecialchars(trim(preg_replace('/\[Equipamentos Solicitados:.*?\]/', '', $solicitacao['observacoes']))); ?></textarea>
                        </div>
                        
                        <div class="flex-end">
                            <a href="pendentes.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancelar
                            </a>
                            <button type="submit" class="btn btn-primary" id="submit-button">
                                <i class="fas fa-save"></i> Salvar Alterações
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <?php else: ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> Não foi possível carregar os dados da solicitação.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        const TIPO_SOLICITACAO = "<?php echo $solicitacao['tipo_solicitacao'] ?? ''; ?>";
        const MATERIAIS_PRE_SELECIONADOS = <?php echo $materiais_selecionados_js; ?>;
    
        document.addEventListener('DOMContentLoaded', function() {
            function toggleSidebar() {
                const sidebar = document.querySelector(".sidebar");
                const overlay = document.querySelector(".sidebar-overlay");
                if (sidebar) sidebar.classList.toggle("open");
                if (overlay) overlay.classList.toggle("active");
            }
            function closeSidebar() {
                const sidebar = document.querySelector(".sidebar");
                const overlay = document.querySelector(".sidebar-overlay");
                if (sidebar) sidebar.classList.remove("open");
                if (overlay) overlay.classList.remove("active");
            }
            const mobileMenuToggle = document.querySelector(".mobile-menu-toggle");
            if (mobileMenuToggle) mobileMenuToggle.onclick = toggleSidebar;
            const sidebarOverlay = document.querySelector(".sidebar-overlay");
            if (sidebarOverlay) sidebarOverlay.onclick = closeSidebar;

            const turnoContainer = document.getElementById('turno-container');
            const equipamentosContainer = document.getElementById('equipamentos-container');
            const materiaisContainer = document.getElementById('materiais-container');
            const outrosMateriaisContainer = document.getElementById('outros-materiais-container');
            const softwareContainer = document.getElementById('software-container');
            const dataGeralContainer = document.getElementById('data-geral-container');
            const salaGeralContainer = document.getElementById('sala-geral-container');
            
            const salaGeralInput = document.getElementById('sala');
            const chaveLabInput = document.getElementById('chave_lab');
            
            function inicializarFormularioDeEdicao() {
                if (turnoContainer) turnoContainer.style.display = 'none';
                if (equipamentosContainer) equipamentosContainer.style.display = 'none';
                if (materiaisContainer) materiaisContainer.style.display = 'none';
                if (softwareContainer) softwareContainer.style.display = 'none';
                if (outrosMateriaisContainer) outrosMateriaisContainer.style.display = 'none';
                if (dataGeralContainer) dataGeralContainer.style.display = 'none';
                if (salaGeralContainer) salaGeralContainer.style.display = 'none';

                if (TIPO_SOLICITACAO === 'equipamentos') {
                    if (turnoContainer) turnoContainer.style.display = 'block';
                    if (equipamentosContainer) equipamentosContainer.style.display = 'block';
                    if (dataGeralContainer) dataGeralContainer.style.display = 'block';
                    if (salaGeralContainer) salaGeralContainer.style.display = 'block';
                } else if (TIPO_SOLICITACAO === 'materiais') {
                    if (turnoContainer) turnoContainer.style.display = 'block';
                    if (materiaisContainer) materiaisContainer.style.display = 'block';
                    if (outrosMateriaisContainer) outrosMateriaisContainer.style.display = 'block';
                    if (salaGeralContainer) salaGeralContainer.style.display = 'block';
                    
                    MATERIAIS_PRE_SELECIONADOS.forEach(mat => {
                        materiaisSelecionados.set(mat.id, {
                            nome: mat.nome,
                            quantidade: mat.quantidade
                        });
                    });
                    atualizarResumoMateriais();
                    
                } else if (TIPO_SOLICITACAO === 'software') {
                    if (softwareContainer) softwareContainer.style.display = 'block';
                }
            }

            if (chaveLabInput && salaGeralInput) {
                chaveLabInput.addEventListener('change', function() {
                    const chaveSelecionada = this.value;
                    switch (chaveSelecionada) {
                        case 'chave_lab1': salaGeralInput.value = 'Laboratório 1'; break;
                        case 'chave_lab2': salaGeralInput.value = 'Laboratório 2'; break;
                        case 'chave_lab3': salaGeralInput.value = 'Laboratório 3'; break;
                    }
                });
            }
            
            const buscaMateriais = document.getElementById('busca-materiais');
            const materiaisGrid = document.getElementById('materiais-grid');
            let timeoutId;
            if (buscaMateriais) {
                buscaMateriais.addEventListener('input', function() {
                    clearTimeout(timeoutId);
                    const termo = this.value.trim();
                    if (termo.length < 2) {
                        if (materiaisGrid) {
                            materiaisGrid.style.display = 'none';
                            materiaisGrid.innerHTML = '';
                        }
                        return;
                    }
                    timeoutId = setTimeout(() => buscarMateriais(termo), 300);
                });
            }

            const mainForm = document.querySelector('.card-body form');
            const btnSubmit = document.getElementById('submit-button');
            if (mainForm) {
                mainForm.addEventListener('submit', function(e) {
                    if (btnSubmit) {
                        btnSubmit.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Salvando...';
                        btnSubmit.disabled = true;
                    }
                    const selectedMaterialsArray = [];
                    materiaisSelecionados.forEach((materialData, id) => {
                        selectedMaterialsArray.push({
                            id: id,
                            quantidade: materialData.quantidade
                        });
                    });
                    document.getElementById('selected-materials-json').value = JSON.stringify(selectedMaterialsArray);
                });
            }
            inicializarFormularioDeEdicao();
        });

        let materiaisSelecionados = new Map();

        function buscarMateriais(termo) {
            const materiaisGrid = document.getElementById('materiais-grid');
            if (!materiaisGrid) return;

            fetch(`buscar_materiais.php?termo=${encodeURIComponent(termo)}`)
                .then(response => response.json())
                .then(data => {
                    materiaisGrid.innerHTML = '';
                    if (data.length === 0) {
                        materiaisGrid.innerHTML = '<p style="text-align:center;color:#6b7280;padding:1rem;">Nenhum material encontrado.</p>';
                    } else {
                        data.forEach(material => {
                            const materialDiv = document.createElement('div');
                            materialDiv.className = 'material-item-search';
                            const jaEstavaSelecionado = materiaisSelecionados.has(material.id);
                            const quantidadeSalva = materiaisSelecionados.get(material.id)?.quantidade || 1;
                            const nomeSeguro = material.nome.replace(/'/g, "\\'");
                            
                            materialDiv.innerHTML = `
                        <div class="material-left">
                            <input type="checkbox" id="material_${material.id}" name="materiais[]" value="${material.id}"
                                class="checkbox-scale-sm"
                                onchange="toggleQuantityInput(this, ${material.id}, '${nomeSeguro}')"
                                ${jaEstavaSelecionado ? 'checked' : ''}>
                            <div class="material-info">
                                <div class="material-name">${material.nome}</div>
                                <div class="material-qty">Disponível: ${material.quantidade}</div>
                            </div>
                        </div>
                        <div class="material-right">
                            <label for="qty_material_${material.id}" style="font-size:0.875rem;color:#6b7280;">Qtd:</label>
                            <input type="number" id="qty_material_${material.id}" name="qty_materiais[${material.id}]"
                                min="1" max="${material.quantidade_maxima}" value="${quantidadeSalva}"
                                class="input-qtd-sm"
                                ${jaEstavaSelecionado ? '' : 'disabled'}>
                        </div>
                    `;
                            materiaisGrid.appendChild(materialDiv);
                        });
                    }
                    materiaisGrid.style.display = 'block';
                    atualizarResumoMateriais();
                })
                .catch(error => console.error('Erro ao buscar materiais:', error));
        }

        function toggleQuantityInput(checkbox, materialId, materialName) {
            const quantityInput = document.getElementById(`qty_material_${materialId}`);
            if (!quantityInput) return;
            quantityInput.disabled = !checkbox.checked;

            if (checkbox.checked) {
                const quantidade = parseInt(quantityInput.value) || 1;
                const nomeParaSalvar = materialName || materiaisSelecionados.get(materialId)?.nome || `Material ${materialId}`;
                materiaisSelecionados.set(materialId, {
                    nome: nomeParaSalvar,
                    quantidade: quantidade
                });
                quantityInput.onchange = function() {
                    if (checkbox.checked) {
                        const materialData = materiaisSelecionados.get(materialId);
                        if (materialData) { 
                            materialData.quantidade = parseInt(this.value) || 1;
                        }
                        atualizarResumoMateriais();
                    }
                };
            } else {
                materiaisSelecionados.delete(materialId);
                quantityInput.value = 1;
                quantityInput.onchange = null;
            }
            atualizarResumoMateriais();
        }

        function atualizarResumoMateriais() {
            let resumoContainer = document.getElementById('resumo-materiais');
            if (!resumoContainer) {
                resumoContainer = document.createElement('div');
                resumoContainer.id = 'resumo-materiais';
                resumoContainer.className = 'resumo-box';
                const materiaisContainer = document.getElementById('outros-materiais-container');
                if (materiaisContainer) materiaisContainer.appendChild(resumoContainer);
            }
            if (materiaisSelecionados.size === 0) {
                resumoContainer.style.display = 'none';
                resumoContainer.innerHTML = '';
                return;
            }
            let html = '<h4 class="resumo-titulo"><i class="fas fa-check-circle"></i> Materiais Selecionados:</h4>';
            html += '<div class="resumo-lista">';
            materiaisSelecionados.forEach((materialData, materialId) => {
                let nomeMateria = materialData.nome;
                const quantidade = materialData.quantidade;
                if (!nomeMateria) {
                    const checkbox = document.getElementById(`material_${materialId}`);
                    const materialInfo = checkbox?.closest('.material-item-search')?.querySelector('.material-name');
                    nomeMateria = materialInfo ? materialInfo.textContent : `Material ${materialId}`;
                    if (materialData) materialData.nome = nomeMateria;
                }
                html += `
            <span class="badge-material">
                ${nomeMateria} (${quantidade}x)
                <button type="button" onclick="removerMaterial(${materialId})" class="btn-remove-badge">×</button>
            </span>`;
            });
            html += '</div>';
            resumoContainer.innerHTML = html;
            resumoContainer.style.display = 'block';
        }

        function removerMaterial(materialId) {
            materiaisSelecionados.delete(materialId);
            const checkbox = document.getElementById(`material_${materialId}`);
            if (checkbox) {
                checkbox.checked = false;
                const quantityInput = document.getElementById(`qty_material_${materialId}`);
                if (quantityInput) quantityInput.disabled = true;
                quantityInput.value = 1;
            }
            atualizarResumoMateriais();
        }

        function atualizarContador() {
            const contadorElement = document.getElementById('contador-pendentes');
            if (contadorElement) {
                fetch('contador_pendentes.php')
                    .then(response => response.ok ? response.text() : '')
                    .then(data => {
                        contadorElement.innerHTML = data;
                    })
                    .catch(error => console.error("Erro ao atualizar contador:", error));
            }
        }
        atualizarContador();
        setInterval(atualizarContador, 5000);
    </script>
</body>
</html>