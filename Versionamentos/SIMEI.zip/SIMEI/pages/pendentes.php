<?php
require_once '../includes/config.php';

// Verificar se está logado
if (!isLoggedIn()) {
    redirect('../index.php');
}

$error = '';
$success = '';

// Processar ações (aprovar, retirar, devolver)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($_POST['action'] ?? '');
    $solicitacao_id = (int)($_POST['solicitacao_id'] ?? 0);

    if ($action && $solicitacao_id) {
        try {
            $pdo = getDBConnection();

            switch ($action) {
                case 'aprovar':
                    if (isAdmin()) {
                        try {
                            error_log("Tentativa de aprovar solicitação #{$solicitacao_id} pelo usuário ID: {$_SESSION['user_id']}");
                            $stmt = $pdo->prepare("UPDATE solicitacoes SET status = 'aprovada', aprovada_por = ? WHERE id = ? AND status = 'pendente'");
                            $stmt->execute([$_SESSION['user_id'], $solicitacao_id]);
                            $success = 'Solicitação aprovada com sucesso!';
                        } catch (PDOException $e) {
                            $error = "Erro no banco de dados: " . $e->getMessage();
                        }
                    }
                    break;

                case 'retirar':
                    if (isAdmin()) {
                        $pdo->beginTransaction();
                        try {
                            $stmt_materiais = $pdo->prepare("SELECT id_material, quantidade_solicitada FROM solicitacoes_materiais WHERE id_solicitacao = ?");
                            $stmt_materiais->execute([$solicitacao_id]);
                            $materiais = $stmt_materiais->fetchAll(PDO::FETCH_ASSOC);

                            if (!empty($materiais)) {
                                $stmt_update_estoque = $pdo->prepare("UPDATE materiais SET quantidade = quantidade - ? WHERE id = ?");
                                foreach ($materiais as $material) {
                                    $stmt_update_estoque->execute([$material['quantidade_solicitada'], $material['id_material']]);
                                }
                            }
                            $stmt = $pdo->prepare("UPDATE solicitacoes SET status = 'retirada', data_retirada = NOW() WHERE id = ? AND status = 'aprovada'");
                            $stmt->execute([$solicitacao_id]);
                            $pdo->commit();
                            $success = 'Solicitação marcada como retirada e estoque atualizado!';
                        } catch (PDOException $e) {
                            $pdo->rollBack();
                            $error = 'Erro ao processar a retirada.';
                        }
                    }
                    break;

                case 'devolver_materiais':
                    if (isAdmin()) {
                        $pdo->beginTransaction();
                        try {
                            $materiais_devolvidos = $_POST['materiais_devolvidos'] ?? [];
                            $materiais_danificados = $_POST['materiais_danificados'] ?? [];
                            $observacoes_devolucao = sanitize($_POST['observacoes_devolucao'] ?? '');
                            $observacoes_danificados = [];

                            foreach ($materiais_devolvidos as $material_id => $quantidade_devolvida) {
                                $quantidade_devolvida = (int)$quantidade_devolvida;
                                $quantidade_danificada = (int)($materiais_danificados[$material_id] ?? 0);

                                if ($quantidade_devolvida > 0) {
                                    $quantidade_para_estoque = $quantidade_devolvida - $quantidade_danificada;
                                    if ($quantidade_para_estoque > 0) {
                                        $stmt = $pdo->prepare("UPDATE materiais SET quantidade = quantidade + ? WHERE id = ?");
                                        $stmt->execute([$quantidade_para_estoque, $material_id]);
                                    }
                                    if ($quantidade_danificada > 0) {
                                        $stmt_material_nome = $pdo->prepare("SELECT nome FROM materiais WHERE id = ?");
                                        $stmt_material_nome->execute([$material_id]);
                                        $material_nome = $stmt_material_nome->fetchColumn();
                                        $observacoes_danificados[] = "{$material_nome}: {$quantidade_danificada} unidade(s) danificada(s) - removida(s) do estoque";
                                    }
                                }
                            }

                            $observacoes_completas = [];
                            if ($observacoes_devolucao) { $observacoes_completas[] = "Devolução: " . $observacoes_devolucao; }
                            if (!empty($observacoes_danificados)) { $observacoes_completas[] = "Itens danificados: " . implode('; ', $observacoes_danificados); }
                            $observacoes_final = !empty($observacoes_completas) ? implode('\n\n', $observacoes_completas) : null;

                            $stmt = $pdo->prepare("UPDATE solicitacoes SET status = 'devolvida', data_devolucao = NOW(), observacoes = CASE WHEN observacoes IS NULL OR observacoes = '' THEN ? ELSE CONCAT(observacoes, '\n\n', ?) END WHERE id = ?");
                            $stmt->execute([$observacoes_final, $observacoes_final, $solicitacao_id]);

                            $pdo->commit();
                            $success = 'Devolução processada com sucesso!';
                            header("Location: pendentes.php?success=" . urlencode($success));
                            exit;
                        } catch (PDOException $e) {
                            $pdo->rollBack();
                            $error = 'Erro ao processar devolução.';
                            header("Location: pendentes.php?error=" . urlencode($error));
                            exit;
                        }
                    }
                    break;

                case 'cancelar':
                    $pdo->beginTransaction();
                    try {
                        $stmt_materiais = $pdo->prepare("SELECT id_material, quantidade_solicitada FROM solicitacoes_materiais WHERE id_solicitacao = ?");
                        $stmt_materiais->execute([$solicitacao_id]);
                        $materiais = $stmt_materiais->fetchAll(PDO::FETCH_ASSOC);

                        if (!empty($materiais)) {
                            $stmt_update_estoque = $pdo->prepare("UPDATE materiais SET quantidade = quantidade + ? WHERE id = ?");
                            foreach ($materiais as $material) {
                                $stmt_update_estoque->execute([$material['quantidade_solicitada'], $material['id_material']]);
                            }
                        }
                        $stmt = $pdo->prepare("UPDATE solicitacoes SET status = 'cancelada' WHERE id = ? AND status = 'pendente'");
                        $stmt->execute([$solicitacao_id]);
                        $pdo->commit();
                        $success = 'Solicitação cancelada com sucesso!';
                    } catch (PDOException $e) {
                        $pdo->rollBack();
                        $error = 'Erro ao cancelar a solicitação.';
                    }
                    break;

                case 'excluir':
                    if (isAdmin()) {
                        $stmt = $pdo->prepare("SELECT status, materiais_solicitados FROM solicitacoes WHERE id = ? AND status = 'pendente'");
                        $stmt->execute([$solicitacao_id]);
                        $solicitacao = $stmt->fetch();

                        if ($solicitacao) {
                            if ($solicitacao['materiais_solicitados']) {
                                $materiais = json_decode($solicitacao['materiais_solicitados'], true);
                                if ($materiais) {
                                    foreach ($materiais as $material_id => $quantidade) {
                                        if (is_numeric($material_id)) {
                                            $stmt = $pdo->prepare("UPDATE materiais SET quantidade = quantidade + ? WHERE id = ?");
                                            $stmt->execute([$quantidade, $material_id]);
                                        } else {
                                            $materiais_extras_map = ['caixa_som' => 'Caixa de Som', 'extensao' => 'Extensão', 'microfone' => 'Microfone'];
                                            if (isset($materiais_extras_map[$material_id])) {
                                                $stmt = $pdo->prepare("UPDATE materiais SET quantidade = quantidade + ? WHERE nome = ?");
                                                $stmt->execute([$quantidade, $materiais_extras_map[$material_id]]);
                                            }
                                        }
                                    }
                                }
                            }
                            $stmt = $pdo->prepare("DELETE FROM solicitacoes WHERE id = ?");
                            $stmt->execute([$solicitacao_id]);
                            $success = 'Solicitação excluída com sucesso!';
                            header("Location: pendentes.php?success=" . urlencode($success));
                            exit;
                        } else {
                            $error = 'Apenas solicitações pendentes podem ser excluídas.';
                        }
                    }
                    break;
            }
        } catch (PDOException $e) {
            $error = 'Erro interno do sistema.';
        }
    }
}

// Filtros e Busca
$filtro_status = sanitize($_GET['status'] ?? '');
$filtro_data = sanitize($_GET['data'] ?? '');
$filtro_tipo = sanitize($_GET['tipo'] ?? '');

try {
    $pdo = getDBConnection();
    $where_conditions = [];
    $params = [];

    if (!isAdmin()) {
        $where_conditions[] = "s.usuario_id = ?";
        $params[] = $_SESSION['user_id'];
    }
    if ($filtro_status) {
        $where_conditions[] = "s.status = ?";
        $params[] = $filtro_status;
    } else {
        $where_conditions[] = "s.status != 'cancelada'";
    }
    if ($filtro_data) {
        $where_conditions[] = "s.data_utilizacao = ?";
        $params[] = $filtro_data;
    }
    if ($filtro_tipo) {
        $where_conditions[] = "s.tipo_solicitacao = ?";
        $params[] = $filtro_tipo;
    }

    $where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
    $stmt = $pdo->prepare("SELECT s.*, u.nome as usuario_nome FROM solicitacoes s JOIN usuarios u ON s.usuario_id = u.id $where_clause ORDER BY s.data_solicitacao DESC");
    $stmt->execute($params);
    $solicitacoes = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Erro ao carregar solicitações.";
    $solicitacoes = [];
}

function obterNomesMateriais($pdo, $materiais_json) {
    global $pdo;
    if (!$materiais_json) return [];
    $materiais_solicitados = json_decode($materiais_json, true);
    if (empty($materiais_solicitados)) return [];
    $ids = array_keys($materiais_solicitados);
    if (empty($ids)) return [];
    $placeholders = implode(",", array_fill(0, count($ids), "?"));
    $stmt = $pdo->prepare("SELECT id, nome FROM materiais WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $materiais_db = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    $materiais_info = [];
    foreach ($materiais_solicitados as $id => $quantidade) {
        if (isset($materiais_db[$id])) {
            $materiais_info[] = ['nome' => $materiais_db[$id], 'quantidade' => $quantidade];
        }
    }
    return $materiais_info;
}

if (isset($_GET['ajax'])) {
    include 'partials/solicitacoes_table.php'; 
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Solicitações</title>
    
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/estilos_sistema.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body class="bg-fix">
    <button class="mobile-menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <div class="sidebar-overlay" onclick="closeSidebar()"></div>

    <div class="main-layout">
        <div class="sidebar">
            <div class="sidebar-header">
                <h1>SIMEI - IBC</h1>
                <p>Bem-vindo, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>

            <nav class="sidebar-nav">
                <?php if (isAdmin() || isColaborador()): ?>
                    <a href="usuarios.php" class="nav-item">
                        <i class="fas fa-users"></i> Usuários
                    </a>
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="materiais.php" class="nav-item">
                        <i class="fas fa-boxes"></i> Gestão de Materiais
                    </a>
                    <a href="relatorios.php" class="nav-item">
                        <i class="fas fa-chart-bar"></i> Relatórios
                    </a>
                <?php endif; ?>
                <?php if ($_SESSION['user_type'] === 'professor' || isAdmin() || isColaborador()): ?>
                    <a href="solicitar.php" class="nav-item">
                        <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                    </a>
                    <?php
                    $stmt = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
                    $pendentes_count = $stmt->fetchColumn();
                    ?>
                    <a href="pendentes.php" class="nav-item">
                        <span id="contador-pendentes">
                            <i class="fas fa-clock"></i>
                        </span>
                        Solicitações
                    </a>
                <?php endif; ?>
            </nav>

            <div class="sidebar-footer">
                <a href="../logout.php" class="btn btn-secondary btn-full">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>

        <div class="main-content bg-white">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-list"></i> Solicitações <?php echo isAdmin() ? '' : 'Minhas'; ?>
                </h1>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-filter"></i> Filtros
                    </h2>
                </div>
                <div class="card-body">
                    <form method="GET" action="" style="display: flex; gap: 1rem; align-items: flex-end; flex-wrap: wrap;">
                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="status" class="form-label">Status</label>
                            <select id="status" name="status" class="form-input">
                                <option value="">Todos (Exceto Canceladas)</option>
                                <option value="pendente" <?php echo $filtro_status === 'pendente' ? 'selected' : ''; ?>>Pendente</option>
                                <option value="aprovada" <?php echo $filtro_status === 'aprovada' ? 'selected' : ''; ?>>Aprovada</option>
                                <option value="retirada" <?php echo $filtro_status === 'retirada' ? 'selected' : ''; ?>>Retirada</option>
                                <option value="devolvida" <?php echo $filtro_status === 'devolvida' ? 'selected' : ''; ?>>Devolvida</option>
                                <option value="cancelada" <?php echo $filtro_status === 'cancelada' ? 'selected' : ''; ?>>Cancelada</option>
                            </select>
                        </div>
                        
                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="tipo" class="form-label">Tipo</label>
                            <select id="tipo" name="tipo" class="form-input">
                                <option value="">Todos</option>
                                <option value="equipamentos" <?php echo $filtro_tipo === 'equipamentos' ? 'selected' : ''; ?>>Equipamentos</option>
                                <option value="materiais" <?php echo $filtro_tipo === 'materiais' ? 'selected' : ''; ?>>Materiais</option>
                                <option value="software" <?php echo $filtro_tipo === 'software' ? 'selected' : ''; ?>>Software</option>
                                </select>
                        </div>

                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="data" class="form-label">Data</label>
                            <input type="date" id="data" name="data" class="form-input" value="<?php echo htmlspecialchars($filtro_data); ?>" style="width: 150px;">
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Filtrar
                        </button>

                        <a href="pendentes.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Limpar
                        </a>
                    </form>
                </div>
            </div>

            <div class="table-container" id="lista-solicitacoes">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Professor</th>
                            <th>Tipo</th>
                            <th>Data</th>
                            <th>Turno</th>
                            <th>Sala</th>
                            <th>Materiais/Softwares</th>
                            <th>Status</th>
                            <th>Observações</th>
                            <?php if (isAdmin()): ?>
                                <th>Ações</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody id="tabela-corpo">
                        <?php include 'partials/solicitacoes_table.php'; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="detalhesModal" class="modal">
        <div class="modal-content-large">
            <button class="close" onclick="fecharDetalhes()">&times;</button>
            <div class="modal-header">
                <h2 id="detalhesTitle" class="modal-title">Detalhes da Solicitação</h2>
            </div>
            <div id="detalhes-modal-body" class="modal-body">
                </div>
        </div>
    </div>

    <div id="devolucaoModal" class="modal">
        <div class="modal-content-large">
            <button class="close" onclick="fecharModalDevolucao()">&times;</button>
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-undo"></i> Confirmar Devolução de Materiais
                </h2>
            </div>
            <div class="modal-body">
                <form id="formDevolucao" method="POST">
                    <input type="hidden" name="action" value="devolver_materiais">
                    <input type="hidden" name="solicitacao_id" id="devolucao_solicitacao_id">

                    <div id="materiaisParaDevolucao">
                        </div>

                    <div class="form-group" style="margin-top: 1.5rem;">
                        <label for="observacoes_devolucao" class="form-label">
                            <i class="fas fa-comment"></i> Observações (opcional)
                        </label>
                        <textarea
                            id="observacoes_devolucao"
                            name="observacoes_devolucao"
                            class="form-input"
                            rows="3"
                            placeholder="Informe se houve alguma avaria, material danificado ou outras observações..."></textarea>
                    </div>

                    <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 2rem;">
                        <button type="button" class="btn btn-secondary" onclick="fecharModalDevolucao()">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-check"></i> Confirmar Devolução
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");

            sidebar.classList.toggle("open");
            overlay.classList.toggle("active");

            if (sidebar.classList.contains("open")) {
                toggleButton.style.opacity = "0";
                toggleButton.style.pointerEvents = "none";
                mainContent.classList.add("menu-open");
            } else {
                toggleButton.style.opacity = "1";
                toggleButton.style.pointerEvents = "auto";
                mainContent.classList.remove("menu-open");
            }
        }

        function closeSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");

            sidebar.classList.remove("open");
            overlay.classList.remove("active");
            toggleButton.style.opacity = "1";
            toggleButton.style.pointerEvents = "auto";
            mainContent.classList.remove("menu-open");
        }

        function atualizarContador() {
            fetch('contador_pendentes.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('contador-pendentes').innerHTML = data;
                })
                .catch(error => console.error("Erro ao atualizar contador:", error));
        }

        atualizarContador();

        function abrirDetalhes(solicitacaoId) {
            fetch(`detalhes_solicitacao.php?id=${solicitacaoId}`)
                .then(response => {
                    if (!response.ok) throw new Error('Erro de rede ou servidor.');
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        const solicitacao = data.solicitacao;
                        const modal = document.getElementById('detalhesModal');
                        const dataInicio = new Date(solicitacao.data_utilizacao + 'T00:00:00-04:00').toLocaleDateString('pt-BR');

                        let html = `
                            <h3>Detalhes da Solicitação #${solicitacao.id}</h3>
                            <div class="detail-section">
                                <h4><i class="fas fa-user-circle"></i> Solicitante</h4>
                                <p>${solicitacao.usuario_nome}</p>
                            </div>
                        `;

                        if (solicitacao.tipo_solicitacao === 'software') {
                            const dataFim = new Date(solicitacao.data_termino_uso + 'T00:00:00-04:00').toLocaleDateString('pt-BR');
                            html += `
                                <div class="detail-section">
                                    <h4><i class="fas fa-laptop-code"></i> Detalhes do Software</h4>
                                    <div class="detail-row">
                                        <span class="detail-label">Softwares:</span>
                                        <span class="detail-value" style="white-space: pre-wrap;">${solicitacao.softwares_solicitados}</span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Sala:</span>
                                        <span class="detail-value">${solicitacao.sala}</span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Período:</span>
                                        <span class="detail-value">${dataInicio} até ${dataFim}</span>
                                    </div>
                                `;
                            
                            if (solicitacao.anexo_path) {
                                html += `
                                    <div class="detail-row">
                                        <span class="detail-label">Anexo:</span>
                                        <span class="detail-value">
                                            <a href="../${solicitacao.anexo_path}" target="_blank" class="btn btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.875rem;">
                                                <i class="fas fa-file-alt"></i> Baixar Guia
                                            </a>
                                        </span>
                                    </div>
                                `;
                            }
                            html += `</div>`;
                        } else {
                            let dataLabel = "Data de Uso";
                            let dataValor = dataInicio;
                            if (solicitacao.tipo_solicitacao === 'materiais' && solicitacao.data_termino_uso) {
                                const dataFim = new Date(solicitacao.data_termino_uso + 'T00:00:00-04:00').toLocaleDateString('pt-BR');
                                dataLabel = "Período:";
                                dataValor = `${dataInicio} até ${dataFim}`;
                            }

                            html += `
                                <div class="detail-section">
                                    <h4><i class="fas fa-calendar-alt"></i> ${dataLabel}</h4>
                                    <p>${dataValor}</p>
                                </div>
                                <div class="detail-section">
                                    <h4><i class="fas fa-map-marker-alt"></i> Sala</h4>
                                    <p>${solicitacao.sala || 'N/A'}</p>
                                </div>
                            `;
                            
                            if (solicitacao.materiais && solicitacao.materiais.length > 0) {
                                html += `
                                    <div class="detail-section">
                                        <h4><i class="fas fa-boxes"></i> Materiais Solicitados</h4>
                                        <ul class="modal-material-list">
                                `;
                                solicitacao.materiais.forEach(material => {
                                    html += `
                                        <li class="modal-material-item">
                                            <span class="material-name">${material.nome}</span>
                                            <span class="modal-material-qty">x${material.quantidade_solicitada}</span>
                                        </li>
                                    `;
                                });
                                html += `</ul></div>`;
                            }
                        }

                        html += `
                            <div class="detail-section">
                                <h4><i class="fas fa-info-circle"></i> Status</h4>
                                <p><span class="badge badge-${solicitacao.status === 'pendente' ? 'warning' : 
                                    (solicitacao.status === 'aprovada' ? 'info' : 
                                    (solicitacao.status === 'retirada' ? 'success' : 
                                    (solicitacao.status === 'devolvida' ? 'success' : 'danger')))}">${ucfirst(solicitacao.status)}</span></p>
                            </div>
                        `;

                        if (solicitacao.observacoes) {
                            html += `
                                <div class="detail-section">
                                    <h4><i class="fas fa-comment"></i> Observações</h4>
                                    <p style="white-space: pre-wrap;">${solicitacao.observacoes}</p>
                                </div>
                            `;
                        }

                        document.getElementById('detalhes-modal-body').innerHTML = html;
                        modal.style.display = 'block';
                    } else {
                        alert('Erro ao carregar detalhes: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error("Erro:", error);
                    alert("Erro ao carregar detalhes.");
                });
        }

        function fecharDetalhes() {
            document.getElementById('detalhesModal').style.display = 'none';
        }

        function ucfirst(str) {
            if (!str) return str;
            return str.charAt(0).toUpperCase() + str.slice(1);
        }
        
        window.onclick = function(event) {
            const modal = document.getElementById('detalhesModal');
            const devolucaoModal = document.getElementById('devolucaoModal');
            if (event.target === modal) fecharDetalhes();
            if (event.target === devolucaoModal) fecharModalDevolucao();
        }

        function fecharModalDevolucao() {
            document.getElementById('devolucaoModal').style.display = 'none';
            document.getElementById('formDevolucao').reset();
            document.getElementById('materiaisParaDevolucao').innerHTML = '';
        }

        setInterval(atualizarContador, 2000);

        <?php if (isAdmin()): ?>
            let notificacoesPermitidas = false;
            function solicitarPermissaoNotificacao() {
                if ("Notification" in window) {
                    if (Notification.permission === "default") {
                        Notification.requestPermission().then(function(permission) {
                            if (permission === "granted") notificacoesPermitidas = true;
                        });
                    } else if (Notification.permission === "granted") {
                        notificacoesPermitidas = true;
                    }
                }
            }

            function verificarNovasSolicitacoes() {
                if (!notificacoesPermitidas) return;
                fetch('notificacoes.php')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.novas_solicitacoes > 0) {
                            const notification = new Notification("Nova Solicitação - SIMEI IBC", {
                                body: `${data.novas_solicitacoes} nova(s) solicitação(ões) pendente(s)`,
                                icon: "../assets/images/3dd9c2bf93e33f1adf031b0ad3801207b79cf53d.png",
                                tag: "nova-solicitacao",
                                requireInteraction: true
                            });
                            notification.onclick = function() {
                                window.focus();
                                notification.close();
                                location.reload();
                            };
                            setTimeout(() => { notification.close(); }, 30000);
                        }
                    })
                    .catch(error => console.error('Erro ao verificar notificações:', error));
            }

            document.addEventListener('DOMContentLoaded', function() {
                solicitarPermissaoNotificacao();
                setInterval(verificarNovasSolicitacoes, 2000);
            });
        <?php endif; ?>

        function abrirModalDevolucao(solicitacaoId) {
            fetch(`detalhes_solicitacao.php?id=${solicitacaoId}`)
                .then(response => {
                    if (!response.ok) throw new Error('Erro ao buscar detalhes.');
                    return response.json();
                })
                .then(data => {
                    if (data.success && data.solicitacao) {
                        const solicitacao = data.solicitacao;
                        const materiaisContainer = document.getElementById('materiaisParaDevolucao');
                        materiaisContainer.innerHTML = '';
                        document.getElementById('devolucao_solicitacao_id').value = solicitacaoId;

                        if (solicitacao.materiais && solicitacao.materiais.length > 0) {
                            let html = `<div class="alert alert-info" style="margin-bottom: 1.5rem;">
                                            <i class="fas fa-info-circle"></i>
                                            <strong>Atenção:</strong> Confirme as quantidades devolvidas. Itens danificados serão removidos do estoque.
                                        </div>`;

                            solicitacao.materiais.forEach(material => {
                                html += `
                                    <div class="box-devolucao">
                                        <h4 style="margin: 0 0 0.75rem 0; color: #1f2937; font-size: 1rem;">${material.nome}</h4>
                                        <p style="margin: 0 0 1rem 0; color: #6b7280; font-size: 0.875rem;">
                                            Quantidade solicitada: <strong>${material.quantidade_solicitada}</strong>
                                        </p>
                                        
                                        <div class="grid-devolucao">
                                            <div class="form-group" style="margin-bottom: 0 !important;">
                                                <label for="material_${material.id_material}_devolvido" class="form-label">
                                                    Quantidade devolvida:
                                                </label>
                                                <input type="number" id="material_${material.id_material}_devolvido" 
                                                    name="materiais_devolvidos[${material.id_material}]" class="form-input" 
                                                    min="0" max="${material.quantidade_solicitada}" value="${material.quantidade_solicitada}"
                                                    onchange="atualizarQuantidadeDanificada(${material.id_material}, ${material.quantidade_solicitada})" required>
                                            </div>
                                            
                                            <div class="form-group" style="margin-bottom: 0 !important;">
                                                <label for="material_${material.id_material}_danificado" class="form-label">
                                                    <i class="fas fa-exclamation-triangle" style="color: #f59e0b;"></i> Qtd. danificada:
                                                </label>
                                                <input type="number" id="material_${material.id_material}_danificado" 
                                                    name="materiais_danificados[${material.id_material}]" class="form-input" 
                                                    min="0" max="${material.quantidade_solicitada}" value="0"
                                                    onchange="validarQuantidadeDanificada(${material.id_material}, ${material.quantidade_solicitada})">
                                                <small style="color: #6b7280;">Remover do estoque</small>
                                            </div>
                                        </div>
                                    </div>
                                `;
                            });
                            materiaisContainer.innerHTML = html;
                        } else {
                            materiaisContainer.innerHTML = '<p>Nenhum material associado.</p>';
                        }
                        document.getElementById('devolucaoModal').style.display = 'block';
                    } else {
                        alert("Erro: " + data.message);
                    }
                })
                .catch(error => {
                    console.error("Erro:", error);
                    alert("Erro ao carregar detalhes da solicitação.");
                });
        }

        function atualizarQuantidadeDanificada(materialId, quantidadeMaxima) {
            const inputDevolvido = document.getElementById(`material_${materialId}_devolvido`);
            const inputDanificado = document.getElementById(`material_${materialId}_danificado`);
            const quantidadeDevolvida = parseInt(inputDevolvido.value) || 0;
            const quantidadeDanificada = parseInt(inputDanificado.value) || 0;
            inputDanificado.max = quantidadeDevolvida;
            if (quantidadeDanificada > quantidadeDevolvida) inputDanificado.value = quantidadeDevolvida;
        }

        function validarQuantidadeDanificada(materialId, quantidadeMaxima) {
            const inputDevolvido = document.getElementById(`material_${materialId}_devolvido`);
            const inputDanificado = document.getElementById(`material_${materialId}_danificado`);
            const quantidadeDevolvida = parseInt(inputDevolvido.value) || 0;
            const quantidadeDanificada = parseInt(inputDanificado.value) || 0;
            if (quantidadeDanificada > quantidadeDevolvida) {
                alert('A quantidade danificada não pode ser maior que a quantidade devolvida.');
                inputDanificado.value = quantidadeDevolvida;
            }
            if (quantidadeDanificada > quantidadeMaxima) {
                alert('A quantidade danificada não pode ser maior que a quantidade solicitada.');
                inputDanificado.value = quantidadeMaxima;
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('success')) {
                const message = urlParams.get('success');
                alert(decodeURIComponent(message));
            }
        });
    </script>
</body>
</html>