<?php
require_once '../includes/config.php';

// Verificar se está logado
if (!isLoggedIn()) {
    redirect('../index.php');
}

$error = '';
$success = '';

// Processar ações (aprovar, retirar, devolver)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($_POST['action'] ?? '');
    $solicitacao_id = (int)($_POST['solicitacao_id'] ?? 0);
    
    if ($action && $solicitacao_id) {
        try {
            $pdo = getDBConnection();
            
            switch ($action) {
                case 'aprovar':
                    if (isAdmin()) {
                        try {
                            // Depuração: verifique os valores das variáveis
                            error_log("Tentativa de aprovar solicitação #{$solicitacao_id} pelo usuário ID: {$_SESSION['user_id']}");
                            
                            $stmt = $pdo->prepare("
                                UPDATE solicitacoes 
                                SET status = 'aprovada', aprovada_por = ? 
                                WHERE id = ? AND status = 'pendente'
                            ");

                            $stmt->execute([$_SESSION['user_id'], $solicitacao_id]);
                            
                            $success = 'Solicitação aprovada com sucesso!';

                        } catch (PDOException $e) {
                            // Exibir erro específico do banco de dados
                            $error = "Erro no banco de dados: " . $e->getMessage();
                            error_log("Erro ao aprovar solicitação: " . $e->getMessage());
                        }
                    }
                    break;
                    
                case 'retirar':
                    if (isAdmin()) {
                        // 1. Iniciar uma transação para garantir a integridade
                        $pdo->beginTransaction();

                        try {
                            // 2. Obter os materiais da solicitação
                            $stmt_materiais = $pdo->prepare("
                                SELECT id_material, quantidade_solicitada
                                FROM solicitacoes_materiais
                                WHERE id_solicitacao = ?
                            ");
                            $stmt_materiais->execute([$solicitacao_id]);
                            $materiais = $stmt_materiais->fetchAll(PDO::FETCH_ASSOC);

                            if (!empty($materiais)) {
                                // 3. Atualizar a quantidade de cada material no estoque
                                $stmt_update_estoque = $pdo->prepare("
                                    UPDATE materiais
                                    SET quantidade = quantidade - ?
                                    WHERE id = ?
                                ");
                                foreach ($materiais as $material) {
                                    $stmt_update_estoque->execute([
                                        $material['quantidade_solicitada'],
                                        $material['id_material']
                                    ]);
                                }
                            }

                            // 4. Atualizar o status da solicitação
                            $stmt = $pdo->prepare("
                                UPDATE solicitacoes 
                                SET status = 'retirada', data_retirada = NOW() 
                                WHERE id = ? AND status = 'aprovada'
                            ");
                            $stmt->execute([$solicitacao_id]);

                            $pdo->commit(); // Confirma as alterações
                            $success = 'Solicitação marcada como retirada e estoque atualizado!';

                        } catch (PDOException $e) {
                            $pdo->rollBack(); // Desfaz todas as alterações em caso de erro
                            $error = 'Erro ao processar a retirada. Tente novamente.';
                            error_log("Erro ao processar retirada: " . $e->getMessage());
                        }
                    }
                    break;
                    
                case 'devolver_materiais':
                    if (isAdmin()) {
                        $pdo->beginTransaction();
                        try {
                            $materiais_devolvidos = $_POST['materiais_devolvidos'] ?? [];
                            $materiais_danificados = $_POST['materiais_danificados'] ?? [];
                            $observacoes_devolucao = sanitize($_POST['observacoes_devolucao'] ?? '');
                            
                            $observacoes_danificados = [];
                            
                            // 1. Atualizar a quantidade dos materiais no estoque
                            foreach ($materiais_devolvidos as $material_id => $quantidade_devolvida) {
                                $quantidade_devolvida = (int)$quantidade_devolvida;
                                $quantidade_danificada = (int)($materiais_danificados[$material_id] ?? 0);
                                
                                if ($quantidade_devolvida > 0) {
                                    // Quantidade que volta ao estoque (total devolvido - danificado)
                                    $quantidade_para_estoque = $quantidade_devolvida - $quantidade_danificada;
                                    
                                    if ($quantidade_para_estoque > 0) {
                                        $stmt = $pdo->prepare("
                                            UPDATE materiais 
                                            SET quantidade = quantidade + ? 
                                            WHERE id = ?
                                        ");
                                        $stmt->execute([$quantidade_para_estoque, $material_id]);
                                    }
                                    
                                    // Se há itens danificados, registrar nas observações
                                    if ($quantidade_danificada > 0) {
                                        $stmt_material_nome = $pdo->prepare("SELECT nome FROM materiais WHERE id = ?");
                                        $stmt_material_nome->execute([$material_id]);
                                        $material_nome = $stmt_material_nome->fetchColumn();
                                        
                                        $observacoes_danificados[] = "{$material_nome}: {$quantidade_danificada} unidade(s) danificada(s) - removida(s) do estoque";
                                    }
                                }
                            }
                            
                            // 2. Atualizar o status da solicitação
                            $observacoes_completas = [];
                            if ($observacoes_devolucao) {
                                $observacoes_completas[] = "Devolução: " . $observacoes_devolucao;
                            }
                            if (!empty($observacoes_danificados)) {
                                $observacoes_completas[] = "Itens danificados: " . implode('; ', $observacoes_danificados);
                            }
                            
                            $observacoes_final = !empty($observacoes_completas) ? implode('\n\n', $observacoes_completas) : null;
                            
                            $stmt = $pdo->prepare("
                                UPDATE solicitacoes 
                                SET status = 'devolvida', 
                                    data_devolucao = NOW(),
                                    observacoes = CASE 
                                        WHEN observacoes IS NULL OR observacoes = '' THEN ?
                                        ELSE CONCAT(observacoes, '\n\n', ?)
                                    END
                                WHERE id = ?
                            ");
                            $stmt->execute([$observacoes_final, $observacoes_final, $solicitacao_id]);
                            
                            $pdo->commit();
                            $success = 'Devolução processada com sucesso! Estoque atualizado automaticamente.';
                            if (!empty($observacoes_danificados)) {
                                $success .= ' Itens danificados foram removidos do estoque.';
                            }
                            header("Location: pendentes.php?success=" . urlencode($success));
                            exit;
                        } catch (PDOException $e) {
                            $pdo->rollBack();
                            $error = 'Erro ao processar devolução.';
                            header("Location: pendentes.php?error=" . urlencode($error));
                            exit;
                        }
                    }
                    break;

                    
                case 'cancelar':
                    // Ação de cancelamento da solicitação (pode ser feita por qualquer usuário na própria solicitação)
                    $pdo->beginTransaction();
                    try {
                        // Obter os materiais da solicitação para devolver ao estoque
                        $stmt_materiais = $pdo->prepare("
                            SELECT id_material, quantidade_solicitada
                            FROM solicitacoes_materiais
                            WHERE id_solicitacao = ?
                        ");
                        $stmt_materiais->execute([$solicitacao_id]);
                        $materiais = $stmt_materiais->fetchAll(PDO::FETCH_ASSOC);

                        // Atualizar a quantidade de cada material no estoque
                        if (!empty($materiais)) {
                            $stmt_update_estoque = $pdo->prepare("
                                UPDATE materiais
                                SET quantidade = quantidade + ?
                                WHERE id = ?
                            ");
                            foreach ($materiais as $material) {
                                $stmt_update_estoque->execute([
                                    $material['quantidade_solicitada'],
                                    $material['id_material']
                                ]);
                            }
                        }

                        // Mudar o status da solicitação para cancelada
                        $stmt = $pdo->prepare("
                            UPDATE solicitacoes 
                            SET status = 'cancelada' 
                            WHERE id = ? AND status = 'pendente'
                        ");
                        $stmt->execute([$solicitacao_id]);

                        $pdo->commit();
                        $success = 'Solicitação cancelada e material devolvido ao estoque com sucesso!';
                    } catch (PDOException $e) {
                        $pdo->rollBack();
                        $error = 'Erro ao cancelar a solicitação. Tente novamente.';
                        error_log("Erro ao cancelar solicitação: " . $e->getMessage());
                    }
                    break;
                    
                case 'excluir':
                    // Apenas admin pode excluir solicitações pendentes
                    if (isAdmin()) {
                        // Primeiro, verificar se a solicitação está pendente
                        $stmt = $pdo->prepare("
                            SELECT status, materiais_solicitados 
                            FROM solicitacoes 
                            WHERE id = ? AND status = 'pendente'
                        ");
                        $stmt->execute([$solicitacao_id]);
                        $solicitacao = $stmt->fetch();
                        
                        if ($solicitacao) {
                            // Restaurar quantidades dos materiais antes de excluir
                            if ($solicitacao['materiais_solicitados']) {
                                $materiais = json_decode($solicitacao['materiais_solicitados'], true);
                                if ($materiais) {
                                    foreach ($materiais as $material_id => $quantidade) {
                                        // Verificar se é material extra (string) ou normal (numeric)
                                        if (is_numeric($material_id)) {
                                            // Material normal - usar ID
                                            $stmt = $pdo->prepare("
                                                UPDATE materiais 
                                                SET quantidade = quantidade + ? 
                                                WHERE id = ?
                                            ");
                                            $stmt->execute([$quantidade, $material_id]);
                                        } else {
                                            // Material extra - usar nome
                                            $materiais_extras_map = [
                                                'caixa_som' => 'Caixa de Som',
                                                'extensao' => 'Extensão', 
                                                'microfone' => 'Microfone'
                                            ];
                                            
                                            if (isset($materiais_extras_map[$material_id])) {
                                                $stmt = $pdo->prepare("
                                                    UPDATE materiais 
                                                    SET quantidade = quantidade + ? 
                                                    WHERE nome = ?
                                                ");
                                                $stmt->execute([$quantidade, $materiais_extras_map[$material_id]]);
                                            }
                                        }
                                    }
                                }
                            }
                            
                            // Excluir a solicitação
                            $stmt = $pdo->prepare("DELETE FROM solicitacoes WHERE id = ?");
                            $stmt->execute([$solicitacao_id]);
                            
                            $success = 'Solicitação excluída com sucesso! Materiais devolvidos ao estoque.';
                            header("Location: pendentes.php?success=" . urlencode($success));
                            exit;
                        } else {
                            $error = 'Apenas solicitações pendentes podem ser excluídas.';
                        }
                    }
                    break;
            }
        } catch (PDOException $e) {
            $error = 'Erro interno do sistema. Tente novamente.';
        }
    }
}

// Filtros
$filtro_status = sanitize($_GET['status'] ?? '');
$filtro_data = sanitize($_GET['data'] ?? '');
$filtro_tipo = sanitize($_GET['tipo'] ?? '');

// Buscar solicitações
try {
    $pdo = getDBConnection();
    
    $where_conditions = [];
    $params = [];
    
    // Se não for admin, mostrar apenas suas solicitações
    if (!isAdmin()) {
        $where_conditions[] = "s.usuario_id = ?";
        $params[] = $_SESSION['user_id'];
    }
    
    // Filtro por status
    if ($filtro_status) {
        $where_conditions[] = "s.status = ?";
        $params[] = $filtro_status;
    } else {
        // Por padrão, não mostrar canceladas
        $where_conditions[] = "s.status != 'cancelada'";
    }
    
    // Filtro por data
    if ($filtro_data) {
        $where_conditions[] = "s.data_utilizacao = ?";
        $params[] = $filtro_data;
    }
    
    // Filtro por tipo
    if ($filtro_tipo) {
        $where_conditions[] = "s.tipo_solicitacao = ?";
        $params[] = $filtro_tipo;
    }
    
    $where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
    
    $stmt = $pdo->prepare("
        SELECT s.*, u.nome as usuario_nome
        FROM solicitacoes s 
        JOIN usuarios u ON s.usuario_id = u.id 
        $where_clause
        ORDER BY s.data_solicitacao DESC
    ");
    $stmt->execute($params);
    $solicitacoes = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = "Erro ao carregar solicitações.";
    $solicitacoes = [];
}

// Função para obter nomes dos materiais
function obterNomesMateriais($pdo, $materiais_json) {
    global $pdo;
    if (!$materiais_json) return [];
    
    $materiais_solicitados = json_decode($materiais_json, true);
    if (empty($materiais_solicitados)) return [];

    $materiais_info = [];
    $ids = array_keys($materiais_solicitados);

    if (empty($ids)) return [];

    $placeholders = implode(",", array_fill(0, count($ids), "?"));
    $stmt = $pdo->prepare("SELECT id, nome FROM materiais WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $materiais_db = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    foreach ($materiais_solicitados as $id => $quantidade) {
        if (isset($materiais_db[$id])) {
            $materiais_info[] = [
                'nome' => $materiais_db[$id],
                'quantidade' => $quantidade
            ];
        }
    }

    return $materiais_info;
}

if (isset($_GET['ajax'])) {
    include 'partials/solicitacoes_table.php'; // extrai apenas a tabela num arquivo separado
    exit;
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Solicitações</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .tipo-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .tipo-datashow {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .tipo-materiais {
            background: #d1fae5;
            color: #065f46;
        }
        
        .materiais-list {
            font-size: 0.875rem;
            color: #6b7280;
            margin-top: 0.25rem;
        }
        
        .materiais-list .material-item {
            display: inline-block;
            background: #f3f4f6;
            padding: 0.125rem 0.375rem;
            border-radius: 3px;
            margin: 0.125rem;
        }
        
        .observacao-cell {
            max-width: 200px;
        }
        
        .turno-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .turno-matutino {
            background: #fef3c7;
            color: #92400e;
        }
        
        .turno-vespertino {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .turno-noturno {
            background: #e0e7ff;
            color: #3730a3;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }
        
        .modal-content-large {
            background-color: white;
            margin: 2% auto;
            padding: 2rem;
            border-radius: 8px;
            width: 90%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
            position: relative;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .modal-title {
            margin: 0;
            color: #1f2937;
        }
        
        .close {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #6b7280;
        }
        
        .close:hover {
            color: #374151;
        }
        
        .modal-body {
            line-height: 1.6;
        }
        
        .detail-section {
            margin-bottom: 1.5rem;
            padding: 1rem;
            background: #f9fafb;
            border-radius: 6px;
        }
        
        .detail-section h3 {
            margin: 0 0 0.75rem 0;
            color: #374151;
            font-size: 1.1rem;
        }
        
        .detail-row {
            display: flex;
            margin-bottom: 0.5rem;
        }
        
        .detail-label {
            font-weight: 600;
            color: #4b5563;
            min-width: 120px;
        }
        
        .detail-value {
            color: #1f2937;
            flex: 1;
        }
        
        .clickable-row {
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        
        .clickable-row:hover {
            background-color: #f3f4f6;
        }
        
        @media (max-width: 768px) {
            .modal-content-large {
                width: 95%;
                margin: 5% auto;
                padding: 1rem;
            }
            
            .detail-row {
                flex-direction: column;
            }
            
            .detail-label {
                min-width: auto;
                margin-bottom: 0.25rem;
            }
        }
        
        .observacao-text {
            display: block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            cursor: help;
        }
        
        .materiais-column {
            max-width: 200px;
        }
        
        .material-item-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.125rem 0.375rem;
            margin: 0.125rem 0;
            background: #f3f4f6;
            border-radius: 3px;
            font-size: 0.75rem;
        }
        
        .material-name {
            flex: 1;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-right: 0.5rem;
        }
        
        .material-qty {
            font-weight: 600;
            color: #059669;
            background: #d1fae5;
            padding: 0.125rem 0.25rem;
            border-radius: 2px;
            min-width: 30px;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Botão de menu hambúrguer para mobile -->
    <button class="mobile-menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    
    <!-- Overlay para fechar sidebar em mobile -->
    <div class="sidebar-overlay" onclick="closeSidebar()"></div>
    
    <div class="main-layout">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h1>SIMEI - IBC</h1>
                <p>Bem-vindo, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>
            
            <nav class="sidebar-nav">
                <?php if (isAdmin() || isColaborador()): ?>
                    <a href="usuarios.php" class="nav-item">
                        <i class="fas fa-users"></i> Usuários
                    </a>
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="materiais.php" class="nav-item">
                        <i class="fas fa-boxes"></i> Gestão de Materiais
                    </a>
                    <a href="relatorios.php" class="nav-item">
                        <i class="fas fa-chart-bar"></i> Relatórios
                    </a>
                <?php endif; ?>
                <?php if ($_SESSION['user_type'] === 'professor' || isAdmin() || isColaborador()): ?>
                    <a href="solicitar.php" class="nav-item">
                        <i class="fas fa-plus-circle"></i> Solicitar Equipamentos
                    </a>
                <?php
                $stmt = $pdo->query("SELECT COUNT(*) FROM solicitacoes WHERE status = 'pendente'");
                $pendentes_count = $stmt->fetchColumn();
                ?>
                <a href="pendentes.php" class="nav-item">
                    <span id="contador-pendentes">
                        <i class="fas fa-clock"></i>
                    </span>
                    Solicitações
                </a>
                <?php endif; ?>
            </nav>
            
            <div class="sidebar-footer">
                <a href="../logout.php" class="btn btn-secondary btn-full">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>
        
        <!-- Conteúdo Principal -->
        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-list"></i> Solicitações <?php echo isAdmin() ? '' : 'Minhas'; ?>
                </h1>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <!-- Filtros -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" action="" style="display: flex; gap: 1rem; align-items: end; flex-wrap: wrap;">
                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="status" class="form-label">Status</label>
                            <select id="status" name="status" class="form-input" style="width: 150px;">
                                <option value="">Todos</option>
                                <option value="pendente" <?php echo $filtro_status === 'pendente' ? 'selected' : ''; ?>>Pendente</option>
                                <option value="aprovada" <?php echo $filtro_status === 'aprovada' ? 'selected' : ''; ?>>Aprovada</option>
                                <option value="retirada" <?php echo $filtro_status === 'retirada' ? 'selected' : ''; ?>>Retirada</option>
                                <option value="devolvida" <?php echo $filtro_status === 'devolvida' ? 'selected' : ''; ?>>Devolvida</option>
                                <option value="cancelada" <?php echo $filtro_status === 'cancelada' ? 'selected' : ''; ?>>Cancelada</option>
                            </select>
                        </div>
                        
                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="tipo" class="form-label">Tipo</label>
                            <select id="tipo" name="tipo" class="form-input" style="width: 150px;">
                                <option value="">Todos</option>
                                <option value="equipamentos" <?php echo $filtro_tipo === 'equipamentos' ? 'selected' : ''; ?>>Equipamentos</option>
                                <option value="materiais" <?php echo $filtro_tipo === 'materiais' ? 'selected' : ''; ?>>Materiais</option>
                            </select>
                        </div>
                        
                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="data" class="form-label">Data</label>
                            <input type="date" id="data" name="data" class="form-input" value="<?php echo htmlspecialchars($filtro_data); ?>" style="width: 150px;">
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Filtrar
                        </button>
                        
                        <a href="pendentes.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Limpar
                        </a>
                    </form>
                </div>
            </div>
            
            <!-- Tabela de Solicitações -->
            <div class="table-container" id="lista-solicitacoes">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Professor</th>
                            <th>Tipo</th>
                            <th>Data</th>
                            <th>Turno</th>
                            <th>Sala</th>
                            <th>Materiais</th>
                            <th>Status</th>
                            <th>Observações</th>
                            <?php if (isAdmin()): ?>
                            <th>Ações</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody id="tabela-corpo">
                        <?php if (empty($solicitacoes)): ?>
                            <tr>
                                <td colspan="<?php echo isAdmin() ? '9' : '8'; ?>" class="text-center" style="padding: 2rem; color: #6b7280;">
                                    <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 1rem; display: block;"></i>
                                    Nenhuma solicitação encontrada.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($solicitacoes as $solicitacao): ?>
                                <tr class="clickable-row" onclick="abrirDetalhes(<?php echo $solicitacao['id']; ?>)">
                                    <td>
                                        <strong><?php echo htmlspecialchars($solicitacao['usuario_nome']); ?></strong>
                                        <br>
                                        <small style="color: #6b7280;">
                                            Solicitado em: <?php echo date('d/m/Y H:i', strtotime($solicitacao['data_solicitacao'])); ?>
                                        </small>
                                    </td>
                                    
                                    <td>
                                        <?php
                                        $tipo = $solicitacao['tipo_solicitacao'];
                                        
                                        $tipo_classes = [
                                            'equipamentos' => 'tipo-datashow',
                                            'materiais' => 'tipo-materiais'
                                        ];
                                        $tipo_icons = [
                                            'equipamentos' => 'fas fa-video',
                                            'materiais' => 'fas fa-boxes'
                                        ];
                                        $tipo_labels = [
                                            'equipamentos' => 'Equipamentos',
                                            'materiais' => 'Materiais'
                                        ];

                                        // Adiciona uma verificação para lidar com valores vazios ou inesperados
                                        $classe = $tipo_classes[$tipo] ?? '';
                                        $icone = $tipo_icons[$tipo] ?? 'fas fa-question-circle';
                                        $label = $tipo_labels[$tipo] ?? ucfirst($tipo ?: 'Indefinido'); // Usa 'Indefinido' se $tipo for vazio
                                        ?>
                                        <span class="tipo-badge <?php echo $classe; ?>">
                                            <i class="<?php echo $icone; ?>"></i>
                                            <?php echo $label; ?>
                                        </span>
                                    </td>
                                    
                                    <td><?php echo date('d/m/Y', strtotime($solicitacao['data_utilizacao'])); ?></td>
                                    
                                    <td>
                                        <?php if ($tipo === 'equipamentos' || $tipo === 'materiais'): ?>
                                            <?php if ($solicitacao['turno']): ?>
                                                <span class="turno-badge turno-<?php echo $solicitacao['turno']; ?>">
                                                    <?php 
                                                    $turnos = [
                                                        'matutino' => 'Matutino',
                                                        'vespertino' => 'Vespertino', 
                                                        'noturno' => 'Noturno'
                                                    ];
                                                    echo $turnos[$solicitacao['turno']] ?? 'N/A';
                                                    ?>
                                                </span>
                                            <?php else: ?>
                                                <span style="color: #6b7280;">-</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span style="color: #6b7280;">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td><?php echo htmlspecialchars($solicitacao['sala']); ?></td>
                                    
                                    <td>
                                        <?php if (($tipo === 'materiais') && $solicitacao['materiais_solicitados']): ?>
                                            <?php 
                                            $materiais_data = json_decode($solicitacao['materiais_solicitados'], true);
                                            if ($materiais_data): 
                                            ?>
                                                <div class="materiais-column">
                                                    <?php
                                                        $materiais_solicitados = '';
                                                        $stmt_materiais = $pdo->prepare("
                                                            SELECT m.nome, sm.quantidade_solicitada
                                                            FROM solicitacoes_materiais sm
                                                            JOIN materiais m ON sm.id_material = m.id
                                                            WHERE sm.id_solicitacao = ?
                                                        ");
                                                        $stmt_materiais->execute([$solicitacao['id']]);
                                                        $materiais = $stmt_materiais->fetchAll(PDO::FETCH_ASSOC);

                                                        if ($materiais) {
                                                            foreach ($materiais as $material) {
                                                                $materiais_solicitados .= htmlspecialchars($material['nome']) . ' (x' . htmlspecialchars($material['quantidade_solicitada']) . ')<br>';
                                                            }
                                                        } else {
                                                            $materiais_solicitados = 'Nenhum material associado';
                                                        }
                                                        echo $materiais_solicitados;
                                                    ?>
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span style="color: #6b7280;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td class="observacao-cell">
                                        <?php if ($solicitacao['observacoes']): ?>
                                            <span class="observacao-text" title="<?php echo htmlspecialchars($solicitacao['observacoes']); ?>">
                                                <i class="fas fa-comment"></i> <?php echo htmlspecialchars(substr($solicitacao['observacoes'], 0, 30)); ?>...
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <?php if (isAdmin()): ?>
                                    <td>
                                        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                                            <?php if ($solicitacao['status'] === 'pendente'): ?>
                                                <form method="POST" style="display: inline;" onclick="event.stopPropagation();">
                                                    <input type="hidden" name="action" value="aprovar">
                                                    <input type="hidden" name="solicitacao_id" value="<?php echo htmlspecialchars($solicitacao['id']); ?>">
                                                    <button type="submit" class="btn btn-success" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Tem certeza que deseja aprovar esta solicitação?');">
                                                        <i class="fas fa-check"></i> Aprovar
                                                    </button>
                                                </form>
                                                <form method="POST" style="display: inline;" onclick="event.stopPropagation();">
                                                    <input type="hidden" name="action" value="excluir">
                                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                                    <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Excluir esta solicitação? Esta ação não pode ser desfeita e os materiais serão devolvidos ao estoque.')">
                                                        <i class="fas fa-trash"></i> Excluir
                                                    </button>
                                                </form>
                                            <?php elseif ($solicitacao['status'] === 'aprovada'): ?>
                                                <form method="POST" style="display: inline;" onclick="event.stopPropagation();">
                                                    <input type="hidden" name="action" value="retirar">
                                                    <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                                    <button type="submit" class="btn btn-warning" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Confirmar retirada?')">
                                                        <i class="fas fa-hand-paper"></i> Retirar
                                                    </button>
                                                </form>
                                            <?php elseif ($solicitacao['status'] === 'retirada'): ?>
                                                <button type="button" class="btn btn-primary" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="event.stopPropagation(); abrirModalDevolucao(<?php echo $solicitacao['id']; ?>)">
                                                    <i class="fas fa-undo"></i> Devolver
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <?php elseif ($solicitacao['status'] === 'pendente' && $solicitacao['usuario_id'] == $_SESSION['user_id']): ?>
                                    <td>
                                        <form method="POST" style="display: inline;" onclick="event.stopPropagation();">
                                            <input type="hidden" name="action" value="cancelar">
                                            <input type="hidden" name="solicitacao_id" value="<?php echo $solicitacao['id']; ?>">
                                            <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" onclick="return confirm('Cancelar esta solicitação?')">
                                                <i class="fas fa-times"></i> Cancelar
                                            </button>
                                        </form>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Modal para Visualização Detalhada -->
    <div id="detalhesModal" class="modal" style="display: none;">
        <div class="modal-content-large">
            <button class="close" onclick="fecharDetalhes()">&times;</button>
            <div class="modal-header">
                <h2 id="detalhesTitle" class="modal-title">Detalhes da Solicitação</h2>
            </div>
            <div id="detalhes-modal-body" class="modal-body">
                <!-- Conteúdo será carregado via JavaScript -->
            </div>

    
        </div>
    </div>
    
    <!-- Modal para Confirmação de Devolução -->
    <div id="devolucaoModal" class="modal" style="display: none;">
        <div class="modal-content-large">
            <button class="close" onclick="fecharModalDevolucao()">&times;</button>
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-undo"></i> Confirmar Devolução de Materiais
                </h2>
            </div>
            <div class="modal-body">
                <form id="formDevolucao" method="POST">
                    <input type="hidden" name="action" value="devolver_materiais">
                    <input type="hidden" name="solicitacao_id" id="devolucao_solicitacao_id">
                    
                    <div id="materiaisParaDevolucao">
                        <!-- Materiais serão carregados via JavaScript -->
                    </div>
                    
                    <div class="form-group" style="margin-top: 1.5rem;">
                        <label for="observacoes_devolucao" class="form-label">
                            <i class="fas fa-comment"></i> Observações (opcional)
                        </label>
                        <textarea 
                            id="observacoes_devolucao" 
                            name="observacoes_devolucao" 
                            class="form-input" 
                            rows="3" 
                            placeholder="Informe se houve alguma avaria, material danificado ou outras observações..."
                        ></textarea>
                    </div>
                    
                    <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 2rem;">
                        <button type="button" class="btn btn-secondary" onclick="fecharModalDevolucao()">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-check"></i> Confirmar Devolução
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // Funções para controle do menu mobile
        function toggleSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");
            
            sidebar.classList.toggle("open");
            overlay.classList.toggle("active");
            
            if (sidebar.classList.contains("open")) {
                toggleButton.style.opacity = "0";
                toggleButton.style.pointerEvents = "none";
                mainContent.classList.add("menu-open");
            } else {
                toggleButton.style.opacity = "1";
                toggleButton.style.pointerEvents = "auto";
                mainContent.classList.remove("menu-open");
            }
        }
        
        function closeSidebar() {
            const sidebar = document.querySelector(".sidebar");
            const overlay = document.querySelector(".sidebar-overlay");
            const toggleButton = document.querySelector(".mobile-menu-toggle");
            const mainContent = document.querySelector(".main-content");
            
            sidebar.classList.remove("open");
            overlay.classList.remove("active");
            toggleButton.style.opacity = "1";
            toggleButton.style.pointerEvents = "auto";
            mainContent.classList.remove("menu-open");
        }

        function atualizarContador() {
            fetch('contador_pendentes.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('contador-pendentes').innerHTML = data;
                })
                .catch(error => console.error("Erro ao atualizar contador:", error));
        }

        // chama logo no carregamento
        atualizarContador();

        // Função para abrir detalhes da solicitação
        function abrirDetalhes(solicitacaoId) {
            fetch(`detalhes_solicitacao.php?id=${solicitacaoId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Erro de rede ou servidor.');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        const solicitacao = data.solicitacao;
                        const modal = document.getElementById('detalhesModal');
                        let html = `
                            <h3>Detalhes da Solicitação #${solicitacao.id}</h3>
                            <div class="detail-section">
                                <h4><i class="fas fa-user-circle"></i> Solicitante</h4>
                                <p>${solicitacao.usuario_nome}</p>
                            </div>
                            <div class="detail-section">
                                <h4><i class="fas fa-calendar-alt"></i> Data de Uso</h4>
                                <p>${solicitacao.data_utilizacao}</p>
                            </div>
                            <div class="detail-section">
                                <h4><i class="fas fa-map-marker-alt"></i> Sala</h4>
                                <p>${solicitacao.sala}</p>
                            </div>
                            <div class="detail-section">
                                <h4><i class="fas fa-info-circle"></i> Status</h4>
                                <p><span class="status-badge status-${solicitacao.status}">${solicitacao.status}</span></p>
                            </div>
                        `;

                        if (solicitacao.materiais && solicitacao.materiais.length > 0) {
                            html += `
                                <div class="detail-section">
                                    <h4><i class="fas fa-boxes"></i> Materiais Solicitados</h4>
                                    <ul class="materiais-list-detail">
                            `;
                            solicitacao.materiais.forEach(material => {
                                html += `
                                    <li>
                                        <span class="material-name">${material.nome}</span>
                                        <span class="material-quantity">x${material.quantidade_solicitada}</span>
                                    </li>
                                `;
                            });
                            html += `
                                    </ul>
                                </div>
                            `;
                        }

                        if (solicitacao.observacoes) {
                            html += `
                                <div class="detail-section">
                                    <h4><i class="fas fa-comment"></i> Observações</h4>
                                    <p>${solicitacao.observacoes}</p>
                                </div>
                            `;
                        }

                        document.getElementById('detalhes-modal-body').innerHTML = html;
                        modal.style.display = 'block';

                    } else {
                        alert('Erro ao carregar detalhes da solicitação: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error("Erro ao buscar detalhes da solicitação:", error);
                    alert("Erro ao carregar detalhes da solicitação. Verifique o console para mais informações.");
                });
        }
        
        // Função para mostrar o modal com os detalhes
        function mostrarDetalhes(solicitacao) {
            const modal = document.getElementById('detalhesModal');
            const content = document.getElementById('detalhesContent');
            
            // Montar o conteúdo do modal
            let html = `
                <div class="detail-section">
                    <h3><i class="fas fa-user"></i> Informações do Solicitante</h3>
                    <div class="detail-row">
                        <span class="detail-label">Professor:</span>
                        <span class="detail-value">${solicitacao.usuario_nome}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Data da Solicitação:</span>
                        <span class="detail-value">${formatarDataHora(solicitacao.data_solicitacao)}</span>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h3><i class="fas fa-calendar"></i> Informações da Utilização</h3>
                    <div class="detail-row">
                        <span class="detail-label">Tipo:</span>
                        <span class="detail-value">${obterTipoLabel(solicitacao.tipo_solicitacao)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Data de Utilização:</span>
                        <span class="detail-value">${formatarData(solicitacao.data_utilizacao)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Sala:</span>
                        <span class="detail-value">${solicitacao.sala}</span>
                    </div>
            `;
            
            // Adicionar informações específicas do tipo
            if (solicitacao.tipo_solicitacao === 'datashow') {
                html += `
                    <div class="detail-row">
                        <span class="detail-label">Turno:</span>
                        <span class="detail-value">${obterTurnoLabel(solicitacao.turno)}</span>
                    </div>
                `;
            }
            
            html += `</div>`;
            
            // Adicionar materiais se houver
            if (solicitacao.materiais && solicitacao.materiais.length > 0) {
                html += `
                    <div class="detail-section">
                        <h3><i class="fas fa-boxes"></i> Materiais Solicitados</h3>
                        <div style="display: grid; gap: 0.75rem;">
                `;
                
                solicitacao.materiais.forEach(material => {
                    html += `
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; background: #f8fafc; border-radius: 6px; border-left: 4px solid #059669;">
                            <div>
                                <div style="font-weight: 600; color: #1f2937;">${material.nome}</div>
                                <div style="font-size: 0.875rem; color: #6b7280;">Estoque atual: ${material.estoque_atual || 'N/A'} unidades</div>
                            </div>
                            <div style="text-align: right;">
                                <div style="font-weight: 700; color: #059669; font-size: 1.125rem;">${material.quantidade_solicitada}x</div>
                                <div style="font-size: 0.75rem; color: #6b7280;">solicitado</div>
                            </div>
                        </div>
                    `;
                });
                
                html += `
                        </div>
                    </div>
                `;
            }
            
            // Adicionar observações se houver
            if (solicitacao.observacoes || solicitacao.observacoes_materiais) {
                html += `<div class="detail-section">
                    <h3><i class="fas fa-comment"></i> Observações</h3>
                `;
                
                if (solicitacao.observacoes) {
                    html += `
                        <div class="detail-row">
                            <span class="detail-label">Gerais:</span>
                            <span class="detail-value">${solicitacao.observacoes}</span>
                        </div>
                    `;
                }
                
                if (solicitacao.observacoes_materiais) {
                    html += `
                        <div class="detail-row">
                            <span class="detail-label">Materiais:</span>
                            <span class="detail-value">${solicitacao.observacoes_materiais}</span>
                        </div>
                    `;
                }
                
                html += `</div>`;
            }
            
            // Adicionar informações de status

            // Adicionar informações dos materiais
            if (data.solicitacao.materiais && data.solicitacao.materiais.length > 0) {
                html += `
                    <div class="detail-section">
                        <h3><i class="fas fa-boxes"></i> Materiais Solicitados</h3>
                        <div class="materiais-list-detail">
                `;

                data.solicitacao.materiais.forEach(material => {
                    html += `
                        <div class="material-item">
                            <span class="material-name">${material.nome}</span>
                            <span class="material-quantity">x${material.quantidade_solicitada}</span>
                        </div>
                    `;
                });

                html += `
                        </div>
                    </div>
                `;
            }
            html += `
                <div class="detail-section">
                    <h3><i class="fas fa-info-circle"></i> Status</h3>
                    <div class="detail-row">
                        <span class="detail-label">Status Atual:</span>
                        <span class="detail-value">${obterStatusLabel(solicitacao.status)}</span>
                    </div>
            `;
            
            if (solicitacao.aprovada_por_nome) {
                html += `
                    <div class="detail-row">
                        <span class="detail-label">Aprovada por:</span>
                        <span class="detail-value">${solicitacao.aprovada_por_nome}</span>
                    </div>
                `;
            }
            
            if (solicitacao.data_aprovacao) {
                html += `
                    <div class="detail-row">
                        <span class="detail-label">Data de Aprovação:</span>
                        <span class="detail-value">${formatarDataHora(solicitacao.data_aprovacao)}</span>
                    </div>
                `;
            }
            
            html += `</div>`;
            
            content.innerHTML = html;
            modal.style.display = 'block';
        }
        
        // Função para fechar o modal
        function fecharDetalhes() {
            document.getElementById('detalhesModal').style.display = 'none';
        }
        
        // Funções auxiliares para formatação
        function formatarData(data) {
            return new Date(data).toLocaleDateString('pt-BR');
        }
        
        function formatarDataHora(dataHora) {
            return new Date(dataHora).toLocaleString('pt-BR');
        }
        
        function obterTipoLabel(tipo) {
            const tipos = {
                'datashow': 'Datashow',
                'materiais': 'Materiais'
            };
            return tipos[tipo] || tipo;
        }
        
        function obterTurnoLabel(turno) {
            const turnos = {
                'matutino': 'Matutino',
                'vespertino': 'Vespertino',
                'noturno': 'Noturno'
            };
            return turnos[turno] || turno;
        }
        
        function obterStatusLabel(status) {
            const statuses = {
                'pendente': 'Pendente',
                'aprovada': 'Aprovada',
                'retirada': 'Retirada',
                'devolvida': 'Devolvida',
                'cancelada': 'Cancelada'
            };
            return statuses[status] || status;
        }
        
        // Fechar modal ao clicar fora dele
        window.onclick = function(event) {
            const modal = document.getElementById('detalhesModal');
            const devolucaoModal = document.getElementById('devolucaoModal');
            if (event.target === modal) {
                fecharDetalhes();
            }
            if (event.target === devolucaoModal) {
                fecharModalDevolucao();
            }
        }
        
        function mostrarModalDevolucao(solicitacao) {
            const modal = document.getElementById('devolucaoModal');
            const solicitacaoIdInput = document.getElementById('devolucao_solicitacao_id');
            const materiaisContainer = document.getElementById('materiaisParaDevolucao');
            
            // Definir ID da solicitação
            solicitacaoIdInput.value = solicitacao.id;
            
            // Limpar container de materiais
            materiaisContainer.innerHTML = '';
            
            // Verificar se há materiais
            if (solicitacao.materiais && solicitacao.materiais.length > 0) {
                let html = '<div style="display: grid; gap: 1rem;">';
                
                solicitacao.materiais.forEach((material, index) => {
                    html += `
                        <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1rem; background: #f9fafb;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
                                <div>
                                    <h4 style="margin: 0; color: #1f2937; font-size: 1rem;">${material.nome}</h4>
                                    <p style="margin: 0; color: #6b7280; font-size: 0.875rem;">
                                        Quantidade levada: <strong>${material.quantidade_solicitada}</strong>
                                    </p>
                                </div>
                            </div>
                            
                            <div class="form-group" style="margin: 0;">
                                <label for="material_${material.id}_devolvido" class="form-label">
                                    Quantidade devolvida:
                                </label>
                                <input 
                                    type="number" 
                                    id="material_${material.id}_devolvido" 
                                    name="materiais_devolvidos[${material.id}]" 
                                    class="form-input" 
                                    min="0" 
                                    max="${material.quantidade_solicitada}" 
                                    value="${material.quantidade_solicitada}"
                                    style="width: 120px;"
                                    required
                                >
                                <small style="color: #6b7280;">Máximo: ${material.quantidade_solicitada}</small>
                            </div>
                        </div>
                    `;
                });
                
                html += '</div>';
                materiaisContainer.innerHTML = html;
            } else {
                materiaisContainer.innerHTML = `
                    <div style="text-align: center; padding: 2rem; color: #6b7280;">
                        <i class="fas fa-info-circle" style="font-size: 2rem; margin-bottom: 1rem;"></i>
                        <p>Esta solicitação não possui materiais para devolução.</p>
                    </div>
                `;
            }
            
            // Mostrar modal
            modal.style.display = 'block';
        }
        
        function fecharModalDevolucao() {
            const modal = document.getElementById('devolucaoModal');
            modal.style.display = 'none';
            
            // Limpar formulário
            document.getElementById('formDevolucao').reset();
            document.getElementById('materiaisParaDevolucao').innerHTML = '';
        }

        // e repete a cada 5s
        setInterval(atualizarContador, 2000);
        
        // Sistema de notificações push para administradores
        <?php if (isAdmin()): ?>
        let notificacoesPermitidas = false;
        
        // Solicitar permissão para notificações
        function solicitarPermissaoNotificacao() {
            if ("Notification" in window) {
                if (Notification.permission === "default") {
                    Notification.requestPermission().then(function (permission) {
                        if (permission === "granted") {
                            notificacoesPermitidas = true;
                            console.log("Permissão para notificações concedida");
                        }
                    });
                } else if (Notification.permission === "granted") {
                    notificacoesPermitidas = true;
                }
            }
        }
        
        // Verificar novas solicitações
        function verificarNovasSolicitacoes() {
            if (!notificacoesPermitidas) return;
            
            fetch('notificacoes.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.novas_solicitacoes > 0) {
                        // Criar notificação
                        const notification = new Notification("Nova Solicitação - SIMEI IBC", {
                            body: `${data.novas_solicitacoes} nova(s) solicitação(ões) pendente(s)`,
                            icon: "../assets/images/3dd9c2bf93e33f1adf031b0ad3801207b79cf53d.png",
                            tag: "nova-solicitacao",
                            requireInteraction: true
                        });
                        
                        // Ao clicar na notificação, focar na janela
                        notification.onclick = function() {
                            window.focus();
                            notification.close();
                            // Recarregar a página para mostrar as novas solicitações
                            location.reload();
                        };
                        
                        // Fechar automaticamente após 30 segundos
                        setTimeout(() => {
                            notification.close();
                        }, 30000);
                    }
                })
                .catch(error => {
                    console.error('Erro ao verificar notificações:', error);
                });
        }
        
        // Inicializar sistema de notificações
        document.addEventListener('DOMContentLoaded', function() {
            solicitarPermissaoNotificacao();
            
            // Verificar novas solicitações a cada 30 segundos
            setInterval(verificarNovasSolicitacoes, 2000);
        });
        <?php endif; ?>

        function abrirModalDevolucao(solicitacaoId) {
            fetch(`detalhes_solicitacao.php?id=${solicitacaoId}`)
                .then(response => {
                    // Verifica se a resposta foi bem-sucedida
                    if (!response.ok) {
                        throw new Error('Erro de rede ou servidor ao buscar detalhes.');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success && data.solicitacao) {
                        const solicitacao = data.solicitacao;
                        // CORREÇÃO: Pegar o elemento com o ID correto
                        const materiaisContainer = document.getElementById('materiaisParaDevolucao');

                        // Limpa o conteúdo anterior
                        materiaisContainer.innerHTML = ''; 
                        
                        // Define o ID da solicitação no formulário
                        document.getElementById('devolucao_solicitacao_id').value = solicitacaoId;

                        if (solicitacao.materiais && solicitacao.materiais.length > 0) {
                            let html = `<div class="alert alert-info" style="margin-bottom: 1.5rem;">
                                            <i class="fas fa-info-circle"></i>
                                            <strong>Atenção:</strong> Confirme as quantidades que foram efetivamente devolvidas. 
                                            Itens danificados serão automaticamente removidos do estoque.
                                        </div>`;

                            solicitacao.materiais.forEach(material => {
                                html += `
                                    <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1rem; margin-bottom: 1rem; background: #f9fafb;">
                                        <h4 style="margin: 0 0 0.75rem 0; color: #1f2937; font-size: 1rem;">${material.nome}</h4>
                                        <p style="margin: 0 0 1rem 0; color: #6b7280; font-size: 0.875rem;">
                                            Quantidade solicitada: <strong>${material.quantidade_solicitada}</strong>
                                        </p>
                                        
                                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                                            <div class="form-group" style="margin: 0;">
                                                <label for="material_${material.id_material}_devolvido" class="form-label">
                                                    Quantidade devolvida:
                                                </label>
                                                <input 
                                                    type="number" 
                                                    id="material_${material.id_material}_devolvido" 
                                                    name="materiais_devolvidos[${material.id_material}]" 
                                                    class="form-input" 
                                                    min="0" 
                                                    max="${material.quantidade_solicitada}" 
                                                    value="${material.quantidade_solicitada}"
                                                    onchange="atualizarQuantidadeDanificada(${material.id_material}, ${material.quantidade_solicitada})"
                                                    required
                                                >
                                            </div>
                                            
                                            <div class="form-group" style="margin: 0;">
                                                <label for="material_${material.id_material}_danificado" class="form-label">
                                                    <i class="fas fa-exclamation-triangle" style="color: #f59e0b;"></i>
                                                    Quantidade danificada:
                                                </label>
                                                <input 
                                                    type="number" 
                                                    id="material_${material.id_material}_danificado" 
                                                    name="materiais_danificados[${material.id_material}]" 
                                                    class="form-input" 
                                                    min="0" 
                                                    max="${material.quantidade_solicitada}" 
                                                    value="0"
                                                    onchange="validarQuantidadeDanificada(${material.id_material}, ${material.quantidade_solicitada})"
                                                >
                                                <small style="color: #6b7280;">Itens danificados serão removidos do estoque</small>
                                            </div>
                                        </div>
                                    </div>
                                `;
                            });

                            materiaisContainer.innerHTML = html;
                        } else {
                            materiaisContainer.innerHTML = '<p>Nenhum material associado a esta solicitação.</p>';
                        }

                        // Abre o modal após preencher o conteúdo
                        document.getElementById('devolucaoModal').style.display = 'block';
                    } else {
                        // Mensagem de erro se a resposta não for bem-sucedida
                        alert("Erro: " + data.message);
                    }
                })
                .catch(error => {
                    // Exibe o erro no console para depuração
                    console.error("Erro ao buscar detalhes da solicitação:", error);
                    alert("Erro ao carregar detalhes da solicitação. Verifique o console do navegador para mais informações.");
                });
        }

        // Funções para validação das quantidades danificadas
        function atualizarQuantidadeDanificada(materialId, quantidadeMaxima) {
            const inputDevolvido = document.getElementById(`material_${materialId}_devolvido`);
            const inputDanificado = document.getElementById(`material_${materialId}_danificado`);
            
            const quantidadeDevolvida = parseInt(inputDevolvido.value) || 0;
            const quantidadeDanificada = parseInt(inputDanificado.value) || 0;
            
            // Ajustar o máximo do campo danificado baseado na quantidade devolvida
            inputDanificado.max = quantidadeDevolvida;
            
            // Se a quantidade danificada for maior que a devolvida, ajustar
            if (quantidadeDanificada > quantidadeDevolvida) {
                inputDanificado.value = quantidadeDevolvida;
            }
        }
        
        function validarQuantidadeDanificada(materialId, quantidadeMaxima) {
            const inputDevolvido = document.getElementById(`material_${materialId}_devolvido`);
            const inputDanificado = document.getElementById(`material_${materialId}_danificado`);
            
            const quantidadeDevolvida = parseInt(inputDevolvido.value) || 0;
            const quantidadeDanificada = parseInt(inputDanificado.value) || 0;
            
            // Validar se a quantidade danificada não excede a devolvida
            if (quantidadeDanificada > quantidadeDevolvida) {
                alert('A quantidade danificada não pode ser maior que a quantidade devolvida.');
                inputDanificado.value = quantidadeDevolvida;
            }
            
            // Validar se não excede a quantidade máxima
            if (quantidadeDanificada > quantidadeMaxima) {
                alert('A quantidade danificada não pode ser maior que a quantidade solicitada.');
                inputDanificado.value = quantidadeMaxima;
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('success')) {
                const message = urlParams.get('success');
                alert(decodeURIComponent(message));
            }
        });
    </script>

    <div id="devolucaoModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="document.getElementById('devolucaoModal').style.display='none'">&times;</span>
            <h2><i class="fas fa-undo-alt"></i> Devolver Materiais</h2>
            <div id="devolucao-modal-body">
                </div>
        </div>
    </div>
</body>
</html>

