<?php
require_once '../includes/config.php';

// Verificar se está logado
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autorizado']);
    exit;
}

// Verificar se o termo de busca foi fornecido
$termo = sanitize($_GET['termo'] ?? '');

if (empty($termo) || strlen($termo) < 2) {
    echo json_encode([]);
    exit;
}

try {
    $pdo = getDBConnection();
    
    // Buscar materiais que correspondem ao termo
    $stmt = $pdo->prepare("
        SELECT id, nome, descricao, quantidade 
        FROM materiais 
        WHERE status_disponibilidade = 'disponivel' 
        AND quantidade > 0
        AND (nome LIKE ? OR descricao LIKE ?)
        ORDER BY nome ASC
    ");
    
    $termo_busca = "%$termo%";
    $stmt->execute([$termo_busca, $termo_busca]);
    $materiais = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calcular quantidade máxima permitida (20% do total)
    foreach ($materiais as &$material) {
        $quantidade_maxima = max(1, floor($material['quantidade'] * 0.2));
        $material['quantidade_maxima'] = $quantidade_maxima;
    }
    
    echo json_encode($materiais);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro interno do servidor']);
}
?>

