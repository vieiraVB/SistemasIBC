<?php
require_once 'config.php';
verificarLogin();

// Processar filtros
$data_inicio = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim = $_GET['data_fim'] ?? date('Y-m-t');

// Incluir a função de buscar dados
function buscarDadosDashboard($pdo, $data_inicio, $data_fim) {
    $dados = [];
    
    // Total de materiais em estoque
    $stmt = $pdo->query("SELECT COUNT(*) as total, SUM(quantidade_total) as quantidade_total FROM materiais WHERE ativo = 1");
    $dados['total_materiais'] = $stmt->fetch();
    
    // Materiais em falta (quantidade zero)
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM materiais WHERE quantidade_total = 0 AND ativo = 1");
    $dados['materiais_zerados'] = $stmt->fetch()['total'];
    
    // Materiais em baixo estoque (abaixo do mínimo)
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM materiais WHERE quantidade_total <= estoque_minimo AND quantidade_total > 0 AND ativo = 1");
    $dados['materiais_baixo_estoque'] = $stmt->fetch()['total'];
    
    // Entradas no período
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_entradas, SUM(quantidade) as quantidade_entradas 
        FROM entradas 
        WHERE data_entrada BETWEEN ? AND ?
    ");
    $stmt->execute([$data_inicio, $data_fim]);
    $dados['entradas'] = $stmt->fetch();
    
    // Saídas no período
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_saidas, SUM(quantidade) as quantidade_saidas 
        FROM saidas 
        WHERE data_saida BETWEEN ? AND ?
    ");
    $stmt->execute([$data_inicio, $data_fim]);
    $dados['saidas'] = $stmt->fetch();
    
    // Tramitações no período
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_tramitacoes 
        FROM tramitacoes 
        WHERE data_criacao BETWEEN ? AND ?
    ");
    $stmt->execute([$data_inicio, $data_fim]);
    $dados['tramitacoes'] = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['total_tramitacoes' => 0];
    
    // Detalhes das tramitações
    $stmt = $pdo->prepare("
        SELECT t.id, t.materiais_solicitados as descricao, t.status, t.data_criacao,
               u.nome as solicitante
        FROM tramitacoes t
        LEFT JOIN usuarios u ON t.usuario_solicitante = u.id
        WHERE t.data_criacao BETWEEN ? AND ?
        ORDER BY t.data_criacao DESC
        LIMIT 50
    ");
    $stmt->execute([$data_inicio, $data_fim]);
    $dados['detalhes_tramitacoes'] = $stmt->fetchAll();
    
    // Materiais com baixo estoque (detalhes)
    $stmt = $pdo->query("
        SELECT codigo, nome, quantidade_total, estoque_minimo
        FROM materiais 
        WHERE quantidade_total <= estoque_minimo AND ativo = 1
        ORDER BY quantidade_total ASC
        LIMIT 50
    ");
    $dados['detalhes_baixo_estoque'] = $stmt->fetchAll();
    
    // Materiais zerados (detalhes)
    $stmt = $pdo->query("
        SELECT codigo, nome, categoria_id
        FROM materiais 
        WHERE quantidade_total = 0 AND ativo = 1
        ORDER BY nome ASC
        LIMIT 50
    ");
    $dados['detalhes_zerados'] = $stmt->fetchAll();
    
    return $dados;
}

$dados = buscarDadosDashboard($pdo, $data_inicio, $data_fim);

// Configurar cabeçalhos para PDF
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="relatorio_sigei_' . date('Y-m-d') . '.pdf"');

// Usar a biblioteca TCPDF ou similar para gerar PDF
// Como não temos TCPDF instalado, vamos usar uma abordagem alternativa com HTML para PDF

// Gerar HTML para conversão em PDF
ob_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Relatório SIGEI - <?php echo formatarData($data_inicio) . ' a ' . formatarData($data_fim); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            margin: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        .header h1 {
            color: #2563eb;
            margin: 0;
        }
        .header p {
            margin: 5px 0;
            color: #666;
        }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        .summary-card {
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
        }
        .summary-card h3 {
            margin: 0 0 10px 0;
            color: #333;
            font-size: 14px;
        }
        .summary-card .value {
            font-size: 24px;
            font-weight: bold;
            color: #2563eb;
            margin-bottom: 5px;
        }
        .summary-card .subtitle {
            font-size: 10px;
            color: #666;
        }
        .section {
            margin-bottom: 30px;
        }
        .section h2 {
            color: #333;
            border-bottom: 1px solid #ddd;
            padding-bottom: 5px;
            margin-bottom: 15px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table th,
        table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        table th {
            background-color: #f5f5f5;
            font-weight: bold;
        }
        .status-badge {
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .status-pendente {
            background-color: #fef3c7;
            color: #92400e;
        }
        .status-aprovado {
            background-color: #d1fae5;
            color: #065f46;
        }
        .status-rejeitado {
            background-color: #fee2e2;
            color: #991b1b;
        }
        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 10px;
            color: #666;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>SIGEI - Sistema de Gerenciamento de Equipamentos e Insumos</h1>
        <p><strong>Relatório de Indicadores</strong></p>
        <p>Período: <?php echo formatarData($data_inicio) . ' a ' . formatarData($data_fim); ?></p>
        <p>Gerado em: <?php echo formatarDataHora(date('Y-m-d H:i:s')); ?></p>
    </div>

    <!-- Resumo Executivo -->
    <div class="summary-grid">
        <div class="summary-card">
            <h3>Total de Materiais</h3>
            <div class="value"><?php echo number_format($dados['total_materiais']['total']); ?></div>
            <div class="subtitle"><?php echo number_format($dados['total_materiais']['quantidade_total'] ?? 0); ?> unidades</div>
        </div>
        
        <div class="summary-card">
            <h3>Materiais em Falta</h3>
            <div class="value"><?php echo $dados['materiais_zerados']; ?></div>
            <div class="subtitle">Estoque zerado</div>
        </div>
        
        <div class="summary-card">
            <h3>Baixo Estoque</h3>
            <div class="value"><?php echo $dados['materiais_baixo_estoque']; ?></div>
            <div class="subtitle">Abaixo do mínimo</div>
        </div>
        
        <div class="summary-card">
            <h3>Entradas (Período)</h3>
            <div class="value"><?php echo $dados['entradas']['total_entradas'] ?? 0; ?></div>
            <div class="subtitle"><?php echo number_format($dados['entradas']['quantidade_entradas'] ?? 0); ?> unidades</div>
        </div>
        
        <div class="summary-card">
            <h3>Saídas (Período)</h3>
            <div class="value"><?php echo $dados['saidas']['total_saidas'] ?? 0; ?></div>
            <div class="subtitle"><?php echo number_format($dados['saidas']['quantidade_saidas'] ?? 0); ?> unidades</div>
        </div>
        
        <div class="summary-card">
            <h3>Tramitações (Período)</h3>
            <div class="card-value">
                        <?php echo number_format($dados['tramitacoes']['total_tramitacoes'] ?? 0); ?>
                    </div>
                    <div class="card-subtitle">Total de tramitações</div>
        </div>
    </div>

    <!-- Materiais em Baixo Estoque -->
    <?php if (!empty($dados['detalhes_baixo_estoque'])): ?>
    <div class="section">
        <h2>Materiais em Baixo Estoque</h2>
        <table>
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Material</th>
                    <th>Estoque Atual</th>
                    <th>Estoque Mínimo</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dados['detalhes_baixo_estoque'] as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['codigo']); ?></td>
                    <td><?php echo htmlspecialchars($item['nome']); ?></td>
                    <td><?php echo $item['quantidade_total']; ?></td>
                    <td><?php echo $item['estoque_minimo']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <!-- Materiais em Falta -->
    <?php if (!empty($dados['detalhes_zerados'])): ?>
    <div class="section">
        <h2>Materiais em Falta (Estoque Zerado)</h2>
        <table>
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Material</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dados['detalhes_zerados'] as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['codigo']); ?></td>
                    <td><?php echo htmlspecialchars($item['nome']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <!-- Tramitações Recentes -->
    <?php if (!empty($dados['detalhes_tramitacoes'])): ?>
    <div class="section">
        <h2>Tramitações no Período</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Solicitante</th>
                    <th>Materiais Solicitados</th>
                    <th>Status</th>
                    <th>Data</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dados['detalhes_tramitacoes'] as $tramitacao): ?>
                <tr>
                    <td><?php echo $tramitacao['id']; ?></td>
                    <td><?php echo htmlspecialchars($tramitacao['solicitante'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($tramitacao['descricao']); ?></td>
                    <td>
                        <span class="status-badge status-<?php echo $tramitacao['status']; ?>">
                            <?php echo ucfirst($tramitacao['status']); ?>
                        </span>
                    </td>
                    <td><?php echo formatarDataHora($tramitacao['data_criacao']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <div class="footer">
        <p>Relatório gerado automaticamente pelo Sistema SIGEI</p>
        <p>Instituto Benjamin Constant - Gerência de Tecnologia</p>
    </div>
</body>
</html>
<?php
$html = ob_get_clean();

// Para uma implementação completa, você precisaria de uma biblioteca como TCPDF ou DomPDF
// Por enquanto, vamos retornar o HTML que pode ser convertido para PDF pelo navegador
header('Content-Type: text/html; charset=utf-8');
header('Content-Disposition: inline; filename="relatorio_sigei_' . date('Y-m-d') . '.html"');

echo $html;
?>
