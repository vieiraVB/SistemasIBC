<?php
// Configurações do banco de dados SIGEI
define('DB_HOST', 'localhost');
define('DB_NAME', 'sigei');
define('DB_USER', 'root');
define('DB_PASS', '');

// Configurações gerais
define('SITE_URL', 'http://localhost/sigei');
define('SITE_NAME', 'SIGEI - Sistema de Gerenciamento de Equipamentos e Insumos');

// Configurações de sessão
ini_set('session.cookie_lifetime', 3600); // 1 hora
session_start();

// Conexão com o banco de dados
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ]
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Erro na conexão com o banco de dados: " . $e->getMessage());
}

// Função para verificar se o usuário está logado
function verificarLogin() {
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: login.php');
        exit();
    }
}

// Função para verificar se é administrador
function verificarAdmin() {
    verificarLogin();
    if ($_SESSION['nivel_acesso'] !== 'admin') {
        header('Location: dashboard.php');
        exit();
    }
}

// Função para formatar CPF
function formatarCPF($cpf) {
    return preg_replace("/(\d{3})(\d{3})(\d{3})(\d{2})/", "$1.$2.$3-$4", $cpf);
}

// Função para limpar CPF (remover formatação)
function limparCPF($cpf) {
    return preg_replace('/[^0-9]/', '', $cpf);
}

// Função para validar CPF
function validarCPF($cpf) {
    $cpf = limparCPF($cpf);
    
    if (strlen($cpf) != 11) {
        return false;
    }
    
    // Verifica se todos os dígitos são iguais
    if (preg_match('/(\d)\1{10}/', $cpf)) {
        return false;
    }
    
    // Calcula os dígitos verificadores
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return false;
        }
    }
    
    return true;
}

// Função para exibir mensagens de alerta
function exibirAlerta($tipo, $mensagem) {
    $classe = '';
    switch($tipo) {
        case 'sucesso':
            $classe = 'alert-success';
            break;
        case 'erro':
            $classe = 'alert-error';
            break;
        case 'aviso':
            $classe = 'alert-warning';
            break;
        case 'info':
            $classe = 'alert-info';
            break;
    }
    
    return "<div class='alert {$classe}'>{$mensagem}</div>";
}

// Função para formatar data brasileira
function formatarData($data) {
    if (empty($data)) return '';
    return date('d/m/Y', strtotime($data));
}

// Função para formatar data e hora brasileira
function formatarDataHora($dataHora) {
    if (empty($dataHora)) return '';
    return date('d/m/Y H:i', strtotime($dataHora));
}

// Função para converter data brasileira para formato MySQL
function converterDataMySQL($data) {
    // Se já estiver no formato YYYY-MM-DD, apenas retorna
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
        return $data;
    }

    // Caso receba DD/MM/YYYY
    $partes = explode('/', $data);
    if (count($partes) == 3) {
        return $partes[2] . '-' . $partes[1] . '-' . $partes[0];
    }

    return null; // formato inválido
}

?>

