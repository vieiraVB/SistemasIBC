# SIGEI - Sistema de Gerenciamento de Equipamentos e Insumos

## Descrição
O SIGEI é um sistema completo para gerenciamento de equipamentos e insumos, desenvolvido para rodar em ambiente XAMPP com banco de dados MySQL. O sistema oferece controle total sobre estoque, movimentações, patrimônio e tramitações de compras.

## Funcionalidades

### 🔐 Sistema de Autenticação
- Login com CPF e senha
- Validação de CPF
- Controle de sessão
- Níveis de acesso (Administrador e Usuário)

### 📦 Gestão de Estoque
- **Materiais e Insumos**: Controle separado por categorias
- **Cadastro completo**: Código, nome, descrição, categoria, unidade de medida
- **Controle de estoque**: Quantidade total e estoque mínimo
- **Alertas automáticos**: Identificação de materiais em falta

### 📥 Entrada de Materiais
- Registro de entradas com data, responsável e fornecedor
- Atualização automática do estoque
- Histórico completo de movimentações
- Suporte a notas fiscais e valores

### 📤 Saída de Materiais
- Controle de saídas com destino e responsável
- Verificação automática de estoque disponível
- **Sistema de devolução**: Marcação de devoluções com atualização automática do estoque
- Histórico detalhado de todas as movimentações

### ⚠️ Controle de Materiais em Falta
- Visualização de itens indisponíveis (quantidade zero)
- Alertas de baixo estoque (abaixo do mínimo definido)
- Filtros e busca avançada
- Ações rápidas para reposição

### 🏢 Controle Patrimonial
- **Organização por locais**:
  - Laboratórios (1 ao 11)
  - Salas (1 ao 11)
  - Setores (Coordenação, Diretoria, Gerência de Tecnologia, Secretaria, Biblioteca)
- **Gestão de patrimônio**:
  - Tombamento único para cada item
  - Controle de estado (novo, bom, regular, ruim, inutilizado)
  - Data e valor de aquisição
  - Relatórios por local

### 📑 Tramitações
- **Solicitações de compra**: Registro detalhado de materiais necessários
- **Controle de status**: Pendente, Em Andamento, Aprovado, Rejeitado, Finalizado
- **Upload de documentos**: Suporte a arquivos PDF de resposta
- **Filtros avançados**: Por data, status e palavra-chave
- **Gestão administrativa**: Controle completo para administradores

### 👥 Gerenciamento de Usuários (Admin)
- Cadastro e edição de usuários
- Controle de níveis de acesso
- Ativação/desativação de contas
- Validação de CPF

## Requisitos do Sistema

### Servidor
- **XAMPP** (Apache + MySQL + PHP)
- **PHP 7.4+** com extensões PDO e MySQL
- **MySQL 5.7+** ou **MariaDB 10.2+**

### Navegador
- Qualquer navegador moderno (Chrome, Firefox, Safari, Edge)
- JavaScript habilitado

## Instalação

### 1. Preparar o Ambiente
1. Instale o XAMPP
2. Inicie os serviços Apache e MySQL
3. Acesse o phpMyAdmin (http://localhost/phpmyadmin)

### 2. Configurar o Banco de Dados
1. Execute o script `database.sql` no phpMyAdmin para criar:
   - Banco de dados `sigei`
   - Todas as tabelas necessárias
   - Dados iniciais (usuário admin, categorias, locais)
   - Views e triggers automáticos

### 3. Instalar o Sistema
1. Copie todos os arquivos para a pasta `htdocs/sigei/` do XAMPP
2. Verifique as permissões da pasta `uploads/` (deve permitir escrita)
3. Configure o arquivo `config.php` se necessário (as configurações padrão funcionam com XAMPP)

### 4. Primeiro Acesso
1. Acesse: http://localhost/sigei/
2. Use as credenciais padrão:
   - **CPF**: 000.000.000-00
   - **Senha**: password
3. **IMPORTANTE**: Altere a senha do administrador após o primeiro login

## Estrutura do Banco de Dados

### Tabelas Principais
- `usuarios` - Controle de acesso e autenticação
- `categorias` - Categorização de materiais e insumos
- `materiais` - Cadastro de todos os itens
- `locais` - Laboratórios, salas e setores
- `patrimonio` - Controle patrimonial por localização
- `entradas` - Histórico de entradas de materiais
- `saidas` - Histórico de saídas de materiais
- `tramitacoes` - Solicitações de compras

### Recursos Automáticos
- **Triggers**: Atualização automática de estoque nas movimentações
- **Views**: Consultas otimizadas para materiais em falta
- **Índices**: Performance otimizada para consultas frequentes

## Funcionalidades Técnicas

### Segurança
- Senhas criptografadas com password_hash()
- Validação de sessões em todas as páginas
- Proteção contra SQL Injection (PDO prepared statements)
- Validação de CPF no frontend e backend
- Controle de acesso por nível de usuário

### Interface
- Design responsivo (funciona em desktop e mobile)
- Interface intuitiva com navegação por abas
- Modais para ações importantes
- Alertas e confirmações para operações críticas
- Filtros e busca em tempo real

### Automações
- Atualização automática de estoque nas movimentações
- Criação automática de entrada na devolução de materiais
- Cálculo automático de status (em falta, baixo estoque)
- Validação de estoque disponível antes das saídas

## Uso do Sistema

### Para Usuários Comuns
1. **Consultar estoque**: Visualizar materiais disponíveis
2. **Registrar movimentações**: Entradas e saídas de materiais
3. **Solicitar compras**: Criar tramitações para novos materiais
4. **Consultar patrimônio**: Ver equipamentos por localização

### Para Administradores
- Todas as funcionalidades de usuários comuns, mais:
1. **Gerenciar usuários**: Criar, editar e desativar contas
2. **Gerenciar tramitações**: Aprovar/rejeitar solicitações
3. **Upload de documentos**: Anexar respostas às solicitações
4. **Configurar sistema**: Categorias, locais e materiais

## Manutenção

### Backup
- Faça backup regular do banco de dados `sigei`
- Mantenha cópias dos arquivos da pasta `uploads/`

### Atualizações
- Sempre teste em ambiente de desenvolvimento
- Faça backup antes de aplicar mudanças
- Verifique compatibilidade com versões do PHP/MySQL

## Suporte

### Logs de Erro
- Verifique os logs do Apache para erros PHP
- Use o console do navegador para erros JavaScript

### Problemas Comuns
1. **Erro de conexão**: Verifique se MySQL está rodando
2. **Página em branco**: Verifique logs de erro PHP
3. **Upload não funciona**: Verifique permissões da pasta uploads/
4. **Login não funciona**: Verifique se o usuário admin foi criado

## Tecnologias Utilizadas

- **Backend**: PHP 7.4+ com PDO
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Banco de Dados**: MySQL/MariaDB
- **Servidor Web**: Apache (XAMPP)
- **Estilo**: CSS customizado com design responsivo
- **Ícones**: Font Awesome 6.0

## Licença

Este sistema foi desenvolvido para uso interno e educacional. Todos os direitos reservados.

---

**Desenvolvido para ambiente XAMPP - Pronto para uso!**

