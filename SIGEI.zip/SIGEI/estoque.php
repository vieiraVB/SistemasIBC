<?php
require_once 'config.php';
verificarLogin();

$sucesso = '';
$erro = '';

// Processar ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['acao'])) {
        switch ($_POST['acao']) {
            case 'adicionar_material':
                try {
                    $stmt = $pdo->prepare("INSERT INTO materiais (codigo, nome, descricao, categoria_id, quantidade_total, estoque_minimo, unidade_medida, valor_unitario) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $_POST['codigo'],
                        $_POST['nome'],
                        $_POST['descricao'],
                        $_POST['categoria_id'],
                        $_POST['quantidade_total'],
                        !empty($_POST['estoque_minimo']) ? $_POST['estoque_minimo'] : null,
                        $_POST['unidade_medida'],
                        $_POST['valor_unitario']
                    ]);
                    $sucesso = "Equipamento adicionado com sucesso!";
                } catch (PDOException $e) {
                    if ($e->getCode() == 23000) {
                        $erro = "Código já existe. Use um código diferente.";
                    } else {
                        $erro = "Erro ao adicionar equipamento: " . $e->getMessage();
                    }
                }
                break;

            case 'editar_material':
                try {
                    $stmt = $pdo->prepare("UPDATE materiais SET nome = ?, descricao = ?, categoria_id = ?, quantidade_total = ?, estoque_minimo = ?, unidade_medida = ?, valor_unitario = ? WHERE id = ?");
                    $stmt->execute([
                        $_POST['nome'],
                        $_POST['descricao'],
                        $_POST['categoria_id'],
                        $_POST['quantidade_total'],
                        !empty($_POST['estoque_minimo']) ? $_POST['estoque_minimo'] : null,
                        $_POST['unidade_medida'],
                        $_POST['valor_unitario'],
                        $_POST['material_id']
                    ]);
                    $sucesso = "Equipamento atualizado com sucesso!";
                } catch (PDOException $e) {
                    $erro = "Erro ao atualizar equipamento: " . $e->getMessage();
                }
                break;

            case 'desativar_material':
                try {
                    $stmt = $pdo->prepare("UPDATE materiais SET ativo = 0 WHERE id = ?");
                    $stmt->execute([$_POST['material_id']]);
                    $sucesso = "Equipamento desativado com sucesso!";
                } catch (PDOException $e) {
                    $erro = "Erro ao desativar equipamento: " . $e->getMessage();
                }
                break;
        }
    }
}

// Buscar categorias
$stmt = $pdo->query("SELECT * FROM categorias ORDER BY nome");
$categorias = $stmt->fetchAll();

// Buscar materiais
$filtro_categoria = isset($_GET['categoria']) ? $_GET['categoria'] : '';
$filtro_tipo = isset($_GET['tipo']) ? $_GET['tipo'] : 'equipamento';
$busca = isset($_GET['busca']) ? $_GET['busca'] : '';

$sql = "SELECT m.*, c.nome as categoria_nome, c.tipo as categoria_tipo 
        FROM materiais m 
        LEFT JOIN categorias c ON m.categoria_id = c.id 
        WHERE m.ativo = 1";

if ($filtro_tipo) {
    $sql .= " AND (c.tipo = :tipo OR c.tipo IS NULL)";
}

if ($filtro_categoria) {
    $sql .= " AND m.categoria_id = :categoria";
}

if ($busca) {
    $sql .= " AND (m.nome LIKE :busca OR m.codigo LIKE :busca OR m.descricao LIKE :busca)";
}

$sql .= " ORDER BY m.nome";

$stmt = $pdo->prepare($sql);

if ($filtro_tipo) {
    $stmt->bindValue(':tipo', $filtro_tipo);
}
if ($filtro_categoria) {
    $stmt->bindValue(':categoria', $filtro_categoria);
}
if ($busca) {
    $stmt->bindValue(':busca', '%' . $busca . '%');
}

$stmt->execute();
$materiais = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estoque - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <div class="main-layout">
        <?php include 'includes/sidebar.php'; ?>

        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">Estoque</h1>
                <p>Gerenciamento de materiais e insumos</p>
            </div>

            <?php if ($sucesso): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($sucesso); ?>
                </div>
            <?php endif; ?>

            <?php if ($erro): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($erro); ?>
                </div>
            <?php endif; ?>

            <!-- Abas -->
            <div class="tabs">
                <button class="tab <?php echo $filtro_tipo == 'equipamento' ? 'active' : ''; ?>" onclick="trocarAba('equipamento')">
                    <i class="fas fa-boxes"></i> Equipamentos
                </button>
                <button class="tab <?php echo $filtro_tipo == 'insumo' ? 'active' : ''; ?>" onclick="trocarAba('insumo')">
                    <i class="fas fa-flask"></i> Insumos
                </button>
            </div>

            <!-- Filtros e busca -->
            <div class="card">
                <div class="card-body">
                    <form method="GET" class="form-row">
                        <input type="hidden" name="tipo" value="<?php echo htmlspecialchars($filtro_tipo); ?>">

                        <div class="form-group">
                            <label class="form-label">Buscar</label>
                            <input type="text" name="busca" class="form-input" placeholder="Nome, código ou descrição..." value="<?php echo htmlspecialchars($busca); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Categoria</label>
                            <select name="categoria" class="form-select">
                                <option value="">Todas as categorias</option>
                                <?php foreach ($categorias as $cat): ?>
                                    <?php if ($cat['tipo'] == $filtro_tipo): ?>
                                        <option value="<?php echo $cat['id']; ?>" <?php echo $filtro_categoria == $cat['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($cat['nome']); ?>
                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>

                        </div>

                        <div class="form-group d-flex align-center">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> Buscar
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Botão adicionar -->
            <div class="d-flex justify-between align-center mb-3">
                <h2>Lista de <?php echo ucfirst($filtro_tipo); ?>s</h2>
                <button class="btn btn-success" onclick="abrirModal('modalAdicionar')">
                    <i class="fas fa-plus"></i> Adicionar <?php echo ucfirst($filtro_tipo); ?>
                </button>
            </div>

            <!-- Tabela de materiais -->
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Nome</th>
                            <th>Categoria</th>
                            <th>Quantidade Total</th>
                            <th>Estoque Mínimo</th>
                            <th>Unidade</th>
                            <th>Valor Unitário</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($materiais)): ?>
                            <tr>
                                <td colspan="9" class="text-center">Nenhum equipamento encontrado.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($materiais as $material): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($material['codigo']); ?></td>
                                    <td><?php echo htmlspecialchars($material['nome']); ?></td>
                                    <td><?php echo htmlspecialchars($material['categoria_nome'] ?? 'Sem categoria'); ?></td>
                                    <td><?php echo number_format($material['quantidade_total'], 0, ',', '.'); ?></td>
                                    <td><?php echo $material['estoque_minimo'] ? number_format($material['estoque_minimo'], 0, ',', '.') : '-'; ?></td>
                                    <td><?php echo htmlspecialchars($material['unidade_medida']); ?></td>
                                    <td>R$ <?php echo number_format($material['valor_unitario'], 2, ',', '.'); ?></td>
                                    <td>
                                        <?php
                                        if ($material['quantidade_total'] == 0) {
                                            echo '<span class="badge badge-danger">Indisponível</span>';
                                        } elseif ($material['estoque_minimo'] && $material['quantidade_total'] <= $material['estoque_minimo']) {
                                            echo '<span class="badge badge-warning">Baixo Estoque</span>';
                                        } else {
                                            echo '<span class="badge badge-success">Normal</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" onclick="editarMaterial(<?php echo htmlspecialchars(json_encode($material)); ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger" onclick="confirmarDesativacao(<?php echo $material['id']; ?>, '<?php echo htmlspecialchars($material['nome']); ?>')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal Adicionar Material -->
    <div id="modalAdicionar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Adicionar <?php echo ucfirst($filtro_tipo); ?></h2>
                <button class="close" onclick="fecharModal('modalAdicionar')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="acao" value="adicionar_material">

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Código *</label>
                        <input type="text" name="codigo" class="form-input" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Nome *</label>
                        <input type="text" name="nome" class="form-input" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Descrição</label>
                    <textarea name="descricao" class="form-textarea"></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Categoria</label>
                        <select name="categoria_id" class="form-select">
                            <option value="">Selecione uma categoria</option>
                            <?php foreach ($categorias as $cat): ?>
                                <?php if ($cat['tipo'] == $filtro_tipo): ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['nome']); ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>

                    </div>

                    <div class="form-group">
                        <label class="form-label">Unidade de Medida</label>
                        <select name="unidade_medida" class="form-select">
                            <option value="unidade">Unidade</option>
                            <option value="kit">Kit</option>
                            <option value="resma">Resma</option>
                            <option value="caixa">Caixa</option>
                            <option value="pacote">Pacote</option>
                            <option value="litro">Litro</option>
                            <option value="kg">Quilograma</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Quantidade Inicial</label>
                        <input type="number" name="quantidade_total" class="form-input" value="0" min="0">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Estoque Mínimo</label>
                        <input type="number" name="estoque_minimo" class="form-input" min="0">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Valor Unitário</label>
                        <input type="number" name="valor_unitario" class="form-input" step="0.01" min="0" value="0.00">
                    </div>
                </div>

                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalAdicionar')">Cancelar</button>
                    <button type="submit" class="btn btn-success">Adicionar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Editar Material -->
    <div id="modalEditar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Editar Equipamento</h2>
                <button class="close" onclick="fecharModal('modalEditar')">&times;</button>
            </div>
            <form method="POST" id="formEditar">
                <input type="hidden" name="acao" value="editar_material">
                <input type="hidden" name="material_id" id="edit_material_id">

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Código</label>
                        <input type="text" id="edit_codigo" class="form-input" readonly>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Nome *</label>
                        <input type="text" name="nome" id="edit_nome" class="form-input" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Descrição</label>
                    <textarea name="descricao" id="edit_descricao" class="form-textarea"></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Categoria</label>
                        <select name="categoria_id" class="form-select">
                            <option value="">Selecione uma categoria</option>
                            <?php foreach ($categorias as $cat): ?>
                                <?php if ($cat['tipo'] == $filtro_tipo): ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['nome']); ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Unidade de Medida</label>
                        <select name="unidade_medida" id="edit_unidade_medida" class="form-select">
                            <option value="unidade">Unidade</option>
                            <option value="kit">Kit</option>
                            <option value="resma">Resma</option>
                            <option value="caixa">Caixa</option>
                            <option value="pacote">Pacote</option>
                            <option value="litro">Litro</option>
                            <option value="kg">Quilograma</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Quantidade Atual</label>
                        <input type="number" name="quantidade_total" id="edit_quantidade_total" class="form-input" min="0" value="0">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Estoque Mínimo</label>
                        <input type="number" name="estoque_minimo" id="edit_estoque_minimo" class="form-input" min="0">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Valor Unitário</label>
                        <input type="number" name="valor_unitario" id="edit_valor_unitario" class="form-input" step="0.01" min="0">
                    </div>
                </div>

                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalEditar')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Confirmar Desativação -->
    <div id="modalDesativar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Confirmar Desativação</h2>
                <button class="close" onclick="fecharModal('modalDesativar')">&times;</button>
            </div>
            <p>Tem certeza que deseja desativar o material <strong id="nomeDesativar"></strong>?</p>
            <p class="text-warning">Esta ação não pode ser desfeita.</p>

            <form method="POST" id="formDesativar">
                <input type="hidden" name="acao" value="desativar_material">
                <input type="hidden" name="material_id" id="desativar_material_id">

                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalDesativar')">Cancelar</button>
                    <button type="submit" class="btn btn-danger">Desativar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function trocarAba(tipo) {
            const url = new URL(window.location);
            url.searchParams.set('tipo', tipo);
            url.searchParams.delete('categoria');
            url.searchParams.delete('busca');
            window.location.href = url.toString();
        }

        function abrirModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }

        function fecharModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function editarMaterial(material) {
            document.getElementById('edit_material_id').value = material.id;
            document.getElementById('edit_codigo').value = material.codigo;
            document.getElementById('edit_nome').value = material.nome;
            document.getElementById('edit_descricao').value = material.descricao || '';
            document.getElementById('edit_categoria_id').value = material.categoria_id || '';
            document.getElementById('edit_unidade_medida').value = material.unidade_medida;
            document.getElementById('edit_quantidade_total').value = material.quantidade_total;
            document.getElementById('edit_estoque_minimo').value = material.estoque_minimo || '';
            document.getElementById('edit_valor_unitario').value = material.valor_unitario;

            abrirModal('modalEditar');
        }

        function confirmarDesativacao(id, nome) {
            document.getElementById('desativar_material_id').value = id;
            document.getElementById('nomeDesativar').textContent = nome;
            abrirModal('modalDesativar');
        }

        // Fechar modal clicando fora
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>

</html>