<?php
require_once 'config.php';
verificarLogin();

// Buscar materiais em falta usando a view criada
$stmt = $pdo->query("SELECT * FROM materiais_em_falta ORDER BY 
    CASE 
        WHEN status = 'Indisponível' THEN 1
        WHEN status = 'Baixo Estoque' THEN 2
        ELSE 3
    END, nome");
$materiaisEmFalta = $stmt->fetchAll();

// Estatísticas
$stmt = $pdo->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN quantidade_total = 0 THEN 1 ELSE 0 END) as indisponiveis,
    SUM(CASE WHEN quantidade_total > 0 AND estoque_minimo IS NOT NULL AND quantidade_total <= estoque_minimo THEN 1 ELSE 0 END) as baixo_estoque
    FROM materiais_em_falta");
$estatisticas = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Em Falta - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="main-layout">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">Materiais em Falta</h1>
                <p>Itens com baixo estoque ou indisponíveis</p>
            </div>

            <!-- Cards de estatísticas -->
            <div class="cards-grid">
                <div class="stat-card">
                    <div class="stat-icon red">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Total em Falta</h3>
                        <p><?php echo number_format($estatisticas['total'], 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon red">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Indisponíveis</h3>
                        <p><?php echo number_format($estatisticas['indisponiveis'], 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon yellow">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Baixo Estoque</h3>
                        <p><?php echo number_format($estatisticas['baixo_estoque'], 0, ',', '.'); ?></p>
                    </div>
                </div>
            </div>

            <!-- Filtros -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Filtros</h3>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Buscar</label>
                            <input type="text" id="busca" class="form-input" placeholder="Nome ou código do material..." onkeyup="filtrarTabela()">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select id="filtroStatus" class="form-select" onchange="filtrarTabela()">
                                <option value="">Todos</option>
                                <option value="Indisponível">Indisponível</option>
                                <option value="Baixo Estoque">Baixo Estoque</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabela de materiais em falta -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Lista de Materiais em Falta</h3>
                </div>
                <div class="card-body">
                    <?php if (empty($materiaisEmFalta)): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i>
                            Parabéns! Não há materiais em falta no momento.
                        </div>
                    <?php else: ?>
                        <div class="table-container">
                            <table class="table" id="tabelaMateriais">
                                <thead>
                                    <tr>
                                        <th>Código</th>
                                        <th>Nome do Material</th>
                                        <th>Quantidade Atual</th>
                                        <th>Estoque Mínimo</th>
                                        <th>Status</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($materiaisEmFalta as $material): ?>
                                        <tr data-status="<?php echo $material['status']; ?>" data-nome="<?php echo strtolower($material['nome']); ?>" data-codigo="<?php echo strtolower($material['codigo']); ?>">
                                            <td><?php echo htmlspecialchars($material['codigo']); ?></td>
                                            <td><?php echo htmlspecialchars($material['nome']); ?></td>
                                            <td>
                                                <span class="<?php echo $material['quantidade_total'] == 0 ? 'text-danger' : 'text-warning'; ?>">
                                                    <?php echo number_format($material['quantidade_total'], 0, ',', '.'); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php echo $material['estoque_minimo'] ? number_format($material['estoque_minimo'], 0, ',', '.') : '-'; ?>
                                            </td>
                                            <td>
                                                <?php if ($material['status'] == 'Indisponível'): ?>
                                                    <span class="badge badge-danger">
                                                        <i class="fas fa-times-circle"></i> Indisponível
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge badge-warning">
                                                        <i class="fas fa-exclamation-triangle"></i> Baixo Estoque
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="entrada.php?material=<?php echo $material['id']; ?>" class="btn btn-sm btn-success" title="Registrar Entrada">
                                                    <i class="fas fa-plus"></i> Entrada
                                                </a>
                                                <a href="estoque.php" class="btn btn-sm btn-primary" title="Ver no Estoque">
                                                    <i class="fas fa-eye"></i> Ver
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Dicas -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-lightbulb"></i> Dicas
                    </h3>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <h4>Como gerenciar materiais em falta:</h4>
                        <ul>
                            <li><strong>Indisponível:</strong> Material com quantidade zero. Registre uma entrada para reestabelecer o estoque.</li>
                            <li><strong>Baixo Estoque:</strong> Material com quantidade igual ou menor que o estoque mínimo definido.</li>
                            <li>Use o botão "Entrada" para registrar rapidamente uma nova entrada do material.</li>
                            <li>Defina estoques mínimos adequados na página de Estoque para receber alertas antecipados.</li>
                            <li>Monitore esta página regularmente para evitar falta de materiais importantes.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function filtrarTabela() {
            const busca = document.getElementById('busca').value.toLowerCase();
            const status = document.getElementById('filtroStatus').value;
            const tabela = document.getElementById('tabelaMateriais');
            const linhas = tabela.getElementsByTagName('tr');

            for (let i = 1; i < linhas.length; i++) { // Pula o cabeçalho
                const linha = linhas[i];
                const nome = linha.getAttribute('data-nome');
                const codigo = linha.getAttribute('data-codigo');
                const statusLinha = linha.getAttribute('data-status');

                let mostrar = true;

                // Filtro de busca
                if (busca && !nome.includes(busca) && !codigo.includes(busca)) {
                    mostrar = false;
                }

                // Filtro de status
                if (status && statusLinha !== status) {
                    mostrar = false;
                }

                linha.style.display = mostrar ? '' : 'none';
            }
        }

        // Atualizar contadores em tempo real
        function atualizarContadores() {
            const linhas = document.querySelectorAll('#tabelaMateriais tbody tr:not([style*="display: none"])');
            let indisponiveis = 0;
            let baixoEstoque = 0;

            linhas.forEach(linha => {
                const status = linha.getAttribute('data-status');
                if (status === 'Indisponível') {
                    indisponiveis++;
                } else if (status === 'Baixo Estoque') {
                    baixoEstoque++;
                }
            });

            // Atualizar os cards se necessário
            console.log(`Visíveis: ${linhas.length}, Indisponíveis: ${indisponiveis}, Baixo Estoque: ${baixoEstoque}`);
        }

        // Adicionar event listeners
        document.getElementById('busca').addEventListener('keyup', atualizarContadores);
        document.getElementById('filtroStatus').addEventListener('change', atualizarContadores);
    </script>

    <style>
        .text-danger {
            color: var(--danger-color) !important;
            font-weight: bold;
        }

        .text-warning {
            color: var(--warning-color) !important;
            font-weight: bold;
        }

        .alert ul {
            margin: 0.5rem 0 0 1.5rem;
        }

        .alert li {
            margin-bottom: 0.5rem;
        }

        .badge i {
            margin-right: 0.25rem;
        }
    </style>
</body>
</html>

