<?php
require_once 'config.php';
verificarLogin();

// Processar filtros
$data_inicio = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim = $_GET['data_fim'] ?? date('Y-m-t');
$formato_exportacao = $_POST['formato'] ?? '';

// Função para buscar dados do dashboard
function buscarDadosDashboard($pdo, $data_inicio, $data_fim)
{
    $dados = [];

    // Total de materiais em estoque
    $stmt = $pdo->query("SELECT COUNT(*) as total, SUM(quantidade_total) as quantidade_total FROM materiais WHERE ativo = 1");
    $dados['total_materiais'] = $stmt->fetch();

    // Materiais em falta (quantidade zero)
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM materiais WHERE quantidade_total = 0 AND ativo = 1");
    $dados['materiais_zerados'] = $stmt->fetch()['total'];

    // Materiais em baixo estoque (abaixo do mínimo)
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM materiais WHERE quantidade_total <= estoque_minimo AND quantidade_total > 0 AND ativo = 1");
    $dados['materiais_baixo_estoque'] = $stmt->fetch()['total'];

    // Entradas no período
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_entradas, SUM(quantidade) as quantidade_entradas 
        FROM entradas 
        WHERE data_entrada BETWEEN ? AND ?
    ");
    $stmt->execute([$data_inicio, $data_fim]);
    $dados['entradas'] = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['total_entradas' => 0, 'quantidade_entradas' => 0];

    // Saídas no período
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_saidas, SUM(quantidade) as quantidade_saidas 
        FROM saidas 
        WHERE data_saida BETWEEN ? AND ?
    ");
    $stmt->execute([$data_inicio, $data_fim]);
    $dados['saidas'] = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['total_saidas' => 0, 'quantidade_saidas' => 0];

    // Tramitações no período
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_tramitacoes 
        FROM tramitacoes 
        WHERE data_criacao BETWEEN ? AND ?
    ");
    $stmt->execute([$data_inicio, $data_fim]);
    $dados['tramitacoes'] = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['total_tramitacoes' => 0];

    // Detalhes das tramitações
    $stmt = $pdo->prepare("
        SELECT t.id, t.materiais_solicitados as descricao, t.status, t.data_criacao,
               u.nome as solicitante
        FROM tramitacoes t
        LEFT JOIN usuarios u ON t.usuario_solicitante = u.id
        WHERE t.data_criacao BETWEEN ? AND ?
        ORDER BY t.data_criacao DESC
        LIMIT 50
    ");
    $stmt->execute([$data_inicio, $data_fim]);
    $dados['detalhes_tramitacoes'] = $stmt->fetchAll();

    // Materiais com baixo estoque (detalhes)
    $stmt = $pdo->query("
        SELECT codigo, nome, quantidade_total, estoque_minimo
        FROM materiais 
        WHERE quantidade_total <= estoque_minimo AND ativo = 1
        ORDER BY quantidade_total ASC
        LIMIT 20
    ");
    $dados['detalhes_baixo_estoque'] = $stmt->fetchAll();

    // Materiais zerados (detalhes)
    $stmt = $pdo->query("
        SELECT codigo, nome, categoria_id
        FROM materiais 
        WHERE quantidade_total = 0 AND ativo = 1
        ORDER BY nome ASC
        LIMIT 20
    ");
    $dados['detalhes_zerados'] = $stmt->fetchAll();

    return $dados;
}

$dados = buscarDadosDashboard($pdo, $data_inicio, $data_fim);

// Processar exportação
if ($formato_exportacao) {
    if ($formato_exportacao === 'pdf') {
        // Redirecionar para geração de PDF
        header("Location: relatorios_pdf.php?data_inicio={$data_inicio}&data_fim={$data_fim}");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - SIGEI</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .dashboard-card {
            background: white;
            border-radius: var(--border-radius-lg);
            padding: 1.5rem;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
        }

        .dashboard-card.warning {
            border-left-color: var(--warning-color);
        }

        .dashboard-card.danger {
            border-left-color: var(--danger-color);
        }

        .dashboard-card.success {
            border-left-color: var(--success-color);
        }

        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }

        .card-icon {
            font-size: 2rem;
            margin-right: 1rem;
            color: var(--primary-color);
        }

        .card-icon.warning {
            color: var(--warning-color);
        }

        .card-icon.danger {
            color: var(--danger-color);
        }

        .card-icon.success {
            color: var(--success-color);
        }

        .card-title {
            font-size: 0.875rem;
            color: var(--secondary-color);
            text-transform: uppercase;
            font-weight: 600;
        }

        .card-value {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--dark-gray);
            margin-bottom: 0.5rem;
        }

        .card-subtitle {
            font-size: 0.875rem;
            color: var(--secondary-color);
        }

        .filters-section {
            background: white;
            border-radius: var(--border-radius-lg);
            padding: 1.5rem;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        .filters-form {
            display: flex;
            gap: 1rem;
            align-items: end;
            flex-wrap: wrap;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--dark-gray);
        }

        .form-group input {
            padding: 0.75rem;
            border: 1px solid var(--medium-gray);
            border-radius: var(--border-radius);
            font-size: 0.875rem;
        }

        .export-section {
            background: white;
            border-radius: var(--border-radius-lg);
            padding: 1.5rem;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        .export-buttons {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .details-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .details-card {
            background: white;
            border-radius: var(--border-radius-lg);
            padding: 1.5rem;
            box-shadow: var(--shadow);
        }

        .details-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        .details-table th,
        .details-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--medium-gray);
        }

        .details-table th {
            background-color: var(--light-gray);
            font-weight: 600;
            color: var(--dark-gray);
        }

        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-pendente {
            background-color: #fef3c7;
            color: #92400e;
        }

        .status-aprovado {
            background-color: #d1fae5;
            color: #065f46;
        }

        .status-rejeitado {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .chart-container {
            background: white;
            border-radius: var(--border-radius-lg);
            padding: 1.5rem;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }
    </style>
</head>

<body>
    <div class="main-layout">
        <?php include 'includes/sidebar.php'; ?>

        <div class="main-content">
            <div class="content-header">
                <h1><i class="fas fa-chart-bar"></i> Relatórios e Dashboard</h1>
                <p>Visualize indicadores e exporte relatórios do sistema</p>
            </div>

            <!-- Filtros -->
            <div class="filters-section">
                <h3><i class="fas fa-filter"></i> Filtros de Período</h3>
                <form method="GET" class="filters-form">
                    <div class="form-group">
                        <label for="data_inicio">Data Início:</label>
                        <input type="date" id="data_inicio" name="data_inicio" value="<?php echo $data_inicio; ?>">
                    </div>
                    <div class="form-group">
                        <label for="data_fim">Data Fim:</label>
                        <input type="date" id="data_fim" name="data_fim" value="<?php echo $data_fim; ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Filtrar
                    </button>
                </form>
            </div>

            <!-- Exportação -->
            <div class="export-section">
                <h3><i class="fas fa-download"></i> Exportar Relatório</h3>
                <div class="export-buttons">
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="formato" value="pdf">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-file-pdf"></i> Exportar PDF
                        </button>
                    </form>
                </div>
            </div>

            <!-- Dashboard Cards -->
            <div class="dashboard-grid">
                <!-- Total de Materiais -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <i class="fas fa-boxes card-icon"></i>
                        <div>
                            <div class="card-title">Total de Materiais</div>
                        </div>
                    </div>
                    <div class="card-value"><?php echo number_format($dados['total_materiais']['total'] ?? 0); ?></div>
                    <div class="card-subtitle">
                        <?php echo number_format($dados['total_materiais']['quantidade_total'] ?? 0); ?> unidades em estoque
                    </div>
                </div>

                <!-- Materiais em Falta -->
                <div class="dashboard-card danger">
                    <div class="card-header">
                        <i class="fas fa-exclamation-triangle card-icon danger"></i>
                        <div>
                            <div class="card-title">Materiais em Falta</div>
                        </div>
                    </div>
                    <div class="card-value"><?php echo $dados['materiais_zerados']; ?></div>
                    <div class="card-subtitle">Itens com estoque zerado</div>
                </div>

                <!-- Baixo Estoque -->
                <div class="dashboard-card warning">
                    <div class="card-header">
                        <i class="fas fa-exclamation-circle card-icon warning"></i>
                        <div>
                            <div class="card-title">Baixo Estoque</div>
                        </div>
                    </div>
                    <div class="card-value"><?php echo $dados['materiais_baixo_estoque']; ?></div>
                    <div class="card-subtitle">Abaixo do estoque mínimo</div>
                </div>

                <!-- Entradas no Período -->
                <div class="dashboard-card success">
                    <div class="card-header">
                        <i class="fas fa-arrow-up card-icon success"></i>
                        <div>
                            <div class="card-title">Entradas (Período)</div>
                        </div>
                    </div>
                    <div class="card-value"><?php echo $dados['entradas']['total_entradas'] ?? 0; ?></div>
                    <div class="card-subtitle">
                        <?php echo number_format($dados['entradas']['quantidade_entradas'] ?? 0); ?> unidades
                    </div>
                </div>

                <!-- Saídas no Período -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <i class="fas fa-arrow-down card-icon"></i>
                        <div>
                            <div class="card-title">Saídas (Período)</div>
                        </div>
                    </div>
                    <div class="card-value"><?php echo $dados['saidas']['total_saidas'] ?? 0; ?></div>
                    <div class="card-subtitle">
                        <?php echo number_format($dados['saidas']['quantidade_saidas'] ?? 0); ?> unidades
                    </div>
                </div>

                <!-- Tramitações -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <i class="fas fa-file-alt card-icon"></i>
                        <div>
                            <div class="card-title">Tramitações (Período)</div>
                        </div>
                    </div>
                    <div class="card-value">
                        <?php echo number_format($dados['tramitacoes']['total_tramitacoes'] ?? 0); ?>
                    </div>
                    <div class="card-subtitle">Total de tramitações</div>
                </div>
            </div>

            <!-- Gráfico de Movimentação -->
            <div class="chart-container">
                <h3><i class="fas fa-chart-line"></i> Movimentação do Estoque</h3>
                <canvas id="movimentacaoChart" width="400" height="200"></canvas>
            </div>

            <!-- Detalhes -->
            <div class="details-section">
                <!-- Materiais em Baixo Estoque -->
                <div class="details-card">
                    <h3><i class="fas fa-exclamation-circle"></i> Materiais em Baixo Estoque</h3>
                    <table class="details-table">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Material</th>
                                <th>Atual</th>
                                <th>Mínimo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dados['detalhes_baixo_estoque'] as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['codigo']); ?></td>
                                    <td><?php echo htmlspecialchars($item['nome']); ?></td>
                                    <td><?php echo $item['quantidade_total']; ?></td>
                                    <td><?php echo $item['estoque_minimo']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Materiais Zerados -->
                <div class="details-card">
                    <h3><i class="fas fa-exclamation-triangle"></i> Materiais em Falta</h3>
                    <table class="details-table">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Material</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dados['detalhes_zerados'] as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['codigo']); ?></td>
                                    <td><?php echo htmlspecialchars($item['nome']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Tramitações Recentes -->
                <div class="details-card" style="grid-column: 1 / -1;">
                    <h3><i class="fas fa-file-alt"></i> Tramitações Recentes</h3>
                    <table class="details-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Solicitante</th>
                                <th>Material</th>
                                <th>Descrição</th>
                                <th>Status</th>
                                <th>Data</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dados['detalhes_tramitacoes'] as $tramitacao): ?>
                                <tr>
                                    <td><?php echo $tramitacao['id']; ?></td>
                                    <td><?php echo htmlspecialchars($tramitacao['solicitante'] ?? 'N/A'); ?></td>
                                    <td>-</td>
                                    <td><?php echo htmlspecialchars(substr($tramitacao['descricao'], 0, 50)) . '...'; ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $tramitacao['status']; ?>">
                                            <?php echo ucfirst($tramitacao['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo formatarDataHora($tramitacao['data_criacao']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Gráfico de movimentação
        const ctx = document.getElementById('movimentacaoChart').getContext('2d');
        const movimentacaoChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Entradas', 'Saídas'],
                datasets: [{
                    label: 'Quantidade',
                    data: [
                        <?php echo $dados['entradas']['quantidade_entradas'] ?? 0; ?>,
                        <?php echo $dados['saidas']['quantidade_saidas'] ?? 0; ?>
                    ],
                    backgroundColor: [
                        'rgba(16, 185, 129, 0.8)',
                        'rgba(37, 99, 235, 0.8)'
                    ],
                    borderColor: [
                        'rgba(16, 185, 129, 1)',
                        'rgba(37, 99, 235, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    </script>
</body>

</html>