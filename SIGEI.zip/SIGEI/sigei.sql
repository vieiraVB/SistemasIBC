-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 23/09/2025 às 05:20
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sigei`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `tipo` enum('equipamento','insumo') NOT NULL DEFAULT 'equipamento',
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `categorias`
--

INSERT INTO `categorias` (`id`, `nome`, `descricao`, `tipo`, `data_criacao`) VALUES
(1, 'Equipamentos de Informática', 'Computadores, monitores, periféricos', 'equipamento', '2025-09-21 05:07:21'),
(2, 'Material de Escritório', 'Papéis, canetas, grampeadores', 'insumo', '2025-09-21 05:07:21'),
(3, 'Equipamentos de Laboratório', 'Microscópios, vidrarias, equipamentos científicos', 'equipamento', '2025-09-21 05:07:21'),
(4, 'Produtos de Limpeza', 'Detergentes, desinfetantes, panos', 'insumo', '2025-09-21 05:07:21'),
(5, 'Material Didático', 'Livros, apostilas, materiais educativos', 'equipamento', '2025-09-21 05:07:21');

-- --------------------------------------------------------

--
-- Estrutura para tabela `entradas`
--

CREATE TABLE `entradas` (
  `id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `data_entrada` date NOT NULL,
  `responsavel_recebimento` varchar(100) NOT NULL,
  `observacoes` text DEFAULT NULL,
  `numero_nota_fiscal` varchar(50) DEFAULT NULL,
  `fornecedor` varchar(100) DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `entradas`
--

INSERT INTO `entradas` (`id`, `material_id`, `quantidade`, `data_entrada`, `responsavel_recebimento`, `observacoes`, `numero_nota_fiscal`, `fornecedor`, `valor_total`, `usuario_id`, `data_criacao`) VALUES
(1, 4, 5, '2025-09-21', 'Vitor Vieira', '', '', '', 0.00, 1, '2025-09-21 07:18:14'),
(2, 4, 1, '2025-09-21', 'Sistema - Devolução Automática', 'Devolução automática da saída ID: 1', NULL, NULL, NULL, 1, '2025-09-21 07:19:04');

--
-- Acionadores `entradas`
--
DELIMITER $$
CREATE TRIGGER `atualizar_estoque_entrada` AFTER INSERT ON `entradas` FOR EACH ROW BEGIN
    UPDATE materiais 
    SET quantidade_total = quantidade_total + NEW.quantidade
    WHERE id = NEW.material_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `locais`
--

CREATE TABLE `locais` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `tipo` enum('laboratorio','sala','setor') NOT NULL,
  `descricao` text DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `locais`
--

INSERT INTO `locais` (`id`, `nome`, `tipo`, `descricao`, `ativo`, `data_criacao`) VALUES
(1, 'Laboratório 1', 'laboratorio', 'Laboratório de Informática 1', 1, '2025-09-21 05:07:21'),
(2, 'Laboratório 2', 'laboratorio', 'Laboratório de Informática 2', 1, '2025-09-21 05:07:21'),
(3, 'Laboratório 3', 'laboratorio', 'Laboratório de Informática 3', 1, '2025-09-21 05:07:21'),
(4, 'Laboratório 4', 'laboratorio', 'Laboratório de Informática 4', 1, '2025-09-21 05:07:21'),
(5, 'Laboratório 5', 'laboratorio', 'Laboratório de Informática 5', 1, '2025-09-21 05:07:21'),
(6, 'Laboratório 6', 'laboratorio', 'Laboratório de Informática 6', 1, '2025-09-21 05:07:21'),
(7, 'Laboratório 7', 'laboratorio', 'Laboratório de Informática 7', 1, '2025-09-21 05:07:21'),
(8, 'Laboratório 8', 'laboratorio', 'Laboratório de Informática 8', 1, '2025-09-21 05:07:21'),
(9, 'Laboratório 9', 'laboratorio', 'Laboratório de Informática 9', 1, '2025-09-21 05:07:21'),
(10, 'Laboratório 10', 'laboratorio', 'Laboratório de Informática 10', 1, '2025-09-21 05:07:21'),
(11, 'Laboratório 11', 'laboratorio', 'Laboratório de Informática 11', 1, '2025-09-21 05:07:21'),
(12, 'Sala 1', 'sala', 'Sala de Aula 1', 1, '2025-09-21 05:07:21'),
(13, 'Sala 2', 'sala', 'Sala de Aula 2', 1, '2025-09-21 05:07:21'),
(14, 'Sala 3', 'sala', 'Sala de Aula 3', 1, '2025-09-21 05:07:21'),
(15, 'Sala 4', 'sala', 'Sala de Aula 4', 1, '2025-09-21 05:07:21'),
(16, 'Sala 5', 'sala', 'Sala de Aula 5', 1, '2025-09-21 05:07:21'),
(17, 'Sala 6', 'sala', 'Sala de Aula 6', 1, '2025-09-21 05:07:21'),
(18, 'Sala 7', 'sala', 'Sala de Aula 7', 1, '2025-09-21 05:07:21'),
(19, 'Sala 8', 'sala', 'Sala de Aula 8', 1, '2025-09-21 05:07:21'),
(20, 'Sala 9', 'sala', 'Sala de Aula 9', 1, '2025-09-21 05:07:21'),
(21, 'Sala 10', 'sala', 'Sala de Aula 10', 1, '2025-09-21 05:07:21'),
(22, 'Sala 11', 'sala', 'Sala de Aula 11', 1, '2025-09-21 05:07:21'),
(23, 'Coordenação', 'setor', 'Coordenação Acadêmica', 1, '2025-09-21 05:07:21'),
(24, 'Diretoria', 'setor', 'Diretoria Geral', 1, '2025-09-21 05:07:21'),
(25, 'Gerência de Tecnologia', 'setor', 'Gerência de Tecnologia da Informação', 1, '2025-09-21 05:07:21'),
(26, 'Secretaria', 'setor', 'Secretaria Acadêmica', 1, '2025-09-21 05:07:21'),
(27, 'Biblioteca', 'setor', 'Biblioteca Central', 1, '2025-09-21 05:07:21'),
(28, 'Laboratório de ESD', 'laboratorio', 'Laboratório Especializado', 1, '2025-09-21 06:15:37'),
(29, 'Laboratório de Automação', 'laboratorio', 'Laboratório Especializado', 1, '2025-09-21 06:15:37'),
(30, 'Laboratório de Eletricidade', 'laboratorio', 'Laboratório Especializado', 1, '2025-09-21 06:15:37'),
(31, 'Laboratório de Eletrotécnica', 'laboratorio', NULL, 1, '2025-09-21 06:15:37');

-- --------------------------------------------------------

--
-- Estrutura para tabela `materiais`
--

CREATE TABLE `materiais` (
  `id` int(11) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `descricao` text DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `quantidade_total` int(11) DEFAULT 0,
  `estoque_minimo` int(11) DEFAULT NULL,
  `unidade_medida` varchar(20) DEFAULT 'unidade',
  `valor_unitario` decimal(10,2) DEFAULT 0.00,
  `ativo` tinyint(1) DEFAULT 1,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `materiais`
--

INSERT INTO `materiais` (`id`, `codigo`, `nome`, `descricao`, `categoria_id`, `quantidade_total`, `estoque_minimo`, `unidade_medida`, `valor_unitario`, `ativo`, `data_criacao`, `data_atualizacao`) VALUES
(4, 'papelA4', 'Papel A4', 'Resma de papel A4 500 folhas', 2, 15, 20, 'resma', 0.00, 1, '2025-09-21 05:07:21', '2025-09-21 07:22:28'),
(6, 'lenovoS22', 'Monitor Lenovo Think Vision S22e', '21.5 polegadas com resolução típica de 1920x1080 pixels', 1, 1, NULL, 'unidade', 0.00, 1, '2025-09-21 06:43:22', '2025-09-21 06:58:24');

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `materiais_em_falta`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `materiais_em_falta` (
`id` int(11)
,`codigo` varchar(50)
,`nome` varchar(200)
,`quantidade_total` int(11)
,`estoque_minimo` int(11)
,`status` varchar(13)
);

-- --------------------------------------------------------

--
-- Estrutura para tabela `patrimonio`
--

CREATE TABLE `patrimonio` (
  `id` int(11) NOT NULL,
  `tombamento` varchar(50) NOT NULL,
  `material_id` int(11) NOT NULL,
  `local_id` int(11) NOT NULL,
  `descricao` text DEFAULT NULL,
  `estado` enum('novo','bom','regular','ruim','inutilizado') DEFAULT 'bom',
  `data_aquisicao` date DEFAULT NULL,
  `valor_aquisicao` decimal(10,2) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `patrimonio`
--

INSERT INTO `patrimonio` (`id`, `tombamento`, `material_id`, `local_id`, `descricao`, `estado`, `data_aquisicao`, `valor_aquisicao`, `ativo`, `data_criacao`, `data_atualizacao`) VALUES
(3, 'N°990009662', 6, 1, '', 'bom', '2025-09-21', NULL, 1, '2025-09-21 07:20:03', '2025-09-21 07:20:03');

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `patrimonio_por_local`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `patrimonio_por_local` (
`local_nome` varchar(100)
,`local_tipo` enum('laboratorio','sala','setor')
,`material_nome` varchar(200)
,`quantidade` bigint(21)
);

-- --------------------------------------------------------

--
-- Estrutura para tabela `saidas`
--

CREATE TABLE `saidas` (
  `id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `data_saida` date NOT NULL,
  `destino` varchar(200) NOT NULL,
  `responsavel_entrega` varchar(100) NOT NULL,
  `observacoes` text DEFAULT NULL,
  `devolvido` tinyint(1) DEFAULT 0,
  `data_devolucao` date DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `saidas`
--

INSERT INTO `saidas` (`id`, `material_id`, `quantidade`, `data_saida`, `destino`, `responsavel_entrega`, `observacoes`, `devolvido`, `data_devolucao`, `usuario_id`, `data_criacao`, `data_atualizacao`) VALUES
(1, 4, 1, '2025-09-21', 'coordenação', 'Vitor Vieira', '', 1, '2025-09-21', 1, '2025-09-21 07:18:57', '2025-09-21 07:19:04');

--
-- Acionadores `saidas`
--
DELIMITER $$
CREATE TRIGGER `atualizar_estoque_devolucao` AFTER UPDATE ON `saidas` FOR EACH ROW BEGIN
    IF NEW.devolvido = TRUE AND OLD.devolvido = FALSE THEN
        UPDATE materiais 
        SET quantidade_total = quantidade_total + NEW.quantidade
        WHERE id = NEW.material_id;
        
        -- Inserir registro de entrada automática
        INSERT INTO entradas (material_id, quantidade, data_entrada, responsavel_recebimento, observacoes, usuario_id)
        VALUES (NEW.material_id, NEW.quantidade, NEW.data_devolucao, 'Sistema - Devolução Automática', 
                CONCAT('Devolução automática da saída ID: ', NEW.id), NEW.usuario_id);
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `atualizar_estoque_saida` AFTER INSERT ON `saidas` FOR EACH ROW BEGIN
    UPDATE materiais 
    SET quantidade_total = quantidade_total - NEW.quantidade
    WHERE id = NEW.material_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tramitacoes`
--

CREATE TABLE `tramitacoes` (
  `id` int(11) NOT NULL,
  `data_solicitacao` date NOT NULL,
  `materiais_solicitados` text NOT NULL,
  `observacoes` text DEFAULT NULL,
  `status` enum('pendente','em_andamento','aprovado','rejeitado','finalizado') DEFAULT 'pendente',
  `arquivo_resposta` varchar(255) DEFAULT NULL,
  `usuario_solicitante` int(11) NOT NULL,
  `usuario_responsavel` int(11) DEFAULT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `tramitacoes`
--

INSERT INTO `tramitacoes` (`id`, `data_solicitacao`, `materiais_solicitados`, `observacoes`, `status`, `arquivo_resposta`, `usuario_solicitante`, `usuario_responsavel`, `data_criacao`, `data_atualizacao`) VALUES
(3, '2025-09-21', 'computador', '', 'pendente', NULL, 1, NULL, '2025-09-21 07:20:52', '2025-09-21 07:20:52');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tramitacoes_arquivos`
--

CREATE TABLE `tramitacoes_arquivos` (
  `id` int(11) NOT NULL,
  `tramitacao_id` int(11) NOT NULL,
  `arquivo_nome` varchar(255) NOT NULL,
  `data_upload` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `tramitacoes_arquivos`
--

INSERT INTO `tramitacoes_arquivos` (`id`, `tramitacao_id`, `arquivo_nome`, `data_upload`) VALUES
(4, 3, 'resposta_3_1758439284.pdf', '2025-09-21 04:21:24');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `nivel_acesso` enum('admin','usuario') DEFAULT 'usuario',
  `ativo` tinyint(1) DEFAULT 1,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `cpf`, `nome`, `senha`, `nivel_acesso`, `ativo`, `data_criacao`, `data_atualizacao`) VALUES
(1, '111.444.777-35', 'Administrador', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1, '2025-09-21 05:07:21', '2025-09-21 05:32:34'),
(2, '06302985218', 'Vitor Vieira', '$2y$10$LlESDEqIU9h0w2y7jqYXjexCoDhgBHMfrJH82PdwJRPVlnazfqpGu', 'admin', 1, '2025-09-21 05:36:05', '2025-09-21 05:36:05');

-- --------------------------------------------------------

--
-- Estrutura para view `materiais_em_falta`
--
DROP TABLE IF EXISTS `materiais_em_falta`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `materiais_em_falta`  AS SELECT `m`.`id` AS `id`, `m`.`codigo` AS `codigo`, `m`.`nome` AS `nome`, `m`.`quantidade_total` AS `quantidade_total`, `m`.`estoque_minimo` AS `estoque_minimo`, CASE WHEN `m`.`quantidade_total` = 0 THEN 'Indisponível' WHEN `m`.`quantidade_total` <= `m`.`estoque_minimo` THEN 'Baixo Estoque' ELSE 'Normal' END AS `status` FROM `materiais` AS `m` WHERE `m`.`ativo` = 1 AND (`m`.`quantidade_total` = 0 OR `m`.`estoque_minimo` is not null AND `m`.`quantidade_total` <= `m`.`estoque_minimo`) ;

-- --------------------------------------------------------

--
-- Estrutura para view `patrimonio_por_local`
--
DROP TABLE IF EXISTS `patrimonio_por_local`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `patrimonio_por_local`  AS SELECT `l`.`nome` AS `local_nome`, `l`.`tipo` AS `local_tipo`, `m`.`nome` AS `material_nome`, count(`p`.`id`) AS `quantidade` FROM ((`locais` `l` left join `patrimonio` `p` on(`l`.`id` = `p`.`local_id` and `p`.`ativo` = 1)) left join `materiais` `m` on(`p`.`material_id` = `m`.`id`)) WHERE `l`.`ativo` = 1 GROUP BY `l`.`id`, `l`.`nome`, `l`.`tipo`, `m`.`id`, `m`.`nome` ORDER BY `l`.`tipo` ASC, `l`.`nome` ASC, `m`.`nome` ASC ;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `entradas`
--
ALTER TABLE `entradas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `idx_entradas_material` (`material_id`),
  ADD KEY `idx_entradas_data` (`data_entrada`);

--
-- Índices de tabela `locais`
--
ALTER TABLE `locais`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `materiais`
--
ALTER TABLE `materiais`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD KEY `idx_materiais_codigo` (`codigo`),
  ADD KEY `idx_materiais_categoria` (`categoria_id`);

--
-- Índices de tabela `patrimonio`
--
ALTER TABLE `patrimonio`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tombamento` (`tombamento`),
  ADD KEY `idx_patrimonio_material` (`material_id`),
  ADD KEY `idx_patrimonio_local` (`local_id`);

--
-- Índices de tabela `saidas`
--
ALTER TABLE `saidas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `idx_saidas_material` (`material_id`),
  ADD KEY `idx_saidas_data` (`data_saida`);

--
-- Índices de tabela `tramitacoes`
--
ALTER TABLE `tramitacoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_solicitante` (`usuario_solicitante`),
  ADD KEY `usuario_responsavel` (`usuario_responsavel`),
  ADD KEY `idx_tramitacoes_status` (`status`),
  ADD KEY `idx_tramitacoes_data` (`data_solicitacao`);

--
-- Índices de tabela `tramitacoes_arquivos`
--
ALTER TABLE `tramitacoes_arquivos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tramitacao_id` (`tramitacao_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cpf` (`cpf`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `entradas`
--
ALTER TABLE `entradas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `locais`
--
ALTER TABLE `locais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de tabela `materiais`
--
ALTER TABLE `materiais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `patrimonio`
--
ALTER TABLE `patrimonio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `saidas`
--
ALTER TABLE `saidas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tramitacoes`
--
ALTER TABLE `tramitacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `tramitacoes_arquivos`
--
ALTER TABLE `tramitacoes_arquivos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `entradas`
--
ALTER TABLE `entradas`
  ADD CONSTRAINT `entradas_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `materiais` (`id`),
  ADD CONSTRAINT `entradas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `materiais`
--
ALTER TABLE `materiais`
  ADD CONSTRAINT `materiais_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);

--
-- Restrições para tabelas `patrimonio`
--
ALTER TABLE `patrimonio`
  ADD CONSTRAINT `patrimonio_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `materiais` (`id`),
  ADD CONSTRAINT `patrimonio_ibfk_2` FOREIGN KEY (`local_id`) REFERENCES `locais` (`id`);

--
-- Restrições para tabelas `saidas`
--
ALTER TABLE `saidas`
  ADD CONSTRAINT `saidas_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `materiais` (`id`),
  ADD CONSTRAINT `saidas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `tramitacoes`
--
ALTER TABLE `tramitacoes`
  ADD CONSTRAINT `tramitacoes_ibfk_1` FOREIGN KEY (`usuario_solicitante`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `tramitacoes_ibfk_2` FOREIGN KEY (`usuario_responsavel`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `tramitacoes_arquivos`
--
ALTER TABLE `tramitacoes_arquivos`
  ADD CONSTRAINT `tramitacoes_arquivos_ibfk_1` FOREIGN KEY (`tramitacao_id`) REFERENCES `tramitacoes` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
