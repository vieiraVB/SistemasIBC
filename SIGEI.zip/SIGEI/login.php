<?php
require_once 'config.php';

function normalize_cpf($cpf)
{
    return preg_replace('/\D/', '', $cpf);
}

// Se já estiver logado, redirecionar para o dashboard
if (isset($_SESSION['usuario_id'])) {
    header('Location: dashboard.php');
    exit();
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cpf_raw = $_POST['cpf'] ?? '';
    $senha   = $_POST['senha'] ?? '';

    $cpf = normalize_cpf($cpf_raw); // remove pontos, traços e espaços

    if (empty($cpf) || empty($senha)) {
        $erro = 'Por favor, preencha todos os campos.';
    } elseif (!validarCPF($cpf)) {
        $erro = 'CPF inválido.';
    } else {
        try {
            $stmt = $pdo->prepare("
                SELECT * FROM usuarios 
                WHERE REPLACE(REPLACE(REPLACE(cpf, '.', ''), '-', ''), ' ', '') = :cpf
            ");
            $stmt->bindValue(':cpf', $cpf);
            $stmt->execute();
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($usuario && password_verify($senha, $usuario['senha'])) {
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nome'] = $usuario['nome'];
                $_SESSION['nivel_acesso'] = $usuario['nivel_acesso'];

                header('Location: dashboard.php');
                exit();
            } else {
                $erro = 'CPF ou senha incorretos.';
            }
        } catch (PDOException $e) {
            $erro = 'Erro no sistema. Tente novamente.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <style>
        /* Reset e configurações básicas */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Variáveis CSS */
        :root {
            --primary-color: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary-color: #64748b;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-gray: #f8fafc;
            --medium-gray: #e2e8f0;
            --dark-gray: #475569;
            --white: #ffffff;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            --border-radius: 0.5rem;
            --border-radius-lg: 0.75rem;
        }

        /* Tela de Login */
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            background-image: url("background.jpg");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        /* Otimização para dispositivos móveis */
        @media (max-width: 768px) {
            .login-container {
                background-attachment: scroll;
                background-size: cover;
            }
        }

        .login-card {
            background: var(--white);
            padding: 2rem;
            border-radius: var(--border-radius-lg);
            box-shadow: var(--shadow-lg);
            width: 100%;
            max-width: 400px;
            animation: slideUp 0.5s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .login-header h1 {
            color: var(--primary-color);
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .login-header p {
            color: var(--secondary-color);
            font-size: 0.875rem;
        }

        /* Formulários */
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--dark-gray);
            font-size: 0.875rem;
        }

        .form-input {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid var(--medium-gray);
            border-radius: var(--border-radius);
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: var(--white);
        }

        .form-input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .form-input::placeholder {
            color: #9ca3af;
        }

        /* Botões */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: var(--border-radius);
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            min-height: 44px;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: var(--white);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow);
        }

        .btn-full {
            width: 100%;
        }

        /* Alertas */
        .alert {
            padding: 1rem;
            border-radius: var(--border-radius);
            margin-bottom: 1rem;
            border-left: 4px solid;
        }

        .alert-error {
            background-color: #fef2f2;
            border-color: var(--danger-color);
            color: #991b1b;
        }

        /* Responsividade */
        @media (max-width: 576px) {
            .login-container {
                padding: 0.5rem;
            }

            .login-card {
                margin: 0.5rem;
                padding: 1rem;
                max-width: 100%;
            }

            .login-header h1 {
                font-size: 1.5rem;
            }

            .form-input {
                padding: 0.875rem;
                font-size: 1rem;
            }
        }

        /* Máscara para CPF */
        .cpf-mask {
            font-family: monospace;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <h1>SIGEI</h1>
                <p>Sistema de Gerenciamento de Equipamentos e Insumos</p>
            </div>

            <?php if ($erro): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($erro); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="cpf" class="form-label">CPF</label>
                    <input
                        type="text"
                        id="cpf"
                        name="cpf"
                        class="form-input cpf-mask"
                        placeholder="000.000.000-00"
                        maxlength="14"
                        required
                        value="<?php echo isset($_POST['cpf']) ? htmlspecialchars($_POST['cpf']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label for="senha" class="form-label">Senha</label>
                    <input
                        type="password"
                        id="senha"
                        name="senha"
                        class="form-input"
                        placeholder="Digite sua senha"
                        required>
                </div>

                <button type="submit" class="btn btn-primary btn-full">
                    Entrar
                </button>
            </form>
        </div>
    </div>

    <script>
        // Máscara para CPF
        document.getElementById('cpf').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
            e.target.value = value;
        });

        // Foco automático no primeiro campo
        document.getElementById('cpf').focus();
    </script>
</body>

</html>