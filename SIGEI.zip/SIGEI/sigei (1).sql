-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24/09/2025 às 20:52
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sigei`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `tipo` enum('equipamento','insumo') NOT NULL DEFAULT 'equipamento',
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `categorias`
--

INSERT INTO `categorias` (`id`, `nome`, `descricao`, `tipo`, `data_criacao`) VALUES
(1, 'Equipamentos de Informática', 'Computadores, monitores, periféricos', 'equipamento', '2025-09-21 05:07:21'),
(2, 'Material de Escritório', 'Papéis, canetas, grampeadores', 'insumo', '2025-09-21 05:07:21'),
(3, 'Equipamentos de Laboratório', 'Microscópios, vidrarias, equipamentos científicos', 'equipamento', '2025-09-21 05:07:21'),
(4, 'Produtos de Limpeza', 'Detergentes, desinfetantes, panos', 'insumo', '2025-09-21 05:07:21'),
(5, 'Material Didático', 'Livros, apostilas, materiais educativos', 'equipamento', '2025-09-21 05:07:21');

-- --------------------------------------------------------

--
-- Estrutura para tabela `entradas`
--

CREATE TABLE `entradas` (
  `id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `data_entrada` date NOT NULL,
  `responsavel_recebimento` varchar(100) NOT NULL,
  `observacoes` text DEFAULT NULL,
  `numero_nota_fiscal` varchar(50) DEFAULT NULL,
  `fornecedor` varchar(100) DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Acionadores `entradas`
--
DELIMITER $$
CREATE TRIGGER `atualizar_estoque_entrada` AFTER INSERT ON `entradas` FOR EACH ROW BEGIN
    UPDATE materiais 
    SET quantidade_total = quantidade_total + NEW.quantidade
    WHERE id = NEW.material_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `locais`
--

CREATE TABLE `locais` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `tipo` enum('laboratorio','sala','setor') NOT NULL,
  `descricao` text DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `locais`
--

INSERT INTO `locais` (`id`, `nome`, `tipo`, `descricao`, `ativo`, `data_criacao`) VALUES
(1, 'Laboratório 1', 'laboratorio', 'Laboratório de Informática 1', 1, '2025-09-21 05:07:21'),
(2, 'Laboratório 2', 'laboratorio', 'Laboratório de Informática 2', 1, '2025-09-21 05:07:21'),
(3, 'Laboratório 3', 'laboratorio', 'Laboratório de Informática 3', 1, '2025-09-21 05:07:21'),
(4, 'Laboratório 4', 'laboratorio', 'Laboratório de Informática 4', 1, '2025-09-21 05:07:21'),
(5, 'Laboratório 5', 'laboratorio', 'Laboratório de Informática 5', 1, '2025-09-21 05:07:21'),
(6, 'Laboratório 6', 'laboratorio', 'Laboratório de Informática 6', 1, '2025-09-21 05:07:21'),
(7, 'Laboratório 7', 'laboratorio', 'Laboratório de Informática 7', 1, '2025-09-21 05:07:21'),
(8, 'Laboratório 8', 'laboratorio', 'Laboratório de Informática 8', 1, '2025-09-21 05:07:21'),
(9, 'Laboratório 9', 'laboratorio', 'Laboratório de Informática 9', 1, '2025-09-21 05:07:21'),
(10, 'Laboratório 10', 'laboratorio', 'Laboratório de Informática 10', 1, '2025-09-21 05:07:21'),
(11, 'Laboratório 11', 'laboratorio', 'Laboratório de Informática 11', 1, '2025-09-21 05:07:21'),
(12, 'Sala 1', 'sala', 'Sala de Aula 1', 1, '2025-09-21 05:07:21'),
(13, 'Sala 2', 'sala', 'Sala de Aula 2', 1, '2025-09-21 05:07:21'),
(14, 'Sala 3', 'sala', 'Sala de Aula 3', 1, '2025-09-21 05:07:21'),
(15, 'Sala 4', 'sala', 'Sala de Aula 4', 1, '2025-09-21 05:07:21'),
(16, 'Sala 5', 'sala', 'Sala de Aula 5', 1, '2025-09-21 05:07:21'),
(17, 'Sala 6', 'sala', 'Sala de Aula 6', 1, '2025-09-21 05:07:21'),
(18, 'Sala 7', 'sala', 'Sala de Aula 7', 1, '2025-09-21 05:07:21'),
(19, 'Sala 8', 'sala', 'Sala de Aula 8', 1, '2025-09-21 05:07:21'),
(20, 'Sala 9', 'sala', 'Sala de Aula 9', 1, '2025-09-21 05:07:21'),
(21, 'Sala 10', 'sala', 'Sala de Aula 10', 1, '2025-09-21 05:07:21'),
(22, 'Sala 11', 'sala', 'Sala de Aula 11', 1, '2025-09-21 05:07:21'),
(23, 'Coordenação', 'setor', 'Coordenação Acadêmica', 1, '2025-09-21 05:07:21'),
(24, 'Diretoria', 'setor', 'Diretoria Geral', 1, '2025-09-21 05:07:21'),
(25, 'Gerência de Tecnologia', 'setor', 'Gerência de Tecnologia da Informação', 1, '2025-09-21 05:07:21'),
(26, 'Secretaria', 'setor', 'Secretaria Acadêmica', 1, '2025-09-21 05:07:21'),
(27, 'Biblioteca', 'setor', 'Biblioteca Central', 1, '2025-09-21 05:07:21'),
(28, 'Laboratório de ESD', 'laboratorio', 'Laboratório Especializado', 1, '2025-09-21 06:15:37'),
(29, 'Laboratório de Automação', 'laboratorio', 'Laboratório Especializado', 1, '2025-09-21 06:15:37'),
(30, 'Laboratório de Eletricidade', 'laboratorio', 'Laboratório Especializado', 1, '2025-09-21 06:15:37'),
(31, 'Laboratório de Eletrotécnica', 'laboratorio', NULL, 1, '2025-09-21 06:15:37');

-- --------------------------------------------------------

--
-- Estrutura para tabela `materiais`
--

CREATE TABLE `materiais` (
  `id` int(11) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `descricao` text DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `quantidade_total` int(11) DEFAULT 0,
  `estoque_minimo` int(11) DEFAULT NULL,
  `unidade_medida` varchar(20) DEFAULT 'unidade',
  `valor_unitario` decimal(10,2) DEFAULT 0.00,
  `ativo` tinyint(1) DEFAULT 1,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `materiais`
--

INSERT INTO `materiais` (`id`, `codigo`, `nome`, `descricao`, `categoria_id`, `quantidade_total`, `estoque_minimo`, `unidade_medida`, `valor_unitario`, `ativo`, `data_criacao`, `data_atualizacao`) VALUES
(1079, 'MAT-0001', 'Adaptador de Tomada ', 'Adaptador de Tomada ', 1, 34, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1080, 'MAT-0002', 'Adaptador USB Tipo C', 'Adaptador USB Tipo C', 1, 27, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1081, 'MAT-0003', 'Arduino nano ', 'Arduino nano ', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1082, 'MAT-0004', 'Arduino Lilypad', 'Arduino Lilypad', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1083, 'MAT-0005', 'Adaptadores Wireless', 'Adaptadores Wireless', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1084, 'MAT-0006', 'Alicate Amperímetro Digital ET-3III ', 'Alicate Amperímetro Digital ET-3III ', 1, 4, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1085, 'MAT-0007', 'Alicate Aperímetro LWJ - 302', 'Alicate Aperímetro LWJ - 302', 1, 10, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1086, 'MAT-0008', 'Alicate Corte Diagonal 105x65mm ', 'Alicate Corte Diagonal 105x65mm ', 1, 5, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1087, 'MAT-0009', 'Alicate Corte Diagonal 6.1/2 ', 'Alicate Corte Diagonal 6.1/2 ', 1, 5, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1088, 'MAT-0010', 'Alicate Corte Rente Zero Ac-12 ', 'Alicate Corte Rente Zero Ac-12 ', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1089, 'MAT-0011', 'Alicate de Crimpagem ', 'Alicate de Crimpagem ', 1, 27, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1090, 'MAT-0012', 'Alicate de Inserção HT3140 ', 'Alicate de Inserção HT3140 ', 1, 23, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1091, 'MAT-0013', 'Alicate Tipo Telefone 6,1/2 ', 'Alicate Tipo Telefone 6,1/2 ', 1, 25, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:51', '2025-09-23 20:48:51'),
(1092, 'MAT-0014', 'Alicate Universal Isolado ', 'Alicate Universal Isolado ', 1, 8, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1093, 'MAT-0015', 'Bomba de Esgoto 350GPH ', 'Bomba de Esgoto 350GPH ', 1, 5, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1094, 'MAT-0016', 'Cabo Coaxial BNC ', 'Cabo Coaxial BNC ', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1095, 'MAT-0017', 'Cabo Console', 'Cabo Console', 1, 12, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1096, 'MAT-0018', 'Cabo de Força ', 'Cabo de Força ', 1, 140, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1097, 'MAT-0019', 'Cabo de Impressora ', 'Cabo de Impressora ', 1, 20, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1098, 'MAT-0020', 'Cabo DP para  DVI Fêmea ', 'Cabo DP para  DVI Fêmea ', 1, 165, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1099, 'MAT-0021', 'Cabo DP para HDMI Macho ', 'Cabo DP para HDMI Macho ', 1, 90, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1100, 'MAT-0022', 'Cabo DVI ', 'Cabo DVI ', 1, 135, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1101, 'MAT-0023', 'Cabo Flexível Amarelo', 'Cabo Flexível Amarelo', 1, 5, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1102, 'MAT-0024', 'Cabo Flexível Azul ', 'Cabo Flexível Azul ', 1, 10, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1103, 'MAT-0025', 'Cabo Flexível Cinza', 'Cabo Flexível Cinza', 1, 15, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1104, 'MAT-0026', 'Cabo Flexível Verde', 'Cabo Flexível Verde', 1, 7, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1105, 'MAT-0027', 'Cabo Flexível Vermelho', 'Cabo Flexível Vermelho', 1, 11, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1106, 'MAT-0028', 'Cabo Resolver CR 1,5mm', 'Cabo Resolver CR 1,5mm', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1107, 'MAT-0029', 'Cabo Serial ', 'Cabo Serial ', 1, 9, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1108, 'MAT-0030', 'Cabo USB', 'Cabo USB', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1109, 'MAT-0031', 'Cabo VGA CKIT6305 ', 'Cabo VGA CKIT6305 ', 1, 61, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1110, 'MAT-0032', 'Cabos de Arduino', 'Cabos de Arduino', 1, 8, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1111, 'MAT-0033', 'Cabos HDMI ', 'Cabos HDMI ', 1, 6, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1112, 'MAT-0034', 'Caixa de embutir 4x2 ', 'Caixa de embutir 4x2 ', 1, 19, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1113, 'MAT-0035', 'Caixa de embutir 4x4 ', 'Caixa de embutir 4x4 ', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1114, 'MAT-0036', 'Caixa de Sobrepor Sistema ', 'Caixa de Sobrepor Sistema ', 1, 32, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1115, 'MAT-0037', 'Caixa Múltipla 3/4', 'Caixa Múltipla 3/4', 1, 86, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1116, 'MAT-0038', 'Câmera IP Power Fl895E ', 'Câmera IP Power Fl895E ', 1, 37, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1117, 'MAT-0039', 'Cartucho de Toner Amarelo SMSCLP680', 'Cartucho de Toner Amarelo SMSCLP680', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1118, 'MAT-0040', 'Cartucho de Toner Ciano SMSCLP680', 'Cartucho de Toner Ciano SMSCLP680', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1119, 'MAT-0041', 'Cartucho de Toner Magenta SMSCLP680', 'Cartucho de Toner Magenta SMSCLP680', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1120, 'MAT-0042', 'Cartucho de Toner Preto SMSCLP680', 'Cartucho de Toner Preto SMSCLP680', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1121, 'MAT-0043', 'Circuito Integrado 718/0808', 'Circuito Integrado 718/0808', 1, 9, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1122, 'MAT-0044', 'Contador Auxiliar CA2KN22M7 ', 'Contador Auxiliar CA2KN22M7 ', 1, 5, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1123, 'MAT-0045', 'Conversor de mídia UTP/ST Ethernet AT-MC ', 'Conversor de mídia UTP/ST Ethernet AT-MC ', 1, 8, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1124, 'MAT-0046', 'Development Kit', 'Development Kit', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1125, 'MAT-0047', 'Display LCD', 'Display LCD', 1, 3, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1126, 'MAT-0048', 'Dispositivo De Aplicação Virtual', 'Dispositivo De Aplicação Virtual', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1127, 'MAT-0049', 'Dissipador HP ', 'Dissipador HP ', 1, 10, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1128, 'MAT-0050', 'Estabilizador (SALA MAKER)', 'Estabilizador (SALA MAKER)', 1, 21, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1129, 'MAT-0051', 'Estanhador de Fios CT-11C ', 'Estanhador de Fios CT-11C ', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1130, 'MAT-0052', 'Extensão Elétrica Multipla 5M', 'Extensão Elétrica Multipla 5M', 1, 7, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1131, 'MAT-0053', 'Fios Eletrônica p/2 Coloridos', 'Fios Eletrônica p/2 Coloridos', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1132, 'MAT-0054', 'Fonte DC', 'Fonte DC', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1133, 'MAT-0055', 'Fonte TP2305C', 'Fonte TP2305C', 1, 4, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1134, 'MAT-0056', 'HD externo ', 'HD externo ', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1135, 'MAT-0057', 'Interface de Comando Industrial', 'Interface de Comando Industrial', 1, 26, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1136, 'MAT-0058', 'Interruptor Diferencial 4P 63A ', 'Interruptor Diferencial 4P 63A ', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1137, 'MAT-0059', 'Kit Conjunto Manômetro R22/134ª/404AM ', 'Kit Conjunto Manômetro R22/134ª/404AM ', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1138, 'MAT-0060', 'Kit CPLD', 'Kit CPLD', 1, 10, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1139, 'MAT-0061', 'Kit de Punção P/ Perfurador ', 'Kit de Punção P/ Perfurador ', 1, 8, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1140, 'MAT-0062', 'Kit Diático CLP KDCLP-01 ', 'Kit Diático CLP KDCLP-01 ', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1141, 'MAT-0063', 'Kit Diático para Circuitos ', 'Kit Diático para Circuitos ', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1142, 'MAT-0064', 'Kit Eletrônico Digital', 'Kit Eletrônico Digital', 1, 7, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1143, 'MAT-0065', 'Kit fonte Multímetro Digital 830B ', 'Kit fonte Multímetro Digital 830B ', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1144, 'MAT-0066', 'Localizador de Cabo de Rede Kit', 'Localizador de Cabo de Rede Kit', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1145, 'MAT-0067', 'Lupa com Suporte e Pinça HL-S10 ', 'Lupa com Suporte e Pinça HL-S10 ', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1146, 'MAT-0068', 'Microcontrolador de treino', 'Microcontrolador de treino', 1, 10, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1147, 'MAT-0069', 'Microfone Dinamico sem fio', 'Microfone Dinamico sem fio', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1148, 'MAT-0070', 'Micrômetro Externo 0-25mm ', 'Micrômetro Externo 0-25mm ', 1, 11, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1149, 'MAT-0071', 'Módulo Microcontrolador', 'Módulo Microcontrolador', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1150, 'MAT-0072', 'Modulo Placa 4x4 ', 'Modulo Placa 4x4 ', 1, 50, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1151, 'MAT-0073', 'Monitor', 'Monitor', 1, 10, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1152, 'MAT-074', 'Mouse sem fio Sem adaptador', 'Mouse sem fio Sem adaptador', 1, 7, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 22:09:50'),
(1153, 'MAT-075', 'Mouse com fio ', 'Mouse com fio ', 3, 99, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 23:04:10'),
(1154, 'MAT-076', 'Mouse com fio Logetech', 'Mouse com fio Logetech', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 22:09:50'),
(1155, 'MAT-077', 'Mouse sem fio Logetech Sem adaptador', 'Mouse sem fio Logetech Sem adaptador', 1, 12, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 22:09:50'),
(1156, 'MAT-078', 'Mouse sem fio Logetech ', 'Mouse sem fio Logetech ', 1, 36, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 22:09:50'),
(1157, 'MAT-0079', 'Multímetro Digital DM-1000 ', 'Multímetro Digital DM-1000 ', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1158, 'MAT-0080', 'Multímetro Digital DT- 831B+ ', 'Multímetro Digital DT- 831B+ ', 1, 7, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1159, 'MAT-0081', 'Multímetro Digital DT-830B ', 'Multímetro Digital DT-830B ', 1, 5, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1160, 'MAT-0082', 'Módulo leito de acerto RFID', 'Módulo leito de acerto RFID', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1161, 'MAT-0083', 'Módulo FTDI Basic', 'Módulo FTDI Basic', 1, 3, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1162, 'MAT-0084', 'Módulo Ethernet', 'Módulo Ethernet', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1163, 'MAT-0085', 'Módulo Semáforo', 'Módulo Semáforo', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1164, 'MAT-0086', 'Módulo HX711 conversor analogico Digital', 'Módulo HX711 conversor analogico Digital', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1165, 'MAT-0087', 'Módulo XBEE Com antena e adptador ', 'Módulo XBEE Com antena e adptador ', 1, 3, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1166, 'MAT-0088', 'Módulo XBEE Com antena  ', 'Módulo XBEE Com antena  ', 1, 5, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1167, 'MAT-0089', 'Módulo bluetooth HC-05', 'Módulo bluetooth HC-05', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1168, 'MAT-0090', 'Módulo MP3 WTV 020D', 'Módulo MP3 WTV 020D', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1169, 'MAT-0091', 'Módulo Recptor Infra-vermelho', 'Módulo Recptor Infra-vermelho', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1170, 'MAT-0092', 'Módulo Amperimetro CC', 'Módulo Amperimetro CC', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1171, 'MAT-0093', 'MÓDULO AMPERÍMETRO CA', 'MÓDULO AMPERÍMETRO CA', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1172, 'MAT-0094', 'MÓDULO CHAVE SELETORA 2NA+2NF', 'MÓDULO CHAVE SELETORA 2NA+2NF', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1173, 'MAT-0095', 'MÓDULO WATTIMETRO', 'MÓDULO WATTIMETRO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1174, 'MAT-0096', 'MÓDULO COSFÍMETRO', 'MÓDULO COSFÍMETRO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1175, 'MAT-0097', 'MÓDULO FREQUENCÍMETRO', 'MÓDULO FREQUENCÍMETRO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1176, 'MAT-0098', 'MÓDULO INTERLIGAÇÕES', 'MÓDULO INTERLIGAÇÕES', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1177, 'MAT-0099', 'MÓDULO DIMMER E LÂMPADA', 'MÓDULO DIMMER E LÂMPADA', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1178, 'MAT-0100', 'MÓDULO CONTATOR AUXILIAR 24 Vcc', 'MÓDULO CONTATOR AUXILIAR 24 Vcc', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1179, 'MAT-0101', 'MÓDULO RELÉ TÉRMICO 2,8...4A', 'MÓDULO RELÉ TÉRMICO 2,8...4A', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1180, 'MAT-0102', 'MÓDULO RELÉ TEMPORIZADOR 24 Vcc', 'MÓDULO RELÉ TEMPORIZADOR 24 Vcc', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1181, 'MAT-0103', 'MÓDULO DE SEGURANÇA', 'MÓDULO DE SEGURANÇA', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1182, 'MAT-0104', 'MÓDULO RELÉ TEMPORIZADOR Y-Δ', 'MÓDULO RELÉ TEMPORIZADOR Y-Δ', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1183, 'MAT-0105', 'MÓDULO RELÉ FOTOELÉTRICO', 'MÓDULO RELÉ FOTOELÉTRICO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1184, 'MAT-0106', 'MÓDULO RELÊ COMUTADOR', 'MÓDULO RELÊ COMUTADOR', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1185, 'MAT-0107', 'MÓDULO RELÉ DE ESTADO SÓLIDO', 'MÓDULO RELÉ DE ESTADO SÓLIDO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1186, 'MAT-0108', 'MÓDULO RELÉ DE SOBRECARGA', 'MÓDULO RELÉ DE SOBRECARGA', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1187, 'MAT-0109', 'MÓDULO RELÉ FALTA DE FASE', 'MÓDULO RELÉ FALTA DE FASE', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1188, 'MAT-0110', 'MÓDULO RELÉ TEMPORIZADOR', 'MÓDULO RELÉ TEMPORIZADOR', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1189, 'MAT-0111', 'MÓDULO RELÉ SEGURANÇA', 'MÓDULO RELÉ SEGURANÇA', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1190, 'MAT-0112', 'MÓDULO RESISTORES 10W', 'MÓDULO RESISTORES 10W', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1191, 'MAT-0113', 'MÓDULO FIM DE CURSO', 'MÓDULO FIM DE CURSO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1192, 'MAT-0114', 'MÓDULO CONTROLADOR DE TEMPERATURA', 'MÓDULO CONTROLADOR DE TEMPERATURA', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1193, 'MAT-0115', 'MÓDULO RETIFICADOR', 'MÓDULO RETIFICADOR', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1194, 'MAT-0116', 'MÓDULO CONTATOR TRIPOLAR', 'MÓDULO CONTATOR TRIPOLAR', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1195, 'MAT-0117', 'MÓDULO CONTATOR AUXILIAR', 'MÓDULO CONTATOR AUXILIAR', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1196, 'MAT-0118', 'MÓDULO DISJUNTOR MONOPOLAR', 'MÓDULO DISJUNTOR MONOPOLAR', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1197, 'MAT-0119', 'MÓDULO CHAVE FIM DE CURSO', 'MÓDULO CHAVE FIM DE CURSO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1198, 'MAT-0120', 'MÓDULO INTERRUPTOR SIMPLES E PARALELO', 'MÓDULO INTERRUPTOR SIMPLES E PARALELO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1199, 'MAT-0121', 'MÓDULO QUADRO DE DISJUNTORES', 'MÓDULO QUADRO DE DISJUNTORES', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1200, 'MAT-0122', 'MÓDULO FUSÍVEIS', 'MÓDULO FUSÍVEIS', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1201, 'MAT-0123', 'MÓDULO 3 FUSÍVEIS 25A', 'MÓDULO 3 FUSÍVEIS 25A', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1202, 'MAT-0124', 'MÓDULO CAPACITORES', 'MÓDULO CAPACITORES', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1203, 'MAT-0125', 'MÓDULO DISJUNTOR MOTOR ', 'MÓDULO DISJUNTOR MOTOR ', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1204, 'MAT-0126', 'MODULO FONTE DE TENSÃO', 'MODULO FONTE DE TENSÃO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1205, 'MAT-0127', 'MÓDULO BOTÃO PULSADOR 2NA + 2NF', 'MÓDULO BOTÃO PULSADOR 2NA + 2NF', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1206, 'MAT-0128', 'MÓDULO SINALEIROS LED - 24 VCC', 'MÓDULO SINALEIROS LED - 24 VCC', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1207, 'MAT-0129', 'MÓDULO BOTOEIRA 2NA+2NF', 'MÓDULO BOTOEIRA 2NA+2NF', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1208, 'MAT-0130', 'MÓDULO 3 SINALEIROS', 'MÓDULO 3 SINALEIROS', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1209, 'MAT-0131', 'MÓDULO CENTRAL TELEFONICA', 'MÓDULO CENTRAL TELEFONICA', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1210, 'MAT-0132', 'MODULO M MEDIDOR DE EN ENERGIA ATIVA', 'MODULO M MEDIDOR DE EN ENERGIA ATIVA', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1211, 'MAT-0133', 'MÓDULO CENTRAL DE ALARME', 'MÓDULO CENTRAL DE ALARME', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1212, 'MAT-0134', 'MÓDULO CAMPAINHA', 'MÓDULO CAMPAINHA', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1213, 'MAT-0135', 'MÓDULO LAMPADAS FLUORESCENTES', 'MÓDULO LAMPADAS FLUORESCENTES', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:52', '2025-09-23 20:48:52'),
(1214, 'MAT-0136', 'MÓDULO SENSOR INFRAVERMELHO', 'MÓDULO SENSOR INFRAVERMELHO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1215, 'MAT-0137', 'MÓDULO TERMOSTATO', 'MÓDULO TERMOSTATO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1216, 'MAT-0138', 'MÓDULO SENSOR DE ABERTURA COM FIO', 'MÓDULO SENSOR DE ABERTURA COM FIO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1217, 'MAT-0139', 'MÓDULO SENSOR DE ABERTURA SEM FIO', 'MÓDULO SENSOR DE ABERTURA SEM FIO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1218, 'MAT-0140', 'MÓDULO RESISTIVO', 'MÓDULO RESISTIVO', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1219, 'MAT-0141', 'MÓDULO SIMULAÇÃO DE DEFEITOS', 'MÓDULO SIMULAÇÃO DE DEFEITOS', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1220, 'MAT-0142', 'Multímetro Digital ET-1100A ', 'Multímetro Digital ET-1100A ', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1221, 'MAT-0143', 'Nobreak EasyWay ', 'Nobreak EasyWay ', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1222, 'MAT-0144', 'Osciloscópio Digital TSO1102C+', 'Osciloscópio Digital TSO1102C+', 1, 3, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1223, 'MAT-0145', 'PCB com sensor de vibração', 'PCB com sensor de vibração', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1224, 'MAT-0146', 'Paquímetro Analógico 300mm/12 ', 'Paquímetro Analógico 300mm/12 ', 1, 83, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1225, 'MAT-0147', 'Paquímetro Digital 150mm/6 ', 'Paquímetro Digital 150mm/6 ', 1, 4, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1226, 'MAT-0148', 'Placa Analogica Digital', 'Placa Analogica Digital', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1227, 'MAT-0149', 'Placa Arduino', 'Placa Arduino', 1, 3, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1228, 'MAT-0150', 'Placa Bread Board', 'Placa Bread Board', 1, 15, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1229, 'MAT-0151', 'Placa Buffer', 'Placa Buffer', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1230, 'MAT-0152', 'Placa Comparador de Magnitude ', 'Placa Comparador de Magnitude ', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1231, 'MAT-0153', 'Placa de Automação AI-8S', 'Placa de Automação AI-8S', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1232, 'MAT-0154', 'Placa de Logica Gates', 'Placa de Logica Gates', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1233, 'MAT-0155', 'Placa Decodificador Binário', 'Placa Decodificador Binário', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1234, 'MAT-0156', 'Placa Eprom', 'Placa Eprom', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1235, 'MAT-0157', 'Placa Ethernet ( Arduino )', 'Placa Ethernet ( Arduino )', 1, 4, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1236, 'MAT-0158', 'Placa Flip-Flop', 'Placa Flip-Flop', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1237, 'MAT-0159', 'Placa Sistema X para XRJ45 ', 'Placa Sistema X para XRJ45 ', 1, 13, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1238, 'MAT-0160', 'Ponta de Prova de Osciloscópio LF-20A/ LF-60/ LF-100A ', 'Ponta de Prova de Osciloscópio LF-20A/ LF-60/ LF-100A ', 1, 5, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1239, 'MAT-0161', 'Ponta de Prova de Osciloscópio MTL-21 ', 'Ponta de Prova de Osciloscópio MTL-21 ', 1, 21, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1240, 'MAT-0162', 'Ponta de Prova de Osciloscópio P2200 ', 'Ponta de Prova de Osciloscópio P2200 ', 1, 5, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1241, 'MAT-0163', 'Ponta de Prova de Osciloscópio UT-P00 ', 'Ponta de Prova de Osciloscópio UT-P00 ', 1, 11, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1242, 'MAT-0164', 'Pontas de Prova Multímetro Jacaré HK-23 ', 'Pontas de Prova Multímetro Jacaré HK-23 ', 1, 11, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1243, 'MAT-0165', 'Protoboard Hk-P400', 'Protoboard Hk-P400', 1, 12, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1244, 'MAT-0166', 'Protoboard MP-830A', 'Protoboard MP-830A', 1, 9, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1245, 'MAT-0167', 'Pulseira Antiestática N68-S', 'Pulseira Antiestática N68-S', 1, 38, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1246, 'MAT-0168', 'Quadro de Distribuição ', 'Quadro de Distribuição ', 1, 5, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1247, 'MAT-0169', 'Regulador de Tensão AN7809C', 'Regulador de Tensão AN7809C', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1248, 'MAT-0170', 'Regulador de Tensão BD135', 'Regulador de Tensão BD135', 1, 28, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1249, 'MAT-0171', 'Regulador de Tensão BD156', 'Regulador de Tensão BD156', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1250, 'MAT-0172', 'Regulador de Tensão BT137', 'Regulador de Tensão BT137', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1251, 'MAT-0173', 'Regulador de Tensão BT151', 'Regulador de Tensão BT151', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1252, 'MAT-0174', 'Regulador de Tensão D49/30N06L', 'Regulador de Tensão D49/30N06L', 1, 12, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1253, 'MAT-0175', 'Regulador de Tensão G40LP ', 'Regulador de Tensão G40LP ', 1, 4, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1254, 'MAT-0176', 'Regulador de Tensão L7805', 'Regulador de Tensão L7805', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1255, 'MAT-0177', 'Regulador de Tensão L7805CV', 'Regulador de Tensão L7805CV', 1, 49, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1256, 'MAT-0178', 'Regulador de Tensão L7808', 'Regulador de Tensão L7808', 1, 27, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1257, 'MAT-0179', 'Regulador de Tensão L7905CV', 'Regulador de Tensão L7905CV', 1, 74, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1258, 'MAT-0180', 'Regulador de Tensão L7912CV', 'Regulador de Tensão L7912CV', 1, 36, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1259, 'MAT-0181', 'Regulador de Tensão LM317T', 'Regulador de Tensão LM317T', 1, 42, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1260, 'MAT-0182', 'Regulador de Tensão LM338', 'Regulador de Tensão LM338', 1, 4, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1261, 'MAT-0183', 'Regulador de Tensão LM7809C', 'Regulador de Tensão LM7809C', 1, 15, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1262, 'MAT-0184', 'Regulador de Tensão LM7812', 'Regulador de Tensão LM7812', 1, 18, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1263, 'MAT-0185', 'Regulador de Tensão LM7812C', 'Regulador de Tensão LM7812C', 1, 22, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1264, 'MAT-0186', 'Regulador de Tensão P41C', 'Regulador de Tensão P41C', 1, 39, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1265, 'MAT-0187', 'Regulador de Tensão PHG950', 'Regulador de Tensão PHG950', 1, 16, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1266, 'MAT-0188', 'Regulador de Tensão PJD1045', 'Regulador de Tensão PJD1045', 1, 21, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1267, 'MAT-0189', 'Regulador de Tensão RA7909', 'Regulador de Tensão RA7909', 1, 28, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1268, 'MAT-0190', 'Regulador de Tensão SRTG8656', 'Regulador de Tensão SRTG8656', 1, 7, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1269, 'MAT-0191', 'Regulador de Tensão T1C126D', 'Regulador de Tensão T1C126D', 1, 64, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1270, 'MAT-0192', 'Regulador de Tensão TIC106O', 'Regulador de Tensão TIC106O', 1, 26, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1271, 'MAT-0193', 'Regulador de Tensão TIC126D', 'Regulador de Tensão TIC126D', 1, 30, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1272, 'MAT-0194', 'Regulador de Tensão TIP42C', 'Regulador de Tensão TIP42C', 1, 13, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1273, 'MAT-0195', 'Relógio Comparador 0,01mm ', 'Relógio Comparador 0,01mm ', 1, 12, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1274, 'MAT-0196', 'Rolo de Cabo Cat5e', 'Rolo de Cabo Cat5e', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1275, 'MAT-0197', 'Roteador ', 'Roteador ', 1, 8, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1276, 'MAT-0198', 'Sensor de movimento ', 'Sensor de movimento ', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1277, 'MAT-0199', 'Sensor de Chama ', 'Sensor de Chama ', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1278, 'MAT-0200', 'Sensor de Temperatura ', 'Sensor de Temperatura ', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1279, 'MAT-0201', 'Sensor Ultra Som', 'Sensor Ultra Som', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1280, 'MAT-0202', 'Sensor de rotação ', 'Sensor de rotação ', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1281, 'MAT-0203', 'Sensor Optica reflexiva ', 'Sensor Optica reflexiva ', 1, 4, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1282, 'MAT-0204', 'Sensor com Microfone ', 'Sensor com Microfone ', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1283, 'MAT-0205', 'Sirene Isolada Ademco 748 ', 'Sirene Isolada Ademco 748 ', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1284, 'MAT-0206', 'Suporte de Fixação (Placa) 4x4 ', 'Suporte de Fixação (Placa) 4x4 ', 1, 25, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1285, 'MAT-0207', 'Tampa para Condulete cega 3/4', 'Tampa para Condulete cega 3/4', 1, 16, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1286, 'MAT-0208', 'Teclado ', 'Teclado ', 3, 160, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 23:04:17'),
(1287, 'MAT-0209', 'Testador de Cabo Rj11 Rj45', 'Testador de Cabo Rj11 Rj45', 1, 13, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1288, 'MAT-0210', 'Testador de Pulseira ESD', 'Testador de Pulseira ESD', 1, 3, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1289, 'MAT-0211', 'Traçador de Altura Analogico ', 'Traçador de Altura Analogico ', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1290, 'MAT-0212', 'Transferidor de Grau 10cm ', 'Transferidor de Grau 10cm ', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1291, 'MAT-0213', 'Transformador Pequeno 12v', 'Transformador Pequeno 12v', 1, 0, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1292, 'MAT-0214', 'Caixa de Som', 'Caixa de Som para uso com datashow', 1, 2, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1293, 'MAT-0215', 'Microfone', 'Microfone para uso com datashow', 1, 1, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1294, 'MAT-0216', 'Caixa Organizadora - BIN', 'Caixa para organização de itens', 1, 204, 5, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1295, 'MAT-0217', 'Abraçadeira de Nylon Branco', 'Abraçadeira de Nylon Branco', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1296, 'MAT-0218', 'Apagador', 'Apagador', 2, 224, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1297, 'MAT-0219', 'Apontador ', 'Apontador ', 2, 27, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1298, 'MAT-0220', 'Barramento Trifásico ', 'Barramento Trifásico ', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1299, 'MAT-0221', 'Bateria 3V CR2032', 'Bateria 3V CR2032', 2, 20, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1300, 'MAT-0222', 'Bateria CR123A 3V', 'Bateria CR123A 3V', 2, 19, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1301, 'MAT-0223', 'Borracha ', 'Borracha ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1302, 'MAT-0224', 'Botão 22mm Duplo Plástico ', 'Botão 22mm Duplo Plástico ', 2, 3, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1303, 'MAT-0225', 'Caixa de Resistor 11KΩ', 'Caixa de Resistor 11KΩ', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1304, 'MAT-0226', 'Caixa de Resistor 22KΩ', 'Caixa de Resistor 22KΩ', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1305, 'MAT-0227', 'Caixa de Resistor 33KΩ', 'Caixa de Resistor 33KΩ', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1306, 'MAT-0228', 'Caixa de Resistor 47KΩ', 'Caixa de Resistor 47KΩ', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1307, 'MAT-0229', 'Caneta Azul', 'Caneta Azul', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1308, 'MAT-0230', 'Capacitor Box', 'Capacitor Box', 2, 8, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1309, 'MAT-0231', 'Capacitor Cerâmico 10', 'Capacitor Cerâmico 10', 2, 78, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1310, 'MAT-0232', 'Capacitor Cerâmico 100', 'Capacitor Cerâmico 100', 2, 8, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1311, 'MAT-0233', 'Capacitor Cerâmico 101', 'Capacitor Cerâmico 101', 2, 90, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1312, 'MAT-0234', 'Capacitor Cerâmico 102', 'Capacitor Cerâmico 102', 2, 150, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1313, 'MAT-0235', 'Capacitor Cerâmico 103', 'Capacitor Cerâmico 103', 2, 96, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1314, 'MAT-0236', 'Capacitor Cerâmico 104', 'Capacitor Cerâmico 104', 2, 306, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1315, 'MAT-0237', 'Capacitor Cerâmico 109', 'Capacitor Cerâmico 109', 2, 23, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1316, 'MAT-0238', 'Capacitor Cerâmico 122', 'Capacitor Cerâmico 122', 2, 87, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1317, 'MAT-0239', 'Capacitor Cerâmico 152', 'Capacitor Cerâmico 152', 2, 39, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1318, 'MAT-0240', 'Capacitor Cerâmico 152K', 'Capacitor Cerâmico 152K', 2, 11, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1319, 'MAT-0241', 'Capacitor Cerâmico 182', 'Capacitor Cerâmico 182', 2, 76, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1320, 'MAT-0242', 'Capacitor Cerâmico 1pF', 'Capacitor Cerâmico 1pF', 2, 62, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:53', '2025-09-23 20:48:53'),
(1321, 'MAT-0243', 'Capacitor Cerâmico 22', 'Capacitor Cerâmico 22', 2, 84, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1322, 'MAT-0244', 'Capacitor Cerâmico 220', 'Capacitor Cerâmico 220', 2, 14, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1323, 'MAT-0245', 'Capacitor Cerâmico 221', 'Capacitor Cerâmico 221', 2, 90, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1324, 'MAT-0246', 'Capacitor Cerâmico 222', 'Capacitor Cerâmico 222', 2, 8, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1325, 'MAT-0247', 'Capacitor Cerâmico 223', 'Capacitor Cerâmico 223', 2, 22, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1326, 'MAT-0248', 'Capacitor Cerâmico 229', 'Capacitor Cerâmico 229', 2, 112, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1327, 'MAT-0249', 'Capacitor Cerâmico 272', 'Capacitor Cerâmico 272', 2, 80, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1328, 'MAT-0250', 'Capacitor Cerâmico 33', 'Capacitor Cerâmico 33', 2, 70, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1329, 'MAT-0251', 'Capacitor Cerâmico 330', 'Capacitor Cerâmico 330', 2, 19, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1330, 'MAT-0252', 'Capacitor Cerâmico 331', 'Capacitor Cerâmico 331', 2, 96, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1331, 'MAT-0253', 'Capacitor Cerâmico 332', 'Capacitor Cerâmico 332', 2, 8, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1332, 'MAT-0254', 'Capacitor Cerâmico 339', 'Capacitor Cerâmico 339', 2, 8, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1333, 'MAT-0255', 'Capacitor Cerâmico 3R3', 'Capacitor Cerâmico 3R3', 2, 66, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1334, 'MAT-0256', 'Capacitor Cerâmico 4.7', 'Capacitor Cerâmico 4.7', 2, 60, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1335, 'MAT-0257', 'Capacitor Cerâmico 470', 'Capacitor Cerâmico 470', 2, 39, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1336, 'MAT-0258', 'Capacitor Cerâmico 471', 'Capacitor Cerâmico 471', 2, 80, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1337, 'MAT-0259', 'Capacitor Cerâmico 472', 'Capacitor Cerâmico 472', 2, 4, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1338, 'MAT-0260', 'Capacitor Cerâmico 473', 'Capacitor Cerâmico 473', 2, 11, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1339, 'MAT-0261', 'Capacitor Cerâmico 474', 'Capacitor Cerâmico 474', 2, 24, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1340, 'MAT-0262', 'Capacitor Cerâmico 479', 'Capacitor Cerâmico 479', 2, 23, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1341, 'MAT-0263', 'Capacitor Cerâmico 5', 'Capacitor Cerâmico 5', 2, 17, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1342, 'MAT-0264', 'Capacitor Cerâmico 68', 'Capacitor Cerâmico 68', 2, 6, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1343, 'MAT-0265', 'Capacitor Cerâmico 681', 'Capacitor Cerâmico 681', 2, 13, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1344, 'MAT-0266', 'Capacitor Cerâmico 682', 'Capacitor Cerâmico 682', 2, 80, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1345, 'MAT-0267', 'Capacitor Eletrolítico 0,1UF 50V', 'Capacitor Eletrolítico 0,1UF 50V', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1346, 'MAT-0268', 'Capacitor Eletrolítico 0,22UF 50V', 'Capacitor Eletrolítico 0,22UF 50V', 2, 18, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1347, 'MAT-0269', 'Capacitor Eletrolítico 0,33UF 50V', 'Capacitor Eletrolítico 0,33UF 50V', 2, 88, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1348, 'MAT-0270', 'Capacitor Eletrolítico 1000UF 10V', 'Capacitor Eletrolítico 1000UF 10V', 2, 60, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1349, 'MAT-0271', 'Capacitor Eletrolítico 1000UF 16V', 'Capacitor Eletrolítico 1000UF 16V', 2, 40, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1350, 'MAT-0272', 'Capacitor Eletrolítico 1000UF 25V', 'Capacitor Eletrolítico 1000UF 25V', 2, 15, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1351, 'MAT-0273', 'Capacitor Eletrolítico 1000UF 50V', 'Capacitor Eletrolítico 1000UF 50V', 2, 25, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1352, 'MAT-0274', 'Capacitor Eletrolítico 100UF 16V', 'Capacitor Eletrolítico 100UF 16V', 2, 30, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1353, 'MAT-0275', 'Capacitor Eletrolítico 100UF 25V', 'Capacitor Eletrolítico 100UF 25V', 2, 104, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1354, 'MAT-0276', 'Capacitor Eletrolítico 100UF 50V', 'Capacitor Eletrolítico 100UF 50V', 2, 85, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1355, 'MAT-0277', 'Capacitor Eletrolítico 10UF 16V', 'Capacitor Eletrolítico 10UF 16V', 2, 27, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1356, 'MAT-0278', 'Capacitor Eletrolítico 10UF 25V', 'Capacitor Eletrolítico 10UF 25V', 2, 10, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1357, 'MAT-0279', 'Capacitor Eletrolítico 10UF 50V', 'Capacitor Eletrolítico 10UF 50V', 2, 55, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1358, 'MAT-0280', 'Capacitor Eletrolítico 10UF 63V', 'Capacitor Eletrolítico 10UF 63V', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1359, 'MAT-0281', 'Capacitor Eletrolítico 1500UF 16V', 'Capacitor Eletrolítico 1500UF 16V', 2, 91, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1360, 'MAT-0282', 'Capacitor Eletrolítico 1UF 25V', 'Capacitor Eletrolítico 1UF 25V', 2, 30, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1361, 'MAT-0283', 'Capacitor Eletrolítico 1UF 50V', 'Capacitor Eletrolítico 1UF 50V', 2, 51, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1362, 'MAT-0284', 'Capacitor Eletrolítico 2,2UF 100V', 'Capacitor Eletrolítico 2,2UF 100V', 2, 44, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1363, 'MAT-0285', 'Capacitor Eletrolítico 2,2UF 50V', 'Capacitor Eletrolítico 2,2UF 50V', 2, 85, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1364, 'MAT-0286', 'Capacitor Eletrolítico 2200UF 10V', 'Capacitor Eletrolítico 2200UF 10V', 2, 276, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1365, 'MAT-0287', 'Capacitor Eletrolítico 2200UF 25V', 'Capacitor Eletrolítico 2200UF 25V', 2, 60, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1366, 'MAT-0288', 'Capacitor Eletrolítico 220UF 16V', 'Capacitor Eletrolítico 220UF 16V', 2, 45, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1367, 'MAT-0289', 'Capacitor Eletrolítico 220UF 25V', 'Capacitor Eletrolítico 220UF 25V', 2, 70, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1368, 'MAT-0290', 'Capacitor Eletrolítico 22UF 16V', 'Capacitor Eletrolítico 22UF 16V', 2, 30, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1369, 'MAT-0291', 'Capacitor Eletrolítico 22UF 25V', 'Capacitor Eletrolítico 22UF 25V', 2, 99, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1370, 'MAT-0292', 'Capacitor Eletrolítico 22UF 400V', 'Capacitor Eletrolítico 22UF 400V', 2, 36, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1371, 'MAT-0293', 'Capacitor Eletrolítico 3,3UF 100V', 'Capacitor Eletrolítico 3,3UF 100V', 2, 39, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1372, 'MAT-0294', 'Capacitor Eletrolítico 3,3UF 50V', 'Capacitor Eletrolítico 3,3UF 50V', 2, 31, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1373, 'MAT-0295', 'Capacitor Eletrolítico 330UF 25V', 'Capacitor Eletrolítico 330UF 25V', 2, 47, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1374, 'MAT-0296', 'Capacitor Eletrolítico 330UF 50V', 'Capacitor Eletrolítico 330UF 50V', 2, 100, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1375, 'MAT-0297', 'Capacitor Eletrolítico 33UF 25V', 'Capacitor Eletrolítico 33UF 25V', 2, 106, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1376, 'MAT-0298', 'Capacitor Eletrolítico 4,7UF 160V', 'Capacitor Eletrolítico 4,7UF 160V', 2, 33, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1377, 'MAT-0299', 'Capacitor Eletrolítico 4,7UF 25V', 'Capacitor Eletrolítico 4,7UF 25V', 2, 44, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1378, 'MAT-0300', 'Capacitor Eletrolítico 4,7UF 50V', 'Capacitor Eletrolítico 4,7UF 50V', 2, 35, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1379, 'MAT-0301', 'Capacitor Eletrolítico 4700UF 25V', 'Capacitor Eletrolítico 4700UF 25V', 2, 39, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1380, 'MAT-0302', 'Capacitor Eletrolítico 470UF 25V', 'Capacitor Eletrolítico 470UF 25V', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1381, 'MAT-0303', 'Capacitor Eletrolítico 470UF 50V', 'Capacitor Eletrolítico 470UF 50V', 2, 94, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1382, 'MAT-0304', 'Capacitor Eletrolítico 47UF 16V', 'Capacitor Eletrolítico 47UF 16V', 2, 32, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1383, 'MAT-0305', 'Capacitor Eletrolítico 47UF 25V', 'Capacitor Eletrolítico 47UF 25V', 2, 78, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1384, 'MAT-0306', 'Capacitor Eletrolítico 47UF 50V ', 'Capacitor Eletrolítico 47UF 50V ', 2, 85, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1385, 'MAT-0307', 'Capacitor Eletrolítico 560UF 200V', 'Capacitor Eletrolítico 560UF 200V', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1386, 'MAT-0308', 'Capacitor Eletrolítico 6,8UF 63V', 'Capacitor Eletrolítico 6,8UF 63V', 2, 5, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1387, 'MAT-0309', 'Capacitor Eletrolítico 60UF 250V', 'Capacitor Eletrolítico 60UF 250V', 2, 7, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1388, 'MAT-0310', 'Capacitor Eletrolítico 680UF 25V', 'Capacitor Eletrolítico 680UF 25V', 2, 11, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1389, 'MAT-0311', 'Capacitor Eletrolítico 68UF 250V', 'Capacitor Eletrolítico 68UF 250V', 2, 22, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1390, 'MAT-0312', 'Capacitor Poliester 0.68J', 'Capacitor Poliester 0.68J', 2, 66, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1391, 'MAT-0313', 'Capacitor Poliester 100NF104K 50V', 'Capacitor Poliester 100NF104K 50V', 2, 44, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1392, 'MAT-0314', 'Capacitor Poliester 103J', 'Capacitor Poliester 103J', 2, 100, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1393, 'MAT-0315', 'Capacitor Poliester 104J ( 250V )', 'Capacitor Poliester 104J ( 250V )', 2, 83, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1394, 'MAT-0316', 'Capacitor Poliester 1M224J', 'Capacitor Poliester 1M224J', 2, 101, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1395, 'MAT-0317', 'Capacitor Poliester 1N0J', 'Capacitor Poliester 1N0J', 2, 90, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1396, 'MAT-0318', 'Capacitor Poliester 224', 'Capacitor Poliester 224', 2, 18, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1397, 'MAT-0319', 'Capacitor Poliester 224J ( 250V )', 'Capacitor Poliester 224J ( 250V )', 2, 20, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1398, 'MAT-0320', 'Capacitor Poliester 22K63', 'Capacitor Poliester 22K63', 2, 17, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1399, 'MAT-0321', 'Capacitor Poliester 2A334K', 'Capacitor Poliester 2A334K', 2, 14, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1400, 'MAT-0322', 'Capacitor Poliester 2A68L', 'Capacitor Poliester 2A68L', 2, 89, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1401, 'MAT-0323', 'Capacitor Poliester 2E473J', 'Capacitor Poliester 2E473J', 2, 85, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1402, 'MAT-0324', 'Capacitor Poliester 334', 'Capacitor Poliester 334', 2, 3, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1403, 'MAT-0325', 'Capacitor Poliester 33M63', 'Capacitor Poliester 33M63', 2, 83, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1404, 'MAT-0326', 'Capacitor Poliester 33NK63', 'Capacitor Poliester 33NK63', 2, 50, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1405, 'MAT-0327', 'Capacitor Poliester 474', 'Capacitor Poliester 474', 2, 88, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1406, 'MAT-0328', 'Capacitor Poliester 47NJ', 'Capacitor Poliester 47NJ', 2, 85, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1407, 'MAT-0329', 'Capacitor Poliester 47NK63', 'Capacitor Poliester 47NK63', 2, 31, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54');
INSERT INTO `materiais` (`id`, `codigo`, `nome`, `descricao`, `categoria_id`, `quantidade_total`, `estoque_minimo`, `unidade_medida`, `valor_unitario`, `ativo`, `data_criacao`, `data_atualizacao`) VALUES
(1408, 'MAT-0330', 'Capacitor Poliester 683K (250V )', 'Capacitor Poliester 683K (250V )', 2, 85, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1409, 'MAT-0331', 'Capacitor Poliester 684', 'Capacitor Poliester 684', 2, 14, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1410, 'MAT-0332', 'Capacitor Poliester 68NJ', 'Capacitor Poliester 68NJ', 2, 61, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1411, 'MAT-0333', 'Capacitor Poliester CBB22 250V 223JOCY', 'Capacitor Poliester CBB22 250V 223JOCY', 2, 83, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1412, 'MAT-0334', 'Capacitor Poliester LI05J /EI201', 'Capacitor Poliester LI05J /EI201', 2, 45, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1413, 'MAT-0335', 'Capacitor Poliester LI05J /EI20J', 'Capacitor Poliester LI05J /EI20J', 2, 43, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1414, 'MAT-0336', 'Capacitor Poliester 2A152J', 'Capacitor Poliester 2A152J', 2, 79, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1415, 'MAT-0337', 'Capacitor Poliester 2A223J', 'Capacitor Poliester 2A223J', 2, 73, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1416, 'MAT-0338', 'Capacitor Poliester 2A222J', 'Capacitor Poliester 2A222J', 2, 82, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1417, 'MAT-0339', 'Capacitor R NTL100-11', 'Capacitor R NTL100-11', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1418, 'MAT-0340', 'Capacitor Variavel  ', 'Capacitor Variavel  ', 2, 54, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1419, 'MAT-0341', 'Chave Canhão 03mm ', 'Chave Canhão 03mm ', 2, 17, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1420, 'MAT-0342', 'Chave Canhão 06mm ', 'Chave Canhão 06mm ', 2, 12, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1421, 'MAT-0343', 'Chave Canhão 09mm ', 'Chave Canhão 09mm ', 2, 14, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1422, 'MAT-0344', 'Chave de Fenda 1/4x4 ', 'Chave de Fenda 1/4x4 ', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1423, 'MAT-0345', 'Chave de Fenda 1/8x5 ', 'Chave de Fenda 1/8x5 ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1424, 'MAT-0346', 'Chave de Fenda 3/16x5 ', 'Chave de Fenda 3/16x5 ', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1425, 'MAT-0347', 'Chave de Fenda 3/16x8 ', 'Chave de Fenda 3/16x8 ', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1426, 'MAT-0348', 'Chave Phillips ', 'Chave Phillips ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1427, 'MAT-0349', 'Chave Seletora', 'Chave Seletora', 2, 21, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1428, 'MAT-0350', 'Circuito Integrado 025', 'Circuito Integrado 025', 2, 11, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1429, 'MAT-0351', 'Circuito Integrado 071', 'Circuito Integrado 071', 2, 73, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1430, 'MAT-0352', 'Circuito Integrado 0804', 'Circuito Integrado 0804', 2, 54, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1431, 'MAT-0353', 'Circuito Integrado 14512', 'Circuito Integrado 14512', 2, 6, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1432, 'MAT-0354', 'Circuito Integrado 16628', 'Circuito Integrado 16628', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1433, 'MAT-0355', 'Circuito Integrado 324', 'Circuito Integrado 324', 2, 58, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1434, 'MAT-0356', 'Circuito Integrado 4000', 'Circuito Integrado 4000', 2, 24, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1435, 'MAT-0357', 'Circuito Integrado 4001', 'Circuito Integrado 4001', 2, 77, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1436, 'MAT-0358', 'Circuito Integrado 4002', 'Circuito Integrado 4002', 2, 68, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1437, 'MAT-0359', 'Circuito Integrado 4011', 'Circuito Integrado 4011', 2, 107, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1438, 'MAT-0360', 'Circuito Integrado 4012', 'Circuito Integrado 4012', 2, 74, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1439, 'MAT-0361', 'Circuito Integrado 4013', 'Circuito Integrado 4013', 2, 107, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1440, 'MAT-0362', 'Circuito Integrado 4014', 'Circuito Integrado 4014', 2, 52, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1441, 'MAT-0363', 'Circuito Integrado 4015', 'Circuito Integrado 4015', 2, 26, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1442, 'MAT-0364', 'Circuito Integrado 4016', 'Circuito Integrado 4016', 2, 59, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1443, 'MAT-0365', 'Circuito Integrado 4017', 'Circuito Integrado 4017', 2, 43, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1444, 'MAT-0366', 'Circuito Integrado 4020', 'Circuito Integrado 4020', 2, 71, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1445, 'MAT-0367', 'Circuito Integrado 4021', 'Circuito Integrado 4021', 2, 55, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1446, 'MAT-0368', 'Circuito Integrado 4023', 'Circuito Integrado 4023', 2, 100, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1447, 'MAT-0369', 'Circuito Integrado 4027', 'Circuito Integrado 4027', 2, 50, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1448, 'MAT-0370', 'Circuito Integrado 4028', 'Circuito Integrado 4028', 2, 26, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1449, 'MAT-0371', 'Circuito Integrado 4029', 'Circuito Integrado 4029', 2, 59, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1450, 'MAT-0372', 'Circuito Integrado 4040', 'Circuito Integrado 4040', 2, 48, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1451, 'MAT-0373', 'Circuito Integrado 4045', 'Circuito Integrado 4045', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1452, 'MAT-0374', 'Circuito Integrado 4049', 'Circuito Integrado 4049', 2, 16, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1453, 'MAT-0375', 'Circuito Integrado 4051', 'Circuito Integrado 4051', 2, 90, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1454, 'MAT-0376', 'Circuito Integrado 4052', 'Circuito Integrado 4052', 2, 112, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:54', '2025-09-23 20:48:54'),
(1455, 'MAT-0377', 'Circuito Integrado 4053', 'Circuito Integrado 4053', 2, 106, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1456, 'MAT-0378', 'Circuito Integrado 4060', 'Circuito Integrado 4060', 2, 95, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1457, 'MAT-0379', 'Circuito Integrado 4066', 'Circuito Integrado 4066', 2, 107, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1458, 'MAT-0380', 'Circuito Integrado 4070', 'Circuito Integrado 4070', 2, 76, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1459, 'MAT-0381', 'Circuito Integrado 4071', 'Circuito Integrado 4071', 2, 48, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1460, 'MAT-0382', 'Circuito Integrado 4072', 'Circuito Integrado 4072', 2, 45, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1461, 'MAT-0383', 'Circuito Integrado 4077', 'Circuito Integrado 4077', 2, 38, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1462, 'MAT-0384', 'Circuito Integrado 4081', 'Circuito Integrado 4081', 2, 130, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1463, 'MAT-0385', 'Circuito Integrado 4082', 'Circuito Integrado 4082', 2, 71, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1464, 'MAT-0386', 'Circuito Integrado 4093', 'Circuito Integrado 4093', 2, 104, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1465, 'MAT-0387', 'Circuito Integrado 4096', 'Circuito Integrado 4096', 2, 48, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1466, 'MAT-0388', 'Circuito Integrado 412', 'Circuito Integrado 412', 2, 46, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1467, 'MAT-0389', 'Circuito Integrado 7426', 'Circuito Integrado 7426', 2, 53, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1468, 'MAT-0390', 'Circuito Integrado 4510', 'Circuito Integrado 4510', 2, 74, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1469, 'MAT-0391', 'Circuito Integrado 4511', 'Circuito Integrado 4511', 2, 102, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1470, 'MAT-0392', 'Circuito Integrado 4512', 'Circuito Integrado 4512', 2, 12, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1471, 'MAT-0393', 'Circuito Integrado 4N33', 'Circuito Integrado 4N33', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1472, 'MAT-0394', 'Circuito Integrado 555', 'Circuito Integrado 555', 2, 59, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1473, 'MAT-0395', 'Circuito Integrado 7400', 'Circuito Integrado 7400', 2, 125, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1474, 'MAT-0396', 'Circuito Integrado 7402', 'Circuito Integrado 7402', 2, 141, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1475, 'MAT-0397', 'Circuito Integrado 7403', 'Circuito Integrado 7403', 2, 69, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1476, 'MAT-0398', 'Circuito Integrado 7404', 'Circuito Integrado 7404', 2, 180, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1477, 'MAT-0399', 'Circuito Integrado 7406', 'Circuito Integrado 7406', 2, 51, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1478, 'MAT-0400', 'Circuito Integrado 7407', 'Circuito Integrado 7407', 2, 11, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1479, 'MAT-0401', 'Circuito Integrado 7408', 'Circuito Integrado 7408', 2, 91, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1480, 'MAT-0402', 'Circuito Integrado 741', 'Circuito Integrado 741', 2, 100, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1481, 'MAT-0403', 'Circuito Integrado 7411', 'Circuito Integrado 7411', 2, 38, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1482, 'MAT-0404', 'Circuito Integrado 74121', 'Circuito Integrado 74121', 2, 4, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1483, 'MAT-0405', 'Circuito Integrado 74122', 'Circuito Integrado 74122', 2, 22, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1484, 'MAT-0406', 'Circuito Integrado 74126', 'Circuito Integrado 74126', 2, 105, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1485, 'MAT-0407', 'Circuito Integrado 7413', 'Circuito Integrado 7413', 2, 5, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1486, 'MAT-0408', 'Circuito Integrado 74132', 'Circuito Integrado 74132', 2, 51, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1487, 'MAT-0409', 'Circuito Integrado 74138', 'Circuito Integrado 74138', 2, 5, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1488, 'MAT-0410', 'Circuito Integrado 7414', 'Circuito Integrado 7414', 2, 11, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1489, 'MAT-0411', 'Circuito Integrado 7415', 'Circuito Integrado 7415', 2, 46, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1490, 'MAT-0412', 'Circuito Integrado 74151', 'Circuito Integrado 74151', 2, 23, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1491, 'MAT-0413', 'Circuito Integrado 74153', 'Circuito Integrado 74153', 2, 71, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1492, 'MAT-0414', 'Circuito Integrado 74155', 'Circuito Integrado 74155', 2, 33, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1493, 'MAT-0415', 'Circuito Integrado 74157', 'Circuito Integrado 74157', 2, 14, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1494, 'MAT-0416', 'Circuito Integrado 74160', 'Circuito Integrado 74160', 2, 11, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1495, 'MAT-0417', 'Circuito Integrado 74161', 'Circuito Integrado 74161', 2, 16, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1496, 'MAT-0418', 'Circuito Integrado 74163', 'Circuito Integrado 74163', 2, 66, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1497, 'MAT-0419', 'Circuito Integrado 74165', 'Circuito Integrado 74165', 2, 17, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1498, 'MAT-0420', 'Circuito Integrado 74166', 'Circuito Integrado 74166', 2, 11, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1499, 'MAT-0421', 'Circuito Integrado 74192', 'Circuito Integrado 74192', 2, 84, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1500, 'MAT-0422', 'Circuito Integrado 74193', 'Circuito Integrado 74193', 2, 52, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1501, 'MAT-0423', 'Circuito Integrado 74194', 'Circuito Integrado 74194', 2, 17, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1502, 'MAT-0424', 'Circuito Integrado 7420', 'Circuito Integrado 7420', 2, 25, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1503, 'MAT-0425', 'Circuito Integrado 7421', 'Circuito Integrado 7421', 2, 24, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1504, 'MAT-0426', 'Circuito Integrado 7423', 'Circuito Integrado 7423', 2, 18, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1505, 'MAT-0427', 'Circuito Integrado 7425', 'Circuito Integrado 7425', 2, 20, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1506, 'MAT-0428', 'Circuito Integrado 7427', 'Circuito Integrado 7427', 2, 60, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1507, 'MAT-0429', 'Circuito Integrado 7430', 'Circuito Integrado 7430', 2, 14, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1508, 'MAT-0430', 'Circuito Integrado 7432', 'Circuito Integrado 7432', 2, 131, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1509, 'MAT-0431', 'Circuito Integrado 74368', 'Circuito Integrado 74368', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1510, 'MAT-0432', 'Circuito Integrado 74373', 'Circuito Integrado 74373', 2, 40, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1511, 'MAT-0433', 'Circuito Integrado 74374', 'Circuito Integrado 74374', 2, 34, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1512, 'MAT-0434', 'Circuito Integrado 74379', 'Circuito Integrado 74379', 2, 19, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1513, 'MAT-0435', 'Circuito Integrado 74390', 'Circuito Integrado 74390', 2, 69, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1514, 'MAT-0436', 'Circuito Integrado 74393', 'Circuito Integrado 74393', 2, 43, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1515, 'MAT-0437', 'Circuito Integrado 744020', 'Circuito Integrado 744020', 2, 45, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1516, 'MAT-0438', 'Circuito Integrado 7442', 'Circuito Integrado 7442', 2, 17, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1517, 'MAT-0439', 'Circuito Integrado 7445', 'Circuito Integrado 7445', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1518, 'MAT-0440', 'Circuito Integrado 7447', 'Circuito Integrado 7447', 2, 21, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1519, 'MAT-0441', 'Circuito Integrado 74501', 'Circuito Integrado 74501', 2, 50, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1520, 'MAT-0442', 'Circuito Integrado 74502', 'Circuito Integrado 74502', 2, 47, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1521, 'MAT-0443', 'Circuito Integrado 74509', 'Circuito Integrado 74509', 2, 50, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1522, 'MAT-0444', 'Circuito Integrado 74514', 'Circuito Integrado 74514', 2, 61, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1523, 'MAT-0445', 'Circuito Integrado 74520', 'Circuito Integrado 74520', 2, 30, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1524, 'MAT-0446', 'Circuito Integrado 74530', 'Circuito Integrado 74530', 2, 83, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1525, 'MAT-0447', 'Circuito Integrado 74533', 'Circuito Integrado 74533', 2, 10, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1526, 'MAT-0448', 'Circuito Integrado 74590', 'Circuito Integrado 74590', 2, 55, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1527, 'MAT-0449', 'Circuito Integrado 74595', 'Circuito Integrado 74595', 2, 13, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1528, 'MAT-0450', 'Circuito Integrado 7460', 'Circuito Integrado 7460', 2, 18, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1529, 'MAT-0451', 'Circuito Integrado 7473', 'Circuito Integrado 7473', 2, 52, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1530, 'MAT-0452', 'Circuito Integrado 7474', 'Circuito Integrado 7474', 2, 100, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1531, 'MAT-0453', 'Circuito Integrado 7475', 'Circuito Integrado 7475', 2, 5, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1532, 'MAT-0454', 'Circuito Integrado 7476', 'Circuito Integrado 7476', 2, 36, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1533, 'MAT-0455', 'Circuito Integrado 7486', 'Circuito Integrado 7486', 2, 126, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1534, 'MAT-0456', 'Circuito Integrado 7490', 'Circuito Integrado 7490', 2, 90, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1535, 'MAT-0457', 'Circuito Integrado 7491', 'Circuito Integrado 7491', 2, 36, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1536, 'MAT-0458', 'Circuito Integrado 7493', 'Circuito Integrado 7493', 2, 93, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1537, 'MAT-0459', 'Circuito Integrado 7495', 'Circuito Integrado 7495', 2, 79, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1538, 'MAT-0460', 'Circuito Integrado 8951', 'Circuito Integrado 8951', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1539, 'MAT-0461', 'Conduite Eletroduto ', 'Conduite Eletroduto ', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1540, 'MAT-0462', 'Conector RJ45 Macho', 'Conector RJ45 Macho', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1541, 'MAT-0463', 'Conector RJ45 Fêmea', 'Conector RJ45 Fêmea', 2, 280, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1542, 'MAT-0464', 'Conector Saída Caixa Multipla', 'Conector Saída Caixa Multipla', 2, 20, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1543, 'MAT-0465', 'Console Cable V2', 'Console Cable V2', 2, 11, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1544, 'MAT-0466', 'Controle de TV Samsung', 'Controle de TV Samsung', 2, 3, 3, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:52:37'),
(1545, 'MAT-0467', 'Cotovelo Interno 50x20mm ', 'Cotovelo Interno 50x20mm ', 2, 13, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1546, 'MAT-0468', 'Desencapador de fios', 'Desencapador de fios', 2, 26, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1547, 'MAT-0469', 'Dio Furukawa A-145 ', 'Dio Furukawa A-145 ', 2, 8, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1548, 'MAT-0470', 'Diodo 1N4001 BE', 'Diodo 1N4001 BE', 2, 202, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1549, 'MAT-0471', 'Diodo 1N4004', 'Diodo 1N4004', 2, 31, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1550, 'MAT-0472', 'Diodo 1N4007', 'Diodo 1N4007', 2, 14, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1551, 'MAT-0473', 'Diodo 1N4148', 'Diodo 1N4148', 2, 240, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1552, 'MAT-0474', 'Diodo 1N4733', 'Diodo 1N4733', 2, 5, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1553, 'MAT-0475', 'Diodo 1N60P', 'Diodo 1N60P', 2, 25, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1554, 'MAT-0476', 'Diodo 1N754A120', 'Diodo 1N754A120', 2, 23, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1555, 'MAT-0477', 'Diodo 1N75SA', 'Diodo 1N75SA', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1556, 'MAT-0478', 'Diodo PHBZX79C6V8', 'Diodo PHBZX79C6V8', 2, 15, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1557, 'MAT-0479', 'Diodo 5408', 'Diodo 5408', 2, 4, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1558, 'MAT-0480', 'Diodo B1X56C10', 'Diodo B1X56C10', 2, 56, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1559, 'MAT-0481', 'Diodo BZX55C3V', 'Diodo BZX55C3V', 2, 17, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1560, 'MAT-0482', 'Diodo D45B 8029', 'Diodo D45B 8029', 2, 3, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1561, 'MAT-0483', 'Diodo DB3', 'Diodo DB3', 2, 50, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1562, 'MAT-0484', 'Diodo PHC3V3', 'Diodo PHC3V3', 2, 35, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1563, 'MAT-0485', 'Diodo PHC5V1', 'Diodo PHC5V1', 2, 56, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1564, 'MAT-0486', 'Disjuntor monofasico', 'Disjuntor monofasico', 2, 39, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1565, 'MAT-0487', 'Disjuntor Bifásico ', 'Disjuntor Bifásico ', 2, 8, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1566, 'MAT-0488', 'Disjuntor trifasico', 'Disjuntor trifasico', 2, 9, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1567, 'MAT-0489', 'Esponja Metálica  ', 'Esponja Metálica  ', 2, 5, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1568, 'MAT-0490', 'Estação de Solda Analógica HK-936ESD ', 'Estação de Solda Analógica HK-936ESD ', 2, 11, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1569, 'MAT-0491', 'Estação de Solda e Retrabalho 878D', 'Estação de Solda e Retrabalho 878D', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1570, 'MAT-0492', 'Estação de Solda FT-E50W ', 'Estação de Solda FT-E50W ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1571, 'MAT-0493', 'Estilete', 'Estilete', 2, 11, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1572, 'MAT-0494', 'Exaustor de Fumaça HK-707', 'Exaustor de Fumaça HK-707', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1573, 'MAT-0495', 'Fechaduras MM com Chave', 'Fechaduras MM com Chave', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1574, 'MAT-0496', 'Ferro de Solda ', 'Ferro de Solda ', 2, 14, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1575, 'MAT-0497', 'Filtro Secador DML163 ', 'Filtro Secador DML163 ', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1576, 'MAT-0498', 'Fios Circuito', 'Fios Circuito', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1577, 'MAT-0499', 'Fios Eletrônica p/2', 'Fios Eletrônica p/2', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1578, 'MAT-0500', 'Fios p/ Circuitos ', 'Fios p/ Circuitos ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1579, 'MAT-0501', 'Fita Capacitor Ceramico ', 'Fita Capacitor Ceramico ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1580, 'MAT-0502', 'Fita Dessoldadora', 'Fita Dessoldadora', 2, 4, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1581, 'MAT-0503', 'Fita Isolante Preta', 'Fita Isolante Preta', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:55', '2025-09-23 20:48:55'),
(1582, 'MAT-0504', 'Galaxy S21 FE 5G Muraki', 'Galaxy S21 FE 5G Muraki', 2, 19, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1583, 'MAT-0505', 'Gerador de Função TFG22', 'Gerador de Função TFG22', 2, 4, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1584, 'MAT-0506', 'Grampeador De Pressao', 'Grampeador De Pressao', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1585, 'MAT-0507', 'Grampos ', 'Grampos ', 2, 15, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1586, 'MAT-0508', 'Iphone 13 Mini Muraki', 'Iphone 13 Mini Muraki', 2, 24, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1587, 'MAT-0509', 'Lâmpada Bulbo A60', 'Lâmpada Bulbo A60', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1588, 'MAT-0510', 'Lâmpada LED T8 18W', 'Lâmpada LED T8 18W', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1589, 'MAT-0511', 'Lâmpadas ', 'Lâmpadas ', 2, 20, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1590, 'MAT-0512', 'Lâmpadas Hológena', 'Lâmpadas Hológena', 2, 4, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1591, 'MAT-0513', 'Lápis ', 'Lápis ', 2, 20, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1592, 'MAT-0514', 'Luvas Antiestáticas ', 'Luvas Antiestáticas ', 2, 126, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1593, 'MAT-0515', 'Maleta de ferramenta', 'Maleta de ferramenta', 2, 10, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1594, 'MAT-0516', 'Marca Texto', 'Marca Texto', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1595, 'MAT-0517', 'Marcador de Pizarra', 'Marcador de Pizarra', 2, 115, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1596, 'MAT-0518', 'Marcador Permanente ', 'Marcador Permanente ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1597, 'MAT-0519', 'Mata-Junta 50x20mm ', 'Mata-Junta 50x20mm ', 2, 14, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1598, 'MAT-0520', 'Modulo Luva 50x20mm ', 'Modulo Luva 50x20mm ', 2, 15, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1599, 'MAT-0521', 'MODULO BOTÃO DE EMERGÊNCIA', 'MODULO BOTÃO DE EMERGÊNCIA', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1600, 'MAT-0522', 'MODULO CAMPAINHA', 'MODULO CAMPAINHA', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1601, 'MAT-0523', 'MODULO INDUTOR', 'MODULO INDUTOR', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1602, 'MAT-0524', 'Óculos de Segurança ', 'Óculos de Segurança ', 2, 46, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1603, 'MAT-0525', 'Optic Analog', 'Optic Analog', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1604, 'MAT-0526', 'Pastilha Piezoeletrica ', 'Pastilha Piezoeletrica ', 2, 12, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1605, 'MAT-0527', 'Par de Luvas Vaqueta Mista 16475 ', 'Par de Luvas Vaqueta Mista 16475 ', 2, 10, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1606, 'MAT-0528', 'Pasta Termica 100g', 'Pasta Termica 100g', 2, 16, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1607, 'MAT-0529', 'Pilha AA', 'Pilha AA', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1608, 'MAT-0530', 'Pilha AAA', 'Pilha AAA', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1609, 'MAT-0531', 'Pinça', 'Pinça', 2, 24, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1610, 'MAT-0532', 'Pinça antiestática', 'Pinça antiestática', 2, 59, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1611, 'MAT-0533', 'Pincel antiestático', 'Pincel antiestático', 2, 19, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1612, 'MAT-0534', 'Pino Condutor Colorido ', 'Pino Condutor Colorido ', 2, 4, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1613, 'MAT-0535', 'Pistola de Cola Quente', 'Pistola de Cola Quente', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1614, 'MAT-0536', 'Pontas de Prova PPM-300 ', 'Pontas de Prova PPM-300 ', 2, 58, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1615, 'MAT-0537', 'Protetor Auricular 30Db ', 'Protetor Auricular 30Db ', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1616, 'MAT-0538', 'Régua 50cm ', 'Régua 50cm ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1617, 'MAT-0539', 'Régua 100cm', 'Régua 100cm', 2, 3, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1618, 'MAT-0540', 'Rele térmico', 'Rele térmico', 2, 9, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1619, 'MAT-0541', 'Resistor 0,1Ω / 5%', 'Resistor 0,1Ω / 5%', 2, 15, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1620, 'MAT-0542', 'Resistor 0,91Ω / 5%', 'Resistor 0,91Ω / 5%', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1621, 'MAT-0543', 'Resistor 0,97Ω / 5%', 'Resistor 0,97Ω / 5%', 2, 15, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1622, 'MAT-0544', 'Resistor 1,1KΩ / 5%', 'Resistor 1,1KΩ / 5%', 2, 59, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1623, 'MAT-0545', 'Resistor 1,2KΩ/ 5%', 'Resistor 1,2KΩ/ 5%', 2, 41, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1624, 'MAT-0546', 'Resistor 1,2MΩ/ 5%', 'Resistor 1,2MΩ/ 5%', 2, 125, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1625, 'MAT-0547', 'Resistor 1,5KΩ / 5%', 'Resistor 1,5KΩ / 5%', 2, 114, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1626, 'MAT-0548', 'Resistor 1,5MΩ / 5%', 'Resistor 1,5MΩ / 5%', 2, 90, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1627, 'MAT-0549', 'Resistor 1,8KΩ / 5%', 'Resistor 1,8KΩ / 5%', 2, 25, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1628, 'MAT-0550', 'Resistor 1,8MΩ / 5%', 'Resistor 1,8MΩ / 5%', 2, 86, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1629, 'MAT-0551', 'Resistor 100KΩ / 5%', 'Resistor 100KΩ / 5%', 2, 33, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1630, 'MAT-0552', 'Resistor 100Ω / 5%', 'Resistor 100Ω / 5%', 2, 46, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1631, 'MAT-0553', 'Resistor 101Ω /5%', 'Resistor 101Ω /5%', 2, 4, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1632, 'MAT-0554', 'Resistor 10KΩ / 5%', 'Resistor 10KΩ / 5%', 2, 95, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1633, 'MAT-0555', 'Resistor 10Ω / 10%', 'Resistor 10Ω / 10%', 2, 159, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1634, 'MAT-0556', 'Resistor 10Ω / 5%', 'Resistor 10Ω / 5%', 2, 90, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1635, 'MAT-0557', 'Resistor 120KΩ /5%', 'Resistor 120KΩ /5%', 2, 66, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1636, 'MAT-0558', 'Resistor 120Ω /5%', 'Resistor 120Ω /5%', 2, 14, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1637, 'MAT-0559', 'Resistor 12KΩ /5% ', 'Resistor 12KΩ /5% ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1638, 'MAT-0560', 'Resistor 12Ω /5% ', 'Resistor 12Ω /5% ', 2, 21, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1639, 'MAT-0561', 'Resistor 150Ω /5%', 'Resistor 150Ω /5%', 2, 14, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1640, 'MAT-0562', 'Resistor 150KΩ /5%', 'Resistor 150KΩ /5%', 2, 88, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1641, 'MAT-0563', 'Resistor 151Ω /5%', 'Resistor 151Ω /5%', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1642, 'MAT-0564', 'Resistor 15KΩ /5%', 'Resistor 15KΩ /5%', 2, 38, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1643, 'MAT-0565', 'Resistor 180KΩ /5%', 'Resistor 180KΩ /5%', 2, 107, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1644, 'MAT-0566', 'Resistor 18KΩ /5%', 'Resistor 18KΩ /5%', 2, 46, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1645, 'MAT-0567', 'Resistor 1KΩ / 5%', 'Resistor 1KΩ / 5%', 2, 13, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1646, 'MAT-0568', 'Resistor 1MΩ/ 5%', 'Resistor 1MΩ/ 5%', 2, 260, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1647, 'MAT-0569', 'Resistor 1Ω / 5%', 'Resistor 1Ω / 5%', 2, 30, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1648, 'MAT-0570', 'Resistor 2,2KΩ / 5%', 'Resistor 2,2KΩ / 5%', 2, 20, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1649, 'MAT-0571', 'Resistor 2,2MΩ / 5%', 'Resistor 2,2MΩ / 5%', 2, 169, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1650, 'MAT-0572', 'Resistor 2,6KΩ / 5%', 'Resistor 2,6KΩ / 5%', 2, 25, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1651, 'MAT-0573', 'Resistor 2,7KΩ / 5%', 'Resistor 2,7KΩ / 5%', 2, 47, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1652, 'MAT-0574', 'Resistor 2,7MΩ / 5%', 'Resistor 2,7MΩ / 5%', 2, 117, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1653, 'MAT-0575', 'Resistor 200Ω /5%', 'Resistor 200Ω /5%', 2, 168, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1654, 'MAT-0576', 'Resistor 20Ω /5%', 'Resistor 20Ω /5%', 2, 36, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1655, 'MAT-0577', 'Resistor 220KΩ /5%', 'Resistor 220KΩ /5%', 2, 78, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1656, 'MAT-0578', 'Resistor 220Ω /5%', 'Resistor 220Ω /5%', 2, 56, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1657, 'MAT-0579', 'Resistor 22Ω /5%', 'Resistor 22Ω /5%', 2, 1000, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1658, 'MAT-0580', 'Resistor 24.9Ω /1%', 'Resistor 24.9Ω /1%', 2, 97, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1659, 'MAT-0581', 'Resistor 270Ω /5%', 'Resistor 270Ω /5%', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1660, 'MAT-0582', 'Resistor 27KΩ /5%', 'Resistor 27KΩ /5%', 2, 85, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1661, 'MAT-0583', 'Resistor 2KΩ / 5%', 'Resistor 2KΩ / 5%', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1662, 'MAT-0584', 'Resistor 3,3KΩ / 5%', 'Resistor 3,3KΩ / 5%', 2, 580, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1663, 'MAT-0585', 'Resistor 3,3MΩ / 5%', 'Resistor 3,3MΩ / 5%', 2, 115, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1664, 'MAT-0586', 'Resistor 3,3Ω / 5%', 'Resistor 3,3Ω / 5%', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1665, 'MAT-0587', 'Resistor 3,9KΩ / 5%', 'Resistor 3,9KΩ / 5%', 2, 85, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1666, 'MAT-0588', 'Resistor 300Ω /5%', 'Resistor 300Ω /5%', 2, 200, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1667, 'MAT-0589', 'Resistor 33.1Ω ', 'Resistor 33.1Ω ', 2, 33, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1668, 'MAT-0590', 'Resistor 330KΩ /5%', 'Resistor 330KΩ /5%', 2, 37, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1669, 'MAT-0591', 'Resistor 330Ω /5%', 'Resistor 330Ω /5%', 2, 106, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1670, 'MAT-0592', 'Resistor 33KΩ /5%', 'Resistor 33KΩ /5%', 2, 67, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1671, 'MAT-0593', 'Resistor 33Ω /5%', 'Resistor 33Ω /5%', 2, 165, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1672, 'MAT-0594', 'Resistor 390KΩ /5%', 'Resistor 390KΩ /5%', 2, 165, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1673, 'MAT-0595', 'Resistor 390Ω /5%', 'Resistor 390Ω /5%', 2, 32, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1674, 'MAT-0596', 'Resistor 39KΩ /5%', 'Resistor 39KΩ /5%', 2, 55, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1675, 'MAT-0597', 'Resistor 4,7KΩ / 5%', 'Resistor 4,7KΩ / 5%', 2, 142, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1676, 'MAT-0598', 'Resistor 4,99KΩ / 0,05%', 'Resistor 4,99KΩ / 0,05%', 2, 100, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1677, 'MAT-0599', 'Resistor 402Ω /5%', 'Resistor 402Ω /5%', 2, 69, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1678, 'MAT-0600', 'Resistor 470KΩ /5%', 'Resistor 470KΩ /5%', 2, 194, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1679, 'MAT-0601', 'Resistor 470Ω /5%', 'Resistor 470Ω /5%', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1680, 'MAT-0602', 'Resistor 47KΩ /5% ', 'Resistor 47KΩ /5% ', 2, 245, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1681, 'MAT-0603', 'Resistor 499Ω /1% 50', 'Resistor 499Ω /1% 50', 2, 37, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1682, 'MAT-0604', 'Resistor 499Ω /5%', 'Resistor 499Ω /5%', 2, 37, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1683, 'MAT-0605', 'Resistor 460Ω / 5%', 'Resistor 460Ω / 5%', 2, 56, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1684, 'MAT-0606', 'Resistor 5,6KΩ / 5%', 'Resistor 5,6KΩ / 5%', 2, 17, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1685, 'MAT-0607', 'Resistor 500KΩ /5%', 'Resistor 500KΩ /5%', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1686, 'MAT-0608', 'Resistor 510Ω /5%', 'Resistor 510Ω /5%', 2, 23, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1687, 'MAT-0609', 'Resistor 560KΩ /5%', 'Resistor 560KΩ /5%', 2, 107, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1688, 'MAT-0610', 'Resistor 560Ω /5%', 'Resistor 560Ω /5%', 2, 85, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1689, 'MAT-0611', 'Resistor 56KΩ /5% ', 'Resistor 56KΩ /5% ', 2, 81, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1690, 'MAT-0612', 'Resistor 56Ω /5% ', 'Resistor 56Ω /5% ', 2, 44, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1691, 'MAT-0613', 'Resistor 6,8KΩ / 5%', 'Resistor 6,8KΩ / 5%', 2, 76, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1692, 'MAT-0614', 'Resistor 620KΩ /5%', 'Resistor 620KΩ /5%', 2, 73, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1693, 'MAT-0615', 'Resistor 680KΩ /5%', 'Resistor 680KΩ /5%', 2, 131, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1694, 'MAT-0616', 'Resistor 680Ω /5%', 'Resistor 680Ω /5%', 2, 37, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1695, 'MAT-0617', 'Resistor 68KΩ /5%', 'Resistor 68KΩ /5%', 2, 155, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1696, 'MAT-0618', 'Resistor 68Ω /5%', 'Resistor 68Ω /5%', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1697, 'MAT-0619', 'Resistor 8,2KΩ / 5%', 'Resistor 8,2KΩ / 5%', 2, 20, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1698, 'MAT-0620', 'Resistor 820KΩ /5%', 'Resistor 820KΩ /5%', 2, 72, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1699, 'MAT-0621', 'Resistor 820Ω /5%', 'Resistor 820Ω /5%', 2, 22, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1700, 'MAT-0622', 'Resistor 82KΩ /5%', 'Resistor 82KΩ /5%', 2, 98, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1701, 'MAT-0623', 'Resistor 9,1KΩ / 5%', 'Resistor 9,1KΩ / 5%', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1702, 'MAT-0624', 'Resistor 909Ω /1%', 'Resistor 909Ω /1%', 2, 107, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1703, 'MAT-0625', 'Resistor 910KΩ /5%', 'Resistor 910KΩ /5%', 2, 106, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1704, 'MAT-0626', 'Resistor 910Ω /5%', 'Resistor 910Ω /5%', 2, 3, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1705, 'MAT-0627', 'Resistor 91KΩ /5%', 'Resistor 91KΩ /5%', 2, 102, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1706, 'MAT-0628', 'Resistor 9.1KΩ / 5%', 'Resistor 9.1KΩ / 5%', 2, 28, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1707, 'MAT-0629', 'Resma De Papel A4 500', 'Resma De Papel A4 500', 2, 5, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1708, 'MAT-0630', 'Rolo de Cobre ', 'Rolo de Cobre ', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1709, 'MAT-0631', 'Rolo de Solda CAT em fio', 'Rolo de Solda CAT em fio', 2, 7, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1710, 'MAT-0632', 'Sensor LUZLed', 'Sensor LUZLed', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1711, 'MAT-0633', 'Simulador de Solda', 'Simulador de Solda', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1712, 'MAT-0634', 'Soprador Térmico HK-508 ', 'Soprador Térmico HK-508 ', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1713, 'MAT-0635', 'Sugador de Solda', 'Sugador de Solda', 2, 6, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:56', '2025-09-23 20:48:56'),
(1714, 'MAT-0636', 'Suporte para Ferro de Solda', 'Suporte para Ferro de Solda', 2, 10, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1715, 'MAT-0637', 'Tab P11 Plus - Lenovo  ', 'Tab P11 Plus - Lenovo  ', 2, 23, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1716, 'MAT-0638', 'Tampa para Condulete 3/4', 'Tampa para Condulete 3/4', 2, 125, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1717, 'MAT-0639', 'Teodolito DE 2A-L ', 'Teodolito DE 2A-L ', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1718, 'MAT-0640', 'Tomada 2P+T ', 'Tomada 2P+T ', 2, 69, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1719, 'MAT-0641', 'Tomada Desmontável ', 'Tomada Desmontável ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1720, 'MAT-0642', 'Tomada em Barra', 'Tomada em Barra', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1721, 'MAT-0643', 'Tomada LCS RJ45 ', 'Tomada LCS RJ45 ', 2, 9, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1722, 'MAT-0644', 'Tomada PB 2P+T ', 'Tomada PB 2P+T ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1723, 'MAT-0645', 'Transistor 178205', 'Transistor 178205', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1724, 'MAT-0646', 'Transistor 222', 'Transistor 222', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1725, 'MAT-0647', 'Transistor 2222A', 'Transistor 2222A', 2, 166, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1726, 'MAT-0648', 'Transistor 3904', 'Transistor 3904', 2, 35, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1727, 'MAT-0649', 'Transistor 3906', 'Transistor 3906', 2, 45, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1728, 'MAT-0650', 'Transistor 59014', 'Transistor 59014', 2, 2, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1729, 'MAT-0651', 'Transistor 97081', 'Transistor 97081', 2, 5, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1730, 'MAT-0652', 'Transistor 98039', 'Transistor 98039', 2, 8, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1731, 'MAT-0653', 'Transistor BC327', 'Transistor BC327', 2, 1, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1732, 'MAT-0654', 'Transistor BC337', 'Transistor BC337', 2, 50, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1733, 'MAT-0655', 'Transistor BC548', 'Transistor BC548', 2, 5, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1734, 'MAT-0656', 'Transistor BC5488', 'Transistor BC5488', 2, 50, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1735, 'MAT-0657', 'Transistor BC558', 'Transistor BC558', 2, 28, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1736, 'MAT-0658', 'Transistor C32725', 'Transistor C32725', 2, 48, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1737, 'MAT-0659', 'Transistor C32740', 'Transistor C32740', 2, 29, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1738, 'MAT-0660', 'Transistor C33725', 'Transistor C33725', 2, 38, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1739, 'MAT-0661', 'Transistor C33740', 'Transistor C33740', 2, 7, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1740, 'MAT-0662', 'Transistor CTBF494', 'Transistor CTBF494', 2, 47, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1741, 'MAT-0663', 'Transistor L78L05', 'Transistor L78L05', 2, 45, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1742, 'MAT-0664', 'Trena de Fibra de Vidro ', 'Trena de Fibra de Vidro ', 2, 6, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1743, 'MAT-0665', 'Luvas Nitrícilicas ', 'Luvas Nitrícilicas ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1744, 'MAT-0666', 'Máscaras PFF2', 'Máscaras PFF2', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1745, 'MAT-0667', 'Protetores Auditivos ', 'Protetores Auditivos ', 2, 0, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1746, 'MAT-0668', 'Extensão', 'Extensão elétrica para equipamentos', 2, 10, 10, 'unidade', 0.00, 1, '2025-09-23 20:48:57', '2025-09-23 20:48:57'),
(1747, 'MAT-214', 'Monitor Lenovo Think Vision S22e', '21.5 polegadas com resolução típica de 1920x1080 pixels\r\n', 3, 1, NULL, 'unidade', 0.00, 1, '2025-09-23 21:54:26', '2025-09-23 21:54:26'),
(1748, 'MAT-215', 'Monitor Dell E2222HSF', '21,45 polegadas com resolução típica de 1920x1080 pixels\r\n', 3, 73, NULL, 'unidade', NULL, 1, '2025-09-23 21:57:08', '2025-09-23 22:27:40'),
(1749, 'MAT-216', 'Monitor  Dell P2722Ht', '27 polegadas com resolução típica de 1920x1080 \r\npixels.\r\n', 3, 71, NULL, 'unidade', NULL, 1, '2025-09-23 21:57:53', '2025-09-23 22:11:25'),
(1750, 'MAT-217', 'Nobreak TS Shara UPS Mini ', '', 3, 38, NULL, 'unidade', NULL, 1, '2025-09-23 21:58:30', '2025-09-23 23:02:35'),
(1752, 'MAT-218', 'CPU - Dell OptiPlex 3080  Small Form', 'Intel® Core™ i5-10500 \r\n3.10 GHZ, 8 GB, DDR4, 2666 MHz, 1 TB', 3, 73, NULL, 'unidade', 0.00, 1, '2025-09-23 22:00:41', '2025-09-23 22:27:58'),
(1753, 'MAT-219', 'Monitor Dell S2421Ht', '23,80 polegadas com resolução típica de 1920x1080 pixels\r\n', 3, 23, NULL, 'unidade', 0.00, 1, '2025-09-23 22:02:39', '2025-09-23 22:11:03'),
(1754, 'MAT-220', 'Desktop Positivo D3100 ', 'Core I5, 8gb de ram\r\n', 3, 1, NULL, 'unidade', 0.00, 1, '2025-09-23 22:05:13', '2025-09-23 22:05:13'),
(1755, 'MAT-221', 'Monitor HP PRO DisPlay P221', '21,5 polegadas com resolução típica de 1920x1080 pixels\r\n', 3, 1, NULL, 'unidade', 0.00, 1, '2025-09-23 22:10:35', '2025-09-23 22:10:35');
INSERT INTO `materiais` (`id`, `codigo`, `nome`, `descricao`, `categoria_id`, `quantidade_total`, `estoque_minimo`, `unidade_medida`, `valor_unitario`, `ativo`, `data_criacao`, `data_atualizacao`) VALUES
(1756, 'MAT-222', 'Nobreak Ragtech Save', '', 3, 2, NULL, 'unidade', 0.00, 1, '2025-09-23 22:12:35', '2025-09-23 23:02:41'),
(1758, 'MAT-224', 'Gabinete Lenovo ', 'INTEL® CORE™ i3 10100 CPU@ 3.60GHz,  8GB Ram, 222GB\r\n', 3, 1, NULL, 'unidade', 0.00, 1, '2025-09-23 22:26:33', '2025-09-23 22:26:33'),
(1759, 'MAT-225', 'Monitor - Dell P2219H', 'Resolução: Até 1920 x 1080 através do VGA, DisplayPort e HDMI\"', 3, 19, NULL, 'unidade', 0.00, 1, '2025-09-23 23:00:16', '2025-09-23 23:00:16'),
(1760, 'MAT-226', 'Monitor - Dell P2222h', 'Resolução: Até 1920 x 1080 através do VGA, DisplayPort e HDMI\r\n', 3, 1, NULL, 'unidade', 0.00, 1, '2025-09-23 23:01:14', '2025-09-23 23:01:14'),
(1761, 'MAT-227', 'Monitor - HP Compac LA2006x', 'Resolução: Até 1600 x 900 através do VGA, DisplayPort e DVI\r\n', 3, 1, NULL, 'unidade', 0.00, 1, '2025-09-23 23:01:54', '2025-09-23 23:01:54'),
(1762, 'MAT-228', 'CPU - Dell Optiplex 3070', 'Intel® Core™ i3-9100T, 8GB DDR4 2400MHz, 500 GB HD e 128 GB SSD', 3, 20, NULL, 'unidade', 0.00, 1, '2025-09-23 23:03:27', '2025-09-23 23:03:27'),
(1763, 'MAT-229', 'CPU - Lenovo v50s', 'Intel core i3-10100 DDR4 2933Mhz, 500GB HD e 128 GB SSD\r\n', 3, 1, NULL, 'unidade', 0.00, 1, '2025-09-23 23:03:59', '2025-09-23 23:03:59');

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `materiais_em_falta`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `materiais_em_falta` (
`id` int(11)
,`codigo` varchar(50)
,`nome` varchar(200)
,`quantidade_total` int(11)
,`estoque_minimo` int(11)
,`status` varchar(13)
);

-- --------------------------------------------------------

--
-- Estrutura para tabela `patrimonio`
--

CREATE TABLE `patrimonio` (
  `id` int(11) NOT NULL,
  `tombamento` varchar(50) NOT NULL,
  `material_id` int(11) NOT NULL,
  `local_id` int(11) NOT NULL,
  `descricao` text DEFAULT NULL,
  `estado` enum('novo','bom','regular','ruim','inutilizado') DEFAULT 'bom',
  `data_aquisicao` date DEFAULT NULL,
  `valor_aquisicao` decimal(10,2) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `patrimonio`
--

INSERT INTO `patrimonio` (`id`, `tombamento`, `material_id`, `local_id`, `descricao`, `estado`, `data_aquisicao`, `valor_aquisicao`, `ativo`, `data_criacao`, `data_atualizacao`) VALUES
(4, 'Nº000044', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:36:58', '2025-09-23 22:36:58'),
(5, 'Nº000051', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:37:58', '2025-09-23 22:37:58'),
(6, 'Nº000047', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:38:21', '2025-09-23 22:38:21'),
(7, 'Nº000035', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(8, 'Nº000045', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(9, 'Nº000042', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(10, 'Nº000031', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(11, 'Nº000040', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(12, 'Nº000030', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(13, 'Nº000049', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(14, 'Nº000036', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(15, 'Nº000046', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(16, 'Nº000048', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(17, 'Nº000034', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(18, 'Nº000052', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(19, 'Nº000039', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(20, 'Nº000038', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(21, 'Nº000053', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(22, 'Nº000033', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(23, 'Nº000043', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(24, 'Nº000037', 1753, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:53:31', '2025-09-23 22:53:31'),
(25, 'N°000061', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(26, 'Nº000062', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(27, 'Nº000057', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(28, 'Nº000072', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(29, 'Nº000063', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(30, 'Nº000076', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(31, 'Nº000054', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(32, 'Nº000070', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(33, 'Nº000065', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(34, 'Nº000077', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(35, 'Nº000060', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(36, 'Nº000059', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(37, 'Nº000079', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(38, 'Nº000064', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(39, 'Nº000078', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(40, 'Nº000067', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(41, 'Nº000068', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(42, 'Nº000056', 1749, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:00', '2025-09-23 22:55:00'),
(43, 'Nº 990008958', 1756, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:55:49', '2025-09-23 22:55:49'),
(44, 'Nº 990009666', 1758, 3, '', 'bom', NULL, NULL, 1, '2025-09-23 22:56:27', '2025-09-23 22:56:27');

-- --------------------------------------------------------

--
-- Estrutura para tabela `patrimonio_material`
--

CREATE TABLE `patrimonio_material` (
  `id` int(11) NOT NULL,
  `patrimonio_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `patrimonio_por_local`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `patrimonio_por_local` (
`local_nome` varchar(100)
,`local_tipo` enum('laboratorio','sala','setor')
,`material_nome` varchar(200)
,`quantidade` bigint(21)
);

-- --------------------------------------------------------

--
-- Estrutura para tabela `saidas`
--

CREATE TABLE `saidas` (
  `id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `data_saida` date NOT NULL,
  `destino` varchar(200) NOT NULL,
  `responsavel_entrega` varchar(100) NOT NULL,
  `observacoes` text DEFAULT NULL,
  `devolvido` tinyint(1) DEFAULT 0,
  `data_devolucao` date DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Acionadores `saidas`
--
DELIMITER $$
CREATE TRIGGER `atualizar_estoque_devolucao` AFTER UPDATE ON `saidas` FOR EACH ROW BEGIN
    IF NEW.devolvido = TRUE AND OLD.devolvido = FALSE THEN
        UPDATE materiais 
        SET quantidade_total = quantidade_total + NEW.quantidade
        WHERE id = NEW.material_id;
        
        -- Inserir registro de entrada automática
        INSERT INTO entradas (material_id, quantidade, data_entrada, responsavel_recebimento, observacoes, usuario_id)
        VALUES (NEW.material_id, NEW.quantidade, NEW.data_devolucao, 'Sistema - Devolução Automática', 
                CONCAT('Devolução automática da saída ID: ', NEW.id), NEW.usuario_id);
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `atualizar_estoque_saida` AFTER INSERT ON `saidas` FOR EACH ROW BEGIN
    UPDATE materiais 
    SET quantidade_total = quantidade_total - NEW.quantidade
    WHERE id = NEW.material_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tramitacoes`
--

CREATE TABLE `tramitacoes` (
  `id` int(11) NOT NULL,
  `data_solicitacao` date NOT NULL,
  `materiais_solicitados` text NOT NULL,
  `observacoes` text DEFAULT NULL,
  `status` enum('pendente','em_andamento','aprovado','rejeitado','finalizado') DEFAULT 'pendente',
  `arquivo_resposta` varchar(255) DEFAULT NULL,
  `usuario_solicitante` int(11) NOT NULL,
  `usuario_responsavel` int(11) DEFAULT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `tramitacoes`
--

INSERT INTO `tramitacoes` (`id`, `data_solicitacao`, `materiais_solicitados`, `observacoes`, `status`, `arquivo_resposta`, `usuario_solicitante`, `usuario_responsavel`, `data_criacao`, `data_atualizacao`) VALUES
(3, '2025-09-21', 'computador', '', 'aprovado', NULL, 1, 2, '2025-09-21 07:20:52', '2025-09-22 19:21:57');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tramitacoes_arquivos`
--

CREATE TABLE `tramitacoes_arquivos` (
  `id` int(11) NOT NULL,
  `tramitacao_id` int(11) NOT NULL,
  `arquivo_nome` varchar(255) NOT NULL,
  `data_upload` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `tramitacoes_arquivos`
--

INSERT INTO `tramitacoes_arquivos` (`id`, `tramitacao_id`, `arquivo_nome`, `data_upload`) VALUES
(7, 3, 'resposta_3_1758656989.pdf', '2025-09-23 16:49:49'),
(8, 3, 'resposta_3_1758656999.pdf', '2025-09-23 16:49:59');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `nivel_acesso` enum('admin','usuario') DEFAULT 'usuario',
  `ativo` tinyint(1) DEFAULT 1,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `cpf`, `nome`, `senha`, `nivel_acesso`, `ativo`, `data_criacao`, `data_atualizacao`) VALUES
(1, '111.444.777-35', 'Administrador', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1, '2025-09-21 05:07:21', '2025-09-21 05:32:34'),
(2, '06302985218', 'Vitor Vieira', '$2y$10$LlESDEqIU9h0w2y7jqYXjexCoDhgBHMfrJH82PdwJRPVlnazfqpGu', 'admin', 1, '2025-09-21 05:36:05', '2025-09-21 05:36:05');

-- --------------------------------------------------------

--
-- Estrutura para view `materiais_em_falta`
--
DROP TABLE IF EXISTS `materiais_em_falta`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `materiais_em_falta`  AS SELECT `m`.`id` AS `id`, `m`.`codigo` AS `codigo`, `m`.`nome` AS `nome`, `m`.`quantidade_total` AS `quantidade_total`, `m`.`estoque_minimo` AS `estoque_minimo`, CASE WHEN `m`.`quantidade_total` = 0 THEN 'Indisponível' WHEN `m`.`quantidade_total` <= `m`.`estoque_minimo` THEN 'Baixo Estoque' ELSE 'Normal' END AS `status` FROM `materiais` AS `m` WHERE `m`.`ativo` = 1 AND (`m`.`quantidade_total` = 0 OR `m`.`estoque_minimo` is not null AND `m`.`quantidade_total` <= `m`.`estoque_minimo`) ;

-- --------------------------------------------------------

--
-- Estrutura para view `patrimonio_por_local`
--
DROP TABLE IF EXISTS `patrimonio_por_local`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `patrimonio_por_local`  AS SELECT `l`.`nome` AS `local_nome`, `l`.`tipo` AS `local_tipo`, `m`.`nome` AS `material_nome`, count(`p`.`id`) AS `quantidade` FROM ((`locais` `l` left join `patrimonio` `p` on(`l`.`id` = `p`.`local_id` and `p`.`ativo` = 1)) left join `materiais` `m` on(`p`.`material_id` = `m`.`id`)) WHERE `l`.`ativo` = 1 GROUP BY `l`.`id`, `l`.`nome`, `l`.`tipo`, `m`.`id`, `m`.`nome` ORDER BY `l`.`tipo` ASC, `l`.`nome` ASC, `m`.`nome` ASC ;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `entradas`
--
ALTER TABLE `entradas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `idx_entradas_material` (`material_id`),
  ADD KEY `idx_entradas_data` (`data_entrada`);

--
-- Índices de tabela `locais`
--
ALTER TABLE `locais`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `materiais`
--
ALTER TABLE `materiais`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD KEY `idx_materiais_codigo` (`codigo`),
  ADD KEY `idx_materiais_categoria` (`categoria_id`);

--
-- Índices de tabela `patrimonio`
--
ALTER TABLE `patrimonio`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tombamento` (`tombamento`),
  ADD KEY `idx_patrimonio_material` (`material_id`),
  ADD KEY `idx_patrimonio_local` (`local_id`);

--
-- Índices de tabela `patrimonio_material`
--
ALTER TABLE `patrimonio_material`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patrimonio_id` (`patrimonio_id`),
  ADD KEY `material_id` (`material_id`);

--
-- Índices de tabela `saidas`
--
ALTER TABLE `saidas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `idx_saidas_material` (`material_id`),
  ADD KEY `idx_saidas_data` (`data_saida`);

--
-- Índices de tabela `tramitacoes`
--
ALTER TABLE `tramitacoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_solicitante` (`usuario_solicitante`),
  ADD KEY `usuario_responsavel` (`usuario_responsavel`),
  ADD KEY `idx_tramitacoes_status` (`status`),
  ADD KEY `idx_tramitacoes_data` (`data_solicitacao`);

--
-- Índices de tabela `tramitacoes_arquivos`
--
ALTER TABLE `tramitacoes_arquivos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tramitacao_id` (`tramitacao_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cpf` (`cpf`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `entradas`
--
ALTER TABLE `entradas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `locais`
--
ALTER TABLE `locais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de tabela `materiais`
--
ALTER TABLE `materiais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1764;

--
-- AUTO_INCREMENT de tabela `patrimonio`
--
ALTER TABLE `patrimonio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT de tabela `patrimonio_material`
--
ALTER TABLE `patrimonio_material`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `saidas`
--
ALTER TABLE `saidas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tramitacoes`
--
ALTER TABLE `tramitacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `tramitacoes_arquivos`
--
ALTER TABLE `tramitacoes_arquivos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `entradas`
--
ALTER TABLE `entradas`
  ADD CONSTRAINT `entradas_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `materiais` (`id`),
  ADD CONSTRAINT `entradas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `materiais`
--
ALTER TABLE `materiais`
  ADD CONSTRAINT `materiais_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);

--
-- Restrições para tabelas `patrimonio`
--
ALTER TABLE `patrimonio`
  ADD CONSTRAINT `patrimonio_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `materiais` (`id`),
  ADD CONSTRAINT `patrimonio_ibfk_2` FOREIGN KEY (`local_id`) REFERENCES `locais` (`id`);

--
-- Restrições para tabelas `patrimonio_material`
--
ALTER TABLE `patrimonio_material`
  ADD CONSTRAINT `patrimonio_material_ibfk_1` FOREIGN KEY (`patrimonio_id`) REFERENCES `patrimonio` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `patrimonio_material_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `materiais` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `saidas`
--
ALTER TABLE `saidas`
  ADD CONSTRAINT `saidas_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `materiais` (`id`),
  ADD CONSTRAINT `saidas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `tramitacoes`
--
ALTER TABLE `tramitacoes`
  ADD CONSTRAINT `tramitacoes_ibfk_1` FOREIGN KEY (`usuario_solicitante`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `tramitacoes_ibfk_2` FOREIGN KEY (`usuario_responsavel`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `tramitacoes_arquivos`
--
ALTER TABLE `tramitacoes_arquivos`
  ADD CONSTRAINT `tramitacoes_arquivos_ibfk_1` FOREIGN KEY (`tramitacao_id`) REFERENCES `tramitacoes` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
