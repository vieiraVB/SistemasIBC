<?php
require_once 'config.php';
verificarLogin();

$sucesso = '';
$erro = '';

// Processar ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['acao'])) {
        switch ($_POST['acao']) {
            case 'adicionar_patrimonio':
                try {
                    // Pega os tombamentos separados por linha
                    $tombamentos_input = trim($_POST['tombamentos']);
                    $tombamentos = preg_split('/\r\n|\r|\n/', $tombamentos_input);

                    $material_id = $_POST['material_id'];
                    $local_id = $_POST['local_id'];
                    $descricao = $_POST['descricao'];
                    $estado = $_POST['estado'];
                    $data_aquisicao = !empty($_POST['data_aquisicao']) ? $_POST['data_aquisicao'] : null;
                    $valor_aquisicao = !empty($_POST['valor_aquisicao']) ? $_POST['valor_aquisicao'] : null;

                    $adicionados = 0;
                    $erros = [];

                    foreach ($tombamentos as $tombamento) {
                        $tombamento = trim($tombamento);
                        if (empty($tombamento)) continue;

                        try {
                            $stmt = $pdo->prepare("INSERT INTO patrimonio (tombamento, material_id, local_id, descricao, estado, data_aquisicao, valor_aquisicao) VALUES (?, ?, ?, ?, ?, ?, ?)");
                            $stmt->execute([
                                $tombamento,
                                $material_id,
                                $local_id,
                                $descricao,
                                $estado,
                                $data_aquisicao,
                                $valor_aquisicao
                            ]);
                            $adicionados++;
                        } catch (PDOException $e) {
                            if ($e->getCode() == 23000) {
                                $erros[] = $tombamento; // tombamento duplicado
                            } else {
                                $erros[] = $tombamento . ' (erro: ' . $e->getMessage() . ')';
                            }
                        }
                    }

                    $sucesso = "$adicionados item(s) patrimonial(is) adicionado(s) com sucesso!";
                    if (!empty($erros)) {
                        $erro = "Não foi possível adicionar os seguintes tombamentos: " . implode(', ', $erros);
                    }
                } catch (Exception $e) {
                    $erro = "Erro inesperado: " . $e->getMessage();
                }
                break;

            case 'desativar_patrimonio':
                try {
                    $stmt = $pdo->prepare("UPDATE patrimonio SET ativo = 0 WHERE id = ?");
                    $stmt->execute([$_POST['patrimonio_id']]);
                    $sucesso = "Item patrimonial desativado com sucesso!";
                } catch (PDOException $e) {
                    $erro = "Erro ao desativar item: " . $e->getMessage();
                }
                break;
        }
    }
}

// Buscar locais
$stmt = $pdo->query("
    SELECT *
    FROM locais
    WHERE ativo = 1
    ORDER BY 
        FIELD(tipo, 'laboratorio', 'sala', 'setor'), 
        CASE 
            WHEN tipo = 'laboratorio' THEN CAST(SUBSTRING(nome, 5) AS UNSIGNED)
            WHEN tipo = 'sala' THEN CAST(SUBSTRING(nome, 4) AS UNSIGNED)
            ELSE nome
        END
");

$locais = $stmt->fetchAll();

// Buscar materiais (apenas equipamentos para patrimônio)
$stmt = $pdo->query("SELECT m.* FROM materiais m LEFT JOIN categorias c ON m.categoria_id = c.id WHERE m.ativo = 1 AND (c.tipo = 'equipamento' OR c.tipo IS NULL) ORDER BY m.nome");
$materiais = $stmt->fetchAll();

// Filtros
$filtro_local = isset($_GET['local']) ? $_GET['local'] : '';
$filtro_tipo_local = isset($_GET['tipo_local']) ? $_GET['tipo_local'] : '';
$filtro_equipamento = isset($_GET['equipamento']) ? $_GET['equipamento'] : '';
$busca = isset($_GET['busca']) ? $_GET['busca'] : '';

// Buscar patrimônio com filtros
$sql = "SELECT p.*, m.codigo, m.nome as material_nome, l.nome as local_nome, l.tipo as local_tipo
        FROM patrimonio p
        JOIN materiais m ON p.material_id = m.id
        JOIN locais l ON p.local_id = l.id
        WHERE p.ativo = 1";

$params = [];

if ($filtro_local) {
    $sql .= " AND p.local_id = ?";
    $params[] = $filtro_local;
}

if ($filtro_tipo_local) {
    $sql .= " AND l.tipo = ?";
    $params[] = $filtro_tipo_local;
}

if ($filtro_equipamento) {
    $sql .= " AND p.material_id = ?";
    $params[] = $filtro_equipamento;
}

if ($busca) {
    $sql .= " AND (p.tombamento LIKE ? OR m.nome LIKE ? OR m.codigo LIKE ? OR p.descricao LIKE ?)";
    $busca_param = '%' . $busca . '%';
    $params[] = $busca_param;
    $params[] = $busca_param;
    $params[] = $busca_param;
    $params[] = $busca_param;
}

$sql .= " ORDER BY l.tipo, l.nome, m.nome";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$patrimonios = $stmt->fetchAll();

// Resumo por local (se um local específico for selecionado)
$resumo_local = [];
if ($filtro_local) {
    $stmt = $pdo->prepare("
        SELECT m.nome as material_nome, COUNT(*) as quantidade
        FROM patrimonio p
        JOIN materiais m ON p.material_id = m.id
        WHERE p.local_id = ? AND p.ativo = 1
        GROUP BY m.id, m.nome
        ORDER BY m.nome
    ");
    $stmt->execute([$filtro_local]);
    $resumo_local = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Controle Patrimonial - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <div class="main-layout">
        <?php include 'includes/sidebar.php'; ?>

        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">Controle Patrimonial</h1>
                <p>Gerenciamento de equipamentos por localização</p>
            </div>

            <?php if ($sucesso): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($sucesso); ?>
                </div>
            <?php endif; ?>

            <?php if ($erro): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($erro); ?>
                </div>
            <?php endif; ?>

            <!-- Abas por tipo de local -->
            <div class="tabs">
                <button class="tab <?php echo $filtro_tipo_local == '' ? 'active' : ''; ?>" onclick="trocarTipoLocal('')">
                    <i class="fas fa-building"></i> Todos
                </button>
                <button class="tab <?php echo $filtro_tipo_local == 'laboratorio' ? 'active' : ''; ?>" onclick="trocarTipoLocal('laboratorio')">
                    <i class="fas fa-flask"></i> Laboratórios
                </button>
                <button class="tab <?php echo $filtro_tipo_local == 'sala' ? 'active' : ''; ?>" onclick="trocarTipoLocal('sala')">
                    <i class="fas fa-chalkboard"></i> Salas
                </button>
                <button class="tab <?php echo $filtro_tipo_local == 'setor' ? 'active' : ''; ?>" onclick="trocarTipoLocal('setor')">
                    <i class="fas fa-building"></i> Setores
                </button>
            </div>

            <!-- Filtros -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Filtros de Busca</h3>
                </div>
                <div class="card-body">
                    <form method="GET" class="form-row">
                        <input type="hidden" name="tipo_local" value="<?php echo htmlspecialchars($filtro_tipo_local); ?>">

                        <div class="form-group">
                            <label class="form-label">Buscar</label>
                            <input type="text" name="busca" class="form-input" placeholder="Tombamento, material, descrição..." value="<?php echo htmlspecialchars($busca); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Local</label>
                            <select name="local" class="form-select">
                                <option value="">Todos os locais</option>
                                <?php
                                // Agrupar por tipo
                                $tipos = ['laboratorio' => 'Laboratórios', 'sala' => 'Salas', 'setor' => 'Setores'];
                                foreach ($tipos as $tipo => $label):
                                ?>
                                    <optgroup label="<?php echo $label; ?>">
                                        <?php foreach ($locais as $local): ?>
                                            <?php if ($local['tipo'] == $tipo): ?>
                                                <option value="<?php echo $local['id']; ?>" <?php echo $filtro_local == $local['id'] ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($local['nome']); ?>
                                                </option>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </optgroup>
                                <?php endforeach; ?>
                            </select>
                        </div>


                        <div class="form-group">
                            <label class="form-label">Material</label>
                            <select name="material" class="form-select">
                                <option value="">Todos os materiais</option>
                                <?php foreach ($materiais as $material): ?>
                                    <option value="<?php echo $material['id']; ?>" <?php echo $filtro_equipamento == $material['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($material['codigo'] . ' - ' . $material['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group d-flex align-center">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> Buscar
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Resumo do local selecionado -->
            <?php if ($filtro_local && !empty($resumo_local)): ?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-chart-bar"></i>
                            Resumo do Local: <?php
                                                $local_selecionado = array_filter($locais, function ($l) use ($filtro_local) {
                                                    return $l['id'] == $filtro_local;
                                                });
                                                echo htmlspecialchars(reset($local_selecionado)['nome']);
                                                ?>
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Material</th>
                                        <th>Quantidade</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($resumo_local as $item): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($item['material_nome']); ?></td>
                                            <td><strong><?php echo number_format($item['quantidade'], 0, ',', '.'); ?></strong></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Botão adicionar -->
            <div class="d-flex justify-between align-center mb-3">
                <h2>Itens Patrimoniais</h2>
                <button class="btn btn-success" onclick="abrirModal('modalAdicionar')">
                    <i class="fas fa-plus"></i> Adicionar Item
                </button>
            </div>

            <!-- Tabela de patrimônio -->
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Tombamento</th>
                            <th>Material</th>
                            <th>Local</th>
                            <th>Estado</th>
                            <th>Data Aquisição</th>
                            <th>Valor</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($patrimonios)): ?>
                            <tr>
                                <td colspan="7" class="text-center">Nenhum item patrimonial encontrado.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($patrimonios as $patrimonio): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($patrimonio['tombamento']); ?></strong></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($patrimonio['codigo']); ?></strong><br>
                                        <?php echo htmlspecialchars($patrimonio['material_nome']); ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-info"><?php echo ucfirst($patrimonio['local_tipo']); ?></span><br>
                                        <?php echo htmlspecialchars($patrimonio['local_nome']); ?>
                                    </td>
                                    <td>
                                        <?php
                                        $estado_classes = [
                                            'novo' => 'badge-success',
                                            'bom' => 'badge-success',
                                            'regular' => 'badge-warning',
                                            'ruim' => 'badge-danger',
                                            'inutilizado' => 'badge-danger'
                                        ];
                                        $classe = $estado_classes[$patrimonio['estado']] ?? 'badge-info';
                                        ?>
                                        <span class="badge <?php echo $classe; ?>">
                                            <?php echo ucfirst($patrimonio['estado']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $patrimonio['data_aquisicao'] ? formatarData($patrimonio['data_aquisicao']) : '-'; ?></td>
                                    <td>
                                        <?php if ($patrimonio['valor_aquisicao']): ?>
                                            R$ <?php echo number_format($patrimonio['valor_aquisicao'], 2, ',', '.'); ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" onclick="editarPatrimonio(<?php echo htmlspecialchars(json_encode($patrimonio)); ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-info" onclick="verDetalhes(<?php echo htmlspecialchars(json_encode($patrimonio)); ?>)">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger" onclick="confirmarDesativacao(<?php echo $patrimonio['id']; ?>, '<?php echo htmlspecialchars($patrimonio['tombamento']); ?>')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal Adicionar Item -->
    <div id="modalAdicionar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Adicionar Item Patrimonial</h2>
                <button class="close" onclick="fecharModal('modalAdicionar')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="acao" value="adicionar_patrimonio">

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Tombamento *</label>
                        <textarea name="tombamentos" class="form-textarea" required placeholder="Digite cada tombamento em uma linha"></textarea>
                        <small>Informe um tombamento por linha</small>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Material *</label>
                        <select name="material_id" class="form-select" required>
                            <option value="">Selecione um material</option>
                            <?php foreach ($materiais as $material): ?>
                                <option value="<?php echo $material['id']; ?>">
                                    <?php echo htmlspecialchars($material['codigo'] . ' - ' . $material['nome']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Local *</label>
                        <select name="local_id" class="form-select" required>
                            <option value="">Selecione um local</option>
                            <?php foreach ($tipos as $tipo => $label): ?>
                                <optgroup label="<?php echo $label; ?>">
                                    <?php foreach ($locais as $local): ?>
                                        <?php if ($local['tipo'] == $tipo): ?>
                                            <option value="<?php echo $local['id']; ?>">
                                                <?php echo htmlspecialchars($local['nome']); ?>
                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Estado</label>
                        <select name="estado" class="form-select">
                            <option value="novo">Novo</option>
                            <option value="bom" selected>Bom</option>
                            <option value="regular">Regular</option>
                            <option value="ruim">Ruim</option>
                            <option value="inutilizado">Inutilizado</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Data de Aquisição</label>
                        <input type="date" name="data_aquisicao" class="form-input">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Valor de Aquisição</label>
                        <input type="number" name="valor_aquisicao" class="form-input" step="0.01" min="0">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Descrição</label>
                    <textarea name="descricao" class="form-textarea" placeholder="Informações adicionais sobre o item..."></textarea>
                </div>

                <div class="d-flex justify-between gap-2 mt-3">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalAdicionar')">Cancelar</button>
                    <button type="submit" class="btn btn-success">Adicionar</button>
                </div>
            </form>
        </div>
    </div>

    </div>

    <!-- Modal Editar Item -->
    <div id="modalEditar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Editar Item Patrimonial</h2>
                <button class="close" onclick="fecharModal('modalEditar')">&times;</button>
            </div>
            <form method="POST" id="formEditar">
                <input type="hidden" name="acao" value="editar_patrimonio">
                <input type="hidden" name="patrimonio_id" id="edit_patrimonio_id">

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Tombamento</label>
                        <input type="text" id="edit_tombamento" class="form-input" readonly>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Material</label>
                        <input type="text" id="edit_material" class="form-input" readonly>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Local *</label>
                        <select name="local_id" id="edit_local_id" class="form-select" required>
                            <option value="">Selecione um local</option>
                            <?php
                            foreach ($tipos as $tipo => $label):
                            ?>
                                <optgroup label="<?php echo $label; ?>">
                                    <?php foreach ($locais as $local): ?>
                                        <?php if ($local['tipo'] == $tipo): ?>
                                            <option value="<?php echo $local['id']; ?>">
                                                <?php echo htmlspecialchars($local['nome']); ?>
                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>


                    <div class="form-group">
                        <label class="form-label">Estado</label>
                        <select name="estado" id="edit_estado" class="form-select">
                            <option value="novo">Novo</option>
                            <option value="bom">Bom</option>
                            <option value="regular">Regular</option>
                            <option value="ruim">Ruim</option>
                            <option value="inutilizado">Inutilizado</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Data de Aquisição</label>
                        <input type="date" name="data_aquisicao" id="edit_data_aquisicao" class="form-input">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Valor de Aquisição</label>
                        <input type="number" name="valor_aquisicao" id="edit_valor_aquisicao" class="form-input" step="0.01" min="0">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Descrição</label>
                    <textarea name="descricao" id="edit_descricao" class="form-textarea"></textarea>
                </div>

                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalEditar')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Detalhes -->
    <div id="modalDetalhes" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Detalhes do Item Patrimonial</h2>
                <button class="close" onclick="fecharModal('modalDetalhes')">&times;</button>
            </div>
            <div id="conteudoDetalhes">
                <!-- Conteúdo será preenchido via JavaScript -->
            </div>
            <div class="d-flex justify-between gap-2">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modalDetalhes')">Fechar</button>
            </div>
        </div>
    </div>

    <!-- Modal Confirmar Desativação -->
    <div id="modalDesativar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Confirmar Desativação</h2>
                <button class="close" onclick="fecharModal('modalDesativar')">&times;</button>
            </div>
            <p>Tem certeza que deseja desativar o item patrimonial <strong id="tombamentoDesativar"></strong>?</p>
            <p class="text-warning">Esta ação não pode ser desfeita.</p>

            <form method="POST" id="formDesativar">
                <input type="hidden" name="acao" value="desativar_patrimonio">
                <input type="hidden" name="patrimonio_id" id="desativar_patrimonio_id">

                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalDesativar')">Cancelar</button>
                    <button type="submit" class="btn btn-danger">Desativar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function trocarTipoLocal(tipo) {
            const url = new URL(window.location);
            url.searchParams.set('tipo_local', tipo);
            url.searchParams.delete('local');
            url.searchParams.delete('busca');
            window.location.href = url.toString();
        }

        function abrirModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }

        function fecharModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function editarPatrimonio(patrimonio) {
            document.getElementById('edit_patrimonio_id').value = patrimonio.id;
            document.getElementById('edit_tombamento').value = patrimonio.tombamento;
            document.getElementById('edit_material').value = patrimonio.codigo + ' - ' + patrimonio.material_nome;
            document.getElementById('edit_local_id').value = patrimonio.local_id;
            document.getElementById('edit_estado').value = patrimonio.estado;
            document.getElementById('edit_data_aquisicao').value = patrimonio.data_aquisicao || '';
            document.getElementById('edit_valor_aquisicao').value = patrimonio.valor_aquisicao || '';
            document.getElementById('edit_descricao').value = patrimonio.descricao || '';

            abrirModal('modalEditar');
        }

        function verDetalhes(patrimonio) {
            const conteudo = document.getElementById('conteudoDetalhes');

            conteudo.innerHTML = `
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Tombamento</label>
                        <input type="text" class="form-input" value="${patrimonio.tombamento}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Material</label>
                        <input type="text" class="form-input" value="${patrimonio.codigo} - ${patrimonio.material_nome}" readonly>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Local</label>
                        <input type="text" class="form-input" value="${patrimonio.local_nome} (${patrimonio.local_tipo})" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Estado</label>
                        <input type="text" class="form-input" value="${patrimonio.estado}" readonly>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Data de Aquisição</label>
                        <input type="text" class="form-input" value="${patrimonio.data_aquisicao ? formatarData(patrimonio.data_aquisicao) : '-'}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Valor de Aquisição</label>
                        <input type="text" class="form-input" value="${patrimonio.valor_aquisicao ? 'R$ ' + parseFloat(patrimonio.valor_aquisicao).toLocaleString('pt-BR', {minimumFractionDigits: 2}) : '-'}" readonly>
                    </div>
                </div>
                
                ${patrimonio.descricao ? `
                <div class="form-group">
                    <label class="form-label">Descrição</label>
                    <textarea class="form-textarea" readonly>${patrimonio.descricao}</textarea>
                </div>
                ` : ''}
            `;

            abrirModal('modalDetalhes');
        }

        function confirmarDesativacao(id, tombamento) {
            document.getElementById('desativar_patrimonio_id').value = id;
            document.getElementById('tombamentoDesativar').textContent = tombamento;
            abrirModal('modalDesativar');
        }

        function formatarData(data) {
            const partes = data.split('-');
            return `${partes[2]}/${partes[1]}/${partes[0]}`;
        }

        // Fechar modal clicando fora
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>

</html>