<?php
require_once 'config.php';
verificarAdmin(); // Apenas administradores podem acessar

$sucesso = '';
$erro = '';

// Processar ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['acao'])) {
        switch ($_POST['acao']) {
            case 'adicionar_usuario':
                try {
                    $cpf = limparCPF($_POST['cpf']);
                    
                    if (!validarCPF($cpf)) {
                        $erro = "CPF inválido.";
                    } else {
                        $senha_hash = password_hash($_POST['senha'], PASSWORD_DEFAULT);
                        
                        $stmt = $pdo->prepare("INSERT INTO usuarios (cpf, nome, senha, nivel_acesso) VALUES (?, ?, ?, ?)");
                        $stmt->execute([
                            $cpf,
                            $_POST['nome'],
                            $senha_hash,
                            $_POST['nivel_acesso']
                        ]);
                        
                        $sucesso = "Usuário adicionado com sucesso!";
                    }
                } catch (PDOException $e) {
                    if ($e->getCode() == 23000) {
                        $erro = "CPF já cadastrado no sistema.";
                    } else {
                        $erro = "Erro ao adicionar usuário: " . $e->getMessage();
                    }
                }
                break;
                
            case 'editar_usuario':
                try {
                    $sql = "UPDATE usuarios SET nome = ?, nivel_acesso = ?";
                    $params = [$_POST['nome'], $_POST['nivel_acesso']];
                    
                    if (!empty($_POST['nova_senha'])) {
                        $sql .= ", senha = ?";
                        $params[] = password_hash($_POST['nova_senha'], PASSWORD_DEFAULT);
                    }
                    
                    $sql .= " WHERE id = ?";
                    $params[] = $_POST['usuario_id'];
                    
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);
                    
                    $sucesso = "Usuário atualizado com sucesso!";
                } catch (PDOException $e) {
                    $erro = "Erro ao atualizar usuário: " . $e->getMessage();
                }
                break;
                
            case 'desativar_usuario':
                try {
                    $stmt = $pdo->prepare("UPDATE usuarios SET ativo = 0 WHERE id = ?");
                    $stmt->execute([$_POST['usuario_id']]);
                    
                    $sucesso = "Usuário desativado com sucesso!";
                } catch (PDOException $e) {
                    $erro = "Erro ao desativar usuário: " . $e->getMessage();
                }
                break;
                
            case 'ativar_usuario':
                try {
                    $stmt = $pdo->prepare("UPDATE usuarios SET ativo = 1 WHERE id = ?");
                    $stmt->execute([$_POST['usuario_id']]);
                    
                    $sucesso = "Usuário ativado com sucesso!";
                } catch (PDOException $e) {
                    $erro = "Erro ao ativar usuário: " . $e->getMessage();
                }
                break;
        }
    }
}

// Buscar usuários
$filtro_nivel = isset($_GET['nivel']) ? $_GET['nivel'] : '';
$filtro_status = isset($_GET['status']) ? $_GET['status'] : '';
$busca = isset($_GET['busca']) ? $_GET['busca'] : '';

$sql = "SELECT * FROM usuarios WHERE 1=1";
$params = [];

if ($filtro_nivel) {
    $sql .= " AND nivel_acesso = ?";
    $params[] = $filtro_nivel;
}

if ($filtro_status !== '') {
    $sql .= " AND ativo = ?";
    $params[] = $filtro_status;
}

if ($busca) {
    $sql .= " AND (nome LIKE ? OR cpf LIKE ?)";
    $busca_param = '%' . $busca . '%';
    $params[] = $busca_param;
    $params[] = $busca_param;
}

$sql .= " ORDER BY nome";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$usuarios = $stmt->fetchAll();

// Estatísticas
$stmt = $pdo->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN ativo = 1 THEN 1 ELSE 0 END) as ativos,
    SUM(CASE WHEN ativo = 0 THEN 1 ELSE 0 END) as inativos,
    SUM(CASE WHEN nivel_acesso = 'admin' THEN 1 ELSE 0 END) as admins,
    SUM(CASE WHEN nivel_acesso = 'usuario' THEN 1 ELSE 0 END) as usuarios_comuns
    FROM usuarios");
$estatisticas = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuários - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="main-layout">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">Gerenciamento de Usuários</h1>
                <p>Administração de usuários do sistema</p>
            </div>

            <?php if ($sucesso): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($sucesso); ?>
                </div>
            <?php endif; ?>

            <?php if ($erro): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($erro); ?>
                </div>
            <?php endif; ?>

            <!-- Cards de estatísticas -->
            <div class="cards-grid">
                <div class="stat-card">
                    <div class="stat-icon blue">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Total de Usuários</h3>
                        <p><?php echo number_format($estatisticas['total'], 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon green">
                        <i class="fas fa-user-check"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Usuários Ativos</h3>
                        <p><?php echo number_format($estatisticas['ativos'], 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon red">
                        <i class="fas fa-user-times"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Usuários Inativos</h3>
                        <p><?php echo number_format($estatisticas['inativos'], 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon yellow">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Administradores</h3>
                        <p><?php echo number_format($estatisticas['admins'], 0, ',', '.'); ?></p>
                    </div>
                </div>
            </div>

            <!-- Filtros -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Filtros de Busca</h3>
                </div>
                <div class="card-body">
                    <form method="GET" class="form-row">
                        <div class="form-group">
                            <label class="form-label">Buscar</label>
                            <input type="text" name="busca" class="form-input" placeholder="Nome ou CPF..." value="<?php echo htmlspecialchars($busca); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Nível de Acesso</label>
                            <select name="nivel" class="form-select">
                                <option value="">Todos os níveis</option>
                                <option value="admin" <?php echo $filtro_nivel == 'admin' ? 'selected' : ''; ?>>Administrador</option>
                                <option value="usuario" <?php echo $filtro_nivel == 'usuario' ? 'selected' : ''; ?>>Usuário</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="">Todos</option>
                                <option value="1" <?php echo $filtro_status === '1' ? 'selected' : ''; ?>>Ativo</option>
                                <option value="0" <?php echo $filtro_status === '0' ? 'selected' : ''; ?>>Inativo</option>
                            </select>
                        </div>
                        
                        <div class="form-group d-flex align-center">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> Buscar
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Botão adicionar usuário -->
            <div class="d-flex justify-between align-center mb-3">
                <h2>Lista de Usuários</h2>
                <button class="btn btn-success" onclick="abrirModal('modalAdicionar')">
                    <i class="fas fa-plus"></i> Adicionar Usuário
                </button>
            </div>

            <!-- Tabela de usuários -->
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>CPF</th>
                            <th>Nível de Acesso</th>
                            <th>Status</th>
                            <th>Data de Criação</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($usuarios)): ?>
                            <tr>
                                <td colspan="6" class="text-center">Nenhum usuário encontrado.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($usuarios as $usuario): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($usuario['nome']); ?></td>
                                    <td><?php echo formatarCPF($usuario['cpf']); ?></td>
                                    <td>
                                        <?php if ($usuario['nivel_acesso'] == 'admin'): ?>
                                            <span class="badge badge-warning">
                                                <i class="fas fa-user-shield"></i> Administrador
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-info">
                                                <i class="fas fa-user"></i> Usuário
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($usuario['ativo']): ?>
                                            <span class="badge badge-success">
                                                <i class="fas fa-check"></i> Ativo
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">
                                                <i class="fas fa-times"></i> Inativo
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo formatarDataHora($usuario['data_criacao']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" onclick="editarUsuario(<?php echo htmlspecialchars(json_encode($usuario)); ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        
                                        <?php if ($usuario['id'] != $_SESSION['usuario_id']): // Não pode desativar a si mesmo ?>
                                            <?php if ($usuario['ativo']): ?>
                                                <button class="btn btn-sm btn-danger" onclick="confirmarDesativacao(<?php echo $usuario['id']; ?>, '<?php echo htmlspecialchars($usuario['nome']); ?>')">
                                                    <i class="fas fa-user-times"></i>
                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-success" onclick="confirmarAtivacao(<?php echo $usuario['id']; ?>, '<?php echo htmlspecialchars($usuario['nome']); ?>')">
                                                    <i class="fas fa-user-check"></i>
                                                </button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal Adicionar Usuário -->
    <div id="modalAdicionar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Adicionar Usuário</h2>
                <button class="close" onclick="fecharModal('modalAdicionar')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="acao" value="adicionar_usuario">
                
                <div class="form-group">
                    <label class="form-label">Nome Completo *</label>
                    <input type="text" name="nome" class="form-input" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">CPF *</label>
                        <input type="text" name="cpf" class="form-input cpf-mask" placeholder="000.000.000-00" maxlength="14" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Nível de Acesso *</label>
                        <select name="nivel_acesso" class="form-select" required>
                            <option value="usuario">Usuário</option>
                            <option value="admin">Administrador</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Senha *</label>
                    <input type="password" name="senha" class="form-input" required minlength="6">
                    <small class="text-secondary">Mínimo de 6 caracteres</small>
                </div>
                
                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalAdicionar')">Cancelar</button>
                    <button type="submit" class="btn btn-success">Adicionar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Editar Usuário -->
    <div id="modalEditar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Editar Usuário</h2>
                <button class="close" onclick="fecharModal('modalEditar')">&times;</button>
            </div>
            <form method="POST" id="formEditar">
                <input type="hidden" name="acao" value="editar_usuario">
                <input type="hidden" name="usuario_id" id="edit_usuario_id">
                
                <div class="form-group">
                    <label class="form-label">Nome Completo *</label>
                    <input type="text" name="nome" id="edit_nome" class="form-input" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">CPF</label>
                        <input type="text" id="edit_cpf" class="form-input" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Nível de Acesso *</label>
                        <select name="nivel_acesso" id="edit_nivel_acesso" class="form-select" required>
                            <option value="usuario">Usuário</option>
                            <option value="admin">Administrador</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Nova Senha</label>
                    <input type="password" name="nova_senha" class="form-input" minlength="6">
                    <small class="text-secondary">Deixe em branco para manter a senha atual</small>
                </div>
                
                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalEditar')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Confirmar Desativação -->
    <div id="modalDesativar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Confirmar Desativação</h2>
                <button class="close" onclick="fecharModal('modalDesativar')">&times;</button>
            </div>
            <p>Tem certeza que deseja desativar o usuário <strong id="nomeDesativar"></strong>?</p>
            <p class="alert alert-warning">O usuário não conseguirá mais fazer login no sistema.</p>
            
            <form method="POST" id="formDesativar">
                <input type="hidden" name="acao" value="desativar_usuario">
                <input type="hidden" name="usuario_id" id="desativar_usuario_id">
                
                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalDesativar')">Cancelar</button>
                    <button type="submit" class="btn btn-danger">Desativar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Confirmar Ativação -->
    <div id="modalAtivar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Confirmar Ativação</h2>
                <button class="close" onclick="fecharModal('modalAtivar')">&times;</button>
            </div>
            <p>Tem certeza que deseja ativar o usuário <strong id="nomeAtivar"></strong>?</p>
            <p class="alert alert-info">O usuário poderá fazer login no sistema novamente.</p>
            
            <form method="POST" id="formAtivar">
                <input type="hidden" name="acao" value="ativar_usuario">
                <input type="hidden" name="usuario_id" id="ativar_usuario_id">
                
                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalAtivar')">Cancelar</button>
                    <button type="submit" class="btn btn-success">Ativar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function abrirModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }

        function fecharModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function editarUsuario(usuario) {
            document.getElementById('edit_usuario_id').value = usuario.id;
            document.getElementById('edit_nome').value = usuario.nome;
            document.getElementById('edit_cpf').value = formatarCPF(usuario.cpf);
            document.getElementById('edit_nivel_acesso').value = usuario.nivel_acesso;
            
            abrirModal('modalEditar');
        }

        function confirmarDesativacao(id, nome) {
            document.getElementById('desativar_usuario_id').value = id;
            document.getElementById('nomeDesativar').textContent = nome;
            abrirModal('modalDesativar');
        }

        function confirmarAtivacao(id, nome) {
            document.getElementById('ativar_usuario_id').value = id;
            document.getElementById('nomeAtivar').textContent = nome;
            abrirModal('modalAtivar');
        }

        function formatarCPF(cpf) {
            return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
        }

        // Máscara para CPF
        document.addEventListener('DOMContentLoaded', function() {
            const cpfInputs = document.querySelectorAll('.cpf-mask');
            cpfInputs.forEach(function(input) {
                input.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    value = value.replace(/(\d{3})(\d)/, '$1.$2');
                    value = value.replace(/(\d{3})(\d)/, '$1.$2');
                    value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
                    e.target.value = value;
                });
            });
        });

        // Fechar modal clicando fora
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>

