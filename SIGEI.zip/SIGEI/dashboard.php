<?php
require_once 'config.php';
verificarLogin();

// Buscar estatísticas do sistema
try {
    // Total de materiais
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM materiais WHERE ativo = 1");
    $totalMateriais = $stmt->fetch()['total'];
    
    // Materiais em falta
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM materiais_em_falta");
    $materiaisEmFalta = $stmt->fetch()['total'];
    
    // Saídas do mês atual
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM saidas WHERE MONTH(data_saida) = MONTH(CURRENT_DATE()) AND YEAR(data_saida) = YEAR(CURRENT_DATE())");
    $saidasMes = $stmt->fetch()['total'];
    
    // Entradas do mês atual
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM entradas WHERE MONTH(data_entrada) = MONTH(CURRENT_DATE()) AND YEAR(data_entrada) = YEAR(CURRENT_DATE())");
    $entradasMes = $stmt->fetch()['total'];
    
    // Tramitações pendentes
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM tramitacoes WHERE status = 'pendente'");
    $tramitacoesPendentes = $stmt->fetch()['total'];
    
    // Últimas movimentações
    $stmt = $pdo->query("
        (SELECT 'saida' as tipo, s.data_saida as data, m.nome as material, s.quantidade, s.destino as destino_responsavel
         FROM saidas s 
         JOIN materiais m ON s.material_id = m.id 
         ORDER BY s.data_criacao DESC LIMIT 5)
        UNION ALL
        (SELECT 'entrada' as tipo, e.data_entrada as data, m.nome as material, e.quantidade, e.responsavel_recebimento as destino_responsavel
         FROM entradas e 
         JOIN materiais m ON e.material_id = m.id 
         ORDER BY e.data_criacao DESC LIMIT 5)
        ORDER BY data DESC LIMIT 10
    ");
    $ultimasMovimentacoes = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $erro = "Erro ao carregar dados: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="main-layout">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">Dashboard</h1>
                <p>Bem-vindo(a), <?php echo htmlspecialchars($_SESSION['usuario_nome']); ?>!</p>
            </div>

            <!-- Cards de estatísticas -->
            <div class="cards-grid">
                <div class="stat-card">
                    <div class="stat-icon blue">
                        <i class="fas fa-boxes"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Total de Materiais</h3>
                        <p><?php echo number_format($totalMateriais, 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon red">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Em Falta</h3>
                        <p><?php echo number_format($materiaisEmFalta, 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon green">
                        <i class="fas fa-arrow-up"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Entradas (Mês)</h3>
                        <p><?php echo number_format($entradasMes, 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon yellow">
                        <i class="fas fa-arrow-down"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Saídas (Mês)</h3>
                        <p><?php echo number_format($saidasMes, 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon blue">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Tramitações Pendentes</h3>
                        <p><?php echo number_format($tramitacoesPendentes, 0, ',', '.'); ?></p>
                    </div>
                </div>
            </div>

            <!-- Últimas movimentações -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Últimas Movimentações</h2>
                </div>
                <div class="card-body">
                    <?php if (empty($ultimasMovimentacoes)): ?>
                        <p>Nenhuma movimentação encontrada.</p>
                    <?php else: ?>
                        <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Tipo</th>
                                        <th>Data</th>
                                        <th>Material</th>
                                        <th>Quantidade</th>
                                        <th>Destino/Responsável</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($ultimasMovimentacoes as $mov): ?>
                                        <tr>
                                            <td>
                                                <?php if ($mov['tipo'] == 'entrada'): ?>
                                                    <span class="badge badge-success">Entrada</span>
                                                <?php else: ?>
                                                    <span class="badge badge-warning">Saída</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo formatarData($mov['data']); ?></td>
                                            <td><?php echo htmlspecialchars($mov['material']); ?></td>
                                            <td><?php echo number_format($mov['quantidade'], 0, ',', '.'); ?></td>
                                            <td><?php echo htmlspecialchars($mov['destino_responsavel']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

