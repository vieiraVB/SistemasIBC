<?php
require_once 'config.php';
verificarLogin();

$sucesso = '';
$erro = '';

// Processar ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['acao'])) {
        switch ($_POST['acao']) {
            case 'nova_tramitacao':
                try {
                    // Se a data veio do formulário, converte; senão usa a data atual
                    if (!empty($_POST['data_solicitacao'])) {
                        $data_solicitacao = converterDataMySQL($_POST['data_solicitacao']);
                        if (!$data_solicitacao) {
                            // Se a conversão falhar, usa data atual
                            $data_solicitacao = date('Y-m-d');
                        }
                    } else {
                        $data_solicitacao = date('Y-m-d');
                    }

                    // Verifica se materiais foram informados
                    $materiais_solicitados = trim($_POST['materiais_solicitados'] ?? '');
                    if ($materiais_solicitados === '') {
                        throw new Exception('Informe os materiais solicitados.');
                    }

                    $observacoes = trim($_POST['observacoes'] ?? '');

                    $stmt = $pdo->prepare("
                        INSERT INTO tramitacoes 
                            (data_solicitacao, materiais_solicitados, observacoes, usuario_solicitante) 
                        VALUES (?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $data_solicitacao,
                        $materiais_solicitados,
                        $observacoes,
                        $_SESSION['usuario_id']
                    ]);

                    $sucesso = "Solicitação de compra registrada com sucesso!";
                } catch (PDOException $e) {
                    $erro = "Erro ao registrar solicitação: " . $e->getMessage();
                } catch (Exception $e) {
                    $erro = "Erro: " . $e->getMessage();
                }
                break;

            case 'atualizar_status':
                try {
                    $stmt = $pdo->prepare("UPDATE tramitacoes SET status = ?, usuario_responsavel = ? WHERE id = ?");
                    $stmt->execute([
                        $_POST['status'],
                        $_SESSION['usuario_id'],
                        $_POST['tramitacao_id']
                    ]);

                    $sucesso = "Status da tramitação atualizado com sucesso!";
                } catch (PDOException $e) {
                    $erro = "Erro ao atualizar status: " . $e->getMessage();
                }
                break;

            case 'upload_resposta':
                try {
                    if (isset($_FILES['arquivo_resposta']) && $_FILES['arquivo_resposta']['error'] == 0) {
                        $arquivo = $_FILES['arquivo_resposta'];
                        $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));

                        if ($extensao !== 'pdf') {
                            $erro = "Apenas arquivos PDF são permitidos.";
                        } else {
                            $nome_arquivo = 'resposta_' . $_POST['tramitacao_id'] . '_' . time() . '.pdf';
                            $caminho_destino = 'uploads/' . $nome_arquivo;

                            if (!is_dir('uploads')) mkdir('uploads', 0755, true);

                            if (move_uploaded_file($arquivo['tmp_name'], $caminho_destino)) {
                                $stmt = $pdo->prepare("INSERT INTO tramitacoes_arquivos (tramitacao_id, arquivo_nome) VALUES (?, ?)");
                                $stmt->execute([$_POST['tramitacao_id'], $nome_arquivo]);

                                $sucesso = "Arquivo PDF enviado com sucesso!";
                            } else {
                                $erro = "Erro ao fazer upload do arquivo.";
                            }
                        }
                    }
                } catch (PDOException $e) {
                    $erro = "Erro ao salvar arquivo: " . $e->getMessage();
                }
                break;
        }
    }
}

// Filtros
$filtro_status = isset($_GET['status']) ? $_GET['status'] : '';
$filtro_data_inicio = isset($_GET['data_inicio']) ? $_GET['data_inicio'] : '';
$filtro_data_fim = isset($_GET['data_fim']) ? $_GET['data_fim'] : '';
$busca = isset($_GET['busca']) ? $_GET['busca'] : '';

// Buscar tramitações com filtros
$sql = "SELECT t.*, 
               us.nome as solicitante_nome,
               ur.nome as responsavel_nome
        FROM tramitacoes t
        JOIN usuarios us ON t.usuario_solicitante = us.id
        LEFT JOIN usuarios ur ON t.usuario_responsavel = ur.id
        WHERE 1=1";

$params = [];

if ($filtro_status) {
    $sql .= " AND t.status = ?";
    $params[] = $filtro_status;
}

if ($filtro_data_inicio) {
    $sql .= " AND t.data_solicitacao >= ?";
    $params[] = converterDataMySQL($filtro_data_inicio);
}

if ($filtro_data_fim) {
    $sql .= " AND t.data_solicitacao <= ?";
    $params[] = converterDataMySQL($filtro_data_fim);
}

if ($busca) {
    $sql .= " AND (t.materiais_solicitados LIKE ? OR t.observacoes LIKE ? OR us.nome LIKE ?)";
    $busca_param = '%' . $busca . '%';
    $params[] = $busca_param;
    $params[] = $busca_param;
    $params[] = $busca_param;
}

$sql .= " ORDER BY t.data_solicitacao DESC, t.data_criacao DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tramitacoes = $stmt->fetchAll();

// Estatísticas
$stmt = $pdo->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) as pendentes,
    SUM(CASE WHEN status = 'em_andamento' THEN 1 ELSE 0 END) as em_andamento,
    SUM(CASE WHEN status = 'aprovado' THEN 1 ELSE 0 END) as aprovados,
    SUM(CASE WHEN status = 'rejeitado' THEN 1 ELSE 0 END) as rejeitados,
    SUM(CASE WHEN status = 'finalizado' THEN 1 ELSE 0 END) as finalizados
    FROM tramitacoes");
$estatisticas = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tramitações - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <div class="main-layout">
        <?php include 'includes/sidebar.php'; ?>

        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">Tramitações</h1>
                <p>Gerenciamento de solicitações de compras</p>
            </div>

            <?php if ($sucesso): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($sucesso); ?>
                </div>
            <?php endif; ?>

            <?php if ($erro): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($erro); ?>
                </div>
            <?php endif; ?>

            <!-- Cards de estatísticas -->
            <div class="cards-grid">
                <div class="stat-card">
                    <div class="stat-icon blue">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Total de Solicitações</h3>
                        <p><?php echo number_format($estatisticas['total'], 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon yellow">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Pendentes</h3>
                        <p><?php echo number_format($estatisticas['pendentes'], 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon blue">
                        <i class="fas fa-cog"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Em Andamento</h3>
                        <p><?php echo number_format($estatisticas['em_andamento'], 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon green">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Aprovados</h3>
                        <p><?php echo number_format($estatisticas['aprovados'], 0, ',', '.'); ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon red">
                        <i class="fas fa-times"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Rejeitados</h3>
                        <p><?php echo number_format($estatisticas['rejeitados'], 0, ',', '.'); ?></p>
                    </div>
                </div>
            </div>

            <!-- Botão nova solicitação -->
            <div class="d-flex justify-between align-center mb-3">
                <h2>Nova Solicitação</h2>
                <button class="btn btn-success" onclick="abrirModal('modalNova')">
                    <i class="fas fa-plus"></i> Nova Solicitação
                </button>
            </div>

            <!-- Filtros -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Filtros de Busca</h3>
                </div>
                <div class="card-body">
                    <form method="GET" class="form-row">
                        <div class="form-group">
                            <label class="form-label">Buscar</label>
                            <input type="text" name="busca" class="form-input" placeholder="Materiais, observações, solicitante..." value="<?php echo htmlspecialchars($busca); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="">Todos os status</option>
                                <option value="pendente" <?php echo $filtro_status == 'pendente' ? 'selected' : ''; ?>>Pendente</option>
                                <option value="em_andamento" <?php echo $filtro_status == 'em_andamento' ? 'selected' : ''; ?>>Em Andamento</option>
                                <option value="aprovado" <?php echo $filtro_status == 'aprovado' ? 'selected' : ''; ?>>Aprovado</option>
                                <option value="rejeitado" <?php echo $filtro_status == 'rejeitado' ? 'selected' : ''; ?>>Rejeitado</option>
                                <option value="finalizado" <?php echo $filtro_status == 'finalizado' ? 'selected' : ''; ?>>Finalizado</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" class="form-input" value="<?php echo htmlspecialchars($filtro_data_inicio); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" class="form-input" value="<?php echo htmlspecialchars($filtro_data_fim); ?>">
                        </div>

                        <div class="form-group d-flex align-center">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> Buscar
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Lista de tramitações -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Lista de Tramitações</h3>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Materiais Solicitados</th>
                                    <th>Solicitante</th>
                                    <th>Status</th>
                                    <th>Responsável</th>
                                    <th>Arquivo</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($tramitacoes)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">Nenhuma tramitação encontrada.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($tramitacoes as $tramitacao): ?>
                                        <tr>
                                            <td><?php echo formatarData($tramitacao['data_solicitacao']); ?></td>
                                            <td class="observacao">
                                                <?php echo htmlspecialchars(substr($tramitacao['materiais_solicitados'], 0, 100)); ?>
                                                <?php if (strlen($tramitacao['materiais_solicitados']) > 100): ?>...<?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($tramitacao['solicitante_nome']); ?></td>
                                            <td>
                                                <?php
                                                $status_classes = [
                                                    'pendente' => 'badge-warning',
                                                    'em_andamento' => 'badge-info',
                                                    'aprovado' => 'badge-success',
                                                    'rejeitado' => 'badge-danger',
                                                    'finalizado' => 'badge-success'
                                                ];
                                                $status_labels = [
                                                    'pendente' => 'Pendente',
                                                    'em_andamento' => 'Em Andamento',
                                                    'aprovado' => 'Aprovado',
                                                    'rejeitado' => 'Rejeitado',
                                                    'finalizado' => 'Finalizado'
                                                ];
                                                $classe = $status_classes[$tramitacao['status']] ?? 'badge-info';
                                                $label = $status_labels[$tramitacao['status']] ?? $tramitacao['status'];
                                                ?>
                                                <span class="badge <?php echo $classe; ?>">
                                                    <?php echo $label; ?>
                                                </span>
                                            </td>
                                            <td><?php echo htmlspecialchars($tramitacao['responsavel_nome'] ?? '-'); ?></td>
                                            <td>
                                                <?php
                                                // Buscar arquivos vinculados a esta tramitação
                                                $stmtArquivos = $pdo->prepare("SELECT * FROM tramitacoes_arquivos WHERE tramitacao_id = ?");
                                                $stmtArquivos->execute([$tramitacao['id']]);
                                                $arquivos = $stmtArquivos->fetchAll(PDO::FETCH_ASSOC);
                                                ?>

                                                <?php if (!empty($arquivos)): ?>
                                                    <?php foreach ($arquivos as $arquivo): ?>
                                                        <a href="uploads/<?php echo htmlspecialchars($arquivo['arquivo_nome']); ?>" target="_blank" class="btn btn-sm btn-info mb-1">
                                                            <i class="fas fa-file-pdf"></i> Ver PDF
                                                        </a><br>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-info" onclick="verDetalhes(<?php echo htmlspecialchars(json_encode($tramitacao)); ?>)">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <?php if ($_SESSION['nivel_acesso'] == 'admin'): ?>
                                                    <button class="btn btn-sm btn-primary" onclick="gerenciarTramitacao(<?php echo htmlspecialchars(json_encode($tramitacao)); ?>)">
                                                        <i class="fas fa-cog"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Nova Solicitação -->
    <div id="modalNova" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Nova Solicitação de Compra</h2>
                <button class="close" onclick="fecharModal('modalNova')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="acao" value="nova_tramitacao">

                <div class="form-group">
                    <label class="form-label">Data da Solicitação *</label>
                    <input type="date" name="data_solicitacao" class="form-input" value="<?php echo date('Y-m-d'); ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Materiais Solicitados *</label>
                    <textarea name="materiais_solicitados" class="form-textarea" required placeholder="Descreva detalhadamente os materiais que precisam ser comprados, incluindo quantidades, especificações técnicas, marcas preferenciais, etc."></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Observações</label>
                    <textarea name="observacoes" class="form-textarea" placeholder="Informações adicionais, justificativas, urgência, etc."></textarea>
                </div>

                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalNova')">Cancelar</button>
                    <button type="submit" class="btn btn-success">Registrar Solicitação</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Detalhes -->
    <div id="modalDetalhes" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Detalhes da Tramitação</h2>
                <button class="close" onclick="fecharModal('modalDetalhes')">&times;</button>
            </div>
            <div id="conteudoDetalhes">
                <!-- Conteúdo será preenchido via JavaScript -->
            </div>
            <div class="d-flex justify-between gap-2">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modalDetalhes')">Fechar</button>
            </div>
        </div>
    </div>

    <!-- Modal Gerenciar Tramitação (Admin) -->
    <?php if ($_SESSION['nivel_acesso'] == 'admin'): ?>
        <div id="modalGerenciar" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Gerenciar Tramitação</h2>
                    <button class="close" onclick="fecharModal('modalGerenciar')">&times;</button>
                </div>

                <!-- Atualizar Status -->
                <div class="card mb-3">
                    <div class="card-header">
                        <h3 class="card-title">Atualizar Status</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="formStatus">
                            <input type="hidden" name="acao" value="atualizar_status">
                            <input type="hidden" name="tramitacao_id" id="gerenciar_tramitacao_id">

                            <div class="form-group">
                                <label class="form-label">Novo Status</label>
                                <select name="status" id="gerenciar_status" class="form-select" required>
                                    <option value="pendente">Pendente</option>
                                    <option value="em_andamento">Em Andamento</option>
                                    <option value="aprovado">Aprovado</option>
                                    <option value="rejeitado">Rejeitado</option>
                                    <option value="finalizado">Finalizado</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary">Atualizar Status</button>
                        </form>
                    </div>
                </div>

                <!-- Upload de Arquivo -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Enviar Arquivo de Resposta</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data" id="formUpload">
                            <input type="hidden" name="acao" value="upload_resposta">
                            <input type="hidden" name="tramitacao_id" id="upload_tramitacao_id">

                            <div class="form-group">
                                <label class="form-label">Arquivo PDF</label>
                                <input type="file" name="arquivo_resposta" class="form-input" accept=".pdf" required>
                                <small class="text-secondary">Apenas arquivos PDF são permitidos.</small>
                            </div>

                            <button type="submit" class="btn btn-success">Enviar Arquivo</button>
                        </form>
                    </div>
                </div>

                <div class="d-flex justify-between gap-2 mt-3">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalGerenciar')">Fechar</button>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <script>
        function abrirModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }

        function fecharModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function verDetalhes(tramitacao) {
            const conteudo = document.getElementById('conteudoDetalhes');

            conteudo.innerHTML = `
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Data da Solicitação</label>
                        <input type="text" class="form-input" value="${formatarData(tramitacao.data_solicitacao)}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <input type="text" class="form-input" value="${tramitacao.status}" readonly>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Solicitante</label>
                        <input type="text" class="form-input" value="${tramitacao.solicitante_nome}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Responsável</label>
                        <input type="text" class="form-input" value="${tramitacao.responsavel_nome || '-'}" readonly>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Materiais Solicitados</label>
                    <textarea class="form-textarea" readonly style="min-height: 120px;">${tramitacao.materiais_solicitados}</textarea>
                </div>
                
                ${tramitacao.observacoes ? `
                <div class="form-group">
                    <label class="form-label">Observações</label>
                    <textarea class="form-textarea" readonly>${tramitacao.observacoes}</textarea>
                </div>
                ` : ''}
                
                ${tramitacao.arquivo_resposta ? `
                <div class="form-group">
                    <label class="form-label">Arquivo de Resposta</label>
                    <div>
                        <a href="uploads/${tramitacao.arquivo_resposta}" target="_blank" class="btn btn-info">
                            <i class="fas fa-file-pdf"></i> Visualizar PDF
                        </a>
                    </div>
                </div>
                ` : ''}
            `;

            abrirModal('modalDetalhes');
        }

        <?php if ($_SESSION['nivel_acesso'] == 'admin'): ?>

            function gerenciarTramitacao(tramitacao) {
                document.getElementById('gerenciar_tramitacao_id').value = tramitacao.id;
                document.getElementById('upload_tramitacao_id').value = tramitacao.id;
                document.getElementById('gerenciar_status').value = tramitacao.status;

                abrirModal('modalGerenciar');
            }
        <?php endif; ?>

        function formatarData(data) {
            const partes = data.split('-');
            return `${partes[2]}/${partes[1]}/${partes[0]}`;
        }

        // Fechar modal clicando fora
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>

    <style>
        .observacao {
            white-space: normal;
            word-break: break-word;
            max-width: 300px;
        }
    </style>
</body>

</html>