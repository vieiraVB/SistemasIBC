<div class="sidebar">
    <div class="sidebar-header">
        <h1>SIGEI - IBC</h1>
        <p><strong>Sistema de Gerenciamento de Equipamentos e Insumos</strong></p>
    </div>
    
    <nav class="sidebar-nav">
        <a href="dashboard.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>
        
        <a href="estoque.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'estoque.php' ? 'active' : ''; ?>">
            <i class="fas fa-boxes"></i>
            Estoque
        </a>
        
        <a href="entrada.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'entrada.php' ? 'active' : ''; ?>">
            <i class="fas fa-arrow-up"></i>
            Entrada de Materiais
        </a>
        
        <a href="saida.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'saida.php' ? 'active' : ''; ?>">
            <i class="fas fa-arrow-down"></i>
            Saída de Materiais
        </a>
        
        <a href="em_falta.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'em_falta.php' ? 'active' : ''; ?>">
            <i class="fas fa-exclamation-triangle"></i>
            Em Falta
        </a>
        
        <a href="patrimonio.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'patrimonio.php' ? 'active' : ''; ?>">
            <i class="fas fa-building"></i>
            Controle Patrimonial
        </a>
        
        <a href="tramitacoes.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'tramitacoes.php' ? 'active' : ''; ?>">
            <i class="fas fa-file-alt"></i>
            Tramitações
        </a>
        
        <?php if ($_SESSION['nivel_acesso'] == 'admin'): ?>
        <a href="usuarios.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'usuarios.php' ? 'active' : ''; ?>">
            <i class="fas fa-users"></i>
            Usuários
        </a>
        <?php endif; ?>
    </nav>
    
    <div class="sidebar-footer">
        <a href="logout.php" class="nav-item">
            <i class="fas fa-sign-out-alt"></i>
            Sair
        </a>
    </div>
</div>

