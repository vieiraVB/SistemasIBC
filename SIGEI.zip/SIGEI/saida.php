<?php
require_once 'config.php';
verificarLogin();

$sucesso = '';
$erro = '';

// Processar ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['acao'])) {
        switch ($_POST['acao']) {
            case 'registrar_saida':
                try {
                    // Verificar se há estoque suficiente
                    $stmt = $pdo->prepare("SELECT quantidade_total FROM materiais WHERE id = ?");
                    $stmt->execute([$_POST['material_id']]);
                    $material = $stmt->fetch();
                    
                    if (!$material) {
                        $erro = "Material não encontrado.";
                    } elseif ($material['quantidade_total'] < $_POST['quantidade']) {
                        $erro = "Estoque insuficiente. Disponível: " . $material['quantidade_total'];
                    } else {
                        $data_saida = converterDataMySQL($_POST['data_saida']);
                        
                        $stmt = $pdo->prepare("INSERT INTO saidas (material_id, quantidade, data_saida, destino, responsavel_entrega, observacoes, usuario_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([
                            $_POST['material_id'],
                            $_POST['quantidade'],
                            $data_saida,
                            $_POST['destino'],
                            $_POST['responsavel_entrega'],
                            $_POST['observacoes'],
                            $_SESSION['usuario_id']
                        ]);
                        
                        $sucesso = "Saída registrada com sucesso!";
                    }
                } catch (PDOException $e) {
                    $erro = "Erro ao registrar saída: " . $e->getMessage();
                }
                break;
                
            case 'marcar_devolucao':
                try {
                    $stmt = $pdo->prepare("UPDATE saidas SET devolvido = 1, data_devolucao = CURRENT_DATE WHERE id = ?");
                    $stmt->execute([$_POST['saida_id']]);
                    
                    $sucesso = "Devolução registrada com sucesso! O estoque foi atualizado automaticamente.";
                } catch (PDOException $e) {
                    $erro = "Erro ao registrar devolução: " . $e->getMessage();
                }
                break;
        }
    }
}

// Buscar materiais ativos com estoque
$stmt = $pdo->query("SELECT id, codigo, nome, unidade_medida, quantidade_total FROM materiais WHERE ativo = 1 AND quantidade_total > 0 ORDER BY nome");
$materiais = $stmt->fetchAll();

// Buscar saídas com filtros
$filtro_data_inicio = isset($_GET['data_inicio']) ? $_GET['data_inicio'] : '';
$filtro_data_fim = isset($_GET['data_fim']) ? $_GET['data_fim'] : '';
$filtro_material = isset($_GET['material']) ? $_GET['material'] : '';
$filtro_devolvido = isset($_GET['devolvido']) ? $_GET['devolvido'] : '';
$busca = isset($_GET['busca']) ? $_GET['busca'] : '';

$sql = "SELECT s.*, m.codigo, m.nome as material_nome, m.unidade_medida, u.nome as usuario_nome
        FROM saidas s
        JOIN materiais m ON s.material_id = m.id
        JOIN usuarios u ON s.usuario_id = u.id
        WHERE 1=1";

$params = [];

if ($filtro_data_inicio) {
    $sql .= " AND s.data_saida >= ?";
    $params[] = converterDataMySQL($filtro_data_inicio);
}

if ($filtro_data_fim) {
    $sql .= " AND s.data_saida <= ?";
    $params[] = converterDataMySQL($filtro_data_fim);
}

if ($filtro_material) {
    $sql .= " AND s.material_id = ?";
    $params[] = $filtro_material;
}

if ($filtro_devolvido !== '') {
    $sql .= " AND s.devolvido = ?";
    $params[] = $filtro_devolvido;
}

if ($busca) {
    $sql .= " AND (m.nome LIKE ? OR m.codigo LIKE ? OR s.destino LIKE ? OR s.responsavel_entrega LIKE ?)";
    $busca_param = '%' . $busca . '%';
    $params[] = $busca_param;
    $params[] = $busca_param;
    $params[] = $busca_param;
    $params[] = $busca_param;
}

$sql .= " ORDER BY s.data_saida DESC, s.data_criacao DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$saidas = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saída de Materiais - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="main-layout">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">Saída de Materiais</h1>
                <p>Registrar e gerenciar saídas de materiais e insumos</p>
            </div>

            <?php if ($sucesso): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($sucesso); ?>
                </div>
            <?php endif; ?>

            <?php if ($erro): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($erro); ?>
                </div>
            <?php endif; ?>

            <!-- Botão registrar saída -->
            <div class="d-flex justify-between align-center mb-3">
                <h2>Registrar Nova Saída</h2>
                <button class="btn btn-warning" onclick="abrirModal('modalSaida')">
                    <i class="fas fa-plus"></i> Nova Saída
                </button>
            </div>

            <!-- Filtros e busca -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Filtros de Busca</h3>
                </div>
                <div class="card-body">
                    <form method="GET" class="form-row">
                        <div class="form-group">
                            <label class="form-label">Buscar</label>
                            <input type="text" name="busca" class="form-input" placeholder="Material, destino, responsável..." value="<?php echo htmlspecialchars($busca); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Material</label>
                            <select name="material" class="form-select">
                                <option value="">Todos os materiais</option>
                                <?php 
                                $stmt_all = $pdo->query("SELECT id, codigo, nome FROM materiais WHERE ativo = 1 ORDER BY nome");
                                $todos_materiais = $stmt_all->fetchAll();
                                foreach ($todos_materiais as $material): 
                                ?>
                                    <option value="<?php echo $material['id']; ?>" <?php echo $filtro_material == $material['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($material['codigo'] . ' - ' . $material['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select name="devolvido" class="form-select">
                                <option value="">Todos</option>
                                <option value="0" <?php echo $filtro_devolvido === '0' ? 'selected' : ''; ?>>Não Devolvido</option>
                                <option value="1" <?php echo $filtro_devolvido === '1' ? 'selected' : ''; ?>>Devolvido</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" class="form-input" value="<?php echo htmlspecialchars($filtro_data_inicio); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" class="form-input" value="<?php echo htmlspecialchars($filtro_data_fim); ?>">
                        </div>
                        
                        <div class="form-group d-flex align-center">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> Buscar
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Histórico de saídas -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Histórico de Saídas</h3>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Material</th>
                                    <th>Quantidade</th>
                                    <th>Destino</th>
                                    <th>Responsável</th>
                                    <th>Status</th>
                                    <th>Usuário</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($saidas)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">Nenhuma saída encontrada.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($saidas as $saida): ?>
                                        <tr>
                                            <td><?php echo formatarData($saida['data_saida']); ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($saida['codigo']); ?></strong><br>
                                                <?php echo htmlspecialchars($saida['material_nome']); ?>
                                            </td>
                                            <td><?php echo number_format($saida['quantidade'], 0, ',', '.') . ' ' . $saida['unidade_medida']; ?></td>
                                            <td><?php echo htmlspecialchars($saida['destino']); ?></td>
                                            <td><?php echo htmlspecialchars($saida['responsavel_entrega']); ?></td>
                                            <td>
                                                <?php if ($saida['devolvido']): ?>
                                                    <span class="badge badge-success">Devolvido</span>
                                                    <?php if ($saida['data_devolucao']): ?>
                                                        <br><small><?php echo formatarData($saida['data_devolucao']); ?></small>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="badge badge-warning">Não Devolvido</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($saida['usuario_nome']); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-info" onclick="verDetalhes(<?php echo htmlspecialchars(json_encode($saida)); ?>)">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <?php if (!$saida['devolvido']): ?>
                                                    <button class="btn btn-sm btn-success" onclick="confirmarDevolucao(<?php echo $saida['id']; ?>, '<?php echo htmlspecialchars($saida['material_nome']); ?>')">
                                                        <i class="fas fa-undo"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Nova Saída -->
    <div id="modalSaida" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Registrar Nova Saída</h2>
                <button class="close" onclick="fecharModal('modalSaida')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="acao" value="registrar_saida">
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Data da Saída *</label>
                        <input type="date" name="data_saida" class="form-input" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Material *</label>
                        <select name="material_id" class="form-select" required onchange="atualizarEstoque()">
                            <option value="">Selecione um material</option>
                            <?php foreach ($materiais as $material): ?>
                                <option value="<?php echo $material['id']; ?>" 
                                        data-unidade="<?php echo $material['unidade_medida']; ?>"
                                        data-estoque="<?php echo $material['quantidade_total']; ?>">
                                    <?php echo htmlspecialchars($material['codigo'] . ' - ' . $material['nome'] . ' (Estoque: ' . $material['quantidade_total'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Quantidade *</label>
                        <input type="number" name="quantidade" class="form-input" min="1" required onchange="validarQuantidade()">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Unidade</label>
                        <input type="text" id="unidade_display_saida" class="form-input" readonly placeholder="Selecione um material">
                    </div>
                </div>
                
                <div id="estoque_info" class="alert alert-info" style="display: none;">
                    <strong>Estoque disponível:</strong> <span id="estoque_disponivel">0</span>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Destino *</label>
                    <input type="text" name="destino" class="form-input" required placeholder="Para onde o material está sendo enviado">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Responsável pela Entrega *</label>
                    <input type="text" name="responsavel_entrega" class="form-input" required placeholder="Quem está entregando o material">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Observações</label>
                    <textarea name="observacoes" class="form-textarea" placeholder="Informações adicionais sobre a saída..."></textarea>
                </div>
                
                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalSaida')">Cancelar</button>
                    <button type="submit" class="btn btn-warning" id="btnRegistrarSaida">Registrar Saída</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Detalhes -->
    <div id="modalDetalhes" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Detalhes da Saída</h2>
                <button class="close" onclick="fecharModal('modalDetalhes')">&times;</button>
            </div>
            <div id="conteudoDetalhes">
                <!-- Conteúdo será preenchido via JavaScript -->
            </div>
            <div class="d-flex justify-between gap-2">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modalDetalhes')">Fechar</button>
            </div>
        </div>
    </div>

    <!-- Modal Confirmar Devolução -->
    <div id="modalDevolucao" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Confirmar Devolução</h2>
                <button class="close" onclick="fecharModal('modalDevolucao')">&times;</button>
            </div>
            <p>Tem certeza que deseja marcar como devolvido o material <strong id="materialDevolucao"></strong>?</p>
            <p class="alert alert-info">O estoque será atualizado automaticamente e um registro de entrada será criado.</p>
            
            <form method="POST" id="formDevolucao">
                <input type="hidden" name="acao" value="marcar_devolucao">
                <input type="hidden" name="saida_id" id="devolucao_saida_id">
                
                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalDevolucao')">Cancelar</button>
                    <button type="submit" class="btn btn-success">Confirmar Devolução</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function abrirModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }

        function fecharModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function atualizarEstoque() {
            const select = document.querySelector('select[name="material_id"]');
            const unidadeDisplay = document.getElementById('unidade_display_saida');
            const estoqueInfo = document.getElementById('estoque_info');
            const estoqueDisponivel = document.getElementById('estoque_disponivel');
            
            if (select.value) {
                const option = select.options[select.selectedIndex];
                const unidade = option.getAttribute('data-unidade');
                const estoque = option.getAttribute('data-estoque');
                
                unidadeDisplay.value = unidade;
                estoqueDisponivel.textContent = estoque + ' ' + unidade;
                estoqueInfo.style.display = 'block';
            } else {
                unidadeDisplay.value = '';
                estoqueInfo.style.display = 'none';
            }
            
            validarQuantidade();
        }

        function validarQuantidade() {
            const select = document.querySelector('select[name="material_id"]');
            const quantidadeInput = document.querySelector('input[name="quantidade"]');
            const btnRegistrar = document.getElementById('btnRegistrarSaida');
            
            if (select.value && quantidadeInput.value) {
                const option = select.options[select.selectedIndex];
                const estoque = parseInt(option.getAttribute('data-estoque'));
                const quantidade = parseInt(quantidadeInput.value);
                
                if (quantidade > estoque) {
                    quantidadeInput.style.borderColor = 'var(--danger-color)';
                    btnRegistrar.disabled = true;
                    btnRegistrar.textContent = 'Estoque Insuficiente';
                } else {
                    quantidadeInput.style.borderColor = 'var(--medium-gray)';
                    btnRegistrar.disabled = false;
                    btnRegistrar.textContent = 'Registrar Saída';
                }
            }
        }

        function verDetalhes(saida) {
            const conteudo = document.getElementById('conteudoDetalhes');
            
            conteudo.innerHTML = `
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Data da Saída</label>
                        <input type="text" class="form-input" value="${formatarData(saida.data_saida)}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Material</label>
                        <input type="text" class="form-input" value="${saida.codigo} - ${saida.material_nome}" readonly>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Quantidade</label>
                        <input type="text" class="form-input" value="${saida.quantidade} ${saida.unidade_medida}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <input type="text" class="form-input" value="${saida.devolvido ? 'Devolvido' : 'Não Devolvido'}" readonly>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Destino</label>
                        <input type="text" class="form-input" value="${saida.destino}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Responsável</label>
                        <input type="text" class="form-input" value="${saida.responsavel_entrega}" readonly>
                    </div>
                </div>
                
                ${saida.devolvido && saida.data_devolucao ? `
                <div class="form-group">
                    <label class="form-label">Data da Devolução</label>
                    <input type="text" class="form-input" value="${formatarData(saida.data_devolucao)}" readonly>
                </div>
                ` : ''}
                
                <div class="form-group">
                    <label class="form-label">Usuário</label>
                    <input type="text" class="form-input" value="${saida.usuario_nome}" readonly>
                </div>
                
                ${saida.observacoes ? `
                <div class="form-group">
                    <label class="form-label">Observações</label>
                    <textarea class="form-textarea" readonly>${saida.observacoes}</textarea>
                </div>
                ` : ''}
            `;
            
            abrirModal('modalDetalhes');
        }

        function confirmarDevolucao(saidaId, materialNome) {
            document.getElementById('devolucao_saida_id').value = saidaId;
            document.getElementById('materialDevolucao').textContent = materialNome;
            abrirModal('modalDevolucao');
        }

        function formatarData(data) {
            const partes = data.split('-');
            return `${partes[2]}/${partes[1]}/${partes[0]}`;
        }

        // Fechar modal clicando fora
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>

