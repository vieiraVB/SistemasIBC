<?php
require_once 'config.php';
verificarLogin();

$sucesso = '';
$erro = '';


// Processar ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['acao'])) {
        switch ($_POST['acao']) {
            case 'registrar_entrada':
                try {
                    if (!isset($_POST['data_entrada'])) {
                        die("Erro: data_entrada não enviada pelo formulário");
                    }
                    $data_entrada = converterDataMySQL($_POST['data_entrada']);
                    var_dump($data_entrada); // para ver o valor exato


                    $stmt = $pdo->prepare("INSERT INTO entradas (material_id, quantidade, data_entrada, responsavel_recebimento, observacoes, numero_nota_fiscal, fornecedor, valor_total, usuario_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $_POST['material_id'],
                        $_POST['quantidade'],
                        $data_entrada,
                        $_POST['responsavel_recebimento'],
                        $_POST['observacoes'],
                        $_POST['numero_nota_fiscal'],
                        $_POST['fornecedor'],
                        $_POST['valor_total'],
                        $_SESSION['usuario_id']
                    ]);

                    $sucesso = "Entrada registrada com sucesso!";
                } catch (PDOException $e) {
                    $erro = "Erro ao registrar entrada: " . $e->getMessage();
                }
                break;
        }
    }
}

// Buscar materiais ativos
$stmt = $pdo->query("SELECT id, codigo, nome, unidade_medida FROM materiais WHERE ativo = 1 ORDER BY nome");
$materiais = $stmt->fetchAll();

// Buscar entradas com filtros
$filtro_data_inicio = isset($_GET['data_inicio']) ? $_GET['data_inicio'] : '';
$filtro_data_fim = isset($_GET['data_fim']) ? $_GET['data_fim'] : '';
$filtro_material = isset($_GET['material']) ? $_GET['material'] : '';
$busca = isset($_GET['busca']) ? $_GET['busca'] : '';

$sql = "SELECT e.*, m.codigo, m.nome as material_nome, m.unidade_medida, u.nome as usuario_nome
        FROM entradas e
        JOIN materiais m ON e.material_id = m.id
        JOIN usuarios u ON e.usuario_id = u.id
        WHERE 1=1";

$params = [];

if ($filtro_data_inicio) {
    $sql .= " AND e.data_entrada >= ?";
    $params[] = converterDataMySQL($filtro_data_inicio);
}

if ($filtro_data_fim) {
    $sql .= " AND e.data_entrada <= ?";
    $params[] = converterDataMySQL($filtro_data_fim);
}

if ($filtro_material) {
    $sql .= " AND e.material_id = ?";
    $params[] = $filtro_material;
}

if ($busca) {
    $sql .= " AND (m.nome LIKE ? OR m.codigo LIKE ? OR e.responsavel_recebimento LIKE ? OR e.fornecedor LIKE ?)";
    $busca_param = '%' . $busca . '%';
    $params[] = $busca_param;
    $params[] = $busca_param;
    $params[] = $busca_param;
    $params[] = $busca_param;
}

$sql .= " ORDER BY e.data_entrada DESC, e.data_criacao DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$entradas = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrada de Materiais - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <div class="main-layout">
        <?php include 'includes/sidebar.php'; ?>

        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">Entrada de Materiais</h1>
                <p>Registrar e gerenciar entradas de materiais e insumos</p>
            </div>

            <?php if ($sucesso): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($sucesso); ?>
                </div>
            <?php endif; ?>

            <?php if ($erro): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($erro); ?>
                </div>
            <?php endif; ?>

            <!-- Botão registrar entrada -->
            <div class="d-flex justify-between align-center mb-3">
                <h2>Registrar Nova Entrada</h2>
                <button class="btn btn-success" onclick="abrirModal('modalEntrada')">
                    <i class="fas fa-plus"></i> Nova Entrada
                </button>
            </div>

            <!-- Filtros e busca -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Filtros de Busca</h3>
                </div>
                <div class="card-body">
                    <form method="GET" class="form-row">
                        <div class="form-group">
                            <label class="form-label">Buscar</label>
                            <input type="text" name="busca" class="form-input" placeholder="Material, responsável, fornecedor..." value="<?php echo htmlspecialchars($busca); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Material</label>
                            <select name="material" class="form-select">
                                <option value="">Todos os materiais</option>
                                <?php foreach ($materiais as $material): ?>
                                    <option value="<?php echo $material['id']; ?>" <?php echo $filtro_material == $material['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($material['codigo'] . ' - ' . $material['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" class="form-input" value="<?php echo htmlspecialchars($filtro_data_inicio); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" class="form-input" value="<?php echo htmlspecialchars($filtro_data_fim); ?>">
                        </div>

                        <div class="form-group d-flex align-center">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> Buscar
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Histórico de entradas -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Histórico de Entradas</h3>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Material</th>
                                    <th>Quantidade</th>
                                    <th>Responsável</th>
                                    <th>Fornecedor</th>
                                    <th>Nota Fiscal</th>
                                    <th>Valor Total</th>
                                    <th>Usuário</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($entradas)): ?>
                                    <tr>
                                        <td colspan="9" class="text-center">Nenhuma entrada encontrada.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($entradas as $entrada): ?>
                                        <tr>
                                            <td><?php echo formatarData($entrada['data_entrada']); ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($entrada['codigo']); ?></strong><br>
                                                <?php echo htmlspecialchars($entrada['material_nome']); ?>
                                            </td>
                                            <td><?php echo number_format($entrada['quantidade'], 0, ',', '.') . ' ' . $entrada['unidade_medida']; ?></td>
                                            <td><?php echo htmlspecialchars($entrada['responsavel_recebimento']); ?></td>
                                            <td><?php echo htmlspecialchars($entrada['fornecedor'] ?? '-'); ?></td>
                                            <td><?php echo htmlspecialchars($entrada['numero_nota_fiscal'] ?? '-'); ?></td>
                                            <td>
                                                <?php if ($entrada['valor_total']): ?>
                                                    R$ <?php echo number_format($entrada['valor_total'], 2, ',', '.'); ?>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($entrada['usuario_nome']); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-info" onclick="verDetalhes(<?php echo htmlspecialchars(json_encode($entrada)); ?>)">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Nova Entrada -->
    <div id="modalEntrada" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Registrar Nova Entrada</h2>
                <button class="close" onclick="fecharModal('modalEntrada')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="acao" value="registrar_entrada">

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Data da Entrada *</label>
                        <input type="date" name="data_entrada" class="form-input" value="<?php echo date('Y-m-d'); ?>" required>

                    </div>

                    <div class="form-group">
                        <label class="form-label">Material *</label>
                        <select name="material_id" class="form-select" required onchange="atualizarUnidade()">
                            <option value="">Selecione um material</option>
                            <?php foreach ($materiais as $material): ?>
                                <option value="<?php echo $material['id']; ?>" data-unidade="<?php echo $material['unidade_medida']; ?>">
                                    <?php echo htmlspecialchars($material['codigo'] . ' - ' . $material['nome']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Quantidade *</label>
                        <input type="number" name="quantidade" class="form-input" min="1" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Unidade</label>
                        <input type="text" id="unidade_display" class="form-input" readonly placeholder="Selecione um material">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Responsável pelo Recebimento *</label>
                    <input type="text" name="responsavel_recebimento" class="form-input" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Fornecedor</label>
                        <input type="text" name="fornecedor" class="form-input">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Número da Nota Fiscal</label>
                        <input type="text" name="numero_nota_fiscal" class="form-input">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Valor Total</label>
                    <input type="number" name="valor_total" class="form-input" step="0.01" min="0">
                </div>

                <div class="form-group">
                    <label class="form-label">Observações</label>
                    <textarea name="observacoes" class="form-textarea" placeholder="Informações adicionais sobre a entrada..."></textarea>
                </div>

                <div class="d-flex justify-between gap-2">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalEntrada')">Cancelar</button>
                    <button type="submit" class="btn btn-success">Registrar Entrada</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Detalhes -->
    <div id="modalDetalhes" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Detalhes da Entrada</h2>
                <button class="close" onclick="fecharModal('modalDetalhes')">&times;</button>
            </div>
            <div id="conteudoDetalhes">
                <!-- Conteúdo será preenchido via JavaScript -->
            </div>
            <div class="d-flex justify-between gap-2">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modalDetalhes')">Fechar</button>
            </div>
        </div>
    </div>

    <script>
        function abrirModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }

        function fecharModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function atualizarUnidade() {
            const select = document.querySelector('select[name="material_id"]');
            const unidadeDisplay = document.getElementById('unidade_display');

            if (select.value) {
                const option = select.options[select.selectedIndex];
                const unidade = option.getAttribute('data-unidade');
                unidadeDisplay.value = unidade;
            } else {
                unidadeDisplay.value = '';
            }
        }

        function verDetalhes(entrada) {
            const conteudo = document.getElementById('conteudoDetalhes');

            conteudo.innerHTML = `
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Data da Entrada</label>
                        <input type="text" class="form-input" value="${formatarData(entrada.data_entrada)}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Material</label>
                        <input type="text" class="form-input" value="${entrada.codigo} - ${entrada.material_nome}" readonly>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Quantidade</label>
                        <input type="text" class="form-input" value="${entrada.quantidade} ${entrada.unidade_medida}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Responsável</label>
                        <input type="text" class="form-input" value="${entrada.responsavel_recebimento}" readonly>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Fornecedor</label>
                        <input type="text" class="form-input" value="${entrada.fornecedor || '-'}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Nota Fiscal</label>
                        <input type="text" class="form-input" value="${entrada.numero_nota_fiscal || '-'}" readonly>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Valor Total</label>
                        <input type="text" class="form-input" value="${entrada.valor_total ? 'R$ ' + parseFloat(entrada.valor_total).toLocaleString('pt-BR', {minimumFractionDigits: 2}) : '-'}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Usuário</label>
                        <input type="text" class="form-input" value="${entrada.usuario_nome}" readonly>
                    </div>
                </div>
                
                ${entrada.observacoes ? `
                <div class="form-group">
                    <label class="form-label">Observações</label>
                    <textarea class="form-textarea" readonly>${entrada.observacoes}</textarea>
                </div>
                ` : ''}
            `;

            abrirModal('modalDetalhes');
        }

        function formatarData(data) {
            const partes = data.split('-');
            return `${partes[2]}/${partes[1]}/${partes[0]}`;
        }

        // Fechar modal clicando fora
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>

</html>